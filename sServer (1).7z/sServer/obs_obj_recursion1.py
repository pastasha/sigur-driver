
import psycopg2
import queue

settings = __import__('settings')

dbconn = psycopg2.connect(settings.ConnectionString)
cursor = dbconn.cursor()

cursor.execute("""
    select id from observed_objects where deletemark = 0
""")

obsObjIds = [row[0] for row in cursor]

g = [None] * (max(obsObjIds) + 1)

for id in obsObjIds:
    g[id] = []
    
cursor.execute("""
    select srcobj, destobj
    from observed_objects_brg
    where deletemark = 0
""")

for srcobj, destobj in cursor:
    g[destobj].append(srcobj)

s = min(obsObjIds)
used = [False] * (max(obsObjIds) + 1)
used[s] = True
q = queue.Queue()
q.put(s)
while not q.empty():
    v = q.get()
    for to in g[v]:
        if not used[to]:
            q.put(to)
