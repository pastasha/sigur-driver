# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$12.04.2011 9:35:07$"

import logging
import time


def binarySearch(arr, count, patt, cmp):
    if count <= 0:
        return None
    a = 0
    b = count - 1

    while True:
        if b - a < 2:
            if cmp(arr[a], patt) == 0:
                return a
            if cmp(arr[b], patt) == 0:
                return b
            return None

        c = (b + a) // 2
        if cmp(arr[c], patt) == 0:
            return c
        if cmp(arr[c], patt) < 0:
            a = c
        else:
            b = c


def upperBound(arr, count, patt, cmp):
    if count <= 0:
        return 0
    a = 0
    b = count - 1

    while True:
        if b - a < 2:
            if cmp(arr[a], patt) >= 0:
                return a
            if cmp(arr[a], patt) < 0 <= cmp(arr[b], patt):
                return b
            if cmp(arr[b], patt) < 0:
                return b + 1

        c = (b + a) // 2
        if cmp(arr[c], patt) < 0:
            a = c
        else:
            b = c


def castToType(typeName, value):
    try:
        if typeName == 'int':
            return int(value)
        if typeName == 'str':
            return str(value)
    except BaseException:
        logging.getLogger('console').info('Cannot cast to %s. Return as is' % typeName)

    return value


def sparceArrayAppend(arr, el, index):
    while len(arr) <= index:
        arr.append(None)
    arr[index] = el
    return arr


def createAttrValuesList(row, fieldList, startIndex):
    attrValues = {}
    for i, key in enumerate(fieldList[startIndex:]):
        attrValues[key] = row[i + startIndex]
    return attrValues


def isInteger(val):
    try:
        int(val)
        return True
    except BaseException:
        return False


def currTime():
    return time.time()


class ConstList(object):
    def __init__(self, L):
        self.__L = L

    def __getitem__(self, key):
        return self.__L[key]

    def __len__(self): return len(self.__L)

    def __iter__(self): return self.__L.__iter__()


def sqlInsertBuilder(tbl, fields, returning=None):
    fieldList = ''
    args = ''
    for field in fields:
        fieldList = '%s,%s' % (fieldList, field)
        args = '%s,%%(%s)s' % (args, field)
    return """
		insert into %(tbl)s(%(fieldList)s)
		values(%(args)s)
		%(returning)s
	""" % {
        'tbl': tbl,
        'fieldList': fieldList[1:],
        'args': args[1:],
        'returning': ('returning %s' % returning) if returning else ''
    }
