# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, index_decorator, Link
import equipment.dev_except as dev_except


class BaseDeviceType(protocol_obj_base):
    OBSOBJTYPE = 'dev'

    def __init__(self):
        super().__init__()
        self.standard_params = {}

    def sendCommand(self, command_name:str='', **kwargs):
        list_update = self.standard_params.copy()
        if kwargs:
            list_update.update(kwargs)
        return self.sendToPorts(command_name, list_update)

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)


class BaseReader(BaseDeviceType):
    OBSOBJTYPE = 'reader'

    def __init__(self):
        super().__init__()

    def readerBlock(self, **kwargs):
        """
        Стандарный вызов команды блокировки считывателя
        :return:
        """
        self._logger.info('readerBlock from base class')

    def readerArm(self, **kwargs):
        """
        Стандарный вызов команды постоновки считывателя на охрану
        :return:
        """
        self._logger.info('readerArm from base class')

    def readerAcceptAlarm(self, **kwargs):
        """
        Стандарный вызов команды принятия тревоги у считывателя
        :return:
        """
        self._logger.info('readerAcceptAlarm from base class')

    def readerDeblock(self, **kwargs):
        """
        Стандарный вызов команды разблокировки считывателя
        :return:
        """
        self._logger.info('readerDeblock from base class')

    def readerDesarm(self, **kwargs):
        """
        Стандарный вызов команды снятия считывателя с охраны
        :return:
        """
        self._logger.info('readerDesarm from base class')


class BaseMonitor(BaseDeviceType):

    OBSOBJTYPE = 'monitor'

    def __init__(self):
        super().__init__()

    def addShow(self, **kwargs):
        """
        Стандарный вызов команды "Добавить камеру на монитор"
        :return:
        """
        self._logger.info('addShow from base class')

    def removeAll(self, **kwargs):
        """
        Стандарный вызов команды "Очистить монитор"
        :return:
        """
        self._logger.info('removeAll from base class')


class BaseOutput(BaseDeviceType):

    OBSOBJTYPE = 'output'

    def __init__(self):
        super().__init__()

    def outputRestore(self, **kwargs):
        """
        Стандарный вызов команды "Восстановить выход"
        :return:
        """
        self._logger.info('outputRestore from base class')

    def outputFast(self, **kwargs):
        """
        Стандарный вызов команды "Заморгать быстро"
        :return:
        """
        self._logger.info('outputFast from base class')

    def outputSlow(self, **kwargs):
        """
        Стандарный вызов команды "Заморгать медленно"
        :return:
        """
        self._logger.info('outputSlow from base class')

    def outputOn(self, **kwargs):
        """
        Стандарный вызов команды "Запитать замок"
        :return:
        """
        self._logger.info('outputOn from base class')

    def startReload(self, **kwargs):
        """
        Стандарный вызов команды "Прогрузить выход в PCE"
        :return:
        """
        self._logger.info('outputRestore from base class')

    def outputOff(self, **kwargs):
        """
        Стандарный вызов команды "Распитать замок"
        :return:
        """
        self._logger.info('outputOff from base class')


class BaseInput(BaseDeviceType):

    OBSOBJTYPE = 'input'

    def __init__(self):
        super().__init__()

    def inputBlock(self, **kwargs):
        """
        Стандарный вызов команды "Блокировать дверь"
        :return:
        """
        self._logger.info('inputBlock from base class')

    def inputArm(self, **kwargs):
        """
        Стандарный вызов команды "Поставить дверь на охрану"
        :return:
        """
        self._logger.info('inputArm from base class')

    def inputAcceptAlarm(self, **kwargs):
        """
        Стандарный вызов команды "Принять тревогу двери"
        :return:
        """
        self._logger.info('inputAcceptAlarm from base class')

    def inputDeblock(self, **kwargs):
        """
        Стандарный вызов команды "Разблокировать дверь"
        :return:
        """
        self._logger.info('inputDeblock from base class')

    def inputDesarm(self, **kwargs):
        """
        Стандарный вызов команды "Снять дверь с охраны"
        :return:
        """
        self._logger.info('inputDesarm from base class')


class BaseCam(BaseDeviceType):

    OBSOBJTYPE = 'cam'

    def __init__(self):
        super().__init__()

    def move(self, **kwargs):
        """
        Стандарный вызов команды "move"
        :param kwargs:
        :return:
        """
        self._logger.info('move from base class')

    def stop(self, **kwargs):
        """
        Стандарный вызов команды "stop"
        :param kwargs:
        :return:
        """
        self._logger.info('stop from base class')

    def rec(self, **kwargs):
        """
        Стандарный вызов команды "Включить запись"
        :param kwargs:
        :return:
        """
        self._logger.info('rec from base class')

    def startCleaning(self, **kwargs):
        """
        Стандарный вызов команды "Включить стеклоочиститель"
        :param kwargs:
        :return:
        """
        self._logger.info('startCleaning from base class')

    def recStop(self, **kwargs):
        """
        Стандарный вызов команды "Выключить запись"
        :param kwargs:
        :return:
        """
        self._logger.info('recStop from base class')

    def rec2(self, **kwargs):
        """
        Стандарный вызов команды "Начать запись"
        :param kwargs:
        :return:
        """
        self._logger.info('rec2 from base class')

    def clearPreset(self, **kwargs):
        """
        Стандарный вызов команды "Очистить пресет"
        :param kwargs:
        :return:
        """
        self._logger.info('clearPreset from base class')

    def goPreset(self, **kwargs):
        """
        Стандарный вызов команды "Перейти в пресет"
        :param kwargs:
        :return:
        """
        self._logger.info('goPreset from base class')

    def showVideo(self, **kwargs):
        """
        Стандарный вызов команды "Показать видео"
        :param kwargs:
        :return:
        """
        self._logger.info('showVideo from base class')

    def arm(self, **kwargs):
        """
        Стандарный вызов команды "Поставить на охрану"
        :param kwargs:
        :return:
        """
        self._logger.info('arm from base class')

    def disarm(self, **kwargs):
        """
        Стандарный вызов команды "Снять с охраны"
        :param kwargs:
        :return:
        """
        self._logger.info('disarm from base class')

    def setPreset(self, **kwargs):
        """
        Стандарный вызов команды "Установить пресет"
        :param kwargs:
        :return:
        """
        self._logger.info('setPreset from base class')




