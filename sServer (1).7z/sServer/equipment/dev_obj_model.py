# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$09.02.2011 10:10:20$"

from xml.dom.minidom import *
from .dev_obj_model_element import *
from .protocol_obj_base import property_wrapper, Attribute, Link
import some_funcs
import time
import string
from . import dev_except
import logging
import inspect
import os

from esmapi.serializer import Serializer
from esmapi.objects.equipmentobject import EquipmentObject
from esmapi.notifications.sServerNotifications import EquipmentObjectDeletedNotification,\
    EquipmentObjectChildAddedNotification, EquipmentObjectChildRemovedNotification,\
    EquipmentObjectLinkChangedNotification, EquipmentObjectCreatedNotification, EquipmentObjectAttrChangedNotification,\
    EquipmentObjectReadOnlyAttrChangedNotification, EquipmentObjectVirtualAttrChangedNotification,\
    EquipmentObjectObsObjAttrChangedNotification


logger = logging.getLogger('sServer')


class Model:
    """Класс для работы с записями таблиц оборудования в объектном стиле"""

    __instances = {}

    def getCurrOperator(self):
        return self.equipment.getCurrOperator()

    def getCurrOperatorSubject(self):
        op = self.equipment.getCurrOperator()
        if not isinstance(op, dict) or 'opSubjId' not in op:
            return None
        if not isinstance(op['opSubjId'], int):
            return None
        if 'common' not in self.__instances:
            return None

        return self.__instances['common'].elementClasses['subject'] \
            .getElementById(op['opSubjId'])

    @classmethod
    def __getExtDevModel(cls, name):
        if name not in cls.__instances:
            return cls.__instances
            # raise dev_except.UndefinedExtEquipCore()
        return cls.__instances[name]

    def __getitem__(self, index):
        return self.__getExtDevModel(index)

    def newMark(self):
        self.equipment.newMark()

    def getMark(self):
        return self.equipment.getMark()

    def __initClassAttrFromCls(self, Element, cls):
        attrs = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Attribute))
        for attr in attrs:
            if attr[1].storeInDb:
                attrName = attr[0]
                Element.attrs[attrName] = {}
                Element.attrs[attrName]['defval'] = attr[1].defval

        links = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Link))
        for link in links:
            if link[1].storeInDb:
                linkName = link[0]
                Element.attrs[linkName] = {}
                cls = link[1].target
                if cls:
                    data = cls.__name__.split('_')
                    Element.attrs[linkName]['target'] = data[1]
                    if data[0] != Element.equipment.name:
                        Element.attrs[linkName]['targetEquip'] = data[0]
                else:
                    # unilink
                    Element.attrs[linkName]['target'] = ''

    def __initClassActionsFromCls(self, Element, cls):
        """зачатки перехода на питоновкие классы вместо хмл"""
        """добавляем публичные функции из класса как экшены"""
        for func in inspect.getmembers(cls, predicate=inspect.ismethod):
            if func[0][:1] != '_':
                args = inspect.signature(func[1]).parameters
                Element.actions[func[0]] = {
                    'type': 'bound',
                    'args': args
                }
        for func in inspect.getmembers(cls, predicate=inspect.isfunction):
            if func[0][:1] != '_':
                args = inspect.signature(func[1]).parameters
                Element.actions[func[0]] = {
                    'type': 'unbound',
                    'args': args
                }

    def __initClassInterfaceFromCls(self, Element, cls):
        def f(x):
            if not (inspect.isfunction(x) or inspect.ismethod(x)):
                return False
            if hasattr(x, 'actionData'):
                return True
            return False

        Element.interface = {
            'alias': getattr(cls, 'alias'),
            'opt': {
                'hidden': getattr(cls, 'hidden'),
                'bridge': cls.__name__.count('_') == 2
            },
            'attrEdits': {},
            'actions': {}
        }

        Element.flags['archive'] = getattr(cls, 'archive')

        Element.brg = 'unique' if getattr(cls, 'uniqueBridge') else ''

        parent = getattr(cls, 'parent')
        if parent:
            Element.parentTypeName = parent.typeName
            Element.parentTblName = Element.equipment.name + '_' + Element.parentTypeName
            Element.parentLink['alias'] = parent.alias
            Element.parentLink['addrAlias'] = parent.addrAlias
            if parent.addr:
                Element.parentLink['gen'] = 'auto_generators.AutoIncrement(%s, %s)' % parent.addr

        fields = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Attribute))

        for field in fields:
            fieldName = field[0]
            if field[1].showInClient:
                Element.exportAttrs.append(fieldName)
                Element.interface["attrEdits"][fieldName] = {
                    'isAttr'		: True,
                    'type'			: field[1].editorType,
                    'alias'			: field[1].alias,
                    'index'			: field[1].index
                }

        fields = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Link))
        for field in fields:
            fieldName = field[0]
            Element.exportLinks.append(fieldName)  # В клиент отправляются все ссылки, но некоторые могут быть скрыты
            Element.interface["attrEdits"][fieldName] = {
                'isLink'		: True,
                'type'			: 'hidden' if not field[1].showInClient else '',
                'alias'			: field[1].alias,
                'index'			: field[1].index,
                'target'		: field[1].target.__name__.split('_')[1] if field[1].target else ''
            }

        actions = inspect.getmembers(cls, predicate=f)
        for action in actions:
            actName = action[0]
            actionData = action[1].actionData
            newAct = {
                'alias': actionData['alias'],
                'class': actionData['class'],
                'params': {}
            }
            signature = inspect.signature(action[1])
            for param, alias in actionData['params'].items():
                parameter = signature.parameters[param]
                annotation = parameter.annotation
                default = parameter.default
                if annotation == parameter.empty or default == parameter.empty:
                    raise Exception('Expected annotation and default for action %s and parameter %s' % (actName, param))
                paramType = 'str'
                newParam = {
                    'alias': alias,
                    'defval': default
                }
                if annotation == int:
                    paramType = 'int'
                elif annotation == str:
                    paramType = 'str'
                elif annotation == float:
                    paramType = 'float'
                elif annotation == datetime.datetime:
                    paramType = 'datetime'
                elif isinstance(annotation, property_wrapper):
                    paramType = 'obj'
                    newParam['typeOpt'] = {
                        'equip': annotation.__name__.split('_')[0],
                        'type': annotation.__name__.split('_')[1]
                    }
                newParam['type'] = paramType
                newAct['params'][param] = newParam
            Element.interface["actions"][actName] = newAct

    def __initClassConstFromCls(self, Element, cls):
        def f(x):
            return not (inspect.ismethod(x) or inspect.isfunction(x) or inspect.isclass(x) or isinstance(x, (Attribute, Link)))

        consts = [x for x in inspect.getmembers(cls, predicate=f) if not x[0].startswith('_')]
        for const in consts:
            # TODO: пока это дикий костыль
            constName = const[0]
            if constName in ('alias', 'parent', 'archive', 'uniqueBridge', 'hidden', 'addrAlias'):
                continue
            if constName == 'obsobjtype':
                constName = '__obsobjtype'
            Element.consts[constName] = {
                'value': const[1]
            }

    def __initClassIndexesFromCls(self, Element, cls):
        def f(x):
            if not inspect.isfunction(x):
                return False
            if hasattr(x, 'indexName'):
                return True
            return False

        # если мост, то создаем индекс bridge
        if Element.interface['opt']['bridge']:
            Element.indexes['bridge'] = {}

        # остальные индексы
        indexes = inspect.getmembers(cls, predicate=f)
        for index in indexes:
            indexName = index[1].indexName
            keyFunc = index[0]
            Element.indexes[indexName] = {
                'keyValue'	 : {},
                'keyFunc'	 : keyFunc,
                'fields'	 : [],
                'fieldParams': {},
                'unique'	 : False
            }

    def __initClassTranslation(self, Element, devType, translationCfg):
        alias = translationCfg.getElementsByTagName(
            'alias')[0].getElementsByTagName('translation')[0].childNodes[0].data
        if alias != 'undefined':
            Element.interface['alias'] = alias
        parent = translationCfg.getElementsByTagName('parent')
        if len(parent) != 0:
            alias = parent[0].getElementsByTagName('translation')[0].childNodes[0].data
            if alias != 'undefined':
                Element.parentLink['alias'] = alias
        for fieldEl in translationCfg.getElementsByTagName('field'):
            fieldName = fieldEl.getAttribute('name')
            alias = fieldEl.getElementsByTagName('translation')[0].childNodes[0].data
            if alias != 'undefined' and fieldName in Element.interface["attrEdits"]:
                Element.interface["attrEdits"][fieldName]['alias'] = alias
            if fieldName in Element.interface["attrEdits"]:
                if Element.interface["attrEdits"][fieldName]['type'].find('enum') == 0:
                    newEnum = []
                    enum = [s.strip() for s in Element.interface["attrEdits"][fieldName]['type'][5:-1].split(',')]
                    typesEl = fieldEl.getElementsByTagName('type')
                    for s in enum:
                        t = s
                        for tEl in typesEl:
                            source = tEl.getElementsByTagName('source')[0].childNodes[0].data
                            trans = tEl.getElementsByTagName('translation')[0].childNodes[0].data
                            if s == source and trans != 'undefined':
                                t = trans
                        newEnum.append(t)
                    Element.interface["attrEdits"][fieldName]['type'] = 'enum(%s)' % ','.join(newEnum)
        for linkEl in translationCfg.getElementsByTagName('link'):
            linkName = linkEl.getAttribute('name')
            alias = linkEl.getElementsByTagName('translation')[0].childNodes[0].data
            if alias != 'undefined' and linkName in Element.interface["attrEdits"]:
                Element.interface["attrEdits"][linkName]['alias'] = alias
        for unilinkEl in translationCfg.getElementsByTagName('unilink'):
            unilinkName = unilinkEl.getAttribute('name')
            alias = unilinkEl.getElementsByTagName('translation')[0].childNodes[0].data
            if alias != 'undefined' and unilinkName in Element.interface["attrEdits"]:
                Element.interface["attrEdits"][unilinkName]['alias'] = alias
        for actionEl in translationCfg.getElementsByTagName('action'):
            actionName = actionEl.getAttribute('name')
            alias = actionEl.getElementsByTagName('translation')[0].childNodes[0].data
            if actionName in Element.interface["actions"]:
                if alias != 'undefined':
                    Element.interface["actions"][actionName]['alias'] = alias
                for paramEl in actionEl.getElementsByTagName('params')[0].getElementsByTagName('param'):
                    paramName = paramEl.getAttribute('name')
                    alias = paramEl.getElementsByTagName('translation')[0].childNodes[0].data
                    if alias != 'undefined' and paramName in Element.interface["actions"][actionName]['params']:
                        Element.interface["actions"][actionName]['params'][paramName]['alias'] = alias

    def mutationReportCreateObject(self, obj):
        statement = EquipmentObjectCreatedNotification.Statement(self.__mutationReportDev(obj),
                                                                 obj.getAttributesForCreateNotif())
        notif = EquipmentObjectCreatedNotification(statement)
        self.__mutationReportPush(notif)

    def mutationReportDeleteObject(self, obj):
        notif = EquipmentObjectDeletedNotification(self.__mutationReportDev(obj))
        self.__mutationReportPush(notif)

    def mutationReportAddChild(self, obj, addr, parentObj):
        statement = EquipmentObjectChildAddedNotification.Statement(self.__mutationReportDev(parentObj),
                                                                    self.__mutationReportDev(obj), addr)
        notif = EquipmentObjectChildAddedNotification(statement)
        self.__mutationReportPush(notif)

    def mutationReportRemoveChild(self, obj, parentObj):
        statement = EquipmentObjectChildRemovedNotification.Statement(self.__mutationReportDev(parentObj),
                                                                      self.__mutationReportDev(obj))
        notif = EquipmentObjectChildRemovedNotification(statement)
        self.__mutationReportPush(notif)

    def mutationReportBindObject(self, linkedObj, linkName, linkOwnerObj):
        statement = EquipmentObjectLinkChangedNotification.Statement(self.__mutationReportDev(linkOwnerObj),
                                                                     self.__mutationReportDev(linkedObj), linkName)
        notif = EquipmentObjectLinkChangedNotification(statement)
        self.__mutationReportPush(notif)

    def mutationReportUnBindObject(self, linkedObj, linkName, linkOwnerObj):
        statement = EquipmentObjectLinkChangedNotification.Statement(self.__mutationReportDev(linkOwnerObj), None,
                                                                     linkName)
        notif = EquipmentObjectLinkChangedNotification(statement)
        self.__mutationReportPush(notif)

    def mutationReportSetAttribute(self, obj, attrName, attrValue, attrSelectValues, attrInDb, attrEditable, isOO,
                                   isOOList):
        equipObj = self.__mutationReportDev(obj)
        # Обычный атрибут
        statement = EquipmentObjectAttrChangedNotification.Statement(equipObj, attrName, attrValue, attrSelectValues)
        notif = EquipmentObjectAttrChangedNotification(statement)
        if not attrEditable and attrInDb:
            # Атрибут есть в БД но его нельзя редактировать из интерфейса
            statement = EquipmentObjectVirtualAttrChangedNotification.Statement(equipObj, attrName, attrValue,
                                                                                attrSelectValues)
            notif = EquipmentObjectVirtualAttrChangedNotification(statement)
        if not attrEditable and not attrInDb:
            # Атрибута нет в БД и его нельзя редактировать
            statement = EquipmentObjectReadOnlyAttrChangedNotification.Statement(equipObj, attrName, attrValue,
                                                                                 attrSelectValues)
            notif = EquipmentObjectReadOnlyAttrChangedNotification(statement)
        if isOO or isOOList:
            # Атрибут содержит объект мониторинга или список объектов
            statement = EquipmentObjectObsObjAttrChangedNotification.Statement(equipObj, attrName, attrValue,
                                                                               attrSelectValues)
            notif = EquipmentObjectObsObjAttrChangedNotification(statement)
        self.__mutationReportPush(notif)

    def __mutationReportDev(self, obj):
        if isinstance(obj, dict):
            # TODO: подозрительно
            return EquipmentObject(obj['equip'], obj['type'], obj['id'], obj['remoteGuid'])
        else:
            return EquipmentObject(obj.equipment.getName(), obj.typeName, obj.getUniID(), obj.getRemoteGUID())

    def __mutationReportPush(self, notification):
        # TODO: временно
        self.equipment.pushToEquipNotificationsQueue(Serializer.serialize(notification))

    def pushEvent(self, event):
        self.equipment.pushToEventQueue(event)

    def __init__(self, equipment, devTypes):
        self.equipment = equipment
        self.__instances[equipment.getName()] = self
        # список классов объектов обращения к БД
        self.elementClasses = {}

        event_packet = __import__('%s_protocol_config.event_packet' % self.equipment.name).event_packet
        self.event_packet = event_packet

        for devType in devTypes:
            name = '_'.join(devType.split('_')[1:])
            _cls = None
            try:
                _module = __import__('%s_protocol_config.%s' % (self.equipment.name, devType))
                _cls = getattr(getattr(_module, devType), devType)
                _cls._core = self
            except ImportError as e:
                logging.getLogger('console').exception('Module import error!')
            except:
                logging.getLogger('console').exception('%s wrapping error!' % devType)

            class Element(BaseElement):
                elements = []
                protocol_object_type = _cls
                elementsGUID = {}
                typeName = ''
                interface = {}
                attrs = {}
                actions = {}
                indexes = {}
                consts = {}
                commands = {}
                flags = {}
                equipment = None
                tblName = ''
                brg = ''
                parentLink = {}
                # Список атрибутов и ссылок в том порядке как они будут отгружаться при экспорте в json
                exportAttrs = []
                exportLinks = []

                def __init__(self, uniId=None, remoteGUID=None,
                             addr=None, parent=None, attrValues=None, calculateAttrs=True, siteId=''):
                    if attrValues is None:
                        attrValues = {}
                    """сначала надо заполнить protocol_py_object, т.к. в конструкторе 
                    BaseElement-а он может использоваться"""
                    if self.protocol_object_type is not None:
                        try:
                            self.protocol_py_object = self.protocol_object_type(self)
                        except Exception as e:
                            logging.getLogger('console').exception('Create pyobject error')
                    else:
                        self.protocol_py_object = None
                    BaseElement.__init__(
                        self, uniId, remoteGUID, siteId, addr, parent, attrValues, calculateAttrs)

            Element.flags = {'archive': False}
            Element.equipment = equipment
            Element.tblName = devType
            Element.typeName = name
            Element.parentLink = {}

            self.__initClassAttrFromCls(Element, _cls)
            self.__initClassActionsFromCls(Element, _cls)
            self.__initClassInterfaceFromCls(Element, _cls)
            self.__initClassConstFromCls(Element, _cls)
            self.__initClassIndexesFromCls(Element, _cls)

            translationCfg = None
            if equipment.translationCfg:
                for tsDevTypeEl in equipment.translationCfg.getElementsByTagName(
                        'equipment')[0].getElementsByTagName('devTypes')[0].getElementsByTagName('devType'):
                    tsName = tsDevTypeEl.getAttribute('name')
                    if tsName == Element.typeName:
                        translationCfg = tsDevTypeEl
                        break

            if translationCfg:
                self.__initClassTranslation(Element, devType, translationCfg)

            self.elementClasses[name] = Element

    def getStruct(self):
        res = {
            'types': {},
            'alias': self.equipment.alias
        }
        for typeName in self.elementClasses:
            res['types'][typeName] = self.elementClasses[typeName].getStruct()
        return res

    def getElementsByIndex(self, typeName, indexName,
                           keyValueDict, keyValue=None):
        if typeName not in self.elementClasses:
            raise dev_except.UndefinedType(typeName)

        return self.elementClasses[typeName] \
            .getElementsByIndex(indexName, keyValueDict, keyValue)

    def getElements(self, typeName):
        if typeName not in self.elementClasses:
            raise dev_except.UndefinedType(typeName)

        return some_funcs.ConstList(self.elementClasses[typeName].elements)

    def getFirst(self, typeName):
        if typeName not in self.elementClasses:
            raise Exception(
                "error while getFirst: undef type '%s'" % typeName
            )

        if len(self.elementClasses[typeName].elements) == 0:
            return None
            # raise dev_except.ElementNotFound(typeName)

        return self.elementClasses[typeName].elements[0]

    def getString(self, string):
        if string in self.equipment.strings:
            return self.equipment.strings[string]
        raise Exception(
            "error while getString: string '%s' not found" %
            string)

    def getElementById(self, typeName, id):
        if typeName not in self.elementClasses:
            raise dev_except.UndefinedType(typeName)

        return self.elementClasses[typeName].getElementById(id)

    def getElementByRemoteGUID(self, typeName, remote_guid):
        if typeName not in self.elementClasses:
            raise dev_except.UndefinedType(typeName)

        return self.elementClasses[typeName].getElementByRemoteGUID(remote_guid)

    def loadElements(self):

        # загружаем локальные копии таблиц
        for typeName in self.elementClasses:
            self.__loadElementListByType(self.elementClasses[typeName])

    def completeStuct(self):
        # Заполнение ссылок на родителя и детей
        for typeName in self.elementClasses:
            for el in self.elementClasses[typeName].elements:
                if el.devParent is not None:
                    # Ищем родителя
                    parentEl = self.elementClasses[el.parentTypeName].getElementById(
                        el.devParent)
                    if parentEl is not None:
                        el.parent = parentEl
                        el.parent.children[el.typeName][el.devAddr] = el
                    else:
                        # если родитель не найден, сбрасываем ссылку
                        # в локальной бд
                        logging.getLogger('console').info('message: element <%s %d> has bad child link to deleted element <%s %d>' %\
                            (el.typeName, el.uniId, el.parentTypeName, el.devParent))
                        el.devAddr = None

                delattr(el, 'devParent')

        # конвертация ссылок
        for typeName in self.elementClasses:
            for el in self.elementClasses[typeName].elements:
                el.convertLinks()

        # настройка мостов
        badElement = []
        for typeName in self.elementClasses:
            if 'bridge' in self.elementClasses[typeName].indexes:
                for el in self.elementClasses[typeName].elements:
                    mainLinkName = el.typeName.split('_')[1]
                    # В случае дальнего моста
                    if 'targetEquip' in el.attrs[mainLinkName] and el.attrs[mainLinkName]['targetEquip'] != '':
                        try:
                            mainLink = el.getRightFarElements(
                                el.attrs[mainLinkName]['targetEquip'],
                                el.attrs[mainLinkName]['target'],
                                mainLinkName)[0]
                            index = "%d@%s#%d" % (
                                el.parent.uniId, typeName, mainLink.uniId)
                            el.indexes['bridge'][index] = el
                            el.ownIndexes['bridge'] = index
                        except Exception as e:
                            logger.exception(e)
                            logging.getLogger('console').info('<%s %s> need to delete' % (el.typeName, str(el.uniId)))
                            badElement.append(el)
                    else:
                        try:
                            mainLink = el.getLinkedElement(mainLinkName)
                            index = "%d@%s#%d" % (
                                el.parent.uniId, typeName, mainLink.uniId)
                            el.indexes['bridge'][index] = el
                            el.ownIndexes['bridge'] = index
                        except Exception as e:
                            logger.exception(e)
                            logging.getLogger('console').info('<%s %s> need to delete' % (el.typeName, str(el.uniId)))
                            badElement.append(el)

        # удаляем битые записи
        for el in badElement:
            el.selfDelete()
            logging.getLogger('console').info('<%s %s> deleted' % (el.typeName, str(el.uniId)))

        # настраиваем индексы
        for typeName in self.elementClasses:
            for el in self.elementClasses[typeName].elements:
                el.loadingCorrectIndexes()

    def calculateAttributes(self):
        # Предрасчитаем все атрибуты для быстрой отдачи в клиент (будут выполнены eval для get каждого атрибута)
        for typeName in self.elementClasses:
            for el in self.elementClasses[typeName].elements:
                el.calculateCache()

    def getInterfaceOfType(self, typeName):
        if not typeName in self.elementClasses:
            raise Exception('undefined type')

        return self.elementClasses[typeName].interface

    def hasChildOfType(self, parentType, childType):
        if hasattr(self.elementClasses[childType], 'parentTypeName') and\
                self.elementClasses[childType].parentTypeName == parentType:
            return True
        return False

    def createElement(self, typeName, createAction=True,
                      attrs=None, siteId='', remote_guid='', ignore_create_objects=False, force=False, info=None):
        if typeName not in self.elementClasses:
            raise Exception('undefined type of element')
        if not attrs:
            attrs = {}

        ElementType = self.elementClasses[typeName]
        if createAction:
            if 'preCreate' in ElementType.actions:
                try:
                    ElementType.doStaticAction('preCreate', params={'createAttrs': attrs, 'info': info})
                except:
                    if not force:
                        raise

        newEl = ElementType(attrValues=attrs, siteId=siteId, remoteGUID=remote_guid)
        newEl.new(createAction, ignore_create_objects)

        return newEl

    def getChildTypes(self, typeName):
        result = []
        for elementClass in self.elementClasses:
            try:
                if self.elementClasses[elementClass].parentTypeName == typeName:
                    result.append(elementClass)
            except BaseException:
                pass
        return result

    def getTypesList(self):
        result = []
        for elementClass in self.elementClasses:
            result.append(elementClass)
        return result

    def deleteElement(self, element):
        element.selfDelete()

    def loadElement(self, typeName, uniId, devAddr, devParent, cache, parent):
        if not typeName in self.elementClasses:
            raise Exception('undefined type of element')

        loadEl = self.elementClasses[typeName](uniId, devAddr, devParent)
        if cache:
            loadEl.cache = cache
        if parent:
            loadEl.cacheParent = parent
        return loadEl

    def __makeFieldList(self, typeObj):
        # uniId всегда существует
        fieldList = ['uniId', 'remote_guid']

        # если возможен родитель, то добавим соответствующие поля
        if hasattr(typeObj, 'parentTypeName'):
            fieldList.append('devAddr')
            fieldList.append('devParent')

        # определяем поля атрибутов
        for attrName in typeObj.attrs:
            if 'target' in typeObj.attrs[attrName] and typeObj.attrs[attrName]['target'] == '':
                fieldList.append(attrName + '_type')
                fieldList.append(attrName + '_id')
            else:
                fieldList.append(attrName)

        return fieldList

    def __loadElementListByType(self, typeObj):
        try:
            fieldList = self.__makeFieldList(typeObj)
            cur = self.equipment.dbConn.cursor()
            sql = """
                select %(fList)s from %(tbl)s
                %(cond)s
                order by uniid
            """ % {
                'fList': ', '.join(fieldList), 'tbl': typeObj.tblName,
                'cond': 'where (flags & 1) = 0' if typeObj.flags['archive'] else ''
            }
            cur.execute(sql)
            for row in cur:
                if hasattr(typeObj, 'parentTypeName'):
                    attrValues = some_funcs.createAttrValuesList(
                        row, fieldList, 4)
                    obj = typeObj(
                        row[0], row[1], row[2], row[3], attrValues, False
                    )
                    typeObj.elements.append(obj)
                    typeObj.elementsGUID[obj.getRemoteGUID()] = obj
                else:
                    attrValues = some_funcs.createAttrValuesList(
                        row, fieldList, 2)
                    obj = typeObj(
                        row[0], row[1], None, None, attrValues, False
                    )
                    typeObj.elements.append(obj)
                    typeObj.elementsGUID[obj.getRemoteGUID()] = obj
        except Exception as e:
            logger.exception(e)
            logging.getLogger('console').exception(repr(e))

    def sql(self, req, params=None):
        cur = self.equipment.dbConn.cursor()
        try:
            if params:
                cur.execute(req, params)
            else:
                cur.execute(req)
        except Exception as e:
            logger.exception(
                'SQL EXECUTE ERROR: \r\nreq %s, \r\nparams %s' %
                (req, params))
        return cur

    def dbCommit(self):
        self.equipment.dbConn.commit()

    def farEquip(self, eqName):
        return self.equipment.getInstance(eqName)
