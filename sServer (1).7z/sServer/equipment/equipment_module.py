# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$07.02.2011 10:44:12$"

from xml.dom.minidom import *
from . import dev_obj_model

from . import auto_generators

from .constants import *

import collections
import threading

from . import dev_except
import os
import sys
from ctypes import *
import json
from pymetalog.pymetalog import PyMetaLog
import logging

settings = __import__('settings')


class EquipmentModule(metaclass=PyMetaLog):
    dbConn = None
    eventQueueDll = None
    license = None
    client_limitations = None

    __currOperator = None
    __transactionFlag = False

    __typeStruct = None
    __markNumber = 1

    # список экзепляров EquipmentModule
    __equipmentList = {}

    @classmethod
    def setCurrOperator(cls, author):
        cls.__currOperator = author

    @classmethod
    def getCurrOperator(cls):
        return cls.__currOperator

    @classmethod
    def newMark(cls):
        cls.__markNumber += 1

    @classmethod
    def getMark(cls):
        return cls.__markNumber

    @classmethod
    def getClientLicenceLimitations(cls):
        return json.dumps(cls.client_limitations)

    @classmethod
    def checkActPermitsCount(cls):
        cur = cls.dbConn.cursor()
        cur.execute("""SELECT COUNT(*) FROM common_permit WHERE state=1""")
        act_permit_count = int(cur.fetchall()[0][0])
        maxcount = cls.license.getActivatePermitsCount()
        if maxcount == -1:
            return True
        if act_permit_count < maxcount:
            return True
        return False

    @classmethod
    def init(cls, license):
        # получение лицензионных ограничений
        try:
            cls.license = license
            cls.client_limitations = license.getClientLimitations()
        except Exception as e:
            logging.getLogger('console').exception('Error license')
            sys.exit('Wrong key')

        cls.equipNotificationsQueue = collections.deque()
        cls.eventQueue = collections.deque()
        if settings.useDllQueue:
            try:
                cls.eventQueueDll = cdll.LoadLibrary('pqueue.dll')
                if cls.eventQueueDll.init(c_int(1), None) == 0:
                    cls.eventQueueDll = None
                    logging.getLogger('console').info('Use RAM query')
                else:
                    logging.getLogger('console').info('Use DLL query')
            except BaseException:
                cls.eventQueueDll = None
                logging.getLogger('console').info('Use RAM query')
        else:
            cls.eventQueueDll = None
            logging.getLogger('console').info('Use RAM query')

    @classmethod
    def getStruct(cls):
        if not cls.__typeStruct:
            cls.__typeStruct = cls.__getStruct()

        return cls.__typeStruct

    @classmethod
    def __getStruct(cls):
        res = {}
        for equipName in cls.__equipmentList:
            res[equipName] = cls.__equipmentList[equipName].devModel.getStruct()

        return res

    @staticmethod
    def setDBConn(dbConn):
        """Указывает для всех модулей подключения оборудования
        базу с реестром оборудования. В реестре оборудования указаны
        имена таблиц оборудования и прочая информация об оборудавание как о
        классе"""

        EquipmentModule.dbConn = dbConn


    @classmethod
    def getInstance(cls, eqName):
        if eqName not in cls.__equipmentList:
            raise Exception("undefined equipment '%s'" % eqName)

        return cls.__equipmentList[eqName]

    @classmethod
    def hasInstance(cls, eqName):
        return eqName in cls.__equipmentList

    @classmethod
    def pushToEventQueue(cls, notif):
        strNotif = json.dumps(notif)
        if cls.eventQueueDll:
            cls.eventQueueDll.push(c_int(1), c_char_p(strNotif.encode()), len(strNotif))
        else:
            cls.eventQueue.append(strNotif)

    @classmethod
    def pushToEquipNotificationsQueue(cls, notif):
        cls.equipNotificationsQueue.append(notif)

    @classmethod
    def beginTransaction(cls):
        # TODO: не прижилось, наверное надо удалить
        if not cls.__transactionFlag:
            cls.__transactionFlag = True
            cls.equipNotificationsQueue.append('BT')

    @classmethod
    def endTransaction(cls):
        # TODO: не прижилось, наверное надо удалить
        if cls.__transactionFlag:
            cls.equipNotificationsQueue.append('ET')
            cls.__transactionFlag = False

    @classmethod
    def eventsIterator(cls):
        if cls.eventQueueDll:
            while True:
                slen = c_long()
                data = cls.eventQueueDll.pop(c_int(1), byref(slen))
                if slen.value == 0:
                    return
                ev = string_at(data, slen.value)
                yield json.loads(ev)  # WTF: обработка ошибок
                cls.eventQueueDll.erase(c_int(1))
        else:
            while cls.eventQueue:
                ev = cls.eventQueue.popleft()
                yield json.loads(ev)  # WTF: обработка ошибок

    @classmethod
    def equipNotificationsIterator(cls):
        #if not cls.__transactionFlag:
        #    if len(cls.equipNotificationsQueue) > 1:
        #        if cls.equipNotificationsQueue[0] == 'BT':
        #            if cls.equipNotificationsQueue[-1] == 'ET':
        #                notifications = []
        #                cls.equipNotificationsQueue.popleft()
        #                while True:
        #                    ev = cls.equipNotificationsQueue.popleft()
        #                    if ev != 'ET':
        #                        notifications.append(ev)
        #                    else:
        #                        break
        #                yield {'notifPack':notifications}
        #                return
            while len (cls.equipNotificationsQueue) > 0:
                ev = cls.equipNotificationsQueue.popleft()
                try:
                    yield ev
                except Exception as e:
                    logging.getLogger('console').info(
                        '----------\n%s\n----------\n%s#####%s\n----------\n%s\n----------' %
                        (e, ev, type(ev), cls.equipNotificationsQueue))
                    logging.getLogger('console').exception(e)
                    raise

    def load(self):
        try:
            self.devModel.loadElements()
            # self.loadRootElements()
        except Exception as e:
            raise

    def completeStuct(self):
        self.devModel.completeStuct()

    def calculateAttributes(self):
        self.devModel.calculateAttributes()

    def __init__(self, equipName, language):
        bundle_dir = ''
        if getattr(sys, 'frozen', False):
            # we are running in a bundle
            bundle_dir = sys._MEIPASS + '/'

        logging.getLogger('console').info('Load driver %s' % equipName)

        protoFilePath = '%s_protocol_config' % equipName
        equip_module = __import__(protoFilePath)

        types = []
        files = os.listdir('%s%s' % (bundle_dir, protoFilePath))
        for file in files:
            if file.startswith(equipName):
                f = file.split('.')[0]
                if f not in types:
                    types.append(f)

        self.name = equipName

        if not hasattr(equip_module, 'alias'):
            raise AttributeError('__init__.py must contain alias variable')
        else:
            self.alias = getattr(equip_module, 'alias')

        if hasattr(equip_module, 'rootDev'):
            self.rootDev = getattr(equip_module, 'rootDev')
        else:
            self.rootDev = None

        self.translationCfg = None
        if language != 'ru':
            translationFile = bundle_dir + protoFilePath + '/' + 'translate_%s.ts' % language
            if os.path.exists(translationFile):
                self.translationCfg = parse(translationFile)
                newAlias = self.translationCfg.getElementsByTagName('equipment')[0].getElementsByTagName(
                    'alias')[0].getElementsByTagName('translation')[0].childNodes[0].data
                if newAlias != 'undefined':
                    self.alias = newAlias
            else:
                logging.getLogger('console').info('Cant find translation file')
        self.__equipmentList[self.name] = self
        # Загрузка объектной модели
        self.devModel = dev_obj_model.Model(self, types)
        # Загрузка строковых констант если они есть
        self.strings = {}
        stringsFiles = bundle_dir + protoFilePath + '/strings.xml'
        if os.path.exists(stringsFiles):
            stringsFile = parse(stringsFiles)
            strings = stringsFile.getElementsByTagName('strings')[0].getElementsByTagName('string')
            for string in strings:
                name = string.getAttribute('name')
                text = string.childNodes[0].data
                self.strings[name] = text
                if self.translationCfg:
                    trStrings = self.translationCfg.getElementsByTagName(
                        'equipment')[0].getElementsByTagName('strings')[0].getElementsByTagName('string')
                    for tsString in trStrings:
                        if tsString.getAttribute('name') == name:
                            tsText = tsString.getElementsByTagName('translation')[0].childNodes[0].data
                            if tsText != 'undefined':
                                self.strings[name] = tsText
        try:
            self.devModel.event_packet.initStrings(self.devModel)
        except AttributeError:
            pass
        except Exception:
            logging.getLogger('console').exception('initStrings error!')

    def getName(self):
        return self.name

    def getElementById(self, typeName, id):
        return self.devModel.getElementById(typeName, id)
