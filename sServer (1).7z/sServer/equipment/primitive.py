# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$17.02.2011 15:03:26$"

import datetime
from functools import reduce


def cast(typeName, value):
    if not typeName:
        return value
    if isinstance(typeName, str):
        if typeName[0:4] == 'uint' or typeName[0:3] == 'int':
            if isinstance(value, str):
                if value[0:2] == '0x':
                    value = int(value[2:], 16)
            return int(value)
        elif typeName == 'boolean':
            return False if value in (
                'false', 'False', 'FALSE', '0', 0, None, '', False) else True
        elif typeName[0:6] == 'string':
            return value
        elif typeName == 'double':
            return float(value)
        elif typeName == 'date':
            if isinstance(value, list) or isinstance(value, tuple):
                return datetime.date(value[0], value[1], value[2])
    else:
        if typeName == int:
            if isinstance(value, str):
                if value[0:2] == '0x':
                    value = int(value[2:], 16)
            return int(value)
        elif typeName == bool:
            return False if value in (
                'false', 'False', 'FALSE', '0', 0, None, '', False) else True
        elif typeName == str:
            return value
        elif typeName == float:
            return float(value)
        elif typeName == datetime.date:
            if isinstance(value, list) or isinstance(value, tuple):
                return datetime.date(value[0], value[1], value[2])

    return value


def bitSet(boolValuesArray):
    boolValuesArray = [(
            '1' if x in (
                'True',
                '1') else '0') if isinstance(
            x,
            str) else x for x in boolValuesArray]

    boolValuesArray.reverse()

    return reduce(lambda x, y: (x << 1) | 1 if y is not None and int(
        y) != 0 else x << 1, boolValuesArray, 0)


def length(val):
    return len(val)


def swap(val):
    return ((val >> 8) & 0xFF) | ((val << 8) & 0xFF00)


def swap4(val):
    return (swap(val >> 16) & 0xFFFF | (swap(val) << 16) & 0xFFFF0000)


def swapBytes(val, bytes):
    revVal = 0
    for i in range(bytes):
        revVal = (revVal << 8) + (val & 0xFF)
        val = val >> 8
    return revVal


def hexFormat(val, len):
    return eval("'%%0%dx'%%%d" % (len * 2, val))
