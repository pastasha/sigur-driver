# -*- coding: utf-8 -*-

from typing import List, Dict, Optional

from licensemanager.licensemanager import License

from .equipment import Equipment


class EquipmentManager(object):
    """
    Класс представляющий менеджер работы с оборудованием. Хранит в себе все оборудование предоставляет к нему доступ.
    """

    def __init__(self, dbConn, language: str, license: License):
        self.__equipments: Dict[str, Equipment] = {}
        self.__dbConn = dbConn
        self.__language = language
        self.__license = license

    def load(self):
        """
        Загружает оборудование в память
        :return:
        """
        package = self.__license.getPackage()
        available_equip = self.__license.getAvailableEquipments()

        cur = self.__dbConn.cursor()
        cur.execute('select name, enabled from equipments order by name')

        for name, enabled in cur:
            # проверяем, общее ли это оборудование или есть ли лицензия на это оборудование или может это демо лицензия
            if name in ('common', 'system', 'gsm') or name in available_equip or package == 'demo':
                if enabled:
                    eq = Equipment(name, self.__language, self, self.__dbConn)
                    eq.load()
                    self.__equipments[name] = eq

        for eqName in self.__equipments:
            self.__equipments[eqName].completeStruct()
            self.__equipments[eqName].calculateAttributes()

    def hasEquipment(self, name) -> bool:
        """
        Проверяет есть ли оборудование с указанным именем
        :param name: имя оборудование для поиска
        :return:
        """
        return name in self.__equipments

    def getEquipmentsNameList(self) -> List[str]:
        """
        Возвращает список имен загруженного оборудования
        :return: список имен оборудований
        """
        return list(self.__equipments.keys())

    def getEquipment(self, name: str) -> Optional[Equipment]:
        """
        Возвращает экземпляр конкретного оборудования
        :param: name: имя оборудования
        :return
        """
        return self.__equipments.get(name)
