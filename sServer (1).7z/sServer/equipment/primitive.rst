primitive module
================

.. automodule:: primitive
    :members:
    :undoc-members:
    :show-inheritance:
