# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$14.02.2011 14:21:57$"

MAX_UINT8 = 2**8 - 1
MAX_UINT16 = 2**16 - 1
MAX_UINT32 = 2**32 - 1
MAX_UINT64 = 2**63 - 1
