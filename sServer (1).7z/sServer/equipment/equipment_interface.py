# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$24.02.2011 15:18:55$"

from . import equipment_module
from equipment.dev_except import *
from . import dev_except

import sys
from pymetalog.pymetalog import PyMetaLog
import logging

settings = __import__('settings')
sys.path.append('locale')
locale = __import__('%s' % settings.language)


def transactionDecorator(func):
    def f(*args, **kwargs):
        try:
            equipment_module.EquipmentModule.beginTransaction()
            return func(*args, **kwargs)
        except Exception as e:
            logging.getLogger('console').error(str(e))
            raise
        finally:
            equipment_module.EquipmentModule.endTransaction()

    return f


class EquipmentInterface(metaclass=PyMetaLog):
    """Предоставляет программный интерфейс модуля оборудования."""

    __instances = {}

    @classmethod
    def init(cls, dbConn, language, license):

        cls.__EquipmentModule = equipment_module.EquipmentModule
        cls.__EquipmentModule.setDBConn(dbConn)
        cls.__EquipmentModule.init(license)

        cur = dbConn.cursor()
        cur.execute("""select name, enabled from equipments order by name""")

        package = license.getPackage()
        available_equip = license.getAvailableEquipments()
        for row in cur:
            eqName = row[0]
            eqEnabled = row[1]
            # проверяем, общее ли это оборудование или есть ли лицензия на это оборудование или может это демо лицензия
            if eqName in ('common', 'system', 'gsm') or eqName in available_equip or package == 'demo':
                # print 'equipment %s enabled : %s' % (eqName, eqEnabled)
                if eqEnabled:
                    cls.__instances[eqName] = cls(eqName, language)
                    cls.__instances[eqName].load()
        for eqName in cls.__instances:
            cls.__instances[eqName].completeStuct()
            cls.__instances[eqName].calculateAttributes()

        cls.__typeStruct = cls.__EquipmentModule.getStruct()

    @classmethod
    def getInstanceNameList(cls):
        "Получаем список EquipmentInterface-ов для всего оборудования"
        res = []
        for eqName in cls.__instances:
            res.append(eqName)
        return res

    @classmethod
    def getInstance(cls, eqName):
        "Получаем объект EquipmentInterface по имени оборудования"
        if eqName not in cls.__instances:
            raise Exception("undefined equipment '%s'" % eqName)

        return cls.__instances[eqName]

    def __init__(self, eqName, language):
        self.__equipment = self.__EquipmentModule(eqName, language)

    def debug_getEquipModel(self): return self.__equipment

    def initAllDev(self):
        for typeName, type_ in self.__equipment.devModel.elementClasses.items():
            # TODO: init теперь есть всегда Проверка не нужна
            if 'init' in type_.actions:
                for el in type_.elements:
                    try:
                        el.doAction('init')
                    except Exception as e:
                        logging.getLogger('console').exception("error while init device <%s:%s>: %s" % (
                            el.typeName, el.getUniID(), str(e)
                        ))
                        logging.getLogger('console').info('----------------------------------------------------------------')

    def finitAllDev(self):
        for type_ in self.__equipment.devModel.elementClasses.values():
            for el in type_.elements:
                el.finit()

    def load(self):
        self.__equipment.load()
        self.__collections = {}
        for typeName in self.__equipment.devModel.getTypesList():
            try:
                self.__collections[typeName] = CollectionOfType(self.__equipment, typeName)
            except Exception as e:
                pass
                # print str(e)

    def completeStuct(self):
        self.__equipment.completeStuct()

    def calculateAttributes(self):
        self.__equipment.calculateAttributes()

    def getElementsByIndex(self, typeName, indexName, keyValueDict, keyValue=None):
        return self.__equipment.devModel.getElementsByIndex(
            typeName, indexName, keyValueDict, keyValue
        )

    def getElementById(self, typeName, id):
        return self.__equipment.devModel.getElementById(typeName, id)

    def getName(self):
        return self.__equipment.getName()

    @classmethod
    def getStruct(cls):
        return cls.__typeStruct

    def getCurrOperatorSubject(self):
        return self.__equipment.devModel.getCurrOperatorSubject()

    def __getDeviceAttributes(self, obj):
        res = {}
        for attrName in obj.attrs:
            if 'target' not in obj.attrs[attrName]:
                res[attrName] = obj.getAttribute(attrName)
            else:
                try:
                    linkedEl = obj.getLinkedElement(attrName)
                    res[attrName] = {
                        'type'		: linkedEl.typeName,
                        'id'		: linkedEl.getUniID()
                    }
                except BaseException:
                    res[attrName] = None

        return res

    def getDeviceAttributes(self, typeName, objId):
        if typeName not in self.__equipment.devModel.elementClasses:
            raise Exception("undefined type name '%s'" % typeName)

        obj = self.__equipment.devModel.getElementById(typeName, objId)
        if not obj:
            raise dev_except.ElementNotFound(typeName, objId)

        return self.__getDeviceAttributes(obj)

    def getDeviceIdListOfType(self, typeName):
        """Возвращает список идентификаторов устройств типа typeName"""

        if typeName not in self.__equipment.devModel.elementClasses:
            raise Exception("undefined type name '%s'" % typeName)

        return [
            obj.getUniID()
            for obj in self.__equipment.devModel.elementClasses[typeName].elements
        ]

    def getDeviceListOfType(self, typeName):
        """
        Возвращает список устройств типа typeName
        """

        if typeName not in self.__equipment.devModel.elementClasses:
            raise Exception("undefined type name '%s'" % typeName)

        return self.__equipment.devModel.elementClasses[typeName].elements

    def getElementByRemoteGUID(self, typeName, remote_guid):
        return self.__equipment.devModel.getElementByRemoteGUID(typeName, remote_guid)

    def newElement(self, typeName, siteId='', remote_guid='', attributes=None,
                   bridges=None, parent=None, ignore_create_objects=False, force=False, info=None):
        """Создает новый элемент указанного типа"""
        attributes = attributes or {}
        bridges = bridges or {}
        parent = parent or {}
        if typeName not in self.__equipment.devModel.elementClasses:
            raise EquipmentException('undefined type %s' % typeName)

        obj = self.__collections[typeName].new(attributes, siteId, remote_guid, ignore_create_objects, force)

        txt = locale.newElementSuccess % (self.__typeStruct[self.getName()]['types'][typeName]['alias'])
        timeout = 2500
        msgType = 'info'

        for bridgeName, array in bridges.items():
            for arrayItem in array:
                itemEquip = arrayItem[0]
                itemType = arrayItem[1]
                itemId = arrayItem[2]
                bridgeInfo = arrayItem[3] if len(arrayItem) > 3 and isinstance(arrayItem[3], dict) else None
                itemAddr = arrayItem[4] if len(arrayItem) > 4 else None
                try:
                    self.__createLink(obj, itemEquip, itemType, itemId, bridgeName, addr=itemAddr, info=bridgeInfo)
                    txt = '%s<br/>%s' % (txt, bridgeInfo['msg']['txt'])
                except Exception as e:
                    msgType = 'warning'
                    timeout = -1
                    txt = "%s<br/>%s '%s': %s" % (
                        txt, locale.newElementAddBridgeError, self.__typeStruct[self.getName()]
                        ['types'][bridgeName]['parent']['alias']
                        if bridgeName in self.__typeStruct[self.getName()]
                        ['types'] else locale.newElementUnknownType,
                        str(e) if isinstance(
                            e, dev_except.EquipmentException) else repr(e)
                    )
        if parent:
            try:
                parentTypeName = parent['type']
                parentId = parent['id']
                num = parent['addr']

                parentInfo = {}
                self.addChild(parentTypeName, parentId, '', typeName, obj.getUniID(), '', num, info=parentInfo)
            except Exception as e:
                msgType = 'warning'
                timeout = -1
                txt = "%s<br/>%s: %s" % (
                    txt, locale.newElementAddParentError, str(e) if isinstance(
                        e, dev_except.EquipmentException) else repr(e)
                )

        # TODO: не круто
        if isinstance(info, dict):
            info['msg'] = {
                'txt'			: txt,
                'timeout'		: timeout,
                'type'			: msgType
            }

        return obj

    #@transactionDecorator
    def delElement(self, typeName, id, remote_guid, info):
        """Удаляет элемент с идентификатором id и типом typeName.
        Это приводит к удаления элемента из системы"""

        if typeName not in self.__equipment.devModel.elementClasses:
            raise EquipmentException("undefined type name '%s'" % typeName)

        if remote_guid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(typeName, remote_guid)
        else:
            obj = self.__equipment.devModel.getElementById(typeName, id)
        if obj is None:
            logging.getLogger('console').warning("Object %s %s %s not found" % (typeName, id, remote_guid))
            return False
        objDescr = self.__getDescription(obj)
        obj.selfDelete()

        # TODO: не круто
        if isinstance(info, dict):
            info['msg'] = {
                'txt'			: locale.delElementSuccess % objDescr,
                'timeout'		: 2500,
                'type'			: 'info'
            }
        return True

    # @transactionDecorator
    def addChild(self, parentTypeName, parentId, parentRemoteGuid,
                     childTypeName, childId, childRemoteGuid, num, info):
        """Добавляет "ребенка"
        parentTypeName - тип родителя
        parentId - идентификатор родителя
        childTypeName - тип ребенка
        childId - идентификатор ребенка
        num - адрес ребенка на родителе (натуральное число)
        """
        if parentRemoteGuid:
            parentEl = self.__collections[parentTypeName].getElByRemoteGUID(parentRemoteGuid)
        else:
            parentIndex = self.__collections[parentTypeName].getElementIndex(parentId)
            parentEl = self.__collections[parentTypeName].getEl(parentIndex)
        if childRemoteGuid:
            childEl = self.__collections[childTypeName].getElByRemoteGUID(childRemoteGuid)
        else:
            childIndex = self.__collections[childTypeName].getElementIndex(childId)
            childEl = self.__collections[childTypeName].getEl(childIndex)
        """Если ребенок и так уже прицеплен к требуемому родителю с требуемым адресом - ничего не делаем"""
        if childEl.parent is not None and childEl.parent == parentEl and childEl.devAddr == num:
            return

        """Собственно добавление ребенка"""
        parentEl.addChild(childEl, num, info=info)

        if isinstance(info, dict):
            # TODO: не круто
            info['msg'] = {
                'txt'			: locale.addChildSuccess % (
                    self.__getDescription(parentEl),
                    self.__getDescription(childEl),
                    childEl.parentLink['alias']
                ),
                'timeout'		: 2500,
                'type'			: 'info'
            }

    #@transactionDecorator
    def bind(self, obj1TypeName, obj1Id, obj1RemoteGuid, obj2EquipName, obj2TypeName,
             obj2Id, obj2RemoteGuid, linkName, force=False, info=None):
        """Инициализирует ссылку на объект2 у объекта1
        (obj1TypeName obj1Id) - тип и идентификатор объекта, у которого
                инициализруется ссылка
        (obj2EquipName, obj2TypeName obj2Id) - оборудование, тип и идентификатор
                объекта, на который инициализруется ссылка
        linkName - имя ссылки"""

        if obj1RemoteGuid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(obj1TypeName, obj1RemoteGuid)
        else:
            obj = self.__equipment.devModel.getElementById(obj1TypeName, obj1Id)
        if not obj:
            raise dev_except.EquipmentException('object %s_%s#%s(%s) not exist' % (
                self.getName(), obj1TypeName, obj1Id, obj1RemoteGuid))
        self.__bind(obj, obj2EquipName, obj2TypeName, obj2Id, obj2RemoteGuid, linkName, force, info)

    def __bind(self, obj, obj2EquipName, obj2TypeName, obj2Id, obj2RemoteGuid, linkName, force=False, info=None):
        if self.__equipment.getName() == obj2EquipName:
            if obj2RemoteGuid:
                obj2 = self.__equipment.devModel.getElementByRemoteGUID(obj2TypeName, obj2RemoteGuid)
            else:
                obj2 = self.__equipment.devModel.getElementById(obj2TypeName, obj2Id)

            if not obj2:
                raise dev_except.EquipmentException('object %s_%s#%s(%s) not exist' % (
                    obj2EquipName, obj2TypeName, obj2Id, obj2RemoteGuid))
            """если ссылка уже заполнена требуемым объектом - нет смысла его снова перепривязывать"""
            try:
                if obj.getLinkedElement(linkName) == obj2:
                    return
            except: pass

            obj.bindElement(linkName, obj2, force=force)

            if isinstance(info, dict):
                info['msg'] = {
                    'txt'		: locale.bindSuccess % (
                        self.__getDescription(obj),
                        self.__getDescription(obj2),
                        obj.interface["attrEdits"][linkName]['alias']
                    ),
                    'timeout'		: 2500,
                    'type'			: 'info'
                }
        else:
            obj.bindFarObject(obj2EquipName, obj2TypeName, obj2Id, obj2RemoteGuid, linkName)

    def getDescription(self, typeName, objId, objRemoteGuid=''):
        if objRemoteGuid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(typeName, objRemoteGuid)
        else:
            obj = self.__equipment.devModel.getElementById(typeName, objId)
        return self.__getDescription(obj)

    def __getDescription(self, obj):
        if 'description' not in obj.interface['attrEdits']:
            return '<%s#%s>' % (obj.interface['alias'], obj.getUniID())

        return obj.calcAttr('description')

    # @transactionDecorator
    def unBind(self, objTypeName, objId, objRemoteGuid, linkName, info):
        """Инициализирует ссылку у объекта
        (objTypeName objId) - тип и идентификатор объекта, у которого
                инициализруется ссылка
        linkName - имя ссылки"""
        if objRemoteGuid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(objTypeName, objRemoteGuid)
        else:
            obj = self.__equipment.devModel.getElementById(objTypeName, objId)

        obj.unBindElement(linkName)

        if isinstance(info, dict):
            info['msg'] = {
                'txt'			: locale.unBindSuccess % (
                    self.__typeStruct[self.__equipment.getName()]
                    ['types'][obj.typeName]['links']
                    [linkName]['alias'],
                    self.__getDescription(obj)
                ),
                'timeout'		: 2500,
                'type'			: 'info'
            }

    #@transactionDecorator
    def createLink(self, obj1TypeName, obj1Id, obj2EquipName, obj2TypeName, obj2Id,
                   linkName, linkInfo=None, addr=None, info=None):
        """Создает направленную мостовую связь между двумя объектами
        (obj1TypeName, obj1Id) - объект1
        (obj2EquipName, obj2TypeName, obj2Id) - объект2
        linkName - имя ссылки
        linkInfo - атрибуты объекта связи. Представляет собой ассоциативный
                массив пар имя-значение. Если атрибут является ссылкой, то в качестве
                значения указывается ассоциативный массив с ключами type и id, где
                type - тип объекта ссылки, id - идентификатор объекта ссылки.
                Набор атрибутов объекта связи зависит от типа объекта связи.
        addr - адрес объекта связи на первом объекте. Создаваемый объект связи
                является ребенком первого объекта и имеет ссылку на второй объект.
                В зависимости от типа объекта связи адрес может указываться, либо
                генерируется автоматически
        """
        obj1Index = self.__collections[obj1TypeName].getElementIndex(obj1Id)
        obj1 = self.__collections[obj1TypeName].getEl(obj1Index)

        self.__createLink(
            obj1, obj2EquipName, obj2TypeName, obj2Id, linkName, linkInfo, addr, info
        )

    def __createLink(self, obj1, obj2EquipName, obj2TypeName, obj2Id,
                     linkName, linkInfo=None, addr=None, info=None):

        if linkInfo is None:
            linkInfo = {}

        obj2Equipment = self if obj2EquipName == self.getName() else self.getInstance(obj2EquipName)
        obj2Index = obj2Equipment.__collections[obj2TypeName].getElementIndex(obj2Id)
        obj2 = obj2Equipment.__collections[obj2TypeName].getEl(obj2Index)
        obj1.checkLink(linkName, obj2)
        # print "createLink %s %s %s %s %s %s %s"%(linkName, obj2.getUniID(),
        # infoDict, addr, addObjArray, info, obj1.getUniID())
        obj1.createLink(linkName, obj2, linkInfo, addr, info=info)

        if isinstance(info, dict):
            info['msg'] = {
                'txt'			: locale.createLinkSuccess % (
                    obj2Equipment.__getDescription(obj2),
                    self.__getDescription(obj1),
                    self.__typeStruct[self.getName()]
                    ['types'][linkName]['parent']['alias']
                ),
                'timeout'		: 2500,
                'type'			: 'info'
            }

    def deleteLink(self, obj1TypeName, obj1Id, obj2TypeName, obj2Id, linkName):
        """Удаляет мостовой объект связи тип linkName,
        соединяющий объект1(obj1TypeName, obj1Id) и
        объект2(obj2TypeName, obj2Id)
        """
        try:
            obj1Index = self.__collections[obj1TypeName].getElementIndex(
                obj1Id)
            obj2Index = self.__collections[obj2TypeName].getElementIndex(
                obj2Id)
            obj1 = self.__collections[obj1TypeName].getEl(obj1Index)
            obj2 = self.__collections[obj2TypeName].getEl(obj2Index)

            obj1.deleteLink(linkName, obj2)

        except Exception as e:
            raise Exception('error while interface deleteLink: ' + str(e))

    #@transactionDecorator
    def leaveParent(self, objTypeName, objId, remote_guid, info):
        """Отделяет ребенка(childTypeName, childId) от
        родителя(parentTypeName, parentId)"""
        if remote_guid:
            obj = self.__collections[objTypeName].getElByRemoteGUID(remote_guid)
        else:
            objIndex = self.__collections[objTypeName].getElementIndex(objId)
            obj = self.__collections[objTypeName].getEl(objIndex)

        parent = obj.parent

        obj.leaveParent()

        if isinstance(info, dict):
            info['msg'] = {
                'txt'			: locale.removeChildSuccess % (
                    self.__getDescription(obj),
                    obj.parentLink['alias'],
                    self.__getDescription(parent) if parent else ''
                ),
                'timeout'		: 2500,
                'type'			: 'info'
            }

    #@transactionDecorator
    def setAttr(self, typeName, id, remote_guid, fieldName, values, force, info):
        """Устанавливает атрибут с именем fieldName у элемента типа typeName и
        идентификатором id"""
        if typeName not in self.__equipment.devModel.elementClasses:
            raise EquipmentException("undefined type name '%s'" % typeName)

        if remote_guid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(typeName, remote_guid)
        else:
            obj = self.__equipment.devModel.getElementById(typeName, id)
        if not obj.hasEditableField(fieldName) and not force:
            raise NoEditableField(
                locale.setAttrReadOnlyError % obj.interface["attrEdits"][fieldName]['alias']
            )
        """Меняем значение атрибута только если оно изменилось - чтобы не плодить нотификации"""
        try:
            if obj.getAttribute(fieldName) == values:
                return
        except: pass
        self.__setAttr(obj, fieldName, values, info)

    def __setAttr(self, obj, fieldName, values, info):
        obj.setAttr(fieldName, values)

        if isinstance(info, dict):
            # TODO: не круто
            info['msg'] = {
                'txt'			: locale.setAttrSuccess % (obj.interface["attrEdits"][fieldName]['alias'],
                                                            self.__getDescription(obj)),
                'timeout'		: 2500,
                'type'			: 'info'
            }

    def doAction(self, typeName, id, actName, params=None):
        if params is None:
            params = {}
        index = self.__collections[typeName].getElementIndex(id)
        obj = self.__collections[typeName].getEl(index)

        if actName not in obj.interface["actions"]:
            raise Exception(
                "element [type=%s id=%s] has not action '%s'" % (
                    obj.typeName, obj.uniId, actName
                )
            )

        localParams = {}
        for par in params:
            if isinstance(params[par], dict) and \
                    'type' in params[par] and 'id' in params[par]:
                localParams[par] = self.__collections[params[par]['type']]\
                    .getElById(params[par]['id'])
            else:
                localParams[par] = params[par]

        return obj.doAction(actName, localParams)

    #@transactionDecorator
    def execAction(self, typeName, id, remote_guid, actName,
                   params=None, currOperator=None):
        # TODO: похоже что параметр currOperator не используется
        if currOperator:
            logging.getLogger('console').info("currOperator", currOperator)
            self.__EquipmentModule.setCurrOperator(currOperator)
        if params is None:
            params = {}
        objType = self.__equipment.devModel.elementClasses[typeName]
        if remote_guid:
            obj = self.__equipment.devModel.getElementByRemoteGUID(typeName, remote_guid)
        else:
            obj = self.__equipment.devModel.getElementById(typeName, id) if id else None
        if actName not in objType.interface["actions"]:
            raise Exception("element [type=%s] has not action '%s'" % (objType.typeName, actName))

        paramList = objType.interface['actions'][actName]['params']
        localParams = {}
        for param in paramList:
            if paramList[param]['type'][0:3] == 'obj':
                if param in params and \
                        'type' in params[param] and 'id' in params[param]:
                    '''self.__equipment.devModel для того, чтобы можно было получать объекты из другого оборудования'''
                    localParams[param] = self.__equipment.devModel[params[param]['equip']].getElementById(
                        params[param]['type'], params[param]['id'])
                else:
                    localParams[param] = None
            else:
                if param in params:
                    localParams[param] = params[param]
                else:
                    localParams[param] = paramList[param]['defval']

        if 'hostName' in params:
            localParams['hostName'] = params['hostName']

        if obj:
            return obj.doAction(actName, localParams)

        return objType.doStaticAction(actName, localParams)

    def execSysAction(self, typeName, id, actName, params=None):
        if params is None:
            params = {}
        obj = self.__equipment.devModel.getElementById(typeName, id)

        return obj.doAction(actName, params)

    def export(self, typeName, index):
        return self.__equipment.devModel.elementClasses[typeName].export(index)

    def getElements(self, typeName):
        return self.__equipment.devModel.getElements(typeName)


class CollectionOfType:
    def __init__(self, eq, typeName):
        self.__equipment = eq
        self.__typeName = typeName
        self.interface = self.__equipment.devModel.getInterfaceOfType(typeName)
        #if self.interface['opt']['bridge']:
        #    raise Exception(
        #        "Bridge type '%s'. Collection not create" %
        #        typeName)
        self.__elements = self.__equipment.devModel.elementClasses[typeName].elements
        self.__elementsGUID = self.__equipment.devModel.elementClasses[typeName].elementsGUID

    def getDeviceIdList(self):
        res = []
        for el in self.__elements:
            res.append(el.getUniID())

        return res

    def getEl(self, index):
        return self.__elements[int(index)]

    def getElById(self, id):
        return self.getEl(self.getElementIndex(id))

    def getElByRemoteGUID(self, remote_guid):
        return self.__elementsGUID[remote_guid]

    def getElementIndex(self, id):
        index = self.__equipment.devModel.elementClasses[self.__typeName].getElementIndexById(id)
        if index is None:
            raise Exception("element <%s %s> not found" % (self.__typeName, str(id)))
        return index

    def new(self, attrib, siteId='', remote_guid='', ignore_create_objects=False, force=False):
        res = self.__equipment.devModel.createElement(self.__typeName, attrs=attrib, siteId=siteId,
                                                      remote_guid=remote_guid,
                                                      ignore_create_objects=ignore_create_objects, force=force)
        return res
