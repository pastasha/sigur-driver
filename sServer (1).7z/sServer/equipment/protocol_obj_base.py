# -*- coding: utf-8 -*-

import logging
import datetime
import inspect
from typing import Optional, Callable, Union


class ParentStruct(object):
    __slots__ = ['typeName', 'alias', 'addr', 'addrAlias']

    def __init__(self, typeName, alias, addr=None, addrAlias=None):
        super(ParentStruct, self).__init__()
        self.typeName = typeName
        self.alias = alias
        self.addr = addr
        self.addrAlias = addrAlias


class property_wrapper(type):
    def __call__(cls, object, *args, **kwds):
        inst = type.__call__(cls, *args, **kwds)
        inst._obj = object
        return inst

    def __new__(mcs, clsname, bases, attrs, alias='', parent=None, archive=False, uniqueBridge=False, hidden=False):
        instance = super(property_wrapper, mcs).__new__(mcs, clsname, bases, attrs)

        if clsname != 'protocol_obj_base':
            instance.alias = alias
            instance.parent = parent
            instance.archive = archive
            instance.uniqueBridge = uniqueBridge
            instance.hidden = hidden

        return instance


def index_decorator(name):
    """
    Декоратор для помечания методов класса, как методов рассчитывающих индекс.
    :param name: Имя индекса
    :return:
    """
    def wrapper(func):
        func.indexName = name
        return func
    return wrapper


def action_decorator(alias:str, actionClass:str='', **kwargs):
    """
    Декоратор помечающий метод класса, как действие, которое будет выгружено в клиент
    :param alias: Русское название действия дл отображения в клиенте
    :param actionClass: Класс действия (static|fastCall)
    :param kwargs: Описание русских названий параметров
    :return:
    """
    def wrapper(func):
        func.actionData = {
            'alias': alias,
            'class': actionClass,
            'params': kwargs
        }
        return func
    return wrapper


class Attribute(object):
    """
    Дескриптор для описания поля-атрибута в интерфейсе класса оборудования
    """
    __slots__ = ['alias', 'defval', 'fieldType', 'fget', 'fset', 'preAction', 'postAction', 'readOnly', 'storeInDb',
                 'index', 'editorType', 'showInClient', '__name']
    validTypes = Union[int, str, datetime.date, bool, float]

    def __init__(self, alias: str, fieldType: Optional[validTypes]=None, defval: Optional[validTypes]=None,
                 fget: Optional[Callable]=None, fset: Optional[Callable]=None, preAction: Optional[Callable]=None,
                 postAction: Optional[Callable]=None, readOnly: bool=False, storeInDb: bool=True, index: int=0,
                 editorType: str='str', showInClient: bool=True):
        """
        :param alias: Псевдоним типа (русское имя)
        :param fieldType: Тип колонки в БД (int|str|date|bool)
        :param defval: Значение по умолчанию
        :param fget: Функция для получения ссылки, отличная от стандартного поведения
        :param fset: Функция для установки ссылки, отличная от стандартного поведения
        :param preAction: Функция, которая будет вызвана перед установкой ссылки
        :param postAction: Функция, которая будет вызвана после установки ссылки
        :param readOnly: Ссылка только для чтения (не может быть утановлена из клиента)
        :param storeInDb: Ссылка сохраняется в БД (а не живет только пока запущен сервер)
        :param index: Порядковый номер отображения атрибута в клиенте
        :param editorType: Тип редактора атрибута
        :param showInClient: Должен ли атрибут выгружаться в клиент
        """
        self.alias = alias
        self.defval = defval
        self.fieldType = fieldType
        self.fget = fget if fget else self.defaultGet
        self.fset = fset if fset else self.defaultSet
        self.preAction = preAction
        self.postAction = postAction
        self.readOnly = readOnly
        self.storeInDb = storeInDb
        self.index = index
        self.editorType = editorType
        self.showInClient = showInClient

        self.__name = None

        fgetArgs = inspect.signature(self.fget).parameters
        if 'field' not in fgetArgs:
            raise AttributeError('fget for %s attribute must have field parameter' % alias)
        fsetArgs = inspect.signature(self.fset).parameters
        if 'field' not in fsetArgs or 'value' not in fsetArgs:
            raise AttributeError('fset for %s attribute must have field and value parameters' % alias)
        if self.preAction:
            preActionArgs = inspect.signature(self.preAction).parameters
            if not (('field' in preActionArgs and 'value' in preActionArgs) or 'kwargs' in preActionArgs):
                raise AttributeError(
                    'preAction for %s attribute must have field and value or kwargs parameters' % alias)
        if self.postAction:
            postActionArgs = inspect.signature(self.postAction).parameters
            if not (('oldValue' in postActionArgs and 'oldValues' in postActionArgs) or 'kwargs' in postActionArgs):
                raise AttributeError(
                    'postAction for %s attribute must have oldValue and oldValues or kwargs parameters' % alias)
        if self.storeInDb and not self.fieldType:
            raise AttributeError('Attribute %s must have fieldType' % alias)
        if self.storeInDb and not self.defval is not None:
            raise AttributeError('Attribute %s must have defval' % alias)

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return self.fget(obj, field=self.__name)

    def __set__(self, obj, value):
        self.fset(obj, value=value, field=self.__name)

    def defaultGet(self, obj, field=None):
        # Грязный хак, но пока ничего лучше мы не придумали
        return obj._obj._BaseElement__attrValues[self.__name]  # У BaseElement есть __attrValues оттуда и читаем

    def defaultSet(self, obj, value, field=None):
        obj._obj.setAttribute(self.__name, value)

    def __set_name__(self, cls, name):
        self.__name = name


class Link(object):
    """
    Дескриптор для описания поля-ссылки в интерфейсе класса оборудования
    """
    __slots__ = ['alias', 'target', 'fget', 'fset', 'preAction', 'postAction', 'readOnly', 'storeInDb', 'index',
                 'showInClient', '__name']

    def __init__(self, alias: str, target: Optional[type], fget: Optional[Callable]=None,
                 fset: Optional[Callable]=None, preAction: Optional[Callable]=None, postAction: Optional[Callable]=None,
                 readOnly:bool=False, storeInDb:bool=True, index:int=0, showInClient:bool=True):
        """
        :param alias: Псевдоним типа (русское имя)
        :param target: Тип на который указывает ссылка
        :param fget: Функция для получения ссылки, отличная от стандартного поведения
        :param fset: Функция для установки ссылки, отличная от стандартного поведения
        :param preAction: Функция, которая будет вызвана перед установкой ссылки
        :param postAction: Функция, которая будет вызвана после установки ссылки
        :param readOnly: Ссылка только для чтения (не может быть утановлена из клиента)
        :param storeInDb: Ссылка сохраняется в БД (а не живет только пока запущен сервер)
        :param index: Порядковый номер отображения ссылки в клиенте
        :param showInClient: Должна ли ссылка показываться в клиенте
        """
        self.alias = alias
        self.target = target
        self.fget = fget if fget else self.__defaultGet
        self.fset = fset if fset else self.__defaultSet
        self.preAction = preAction
        self.postAction = postAction
        self.readOnly = readOnly
        self.storeInDb = storeInDb
        self.index = index
        self.showInClient = showInClient

        self.__name = None

        fgetArgs = inspect.signature(self.fget).parameters
        if 'field' not in fgetArgs:
            raise AttributeError('fget for %s link must have field parameter' % alias)
        fsetArgs = inspect.signature(self.fset).parameters
        if 'field' not in fsetArgs or 'value' not in fsetArgs:
            raise AttributeError('fset for %s link must have field and value parameters' % alias)
        if self.preAction:
            preActionArgs = inspect.signature(self.preAction).parameters
            if not ('targetObj' in preActionArgs or 'kwargs' in preActionArgs):
                raise AttributeError('preAction for %s link must have targetObj or kwargs parameters' % alias)
        if self.postAction:
            postActionArgs = inspect.signature(self.postAction).parameters
            if not ('targetObj' in postActionArgs or 'kwargs' in postActionArgs):
                raise AttributeError('postAction for %s link must have targetObj or kwargs parameters' % alias)

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return self.fget(obj, field=self.__name)

    def __set__(self, obj, value):
        self.fset(obj, value=value, field=self.__name)

    def __defaultGet(self, obj, field):
        # Грязный хак, но пока ничего лучше мы не придумали
        return obj._obj._BaseElement__attrValues[self.__name]  # У BaseElement есть __attrValues оттуда и читаем

    def __defaultSet(self, obj, value, field):
        if value:
            obj._obj.bindElement(self.__name, value)
        else:
            obj._obj.unBindElement(self.__name)

    def __set_name__(self, cls, name):
        self.__name = name


class protocol_obj_base(object, metaclass=property_wrapper):
    _core = None
    _obj = None
    _logger = logging.getLogger('console')

    def __init__(self):
        self.__in_recursion = False

    def __getattr__(self, item):
        #if self.__in_recursion:
        #    self._logger.exception('Object don\'t contain attr %s' % item)
        #    raise AttributeError("protocol_obj_base instance has no attribute '%s'" % item)
        #self.__in_recursion = True
        if not item.startswith("_") and item in dir(self._obj):
            attr = getattr(self._obj, item)
        else:
            attr = getattr(self, item)
        #self.__in_recursion = False
        return attr

    def __getitem__(self, item):
        return self._obj[item]

    def __setitem__(self, key, value):
        self._obj[key] = value

    def __contains__(self, key):
        return key in self._obj

    def init(self):
        pass

    def finit(self):
        self._logger.info('finit from base class')

    def onEvent(self, event=None, portsEvent=None):
        self._logger.info('onEvent from base class')

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        cls._logger.info('preCreate from base class')

    def postCreate(self, ignore_create_objects=False):
        self._logger.info('postCreate from base class')

    def preDelete(self, deleteAsLink=False):
        """
        :param deleteAsLink: нужна для удаления объекта мостовой связи, передается в delAction параметром,
        используется только в Apollo и руками трогать не нужно
        :return:
        """
        self._logger.info('preDelete from base class')

    @classmethod
    def postDelete(cls, **kwargs):
        cls._logger.info('postDelete from base class')

    def preChangeParent(self, newParent=None, addr=None, info=None):
        self._logger.info('preChangeParent from base class')

    def postChangeParent(self, oldParent=None, info=None):
        self._logger.info('postChangeParent from base class')
