
import inspect
from typing import Dict, List, Any, Type

from . import equipment
from .protocol_obj_base import protocol_obj_base, Attribute, Link


class EquipmentType(object):
    """
    Класс представляющий собой один тип оборудования.
    """

    def __init__(self, fullName, equip: 'equipment.Equipment', dbConn):
        self.__name = '_'.join(fullName.split('_')[1:])
        self.__equipment = equip
        self.__dbConn = dbConn

        self.__event_packet = __import__('%s_protocol_config.event_packet' % self.__equipment.getName()).event_packet
        module = __import__('%s_protocol_config.%s' % (self.__equipment.getName(), fullName))
        self.__typeClass: Type[protocol_obj_base] = getattr(getattr(module, fullName), fullName)

        self.__idIndex: Dict[int, protocol_obj_base] = {}
        self.__remoteGuidIndex: Dict[str, protocol_obj_base] = {}

    def load(self):
        """
        Загружает объекты данного типа из БД во внутреннюю память
        :return:
        """
        fieldList = self.__makeFieldList()
        cur = self.__dbConn.cursor()
        sql = """
            select %(fList)s from %(tbl)s
            %(cond)s
            order by uniid
        """ % {
            'fList': ', '.join(fieldList),
            'tbl': '%s_%s' % (self.__equipment.getName(), self.__name),
            'cond': 'where (flags & 1) = 0' if self.__typeClass.archive else ''
        }
        cur.execute(sql)
        for row in cur:
            if self.__typeClass.parent:
                attrValues = self.__createAttrValuesList(row, fieldList, 4)
                obj = self.__typeClass(uniid=row[0], remoteGuid=row[1], devParent=row[2], devAddress=row[3],
                                       attrValues=attrValues)
            else:
                attrValues = self.__createAttrValuesList(row, fieldList, 2)
                obj = self.__typeClass(uniid=row[0], remoteGuid=row[1], devParent=None, devAddress=None,
                                       attrValues=attrValues)
            self.__idIndex[row[0]] = obj
            self.__idIndex[row[1]] = obj

    def completeStruct(self):
        pass

    def __makeFieldList(self) -> List[str]:
        """
        Формирует список столбцов, которые нужно получить из БД для инициализации объектов данного типа
        """
        # uniid и remote_guid всегда существует
        fieldList = ['uniid', 'remote_guid']

        # если возможен родитель, то добавим соответствующие поля
        if self.__typeClass.parent:
            fieldList.append('devparent')
            fieldList.append('devaddr')

        # определяем поля атрибутов
        attrs = inspect.getmembers(self.__typeClass, predicate=lambda x: isinstance(x, Attribute))
        for attr in attrs:
            if attr[1].storeInDb:
                fieldList.append(attr[0])

        links = inspect.getmembers(self.__typeClass, predicate=lambda x: isinstance(x, Link))
        for link in links:
            if link[1].storeInDb:
                cls = link[1].target
                if cls:
                    # Обычная ссылка
                    fieldList.append(link[0])
                else:
                    # Универсальная ссылка
                    fieldList.append(link[0] + '_type')
                    fieldList.append(link[0] + '_id')

        return fieldList

    def __createAttrValuesList(self, row: List[Any], fieldList: List[str], startIndex: int) -> Dict[str, Any]:
        """
        Формирует словарь с значениями атрибутов объектов оборудования на основании названий атрибутов и данных из БД
        :param row: строка с данными из базы
        :param fieldList: список имен атрибутов в порядке как в строке с данными
        :param startIndex: сколько элементов от начала надо пропустить
        :return:
        """
        attrValues = {}
        for i, key in enumerate(fieldList[startIndex:]):
            attrValues[key] = row[i + startIndex]
        return attrValues
