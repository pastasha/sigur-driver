# -*- coding: utf-8 -*-
import json
import jsonpickle
from jsonobject import *

class ExternalData(object):

    def __init__(self, id_obj:str, guid_root:str, name:str):
        self.name = name
        self.id_obj_subsustems = id_obj
        self.guid_root = guid_root

    def to_json(self):
        return jsonpickle.encode(self)

class ExternalDataPermit(ExternalData):
    def __init__(self, status:bool, **kwargs):
        super().__init__(**kwargs)
        self.status = status


