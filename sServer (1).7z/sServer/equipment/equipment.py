# -*- coding: utf-8 -*-

import logging
import os
import sys

from xml.dom.minidom import *

from typing import Dict

from . import equipment_manager
from .equipment_type import EquipmentType


class Equipment(object):
    """
    Класс представляющий собой конкретное оборудование. Хранит в себе составляющие типы и предоставляет к ним доступ.
    """

    def __init__(self, name: str, language: str, manager: 'equipment_manager.EquipmentManager', dbConn):
        self.__name = name
        self.__language = language
        self.__manager = manager
        self.__dbConn = dbConn

        self.__alias = ''
        self.__rootDev = None
        self.__translationCfg = None

        self.__types: Dict[str, EquipmentType] = {}

        self.protoFilePath = '%s_protocol_config' % self.__name
        self.bundle_dir = ''
        if getattr(sys, 'frozen', False):
            # запускаемс из сборки
            self.bundle_dir = sys._MEIPASS + '/'

        logging.getLogger('console').info('Load driver %s' % self.__name)

        equip_module = __import__(self.protoFilePath)

        if not hasattr(equip_module, 'alias'):
            raise AttributeError('__init__.py must contain alias variable')
        else:
            self.__alias = getattr(equip_module, 'alias')

        if hasattr(equip_module, 'rootDev'):
            self.__rootDev = getattr(equip_module, 'rootDev')

        self.__initTranslation()
        self.__initStrings()
        self.__initTypes()

    def __initTranslation(self):
        """
        Инициализирует перевод оборудования
        :return:
        """
        if self.__language != 'ru':
            translationFile = '%s%s/translate_%s.ts' % (self.bundle_dir, self.protoFilePath, self.__language)
            if os.path.exists(translationFile):
                self.__translationCfg = parse(translationFile)
                newAlias = self.__translationCfg.getElementsByTagName('equipment')[0].getElementsByTagName(
                    'alias')[0].getElementsByTagName('translation')[0].childNodes[0].data
                if newAlias != 'undefined':
                    self.__alias = newAlias
            else:
                logging.getLogger('console').info('Cant find translation file')

    def __initStrings(self):
        """
        Загружает строковые константы оборудования из файла strings.xml
        :return:
        """
        self.strings = {}
        stringsFiles = '%s%s/strings.xml' % (self.bundle_dir, self.protoFilePath)
        if os.path.exists(stringsFiles):
            stringsFile = parse(stringsFiles)
            strings = stringsFile.getElementsByTagName('strings')[0].getElementsByTagName('string')
            for string in strings:
                name = string.getAttribute('name')
                text = string.childNodes[0].data
                self.strings[name] = text
                if self.__translationCfg:
                    trStrings = self.__translationCfg.getElementsByTagName(
                        'equipment')[0].getElementsByTagName('strings')[0].getElementsByTagName('string')
                    for tsString in trStrings:
                        if tsString.getAttribute('name') == name:
                            tsText = tsString.getElementsByTagName('translation')[0].childNodes[0].data
                            if tsText != 'undefined':
                                self.strings[name] = tsText

    def __initTypes(self):
        """
        Создает типы оборудования
        :return:
        """
        types = []
        files = os.listdir(self.protoFilePath)
        for file in files:
            if file.startswith(self.__name):
                f = file.split('.')[0]
                if f not in types:
                    types.append(f)
        for equipmentType in types:
            self.__types[equipmentType] = EquipmentType(equipmentType, self, self.__dbConn)

        try:
            self.devModel.event_packet.initStrings(self.devModel)
        except BaseException:
            pass

    def getName(self) -> str:
        """
        Возвращает имя оборудования
        :return:
        """
        return self.__name

    def load(self):
        """
        Загружает объекты оборудования из БД во внутреннюю память
        :return:
        """
        for typeName, typeObj in self.__types.items():
            typeObj.load()

    def completeStruct(self):
        """
        Инициализирует структуру оборудования. Проставляет ссылки, считает индексы и так далее
        :return:
        """
        for typeName, typeObj in self.__types.items():
            typeObj.completeStruct()

    def calculateAttributes(self):
        pass
