equipment\_module module
========================

.. automodule:: equipment_module
    :members:
    :undoc-members:
    :show-inheritance:
