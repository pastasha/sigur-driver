# -*- coding: utf-8 -*-

from esmapi.commands.sServerCommands import CreateEquipmentObjectCommand, DeleteEquipmentObjectCommand, \
    SetEquipmentObjectLinkCommand, AddEquipmentObjectChildCommand, LeaveEquipmentObjectParentCommand, \
    CreateEquipmentObjectBridgeCommand
from esmapi.no_auth_command_sender import NoAuthCommandSender
from esmapi.objects.equipmentobject import EquipmentObject
from esmapi.auth_command_sender import AuthCommandSender


class MethodsForTesting:

    def __init__(self):
        self.cmdSender = NoAuthCommandSender('localhost', 5562)
        self.dict_equipment = {}
        self.list_equipment = []
        self.dict_common_equipment = {}
        self.equipment_name = 'common'

    def create_and_delete_equipments(self):
        for equipment in self.list_equipment:
            try:
                print(equipment['name'])
                reqData = CreateEquipmentObjectCommand.ReqData(self.equipment_name, equipment['name'],
                                                               attributes=equipment['attributes'])
                cmd = CreateEquipmentObjectCommand(reqData)
                reply = self.cmdSender.send(cmd)
                print(reply)
                newId = reply['repData']['newId']
                cmd = DeleteEquipmentObjectCommand(EquipmentObject(self.equipment_name, equipment['name'], newId))
                reply = self.cmdSender.send(cmd)
                print(reply)
            except Exception as e:
                print(e)
            self.dict_equipment.update({equipment['name']: equipment})


    def delete_childr__equipments(self, parentObj):
        print('Удаление родителя у ребенка %s' % parentObj.type)
        cmd = LeaveEquipmentObjectParentCommand(parentObj)
        reply = self.cmdSender.send(cmd)
        print(reply)

    def add_childr_equipments(self, parentObj, childObj):
        print('Добавление ребенка %s к родителю %s' % (childObj.type, parentObj.type))
        reqData = AddEquipmentObjectChildCommand.ReqData(parentObj, childObj, 1)
        cmd = AddEquipmentObjectChildCommand(reqData)
        reply = self.cmdSender.send(cmd)
        print(reply)

    def delete_equipments(self, equipments):
        print('Удаление объекта %s' % equipments.type)
        cmd = DeleteEquipmentObjectCommand(equipments)
        reply = self.cmdSender.send(cmd)
        print(reply)

    def get_reqData(self, name_equipments):
        print(name_equipments)

        equipment = self.dict_equipment[name_equipments]
        reqData = CreateEquipmentObjectCommand.ReqData(self.equipment_name, equipment['name'],
                                                       attributes=equipment['attributes'])
        cmd = CreateEquipmentObjectCommand(reqData)
        reply = self.cmdSender.send(cmd)
        return EquipmentObject(self.equipment_name, equipment['name'], reply['repData']['newId'])

    def set_link(self, obj, linkedObj, linkName):
        print('Установка ссылки %s объекта %s на объект %s' %(linkName, obj.type, linkedObj.type))
        ReqData_link = SetEquipmentObjectLinkCommand.ReqData(obj, linkedObj, linkName)
        link_obj = SetEquipmentObjectLinkCommand(ReqData_link)
        print(self.cmdSender.send(link_obj))

    def set_bribge(self, obj, linkedObj, linkName):
        # print(obj, linkName)
        ReqData_bribge = CreateEquipmentObjectBridgeCommand.ReqData(obj, linkedObj, linkName)
        bribge_obj = CreateEquipmentObjectBridgeCommand(ReqData_bribge)
        print(self.cmdSender.send(bribge_obj))
