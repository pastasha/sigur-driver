# -*- coding: utf-8 -*-

import base64
import json
import uuid

settings = __import__('settings')
photoDir = settings.photoPath


def save_subj_photo(obj, photo):
    """
    Сохраняет фотографию
    :param obj:
    :param photo: фото в base64
    :return: возвращает название созданой фотографии
    """
    try:
        page = base64.b64decode(photo)
        photoName = str(uuid.uuid1())
        file = open('%s/{%s}.jpg' % (photoDir, photoName), mode='wb')  # b is important -> binary
        file.write(page)
        file.close()
        return photoName
    except Exception as e:
        obj._logger.exception('Cant load photo, error: %s' % repr(e))
        return None


def set_photo_to_obj(obj, photo, attr_name='photo'):
    """
    Привязывает фотографию к субъекту
    :param photo:
    :param obj:
    :param attr_name:
    :return:
    """
    filename = save_subj_photo(obj, photo)
    if filename is not None:
        obj.setAttribute(attr_name, "{" + filename + "}")


def get_subj_photo(photo_name):
    """
    :param photo_name:
    :return: Возвращает фотографию объекта в base64
    """
    if photo_name == '':
        return ''
    fileContent = b''
    try:
        with open('%s\\%s.jpg' % (photoDir, photo_name), mode='rb') as file:  # b is important -> binary
            fileContent = file.read()
    finally:
        return base64.b64encode(fileContent).decode()


def save_subsystem_ids(obj, uid, system_type):
    """
    Сохранение subsystem_ids у объекта
    :param system_type: название сторонней системы
    :param uid: индентификатор в строней системе
    :param obj: объек, у кторого нужно сохранить
    :return:
    """
    result = {system_type: uid}
    subsystem_ids = json.loads(obj.getAttribute('subsystem_ids'))
    subsystem_ids.update(result)
    obj.setAttr('subsystem_ids', json.dumps(subsystem_ids))


def delete_subsystem_id(obj, system_tyoe):
    subsystem_ids_dict = json.loads(obj.getAttribute('subsystem_ids'))
    del subsystem_ids_dict[system_tyoe]
    obj.setAttr('subsystem_ids', json.dumps(subsystem_ids_dict))


def get_subsystem_ids(obj, system_type):
    subsystem_ids = json.loads(obj.getAttribute('subsystem_ids'))
    return subsystem_ids.get(system_type)


def get_child_by_search_dict(parent_device, type_name, search_dict):
    """
    Метод для проверки, есть ли у родителя "parent_device" ребенок типа "type_name_list"
    с адресом "addr"
    :param parent_device: объект родителя
    :param type_name: тип ребенка
    :param search_dict: dict в котором храниться данные для поиск
    :return:
    """
    if search_dict.get('type', 'address') == 'address':
        try:
            return parent_device.getChildByAddr(type_name, search_dict.get('address', 1))
        except:
            return None
    elif search_dict.get('type') == 'index':
        device_list = search_dict.get('core').getElementsByIndex(
            type_name, search_dict.get('index_name', 'id'), None, keyValue=search_dict.get('key_value'))
        if len(device_list) > 0:
            for device_list_id in device_list:
                dev = device_list[device_list_id]
                if not dev.hasParent():
                    parent_device.addChild(dev)
                return dev
        else:
            return None


def save_attribute_for_device(device_type, attr_dict, search_dict, parent_device=None):
    try:
        device_esm = get_child_by_search_dict(parent_device, device_type, search_dict)
        if device_esm is None:
            device_esm = search_dict.get('core').createElement(device_type, attrs=attr_dict)
            if parent_device:
                parent_device.addChild(device_esm)
        else:
            for attr in attr_dict:
                device_esm.setAttribute(attr, attr_dict[attr])
        return device_esm
    except Exception as e:
        print(e)


def get_event_dict(time_event, dev_event, code_event):
    return {
        'notification': {
            'code': code_event,
        },
        'statement': {
            'adverbialTime': {
                'param': time_event
            },
            'directObj': {
                'dev': {
                    'equip': dev_event.getEquipName(),
                    'type': dev_event.getTypeName(),
                    'id': dev_event.getUniID()
                }
            }
        }
    }




