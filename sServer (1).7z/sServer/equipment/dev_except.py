# -*- coding: utf-8 -*-

import sys

settings = __import__('settings')
sys.path.append('locale')
locale = __import__('%s' % settings.language)


class EquipmentException(Exception):
    pass


class UndefinedExtEquipCore(EquipmentException):
    pass


class UndefinedLinkField(EquipmentException):
    def __init__(self, linkName, obj=None):
        self.__linkName = linkName
        self.__obj = obj

    def __str__(self):
        return "undefined link '%s'%s" % (
            self.__linkName,
            ' of <%s#%s>' % (self.__obj.typeName, self.__obj.getUniID())
        )


class UndefinedAction(EquipmentException):
    def __init__(self, txt=locale.undefinedActionExceptionText):
        EquipmentException.__init__(self, txt)


class WrongLinkTargetType(EquipmentException):
    def __init__(self, txt):
        EquipmentException.__init__(self, txt)


class WrongChildType(EquipmentException):
    def __init__(self, txt='wrong child type'):
        EquipmentException.__init__(self, txt)


class UndefinedAttrField(EquipmentException):
    def __init__(self, attrName, obj=None):
        self.__attrName = attrName
        self.__obj = obj

    def __str__(self):
        return "undefined attr '%s'%s" % (
            self.__attrName,
            ' of <%s#%s>' % (self.__obj.typeName, self.__obj.getUniID())
        )


class UndefinedType(EquipmentException):
    def __init__(self, typeName='?'):
        self.__typeName = typeName

    def __str__(self):
        return "Undefined type '%s'" % self.__typeName


class ElementNotFound(EquipmentException):
    def __init__(self, typeName='?', id='?'):
        self.__typeName = typeName
        self.__id = id

    def __str__(self):
        return "Cannot found element <%s#%s>" % (self.__typeName, self.__id)

    def element(self):
        return {'type': self.__typeName, 'id': self.__id}

    def elementStr(self):
        el = self.element()
        if el['type'] == '?' and el['id'] == '?':
            return ''
        return '<%s#%s>' % (el['type'], el['id'])


class LinkedElementNotFound(ElementNotFound):
    def __init__(self, linkName, typeName='?', id='?'):
        ElementNotFound.__init__(self, typeName, id)
        self.__linkName = linkName

    def __str__(self):
        s = self.elementStr()
        return "Cannot found linked by '%s' element %s" % (
            self.__linkName, s if s else ''
        )


class ParentNotFound(ElementNotFound):
    def __init__(self, typeName='?', id='?'):
        ElementNotFound.__init__(self, typeName, id)

    def __str__(self):
        s = self.elementStr()
        return "Element %s has not parent" % (s if s else '')


class DifferentParent(EquipmentException):
    pass


class BridgeElementNotFound(ElementNotFound):
    def __init__(self, linkName,
                 typeName='?', id='?', targType='?', targId='?',
                 ownerDescr=None, arrDescr=None):
        ElementNotFound.__init__(self, typeName, id)
        self.__linkName = linkName
        self.__targType = targType
        self.__targId = targId
        self.__ownerDescr = ownerDescr
        self.__arrDescr = arrDescr

    def __unicode__(self):
        if self.__ownerDescr and self.__arrDescr:
            return locale.bridgeElementNotFoundExceptionText % (
                self.__ownerDescr, self.__arrDescr
            )
        else:
            return '%s' % str(self)

    def __str__(self):
        s = self.elementStr()
        return "Cannot found bridge '%s'%s" % (
            self.__linkName,
            " %s -> <%s#%s>" % (
                self.elementStr(), self.__targType, self.__targId
            )
        )


class ChildNotFound(ElementNotFound):
    def __init__(self, addr, typeName='?', id='?'):
        ElementNotFound.__init__(self, typeName, id)
        self.__addr = addr

    def __str__(self):
        s = self.elementStr()
        return "Element %s has not child [%d]" % (s if s else '', self.__addr)


class TerminateAction(EquipmentException):
    def __init__(self, txt=locale.terminateActionExceptionText):
        EquipmentException.__init__(self, txt)


class PostActionFail(EquipmentException):
    def __init__(self, txt="post action fail"):
        EquipmentException.__init__(self, txt)


class NeedAnswers(EquipmentException):
    def __init__(self, form):
        EquipmentException.__init__(self)
        self.__form = form

    def getForm(self): return self.__form


class PortNotFound(EquipmentException):
    def __init__(self, txt=locale.portNotFoundExceptionText):
        EquipmentException.__init__(self, txt)


class CommandExecError(EquipmentException):
    def __init__(self, txt=locale.commandExecErrorExceptionText):
        EquipmentException.__init__(self, txt)


class CommandExecError2(EquipmentException):
    def __init__(self, txt=locale.commandExecErrorExceptionText):
        EquipmentException.__init__(self, txt)


class NoEditableField(EquipmentException):
    def __init__(self, txt=locale.noEditableFieldExceptionText):
        EquipmentException.__init__(self, txt)


class BridgeMustBeUnique(EquipmentException):
    def __init__(self, linkAddr):
        self.__linkAddr = linkAddr

    def __str__(self):
        return locale.bridgeMustBeUniqueExceptionText % self.__linkAddr


class HandlerCompileError(EquipmentException):
    def __init__(self, txt=locale.handlerCompileErrorExceptionText):
        EquipmentException.__init__(self, txt)
