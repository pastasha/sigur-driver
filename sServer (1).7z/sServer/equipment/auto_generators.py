# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$14.02.2011 12:16:13$"


class AutoIncrement:
    def __init__(self, lowBound, highBound):
        self.__lowBound = int(lowBound)
        self.__highBound = int(highBound)

    def next(self, curr):
        return int(curr) + \
            1 if int(curr) < self.__highBound else self.__lowBound

    def first(self):
        return self.__lowBound
