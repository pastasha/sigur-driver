dev\_except module
==================

.. automodule:: dev_except
    :members:
    :undoc-members:
    :show-inheritance:
