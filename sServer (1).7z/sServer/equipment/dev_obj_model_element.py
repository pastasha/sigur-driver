# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.
import jsonpickle

__author__ = "ananev"
__date__ = "$06.04.2011 17:22:44$"

import json
import datetime
import sys

import types
import uuid
from . import external_data
import ipaddress

from . import primitive
from . import auto_generators
from . import constants
import some_funcs

from . import dev_except
import event_monitor.plugin_except as plgnExcept
import event_monitor.plugin_support as plgn

from pymetalog.pymetalog import PyMetaLog
import logging
import warnings
import sys
settings = __import__('settings')
sys.path.append('locale')
locale = __import__('%s' % settings.language)


class BaseElement:
    # __metaclass__ = PyMetaLog

    @staticmethod
    def __cmp(el, patt):
        if int(el.uniId) == int(patt):
            return 0
        if int(el.uniId) < int(patt):
            return -1
        return 1

    @classmethod
    def getElementIndexById(cl, id):
        if id is None:
            return None
        return some_funcs.binarySearch(
            cl.elements, len(cl.elements), id, cl.__cmp)

    @classmethod
    def getElementById(cl, id):
        index = cl.getElementIndexById(id)
        if index is None:
            return None
        return cl.elements[index]

    @classmethod
    def getElementByRemoteGUID(cl, remote_guid):
        if remote_guid not in cl.elementsGUID:
            return None
        return cl.elementsGUID[remote_guid]

    @classmethod
    def getStruct(cl):
        typeInfo = {
            'alias'			: cl.interface['alias'],
            'brg'			: True if cl.interface['opt']['bridge'] else False,
            'hidden'		: True if cl.interface['opt']['hidden'] else False,
            'parent'		: {
                'type'			: cl.parentTypeName,
                'alias'			: cl.parentLink['alias'],
                'reqAddr'		: False if 'gen' in cl.parentLink else True,
                'addrAlias'		: cl.parentLink['addrAlias']() if cl.parentLink['addrAlias'] else None,
                'index'			: cl.parentLink['index']
                if 'index' in cl.parentLink else 0
            } if hasattr(cl, 'parentTypeName') else None,
            'attrs'			: {},
            'links'			: {},
            'actions'		: cl.interface['actions']
            if 'actions' in cl.interface else {},
            'consts'		: cl.consts
        }
        for attrName in cl.interface['attrEdits']:
            if 'target' in cl.interface['attrEdits'][attrName]:
                targetEquip = cl.attrs[attrName].get('targetEquip', '')
                # TODO: дикий костыль но пока по другому быстро не получается. Нужен чтобы в клиент не попадали
                #  дальные ссылки на выключенное оборудование
                if targetEquip and targetEquip not in cl.equipment.devModel['...']:
                    continue
                typeInfo['links'][attrName] = {
                    'alias'			: cl.interface['attrEdits'][attrName]['alias'],
                    'type'			: cl.interface['attrEdits'][attrName]['type'],
                    'index'			: cl.interface['attrEdits'][attrName]['index']
                }
                if attrName in cl.attrs:
                    typeInfo['links'][attrName]['target'] = {
                        'type': cl.attrs[attrName]['target'],
                        'equip': cl.attrs[attrName].get('targetEquip', cl.equipment.name)
                    }
                else:
                    typeInfo['links'][attrName]['target'] = cl.interface['attrEdits'][attrName]['target']
                continue

            attrType = cl.interface['attrEdits'][attrName]['type']
            typeOpt = None
            if attrType[0:10] == 'treeSelect':
                typeOpt = cl.__doAction(attrType[11:-1])
                attrType = 'treeSelect'
            if attrType[0:17] == 'dynamicTreeSelect':
                attrType = 'dynamicTreeSelect'
            if attrType[0:11] == 'multiSelect':
                typeOpt = cl.__doAction(attrType[12:-1])
                attrType = 'multiSelect'

            typeInfo['attrs'][attrName] = {
                'alias'			: cl.interface['attrEdits'][attrName]['alias'],
                'type'			: attrType,
                'index'			: cl.interface['attrEdits'][attrName]['index']
            }
            if typeOpt:
                typeInfo['attrs'][attrName]['typeOpt'] = typeOpt

        return typeInfo

    @classmethod
    def export(cls, index):
        res = {'fields': []}
        data = []

        res['fields'].extend(cls.exportAttrs)
        res['fields'].extend(cls.exportLinks)

        elements = cls.elements
        if index:
            indexName = index[0]
            indexKeyValue = index[1]
            try:
                elements = iter(cls.getElementsByIndex(indexName, None, indexKeyValue).values())
            except BaseException:
                elements = []
        else:
            if 'cache' in cls.indexes:
                try:
                    elements = iter(cls.getFilteredElements('cache').values())
                except BaseException:
                    elements = []

        class BaseElementList(list):
            def __init__(self, elements):
                self.__elements = elements

            def __iter__(self):
                for el in self.__elements:
                    yield el.getJson()

            def __len__(self):
                return 1

        res['data'] = BaseElementList(elements)
        return res

    def getJson(self):
        return self.__json

    def getCurrOperatorSubject(self):
        return self.equipment.devModel.getCurrOperatorSubject()

    def getDescription(self):
        """
        Либо поле description, либо тип объекта склеенный с uniID

        :return: строковое название объекта
        """
        if 'description' in self.interface['attrEdits']:
            return self.calcAttr('description')

        return '%s#%s' % (self.interface['alias'], self.getUniID())

    def __init__(self, uniId=None, remoteGUID=None, siteId='',
                 addr=None, parent=None, attrValues=None, calculateAttrs=True):
        if attrValues is None:
            attrValues = {}
        self.uniId = uniId
        self.remoteGUID = remoteGUID
        self.siteId = siteId
        if self.uniId:
            self.uniId = int(self.uniId)
        if self.remoteGUID:
            if not self.siteId:
                self.siteId = '.'.join(self.remoteGUID.split('.')[1:])

        self.devParent = parent

        self.parent = None
        self.devAddr = addr

        # Инициализируем списки детей всех элементов всех типов
        self.children = {}
        for childTypeName in self.equipment.devModel.getChildTypes(
                self.typeName):
            self.children[childTypeName] = {}

        # Хранилище всех обратных ссылок
        self.backLinks = {}

        self.ownIndexes = {}

        # Инициализируем атрибуты и ссылки значениями по умолчанию
        # (в случае нового элемента),
        # либо значениями, загруженными из БД
        self.__initAttrValues(attrValues)
        if calculateAttrs:
            self.__calculateJsonCache()
        else:
            self.__json = None
        self.__markNumber = 0

        self.__variables = {}
        self.__plugins = set()

    def __getitem__(self, key):
        return self.__variables[key]

    def __setitem__(self, key, value):
        self.__variables[key] = value

    def __contains__(self, key):
        return key in self.__variables

    def __str__(self):
        return '%s_%s#%s' % (self.equipment.name, self.typeName, self.uniId)

    def __repr__(self):
        return '(<%s> %s_%s#%s)' % (self.__class__.__name__, self.equipment.name, self.typeName, self.uniId)

    def calcAttr(self, attrName):
        if 'get' in self.interface["attrEdits"][attrName]:
            return eval(
                self.interface["attrEdits"][attrName]['get'], None, {
                    'obj'			: self,
                    'some_funcs'	: some_funcs
                }
            )
        else:
            return getattr(self.protocol_py_object, attrName)

    def calcAttrSelectValues(self, attrName):
        attrType = self.interface["attrEdits"][attrName]['type']
        if attrType[0:17] == 'dynamicTreeSelect':
            return self.doAction(attrType[18:-1])
        else:
            return None

    def calcLink(self, linkName):
        if 'get' in self.interface["attrEdits"][linkName]:
            getAction = self.interface["attrEdits"][linkName]['get']
            lnEl = None
            if getAction:
                lnEl = eval(
                    getAction, None, {
                        'obj'			: self,
                        'some_funcs'	: some_funcs
                    }
                )
            else:
                lnEl = self.__attrValues[linkName] if linkName in self.__attrValues else None
            if lnEl:
                return [lnEl.equipment.getName(), lnEl.typeName, lnEl.getUniID(), lnEl.getRemoteGUID()]
            return None
        else:
            return getattr(self.protocol_py_object, linkName)

    def attrUpdated(self, attrName):
        if attrName in self.interface["attrEdits"] and (
                'get' in self.interface["attrEdits"][attrName] or (
                    self.protocol_object_type and attrName in self.exportAttrs
                )
        ):
            if 'isAttr' in self.interface["attrEdits"][attrName]:
                newAttrValue = self.calcAttr(attrName)
                newSelectValues = self.calcAttrSelectValues(attrName)
                # Обновим кеш
                index = self.exportAttrs.index(attrName)
                if self.__json is not None:
                    self.__json[2+index] = [newAttrValue, newSelectValues]
                attrInDb = attrName in self.attrs
                attrEditable = False
                # TODO: старый стиль, надо удалить
                if 'set' in self.interface["attrEdits"][attrName]:
                    attrEditable = True
                if self.protocol_object_type:
                    # TODO: hasattr временно пока не перепишем все на классы
                    if hasattr(self.protocol_object_type, attrName):
                        attrEditable = not getattr(self.protocol_object_type, attrName).readOnly
                isOO = 'obsObjSelect' in self.interface["attrEdits"][attrName]['type']
                isOOList = 'obsObjMultiSelect' in self.interface["attrEdits"][attrName]['type']
                self.equipment.devModel.mutationReportSetAttribute(
                    self, attrName, newAttrValue, newSelectValues, attrInDb, attrEditable, isOO, isOOList)

    def linkUpdated(self, linkName):
        if linkName in self.interface["attrEdits"] and \
                'get' in self.interface["attrEdits"][linkName]:
            if 'isLink' in self.interface["attrEdits"][linkName]:
                lnEl = self.calcLink(linkName)
                #Обновим кеш
                if self.__json is not None:
                    index = 2 + len(self.exportAttrs) + self.exportLinks.index(linkName)
                    self.__json[index] = lnEl
                if lnEl:
                    self.equipment.devModel.mutationReportBindObject(
                        {'equip': lnEl[0], 'type': lnEl[1], 'id': lnEl[2], 'remote_guid': lnEl[3]}, linkName, self)
                else:
                    self.equipment.devModel.mutationReportUnBindObject(
                        None, linkName, self)


    def checkIP(self, ip):
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return False
        else:
            return True

    def buildPlugin(self, pluginClassName, **kwargs):

        if (',' in kwargs['connStr'] and kwargs['connStr'].split(',')[1].isnumeric()
                and self.checkIP(kwargs['connStr'].split(',')[0])) or self.equipment.getName() == 'uld':
            plugin = plgn.PluginSupport.buildPlugin(
                pluginClassName,
                self.equipment.getName(), self.typeName, self.getUniID(),
                **kwargs
            )

            deadPlugins = []
            for pgn in self.__plugins:
                if not pgn.isValid():
                    deadPlugins.append(pgn)
            for pgn in deadPlugins:
                self.__plugins.remove(pgn)

            self.__plugins.add(plugin)

            return plugin
        else:
            raise Exception("the port address field is filled incorrectly '%s'" % kwargs['connStr'])


    def finit(self):
        # TODO: finit теперь есть всегда Проверка не нужна
        if 'finit' in self.actions:
            try:
                self.doAction('finit')
            except Exception as e:
                logging.getLogger('console').info("error while finit device <%s:%s>: %s" % (
                    self.typeName, self.getUniID(), str(e)
                ))

        for plugin in self.__plugins:
            try:
                plugin.release()
            except plgn.PluginError as e:
                logging.getLogger('console').info('WARNING while finit: PluginError: %s' % str(e))

    def mark(self):
        """
        Помечает элемент. Можно использовать для своих целей, все отмеченные элементы можно потом
        получить функцией

        :return:
        """
        self.__markNumber = self.equipment.devModel.getMark()

    def isMarked(self):
        """
        Проверяет, помечен ли элемент

        :return: True or False
        """
        return (self.__markNumber == self.equipment.devModel.getMark())

    def loadingCorrectIndexes(self):
        self.__correctSetIndexes()

    def clearIndexes(self):
        self.__correctClrIndexes()

    def checkUniqueIndex(self, indexName, testValueSet=None):
        """Проверяет уникальность ключа indexName этого объекта,
        или такого же объекта, но с измененными полями.
        Альтернативные значение полей передаются через хэш testValueSet
        """
        if testValueSet is None:
            testValueSet = {}
        if indexName not in self.indexes:
            raise Exception("undefined index '%s'" % indexName)

        # считаем, что все объекты уникальны по индексу без полей
        if len(self.indexes[indexName]['fields']) == 0:
            return True

        # собираем ключ-значение
        keyValue = ''
        cannotBuildKey = False
        for field in self.indexes[indexName]['fields']:
            if 'target' in self.attrs[field]:
                pass
            else:
                value = self.__attrValues[field]
                if field in testValueSet:
                    value = testValueSet[field]
                if not eval(self.indexes[indexName]
                            ['fieldParams'][field]['filter']):
                    cannotBuildKey = True
                    break
                value = eval(self.indexes[indexName]
                             ['fieldParams'][field]['func'])
                if isinstance(value, BaseElement):
                    value = '%s#%d' % (value.typeName, value.getUniID())
                keyValue += ('%s;' % value)
        # если ключ не удалось собрать, считаем, что объект уникален по данному
        # индексу
        if cannotBuildKey:
            return True

        if len(testValueSet) == 0:
            # если testValueSet пусто, то проверяется, есть ли еще объекты с таким ключем
            # если такой ключ существует и содержит больше 1 элементов,
            # тогда набор значений атрибутов не уникален
            if keyValue in self.indexes[indexName]['keyValue'] and\
                    len(self.indexes[indexName]['keyValue'][keyValue]) > 1:
                return False
        else:
            # иначе, проверяем, есть ли хотя бы один объект с ключем, который
            # был бы у этого объекта, если установить у него заданные
            # (testValueSet) поля
            if keyValue in self.indexes[indexName]['keyValue'] and\
                    len(self.indexes[indexName]['keyValue'][keyValue]) > 0:
                return False

        return True

    def __checkUniqueIndexes(self, testValueSet):
        """НЕ ИСПОЛЬЗОВАТЬ!!! Фунция не протестирована."""
        for indexName in self.indexes:
            if 'fields' not in self.indexes[indexName]:
                continue
            if not self.indexes[indexName]['unique']:
                continue

            # собираем ключ-значение
            keyValue = ''
            cannotBuildKey = False
            for field in self.indexes[indexName]['fields']:
                if 'target' in self.attrs[field]:
                    pass
                else:
                    value = testValueSet[field]
                    if not eval(self.indexes[indexName]
                                ['fieldParams'][field]['filter']):
                        cannotBuildKey = True
                        break
                    value = eval(
                        self.indexes[indexName]['fieldParams'][field]['func'])
                    keyValue += ('%s;' % value)
            # если ключ не удалось собрать, не индексируем объект по данному
            # индексу, переходим к следующему индексу
            if cannotBuildKey:
                continue
            # если такой ключ существует и содержит больше 0 элементов,
            # тогда набор значений атрибутов не уникален
            if keyValue in self.indexes[indexName]['keyValue'] and\
                    len(self.indexes[indexName]['keyValue'][keyValue]) > 0:
                return False

        # раскоментировать для отладки индексов
        # print 'indexes after: ' + str(self.indexes)

        # Возвращает True только, если предложенный набор уникален для всех индексов
        return True

    def __buildKeyValue(self, index):
        keyValue = ''
        cannotBuildKey = False
        keyFunc = index['keyFunc']
        if keyFunc:
            try:
                keyValue = self.doAction(keyFunc)
                if keyValue is None:
                    cannotBuildKey = True
            except BaseException:
                cannotBuildKey = True
        else:
            if 'fields' not in index:
                cannotBuildKey = True
            for field in index['fields']:
                value = self.__attrValues[field]
                if not eval(index['fieldParams'][field]['filter']):
                    cannotBuildKey = True
                    break
                value = eval(index['fieldParams'][field]['func'])
                if isinstance(value, BaseElement):
                    value = '%s#%d' % (value.typeName, value.getUniID())
                keyValue += ('%s;' % value)
        return cannotBuildKey, keyValue

    def __correctSetIndexes(self):
        """	Эту функцию необходимо вызывать после каждого изменения атрибутов
                и ссылок"""
        for indexName in self.indexes:
            if indexName == 'bridge':
                continue

            # собираем ключ-значение
            cannotBuildKey, keyValue = self.__buildKeyValue(
                self.indexes[indexName]
            )

            # если ключ не удалось собрать, не индексируем объект по данному
            # индексу, переходим к следующему индексу
            if cannotBuildKey:
                continue

            # если такой ключ не существует, создаем
            if keyValue not in self.indexes[indexName]['keyValue']:
                self.indexes[indexName]['keyValue'][keyValue] = {}

            self.indexes[indexName]['keyValue'][keyValue][self.uniId] = self

        # раскоментировать для отладки индексов
        # print 'indexes after: ' + str(self.indexes)

    def __correctClrIndexes(self):
        """	Эту функцию необходимо вызывать перед каждым изменением атрибутов
                и ссылок"""
        for indexName in self.indexes:
            if indexName == 'bridge':
                continue

            # собираем ключ-значение
            cannotBuildKey, keyValue = self.__buildKeyValue(
                self.indexes[indexName]
            )
            # если ключ не удалось собрать, переходим к следующему индексу
            if cannotBuildKey:
                continue
            # если такой ключ не существует, переходим к следующему индексу
            if keyValue not in self.indexes[indexName]['keyValue']:
                continue

            if self.uniId in self.indexes[indexName]['keyValue'][keyValue]:
                del self.indexes[indexName]['keyValue'][keyValue][self.uniId]
                if len(self.indexes[indexName]['keyValue'][keyValue]) == 0:
                    del self.indexes[indexName]['keyValue'][keyValue]

        # раскоментировать для отладки индексов
        # print 'indexes before: ' + str(self.indexes)

    @classmethod
    def getFilteredElements(cls, indexName):
        if indexName not in cls.indexes:
            raise Exception("error: type '%s' has not index '%s'" %
                            (cls.typeName, indexName)
                            )

        index = cls.indexes[indexName]['keyValue']

        res = {}
        for el in index.values():
            res.update(el)

        return res

    @classmethod
    def getElementsByIndex(cls, indexName, keyValueDict=None, keyValue=None):
        if indexName not in cls.indexes:
            raise Exception("error: type '%s' has not index '%s'" %
                            (cls.typeName, indexName)
                            )

        index = cls.indexes[indexName]

        # собираем ключ-значение
        if keyValueDict is not None and keyValue is None:
            keyValue = ''
            for field in index['fields']:
                if field not in keyValueDict:
                    raise Exception(
                        (	"error: cannot find part of key '%s' of index "
                          "'%s' of '%s' type") % (field, indexName, cls.typeName)
                    )
                value = keyValueDict[field]
                try:
                    value = eval(index['fieldParams'][field]['func'])
                except BaseException:
                    return {}
                if isinstance(value, BaseElement):
                    value = '%s#%d' % (value.typeName, value.getUniID())
                keyValue += ('%s;' % value)

        if keyValue not in index['keyValue']:
            # если нет такого ключа, возвращаем пустой словарь
            return {}

        # ВНИМАНИЕ!!! Возвращаемый словарь нельзя править самостоятельно
        # Вероятно, необходимо будет переписать все в список и возвращать его
        return index['keyValue'][keyValue]

    def __initLink(self, attrName, attrValues):
        targetTypeName = self.attrs[attrName]['target']
        targetObj = None
        if attrName in attrValues and isinstance(attrValues[attrName], BaseElement):
            targetObj = attrValues[attrName]
        else:
            if targetTypeName == '':
                if (attrName + '_id') in attrValues and (attrName + '_type') in attrValues and\
                        attrValues[attrName + '_type'] in self.equipment.devModel.elementClasses and\
                        attrValues[attrName + '_id'] is not None:
                    targetObj = {
                        'id'	: attrValues[attrName + '_id'],
                        'type'	: attrValues[attrName + '_type']
                    }
                self.__attrValues[attrName] = targetObj
            else:
                """TODO Дальние ссылки с remote_guid???"""
                # в случае дальнего моста
                if 'targetEquip' in self.attrs[attrName] and self.attrs[attrName]['targetEquip'] != '':
                    if attrName in attrValues and attrValues[attrName] is not None:
                        targetObj = {
                            'id'	: int(attrValues[attrName]),
                            'type'	: targetTypeName,
                            'equip'	: self.attrs[attrName]['targetEquip']
                        }

                elif targetTypeName in self.equipment.devModel.elementClasses:
                    if attrName in attrValues and attrValues[attrName] is not None:
                        if isinstance(attrValues[attrName], dict):
                            # Если попали сюда значит установка ссылки пришла из createEquipDev.
                            # Пока не поддерживается присвоение дальней ссылки
                            targetObj = self.equipment.devModel\
                                .elementClasses[attrValues[attrName]['type']]\
                                .getElementById(attrValues[attrName]['id'])
                        elif isinstance(attrValues[attrName], list):
                            """Портс удаленного сервера в команды сует список с координатами объекта
                            хотелось бы привести это все к единому виду - когда уйдем от обычных id"""
                            targetObj = self.equipment.devModel[attrValues[attrName][0]] \
                                .elementClasses[attrValues[attrName][1]] \
                                .getElementByRemoteGUID(attrValues[attrName][3])
                        else:
                            targetObj = {
                                'id'	: int(attrValues[attrName]),
                                'type'	: targetTypeName
                            }
                else:
                    raise Exception(
                        "undefined link targetTypeName '%s' in '%s'" %
                        (targetTypeName, self.typeName))

        self.__attrValues[attrName] = targetObj

    def convertLinks(self):
        for attrName in self.attrs:
            if 'target' in self.attrs[attrName]:
                if self.__attrValues[attrName]:
                    existLink = True
                    targetObj = None
                    if 'targetEquip' in self.attrs[attrName] and self.attrs[attrName]['targetEquip'] != '':
                        if self.equipment.hasInstance(self.attrs[attrName]['targetEquip']):
                            # Если идет дальняя ссылка на оборудование и оно включено
                            try:
                                targetObj = self.equipment\
                                    .getInstance(self.attrs[attrName]['targetEquip'])\
                                    .devModel\
                                    .elementClasses[self.__attrValues[attrName]['type']]\
                                    .getElementById(self.__attrValues[attrName]['id'])
                            except Exception:
                                targetObj = None
                        else:
                            existLink = False
                    else:
                        targetObj = self.equipment.devModel\
                            .elementClasses[self.__attrValues[attrName]['type']]\
                            .getElementById(self.__attrValues[attrName]['id'])
                    if self.__attrValues[attrName]['id'] != 0 and targetObj is None and existLink:
                        logging.getLogger('console').info("message: element <%s %d> has bad link '%s' to deleted element <%s %d>" % (
                            self.typeName, self.uniId,
                            attrName,
                            self.__attrValues[attrName]['type'],
                            self.__attrValues[attrName]['id']
                        ))
                    self.__createLinkWithBackLink(attrName, targetObj)

    def __createLinkWithBackLink(self, attrName, targetObj):
        self.__attrValues[attrName] = targetObj
        if not targetObj:
            return
        # Устанавливаем хранилище обратных ссылок с именем attrName на
        # элемент типа себя
        backLinkName = self.typeName + ',' + attrName
        if backLinkName not in targetObj.backLinks:
            targetObj.backLinks[backLinkName] = {}

        targetObj.backLinks[backLinkName][self] = True

    def __deleteLinkWithBackLink(self, attrName, targetObj):
        if not targetObj:
            return
        self.__attrValues[attrName] = None

        backLinkName = self.typeName + ',' + attrName
        if backLinkName not in targetObj.backLinks:
            targetObj.backLinks[backLinkName] = {}

        if self in targetObj.backLinks[backLinkName]:
            del targetObj.backLinks[backLinkName][self]

    def __initAttrValues(self, attrValues):
        self.__attrValues = {}
        for attrName in self.attrs:
            if 'target' in self.attrs[attrName]:
                self.__initLink(attrName, attrValues)
            else:
                if attrName in attrValues:
                    if 'type' in self.attrs[attrName]:
                        self.__attrValues[attrName] = primitive.cast(self.attrs[attrName]['type'], attrValues[attrName])
                    else:
                        attribute = getattr(self.protocol_object_type, attrName)
                        self.__attrValues[attrName] = primitive.cast(attribute.fieldType, attrValues[attrName])
                else:
                    defval = self.attrs[attrName]['defval']
                    if isinstance(defval, str):
                        if defval[0:5] == '<!ev@' and defval[-5:] == '@ev!>':
                            defval = eval(defval[5:-5])
                    self.__attrValues[attrName] = defval

    def __calculateJsonCache(self):
        self.__json = [self.getUniID(), self.getRemoteGUID()]
        for attr in self.exportAttrs:
            value = self.calcAttr(attr)
            select = self.calcAttrSelectValues(attr)
            self.__json.append([value, select])
        for link in self.exportLinks:
            self.__json.append(self.calcLink(link))
        if hasattr(self, 'parentTypeName'):
            self.__json.append([
                self.parent.getUniID(), self.getAddr(), self.parent.getRemoteGUID()] if self.parent else None
            )

    def calculateCache(self):
        self.__calculateJsonCache()

    def debugGetAttrValues(self):
        return self.__attrValues

    def __checkMaxCount(self):
        maxCount = self.equipment.license.getEquipmentsLimit(self.equipment.getName(), self.typeName)
        if maxCount == -1:
            return
        if len(self.elements) >= maxCount:
            raise Exception("You cannot create more than %d of (%s %s)" % (
                maxCount, self.equipment.getName(), self.typeName
            ))

    def new(self, createAction=True, ignore_create_objects=False):
        self.__checkMaxCount()

        if not self.remoteGUID:
            self.remoteGUID = str(uuid.uuid4())
        # Общие объекты будут создаваться для всех серверов поэтому для них не будет добавлятся siteId
        if self.siteId != '' and self.equipment.getName() != 'common':
            self.remoteGUID = '%s.%s' % (self.remoteGUID, self.siteId)
        else:
            self.siteId = ''
        records = {
            'remote_guid'	: self.remoteGUID
        }
        for recName in self.attrs:
            try:
                if 'target' not in self.attrs[recName]:
                    records[recName] = self.__attrValues[recName]
                elif self.__attrValues[recName]:
                    records[recName] = self.__attrValues[recName].getUniID()
            except BaseException:
                pass

        self.uniId = self.equipment.dbConn.directRequest(some_funcs.sqlInsertBuilder(
            self.tblName, records, 'uniid'
        ), records, True)[0][0]

        self.__json[0] = self.uniId
        self.__json[1] = self.remoteGUID
        self.__correctSetIndexes()

        def cmp(el, patt):
            if int(el.uniId) == int(patt):
                return 0
            if int(el.uniId) < int(patt):
                return -1
            return 1

        ind = some_funcs.upperBound(
            self.elements, len(self.elements), self.uniId, cmp
        )

        self.elements.insert(ind, self)

        self.elementsGUID[self.remoteGUID] = self

        self.equipment.devModel.mutationReportCreateObject(self)

        if createAction:
            if 'postCreate' in self.actions:
                try:
                    self.doAction('postCreate', params={'ignore_create_objects': ignore_create_objects})
                except Exception as e:
                    logging.getLogger('console').exception('create action fail because')
                    raise dev_except.PostActionFail(str(e))

    def getUniID(self):
        """
        Возвращает уникальный идентификатор объекта оборудования

        :return: строка
        """
        return self.uniId

    def getRemoteGUID(self): return  self.remoteGUID

    def getSiteId(self): return self.siteId

    def getEquipName(self):
        """
        Возвращает имя оборудования, к которому принадлежит данный объект

        :return: строка
        """
        return self.equipment.getName()

    def getTypeName(self):
        """
        Возвращает название тип объекта внутри оборудования

        :return:
        """
        return self.typeName

    def getAttributesForCreateNotif(self):
        result = {}
        i = 2
        for attr in self.exportAttrs:
            result[attr] = {
                'value' : self.__json[i][0],
                'select': self.__json[i][1]
            }
            i += 1
        for link in self.exportLinks:
            result[link] = {
                'value': self.__json[i]
            }
            i += 1
        return result

    def getAddr(self):
        """
        Возвращает адрес, с которым объект присоединен к объекту (если родителя нет, бросает исключение)

        :return: целое число - адрес
        """
        if self.parent:
            return self.devAddr

        raise Exception(
            "element <type=%s uniId=%s> hasn't parent" %
            (self.typeName, str(
                self.uniId)))

    def getParent(self, level=0):
        """
        Возвращает родителя данного объекта, если родителя нет, бросает исключение dev_except.ParentNotFound

        :param level: уровень родителя 0 - прямой родитель, 1 - родитель родителя и т.д.
        :return: объект родителя
        """
        if not self.parent:
            raise dev_except.ParentNotFound(self.typeName, self.uniId)

        if level == 0:
            return self.parent

        return self.parent.getParent(level - 1)

    def hasParent(self, level=0):
        """
        Возвращает родителя данного объекта

        :param level: уровень родителя 0 - прямой родитель, 1 - родитель родителя и т.д.
        :return: объект родителя или None, если его нет
        """
        try:
            return self.getParent(level)
        except dev_except.ParentNotFound:
            return None

    def addChild(self, child, addr=None, skipTrig=False, info=None):
        """
        Привязывает к текущему объекту-родителю ребенка

        :param child: объект ребенка, если у родителя нет детей такого типа бросится исключение dev_except.WrongChildType
        :param addr: адрес, с которым привяжется ребенок, если адрес = None - будет выброшено исключение
        :param skipTrig: если True - ChangeParentAction-ы выполняться не будут
        :param info: параметр для preChangeParent у child-а
        :return:
        """
        # проверка типа ребенка
        if not hasattr(child, 'parentTypeName') or child.parentTypeName != self.typeName:
            raise dev_except.WrongChildType()

        """Вызов действий ребенка перед изменением родителя"""
        if not skipTrig and 'preChangeParent' in child.actions:
            child.doAction('preChangeParent', params={'newParent': self, 'info': info, 'addr': addr})

        if 'gen' in child.parentLink and not addr:
            # Будем генерировать адрес только если его не передеали явно, иначе это ломает dedicated
            cur = self.equipment.dbConn.cursor()
            cur.execute("""
                select max(devaddr) from %(tbl)s where devparent = %%s
            """ % {'tbl': child.tblName}, (self.getUniID(),))
            for row in cur:
                try:
                    addr = eval(child.parentLink['gen'], {}, {
                        'auto_generators'		: auto_generators,
                        'constants'				: constants
                    }).next(row[0])
                except BaseException:
                    addr = eval(child.parentLink['gen'], {}, {
                        'auto_generators'		: auto_generators,
                        'constants'				: constants
                    }).first()
                break

        if addr is None:
            raise Exception("wrong addr")
        addr = int(addr)

        oldParent = child.parent
        if oldParent:
            oldParent.removeChild(child, skipTrig=True)

        if addr in self.children[child.typeName]:
            self.removeChild(
                self.children[child.typeName][addr], skipTrig=skipTrig
            )

        sql = 'update ' + child.tblName + """ set devaddr = %s, devparent = %s
            where uniid = %s
        """

        self.equipment.dbConn.directRequest(
            sql, (addr, self.uniId, child.uniId), False)

        child.__correctClrIndexes()
        child.devAddr = addr
        child.parent = self
        self.children[child.typeName][addr] = child
        #Обновим кеш
        if self.__json is not None:
            child.__json[-1] = [self.getUniID(), addr, self.getRemoteGUID()]
        child.__correctSetIndexes()

        self.equipment.devModel.mutationReportAddChild(child, addr, self)

        """Вызов действий ребенка после изменением родителя"""
        if not skipTrig and 'postChangeParent' in child.actions:
            try:
                child.doAction('postChangeParent', params={'info': info, 'oldParent': oldParent})
            except Exception as e:
                logging.getLogger('console').info('post action fail because: %s' % str(e))
                raise dev_except.PostActionFail(str(e))

    def leaveParent(self, dbCorrect=True, skipTrig=False):
        """
        Отвязывает объект от родителя

        :param dbCorrect: записывать ли изменения в БД, лучше не трогать - приследующем запуске могут возникнуть "висячие" ссылки. Они корректируются во время загрузки сервера.
        :param skipTrig: если True - ChangeParentAction-ы выполняться не будут
        :return:
        """
        if not self.parent:
            return

        self.parent.removeChild(self, dbCorrect, skipTrig=skipTrig)

    def removeChild(self, child, dbCorrect=True, skipTrig=False):
        """
        Отвязывает от объекта ребенка child

        :param child: объект ребенка, который нужно отвязать
        :param dbCorrect: записывать ли изменения в БД, лучше не трогать - приследующем запуске могут возникнуть "висячие" ссылки. Они корректируются во время загрузки сервера.
        :param skipTrig: если True - ChangeParentAction-ы выполняться не будут
        :return:
        """
        # проверка типа ребенка
        if not hasattr(
                child, 'parentTypeName') or child.parentTypeName != self.typeName:
            raise dev_except.WrongChildType()

        if not child.parent or child.parent.uniId != self.uniId:
            return

        if not skipTrig and 'preChangeParent' in child.actions:
            child.doAction('preChangeParent', params={'newParent': None})

        if dbCorrect:
            self.equipment.dbConn.directRequest(
                "update " + child.tblName +
                """ set devaddr = NULL, devparent = NULL
                    where uniId = %s""",
                (child.uniId,), False
            )

        child.__correctClrIndexes()
        del self.children[child.typeName][child.devAddr]
        oldParent = child.parent
        child.parent = None
        child.devAddr = None
        #Обновим кеш
        if self.__json is not None:
            child.__json[-1] = None
        child.__correctSetIndexes()

        self.equipment.devModel.mutationReportRemoveChild(child, self)

        if not skipTrig and 'postChangeParent' in child.actions:
            try:
                child.doAction('postChangeParent', {'oldParent': oldParent})
            except Exception as e:
                logging.getLogger('console').info('post action fail because: %s' % (str(e)))
                raise dev_except.PostActionFail(str(e))

    def getElementArray(self, linkName, filter='True'):
        """
        Возвращает массив детей, привязанных к объекту через мостовую связь с названием linkName

        :param linkName: имя мостовой таблицы. Если такой связи нет, бросается исключение
        :param filter: строка с кодом, который должен вернуть True, чтобы целевой объект попал в итоговый массив. В области видимости есть переменная linked, где лежит целевой объект.
        :return: массив со связанными объектами
        """
        # проверка: есть ли у объекта дети такого типа
        if not self.equipment.devModel.hasChildOfType(self.typeName, linkName):
            raise Exception(
                "'%s' hasn't child of '%s' type" %
                (self.typeName, linkName))

        linkType = self.equipment.devModel.elementClasses[linkName]

        # определяем тип связанных объектов
        linkedName = linkName[len(self.typeName) + 1:]

        # проверяем есть ли такая ссылка у моста
        if linkedName not in linkType.attrs:
            raise Exception(
                "element <type=%s uniId=%s> hasn't link '%s'" %
                (linkType.typeName, str(
                    linkType.uniId), linkedName))

        linkedType = self.equipment.devModel.elementClasses[linkType.attrs[linkedName]['target']]

        result = []

        for link in self.children[linkName]:
            linked = self.children[linkName][link].getLinkedElement(linkedName)
            if eval(filter):
                result.append(linked)

        return result

    def getChildListByType(self, typeName):
        """
        Возвращает массив привязанных объектов-детей типа typeName

        :param typeName: тип привязанных объектов, если у объекта не может быть
         детей такого типа - бросается исключение
        :return: массив объектов-детей, если детей нет - пустой массив
        """
        # проверка: есть ли у объекта дети такого типа
        if not self.equipment.devModel.hasChildOfType(self.typeName, typeName):
            raise Exception(
                "'%s' hasn't child of '%s' type" %
                (self.typeName, typeName))

        result = [self.children[typeName][el]
                  for el in self.children[typeName]]
        result.sort(key=lambda x: int(x.devAddr))
        return result

    def getChildByAddr(self, typeNameList, addr):
        """
        Возвращает привязанные объекты перечисленных в typeNameList типов с адресом addr
        Если у объекта не существует детей такого типа бросится исключение.
        Если ребенок не будет найден, будет брошено исключение dev_except.ChildNotFound

        :param typeNameList: может быть листом, туплом (тогда ребенок с заданным адресом будет искаться среди объектов каждого типа) либо строкой (тогда поиск будет среди объектов только этого типа). Для листа или тупла будет возвращен первый найденный ребенок.
        :param addr:
        :return: найденный объект-ребенок
        """
        if isinstance(typeNameList, list) or isinstance(typeNameList, tuple):
            for typeName in typeNameList:
                try:
                    return self.__getChildByAddr(typeName, addr)
                except dev_except.ChildNotFound:
                    pass

            raise dev_except.ChildNotFound(
                addr, self.typeName, self.getUniID())

        return self.__getChildByAddr(typeNameList, addr)

    def __getChildByAddr(self, typeName, addr):
        # проверка: есть ли у объекта дети такого типа
        if not self.equipment.devModel.hasChildOfType(self.typeName, typeName):
            raise Exception(
                "'%s' hasn't child of '%s' type" %
                (self.typeName, typeName))

        if addr not in self.children[typeName]:
            raise dev_except.ChildNotFound(
                addr, self.typeName, self.getUniID())

        return self.children[typeName][addr]

    def hasEditableField(self, fieldName):
        """
        Проверяет есть ли у объекта поле с именем fieldName и доступно ли оно для редактирования

        :param fieldName:
        :return: True or False
        """
        if fieldName in self.interface["attrEdits"]:
            if 'set' in self.interface["attrEdits"][fieldName]:
                return True
            if self.protocol_object_type:
                # TODO: hasattr временно пока не перепишем все на классы
                if hasattr(self.protocol_object_type, fieldName):
                    return not getattr(self.protocol_object_type, fieldName).readOnly
        return False

    def setAttr(self, fieldName, value):
        """
        Устанавливает у объекта атрибуту fieldName значение value. Если атрибут не доступен для редактирования -
        бросается исключение dev_except.NoEditableField
        При установке атрибута вызываются функции из postAction и preAction

        :param fieldName: имя атрибута
        :param value: значение аргумента
        :return:
        """
        setAction = None
        attribute = None
        if 'set' in self.interface["attrEdits"][fieldName]:
            setAction = self.interface["attrEdits"][fieldName]['set'] if self.hasEditableField(fieldName) else None

        if self.protocol_object_type:
            # TODO: hasattr временно пока не перепишем все на классы
            if hasattr(self.protocol_object_type, fieldName):
                attribute = getattr(self.protocol_object_type, fieldName)

        params = {
            'value': value,
            'field': fieldName
        }

        if attribute:
            if attribute.preAction:
                attribute.preAction(self.protocol_py_object, value=value, field=fieldName)
        else:
            if fieldName in self.interface["attrEdits"] and 'preAction' in self.interface["attrEdits"][fieldName]:
                """Выполняем действия перед изменением, если они указаны.
                Если действия перед изменением не успешны, имененния не
                производятся"""
                preAction = self.interface["attrEdits"][fieldName]['preAction']
                self.doAction(preAction, params)

        """Выполняем изменения. Если изменения не успешны завершаем"""
        oldValue = None
        oldValues = {}
        for attrName in self.attrs:
            if 'target' not in self.attrs[attrName]:
                oldValues[attrName] = self.getAttribute(attrName)

        if attribute:
            setattr(self.protocol_py_object, fieldName, value)
        else:
            if fieldName in self.attrs:
                oldValue = self.getAttribute(fieldName)
                # Если в set даже для обычного атрибута указано какое-то действие то вызовем его
                if setAction in self.actions:
                    self.doAction(setAction, params)
                else:
                    self.setAttribute(fieldName, value)
            elif setAction is not None:
                self.doAction(setAction, params)

        if attribute:
            if attribute.postAction:
                attribute.postAction(self.protocol_py_object, oldValue=oldValue, oldValues=oldValues)
        else:
            if fieldName in self.interface["attrEdits"] and 'postAction' in self.interface["attrEdits"][fieldName]:
                """Выполняем действия после изменением, если они указаны"""
                postAction = self.interface["attrEdits"][fieldName]['postAction']
                try:
                    self.doAction(postAction, {
                        'oldValue': oldValue, 'oldValues': oldValues
                    })
                except Exception as e:
                    logging.getLogger('console').info('post action fail because: %s' % str(e))
                    raise dev_except.PostActionFail(str(e))

    def setAttribute(self, attrName, value):
        """
        Устанавливает у объекта атрибуту fieldName значение value даже если атрибут не доступен для редактирования
        При установке атрибута НЕ вызываются функции из postAction и preAction

        :param fieldName: имя атрибута
        :param value: значение аргумента
        :return:
        """
        if not self.hasAttribute(attrName) or 'target' in self.attrs[attrName]:
            raise Exception("element <type=%s uniId=%s> hasn't attribute '%s'" %
                            (self.typeName, str(self.uniId), attrName))

        '''В строке могут быть символы переноса каретки, поэтому удаляем их все.'''
        new_value = value
        if 'type' in self.attrs[attrName]:
            attrType = self.attrs[attrName]['type']
            if (attrType == 'string' or attrType == 'unicode') and new_value:
                new_value = ''.join(str(new_value).split('\n'))
            newVal = primitive.cast(attrType, new_value)
        else:
            if isinstance(new_value, str):
                new_value = ''.join(str(new_value).split('\n'))
            attribute = getattr(self.protocol_object_type, attrName)
            newVal = primitive.cast(attribute.fieldType, new_value)

        try:
            self.equipment.dbConn.directRequest(
                'update %s set %s = ' % (self.tblName, attrName) +
                ' %s where uniid = %s', (newVal, self.getUniID()),
                False
            )

            self.__correctClrIndexes()
            self.__attrValues[attrName] = newVal
            self.__correctSetIndexes()

            self.attrUpdated(attrName)

            return True
        except Exception as e:
            logging.getLogger('console').exception('Error in setAttribute')
            eMsg = "element <type=%s uniId=%s> setAttribute('%s', %s) error: %s"\
                % (self.typeName, str(self.uniId), attrName, str(new_value), repr(e))
            raise Exception(eMsg)

    def getConstant(self, constName):
        """
        Возвращает значение константы constName. Если константы с таким именем нет - бросается исключение.

        :param constName: имя константы
        :return: значение константы
        """
        if not self.hasConstant(constName):
            raise Exception("element <type=%s uniId=%s> hasn't constant '%s'"
                            % (self.typeName, str(self.uniId), constName))
        if 'type' in self.consts[constName]:
            return primitive.cast(self.consts[constName]['type'], self.consts[constName]['value'])
        return self.consts[constName]['value']

    def getAttribute(self, attrName):
        """
        Возвращает значение атрибута с именем attrName
        Если атрибута с таким именем у объекта нет - будет брошено исключение dev_except.UndefinedAttrField

        :param attrName:
        :return:
        """
        if not self.hasAttribute(attrName):
            raise dev_except.UndefinedAttrField(attrName, self)

        if 'type' in self.attrs[attrName]:
            return primitive.cast(
                self.attrs[attrName]['type'], self.__attrValues[attrName])
        else:
            return getattr(self.protocol_py_object, attrName)

    def hasConstant(self, constName):
        """
        Проверяет наличие у объекта константы с именем constName

        :param constName:
        :return: True or False
        """
        if constName in self.consts:
            return True
        return False

    def hasAttribute(self, attrName):
        """
        Проверяет наличие у объекта атрибута с именем attrName

        :param attrName:
        :return: True or False
        """
        if attrName in self.attrs:
            return True
        return False

    def pushEvent(self, event):
        """
        Добавление приведенного к единому формату события от оборудования в очередь обработки сервером

        :param event: словарь вида
        {
            'notification': {
                'code': код события,
            },
            'statement': {
                'adverbialTime': {
                    'param': таймштамп время проишествия события
                },
                'adverbialMode': {
                    'param': параметр события
                },
                'directObj': {
                    'dev': {
                        'equip': название оборудования,
                        'type': название типа внутри оборудования,
                        'id': уникальный идентификатор объекта
                    }
                },
                'indirectObj': {
                    'dev': {
                        'equip': название оборудования,
                        'type': название типа внутри оборудования,
                        'id': уникальный идентификатор объекта
                    }
                },
                'subject': {
                    'code': код карты субъекта
                    'dev': {
                        'equip': 'common',
                        'type': 'subject',
                        'id': уникальный идентификатор объекта
                    }
                }
            }
        }

        :return:
        """
        self.equipment.devModel.pushEvent(event)

    def findRoot(self):
        """
        Идет наверх по родителям до тех пор, пока не найдет объект, владеющей portsClient-ом (имеет свзязь с портсом)

        :return: найденный объект или None
        """
        if 'cmdDriver' in self.__variables:
            return self
        if self.parent:
            return self.parent.findRoot()
        return None

    def sendToPorts(self, cmdName, data=None, rootElement=None):
        """
        Посылает данные в Ports
        :param cmdName: Имя команды
        :param data: словь с даннымы для отправки по Ports
        :param rootElement: объект-владелец portsClient-а, через который будет отправлена команда.
        Если None - такой элемент будет найден функцией findRoot.
        Если все равно не будет найдент - будет брошено исключение dev_except.PortNotFound
        :return: ответ портса на команду
        """
        if self.siteId != '':
            logging.getLogger('console').info('Skip send to ports for not local object')
            return None
        if not data:
            data = {}
        if not rootElement:
            rootElement = self.findRoot()
        else:
            if 'cmdDriver' not in rootElement:
                rootElement = None
        logging.getLogger('console').info('Command ready: %.512s' % data)
        if rootElement and 'cmdDriver' in rootElement:
            try:
                cmdDriver = rootElement['cmdDriver']
                if cmdDriver:
                    portsRes = cmdDriver.sendCommand(data)
                    res = self.equipment.devModel.event_packet.decodeCommandResult(
                        self.equipment.devModel, rootElement, portsRes, cmdName)
                else:
                    res = None
            except self.equipment.devModel.event_packet.EventPacketException as e:
                logging.getLogger('console').info("except1 - %s" % (str(e)))
                raise dev_except.CommandExecError(str(e))
            except plgnExcept.PluginSupportError as e:
                logging.getLogger('console').info("except2 - %s. CMD: %s" % (str(e), data))
                return None
            else:
                logging.getLogger('console').info("command '%s' sent success" % cmdName)
                return res

        raise dev_except.PortNotFound()

    def buildCommand(self, cmdName, params=None, rootElement=None):
        """
        Посылает команду в портс. Для этого команда с именем cmdName должна быть описана в разделе <commands> в xml
        с описанием текущего объекта.
        Для разбора ответа на команду будет вызвана функция decodeCommandResult из event_packet-а оборудования.

        :param cmdName: имя команды
        :param params: словарь с параметрами для подстановки в команду
        :param rootElement: объект-владелец portsClient-а, через который будет отправлена команда. Если None - такой элемент будет найден функцией findRoot. Если все равно не будет найдент - будет брошено исключение dev_except.PortNotFound
        :return: ответ портса на команду
        """
        if cmdName in self.commands:
            if not rootElement:
                rootElement = self.findRoot()
            else:
                if 'cmdDriver' not in rootElement:
                    rootElement = None
            instructions = self.commands[cmdName].childNodes
            cmd = {}
            self.__buildCommand(instructions, cmd, cmdName, params)
            logging.getLogger('console').info('Command ready: %.512s' % (cmd))
            if rootElement and 'cmdDriver' in rootElement:
                try:
                    cmdDriver = rootElement['cmdDriver']
                    if cmdDriver:
                        res = self.equipment.devModel.event_packet.decodeCommandResult(
                            self.equipment.devModel, rootElement, cmdDriver.sendCommand(
                                cmd), cmdName
                        )
                    else:
                        res = None
                except self.equipment.devModel.event_packet.EventPacketException as e:
                    logging.getLogger('console').info("except1 - %s"%(str(e)))
                    raise dev_except.CommandExecError(str(e))
                except plgnExcept.PluginSupportError as e:
                    logging.getLogger('console').info("except2 - %s. CMD: %s" % (str(e), cmd))
                    return None
                    #raise dev_except.CommandExecError2(e)
                else:
                    logging.getLogger('console').info("command '%s' sent success" % cmdName)
                    return res

            raise dev_except.PortNotFound()
        else:
            raise Exception("element <type=%s uniId=%s> has not command '%s'"
                            % (self.typeName, str(self.uniId), cmdName))

    def __buildCommand(self, instructions, result, cmd,
                       params, item=None, key=None):
        obj = self
        #if cmd == None: cmd = result
        for instr in instructions:
            if instr.nodeType != 1:
                continue

            if instr.tagName == 'arg':
                name = instr.getAttribute(
                    'name') if instr.hasAttribute('name') else None
                argType = instr.getAttribute(
                    'type') if instr.hasAttribute('type') else None
                value = instr.getAttribute(
                    'value') if instr.hasAttribute('value') else None
                defval = instr.getAttribute(
                    'defvalue') if instr.hasAttribute('defvalue') else None

                try:
                    if argType is None:
                        pass
                    elif argType == 'dict':
                        if not value:
                            value = {}
                        result[name] = value
                        self.__buildCommand(
                            instr.childNodes, value, cmd, params, item, key)
                    elif argType == 'list':
                        if not value:
                            value = []
                        result[name] = value
                        self.__buildArgList(
                            instr.childNodes, value, cmd, params, item, key)
                    else:
                        try:
                            value = eval(value)
                        except Exception as e:
                            logging.getLogger('console').info(repr(e))
                            value = eval(defval)

                        if argType == 'uint8':
                            value = int(value)
                        elif argType == 'uint16':
                            value = int(value)
                        elif argType == 'uint32':
                            value = int(value)
                        elif argType == 'string':
                            if isinstance(value, int):
                                value = str(value)

                        result[name] = value

                except Exception as e:
                    raise Exception('error with argument %s: %s' % (name, str(e)))

                if value is None:
                    raise Exception(
                        'error with argument %s: invalid value' %
                        (name))
                #result[name] = value

            elif instr.tagName == 'if':
                if instr.hasAttribute('condition'):
                    cond = instr.getAttribute('condition')
                    try:
                        if not eval(cond):
                            raise Exception('fail')
                    except BaseException:
                        pass
                    else:
                        self.__buildCommand(
                            instr.childNodes, result, cmd, params, item, key)
                else:
                    raise Exception('error with condition: not found')

            elif instr.tagName == 'for':
                if instr.hasAttribute('iterable'):
                    iterable = eval(instr.getAttribute('iterable'))

                    for key in iterable:
                        self.__buildCommand(
                            instr.childNodes, result, cmd, params, iterable[key], key)
                else:
                    raise Exception('error with iterable: not found')

    def __buildArgList(self, instructions, result, cmd,
                       params, item=None, key=None):
        obj = self
        name = 0
        for instr in instructions:
            if instr.nodeType != 1:
                continue

            if instr.tagName == 'arg':
                argType = instr.getAttribute(
                    'type') if instr.hasAttribute('type') else None
                value = instr.getAttribute('value')
                defval = instr.getAttribute(
                    'defvalue') if instr.hasAttribute('defvalue') else None

                try:
                    if argType is None:
                        pass
                    elif argType == 'dict':
                        value = {}
                        self.__buildCommand(
                            instr.childNodes, value, cmd, params, item, key)
                    elif argType == 'list':
                        value = []
                        self.__buildArgList(
                            instr.childNodes, value, cmd, params, item, key)
                    else:
                        try:
                            value = eval(value)
                        except BaseException:
                            value = eval(defval)

                        if argType == 'uint8':
                            value = int(value)
                        elif argType == 'uint16':
                            value = int(value)
                        elif argType == 'uint32':
                            value = int(value)
                        elif argType == 'string':
                            if isinstance(value, int):
                                value = str(value)

                except Exception as e:
                    raise Exception(
                        'error with argument #%s: %s' %
                        (str(name), repr(e)))

                result.append(value)

            elif instr.tagName == 'if':
                if instr.hasAttribute('condition'):
                    cond = instr.getAttribute('condition')
                    try:
                        if not eval(cond):
                            raise Exception('fail')
                    except BaseException:
                        pass
                    else:
                        #res = self.__buildArgList(instr.childNodes, rootRes)
                        #for arg in res:	result.append(arg)
                        res = []
                        self.__buildArgList(
                            instr.childNodes, res, cmd, params, item, key)
                        list(map(lambda x: result.append(x), res))
                else:
                    raise Exception('error with condition: not found')

            elif instr.tagName == 'for':
                if instr.hasAttribute('iterable'):
                    iterable = eval(instr.getAttribute('iterable'))

                    for it in iterable:
                        res = []
                        if isinstance(iterable, list) or isinstance(
                                iterable, set):
                            self.__buildArgList(
                                instr.childNodes, res, cmd, params, it, it)
                        else:
                            self.__buildArgList(
                                instr.childNodes, res, cmd, params, iterable[it], it)
                        list(map(lambda x: result.append(x), res))
                else:
                    raise Exception('error with iterable: not found')

            name = name + 1

    def doAction(self, actName, params=None):
        """
        Выполняет действие с именем actName у объекта

        :param actName: имя действия, должно быть описано в секции <actions> в xml описании типа текущего объекта
        :param params: словарь с параметрами действия
        :return: переменную result из тела действия, либо None
        """
        return self.__doAction(actName, self, params)

    @classmethod
    def doStaticAction(cls, actName, params=None):
        return cls.__doAction(actName, None, params)

    @classmethod
    def __doAction(cls, actName, obj=None, params=None):
        if params is None:
            params = {}

        if actName in cls.actions:
            if isinstance(cls.actions[actName], dict):
                # зачатки переезда на питоновские классы с хмл - выполняем экшены из класса
                available_params = {}
                for name in params:
                    if name in cls.actions[actName]['args']:
                        available_params[name] = params[name]
                if obj is not None:
                    return getattr(obj.protocol_py_object, actName)(**available_params)
                elif cls.actions[actName]['type'] == 'bound':
                    return getattr(cls.protocol_object_type, actName)(**available_params)
                else:
                    logging.getLogger('console').error('Nonclass method %s was called without object!' % actName)
            else:
                core = cls.equipment.devModel
                localVars = {
                    'obj'		: obj if obj else cls,
                    'core'			: core,
                    'params'		: params,
                    'dev_except'	: dev_except,
                    'plugin_except'	: plgnExcept,
                    'primitive'		: primitive,
                    'event_packet'	: core.event_packet,
                    'result'		: True,
                    'message'		: None,
                    'actName'		: actName
                }
                for paramName in params:
                    if paramName not in localVars:
                        localVars[paramName] = params[paramName]
                eval(cls.actions[actName], localVars)
                return localVars['result']
            raise dev_except.UndefinedAction(
                "unexpected data in actions list for '%s'" % actName
            )
        else:
            if obj:
                raise dev_except.UndefinedAction(
                    "element <type=%s uniId=%s> has not action '%s'" % (
                        obj.typeName, obj.uniId, actName
                    )
                )
            else:
                raise dev_except.UndefinedAction(
                    "undefined action '%s'" % actName
                )

    def __checkLinkField(self, linkName):
        if not self.hasAttribute(linkName) or 'target' not in self.attrs[linkName]:
            raise dev_except.UndefinedLinkField(linkName, self)

    def getLinkedElement(self, linkName):
        """
        Возвращает элемент по ссылке linkName. Если элемент не найден - будет брошено исключение
        dev_except.LinkedElementNotFound

        :param linkName: имя ссылки
        :return: объект
        """
        self.__checkLinkField(linkName)

        el = self.__attrValues[linkName]
        if not el:
            raise dev_except.LinkedElementNotFound(linkName)

        return el

    def isLinkedElement(self, linkName):
        """
        Проверяет не пуста ли ссылка с именем linkName

        :param linkName:
        :return: False если ссылка пуста, True если она на что то ссылается
        """
        try:
            linkedElement = self.getLinkedElement(linkName)
        except dev_except.LinkedElementNotFound:
            return False
        return True

    def bindFarObject(self, obj2EquipName, obj2TypeName, obj2Id, obj2RemoteGuid, linkName):
        """
        Создает дальнюю ссылку (между объектами из различного оборудования)

        :param obj2EquipName: Название оборудования целевого объекта
        :param obj2TypeName: тип внутри оборудования целевого объекта
        :param obj2Id: уникальный идентификатор целевого объекта
        :param obj2RemoteGuid: GUID целевого объекта. Используется вместо obj2Id в многосерверной архитектуре
        :param linkName: название ссылки у текущего объекта
        :return:
        """
        warnings.warn("bindFarObject() is deprecated, "
                      "use bindElement because of far links now works as standard links",
                      DeprecationWarning, stacklevel=2)
        if obj2RemoteGuid:
            obj2 = self.equipment.devModel[obj2EquipName].getElementByRemoteGUID(obj2TypeName, obj2RemoteGuid)
        else:
            obj2 = self.equipment.devModel[obj2EquipName].getElementById(obj2TypeName, obj2Id)
        return self.bindElement(linkName, obj2)

    def bindElement(self, linkName, el, ignoreInstead=False, force=False):
        """
        Заполняет ссылку linkName элементом el
        Если тип целевого объекта не совпадает с типом ссылки будет брошено исключение dev_except.WrongLinkTargetType
        Если при выполнения postAction возникнет ошибка будет брошено исключение dev_except.PostActionFail

        :param linkName: имя ссылки
        :param el: целевой объект
        :param ignoreInstead: если истина - то даже при наличии у ссылки insteadAction - действие выполнено не будет, а будет присвоена ссылка
        :param force: если истина - то даже при генерации исключения pceAction ссылка будет установлена
        :return: возвращает всегда True
        """

        self.__checkLinkField(linkName)
        if self.attrs[linkName]['target'] != '' and self.attrs[linkName]['target'] != el.typeName:
            raise dev_except.WrongLinkTargetType(
                "link '%s'(target='%s') error: wrong target type '%s'" % (
                    linkName, self.attrs[linkName]['target'], el.typeName
                )
            )

        link = None
        if self.protocol_object_type:
            # TODO: hasattr временно пока не перепишем все на классы
            if hasattr(self.protocol_object_type, linkName):
                link = getattr(self.protocol_object_type, linkName)
        if link:
            if link.preAction:
                try:
                    link.preAction(self.protocol_py_object, targetObj=el)
                except Exception as e:
                    if not force:
                        raise
        else:
            if linkName in self.interface["attrEdits"] and 'preAction' in self.interface["attrEdits"][linkName]:
                """Выполняем действия перед изменением, если они указаны"""
                try:
                    preAction = self.interface['attrEdits'][linkName]['preAction']
                    params = {'targetObj': el}
                    self.doAction(preAction, params)
                except Exception as e:
                    if not force:
                        raise
        try:
            linkedElement = self.getLinkedElement(linkName)
            self.unBindElement(linkName, skipActions=True)
        except BaseException:
            pass

        if self.attrs[linkName]['target'] == "":
            sql = """
                update %(tbl)s
                set %(ln)s_type = %%s, %(ln)s_id = %%s
                where uniid = %%s
            """ % {'tbl': self.tblName, 'ln': linkName}
            self.equipment.dbConn.directRequest(sql, (
                el.typeName, el.getUniID(), self.getUniID()
            ), False)
        else:
            sql = """
                update %(tbl)s
                set %(ln)s = %%s
                where uniid = %%s
            """ % {'tbl': self.tblName, 'ln': linkName}
            self.equipment.dbConn.directRequest(sql, (
                el.getUniID(), self.getUniID()
            ), False)

        self.__correctClrIndexes()
        self.__createLinkWithBackLink(linkName, el)
        # Обновим кеш если эта ссылка отправляется в клиент
        if linkName in self.exportLinks and self.__json is not None:
            index = self.exportLinks.index(linkName)
            self.__json[2+len(self.exportAttrs)+index] = [el.equipment.getName(), el.typeName, el.getUniID(),
                                                      el.getRemoteGUID()]
        self.__correctSetIndexes()

        if linkName in self.interface["attrEdits"]:
            self.equipment.devModel.mutationReportBindObject(el, linkName, self)

        if link:
            if link.postAction:
                try:
                    link.postAction(self.protocol_py_object, targetObj=el)
                except Exception as e:
                    logging.getLogger('console').exception("post action fail")
                    raise dev_except.PostActionFail(str(e))
        else:
            if linkName in self.interface["attrEdits"] and 'postAction' in self.interface["attrEdits"][linkName]:
                """Выполняем действия после изменением, если они указаны"""
                postAction = self.interface["attrEdits"][linkName]['postAction']
                params = {'targetObj': el}
                try:
                    self.doAction(postAction, params)
                except Exception as e:
                    logging.getLogger('console').exception("post action '%s' fail: %s" % (postAction, repr(e)))
                    raise dev_except.PostActionFail(str(e))

        return True

    def unBindFarObject(self, linkName):
        """
        Очищает дальнюю ссылку linkName

        :param linkName:
        :return:
        """
        warnings.warn("unBindFarObject() is deprecated, "
                      "use unBindElement because of far links now works as standard links",
                      DeprecationWarning, stacklevel=2)
        return self.unBindElement(linkName)

    def unBindElement(self, linkName, dbCorrect=True,
                      ignoreInstead=False, skipActions=False):
        """
        Очищает ссылку linkName
        Если при выполнения postAction возникнет ошибка будет брошено исключение dev_except.PostActionFail

        :param linkName:
        :param dbCorrect: если False - то изменения в базу записаны не будут. Нужно для архивных объектов, лучше не трогать
        :param ignoreInstead: если истина - то даже при наличии у ссылки insteadAction - действие выполнено не будет, а будет очищена ссылка
        :param skipActions: если True - то post и pre actions выполняться не будут
        :return: всегда True
        """

        linkedElement = None
        try:
            linkedElement = self.getLinkedElement(linkName)
        except BaseException:
            return True

        link = None
        if self.protocol_object_type:
            # TODO: hasattr временно пока не перепишем все на классы
            if hasattr(self.protocol_object_type, linkName):
                link = getattr(self.protocol_object_type, linkName)

        if not skipActions:
            if link:
                if link.preAction:
                    link.preAction(self.protocol_py_object, targetObj=None)
            else:
                if linkName in self.interface["attrEdits"] and 'preAction' in self.interface["attrEdits"][linkName]:
                    """Выполняем действия перед изменением, если они указаны"""
                    preAction = self.interface['attrEdits'][linkName]['preAction']
                    params = {'targetObj': None}
                    self.doAction(preAction, params)

        if dbCorrect:
            if self.attrs[linkName]['target'] == "":
                sql = """
                    update %(tbl)s
                    set %(ln)s_type = null, %(ln)s_id = null
                    where uniid = %%s
                """ % {'tbl': self.tblName, 'ln': linkName}
                self.equipment.dbConn.directRequest(
                    sql, (self.getUniID(),), False)
            else:
                sql = """
                    update %(tbl)s set %(ln)s = null where uniid = %%s
                """ % {'tbl': self.tblName, 'ln': linkName}
                self.equipment.dbConn.directRequest(
                    sql, (self.getUniID(),), False)

        self.__correctClrIndexes()
        self.__deleteLinkWithBackLink(linkName, linkedElement)
        # Обновим кеш если эта ссылка отправляется в клиент
        if linkName in self.exportLinks:
            index = 2 + len(self.exportAttrs) + self.exportLinks.index(linkName)
            if self.hasAttribute('_BaseElement__json'):
                self.__json[index] = None
        self.__correctSetIndexes()

        if linkName in self.interface["attrEdits"]:
            self.equipment.devModel.mutationReportUnBindObject(
                linkedElement, linkName, self
            )

        if not skipActions:
            if link:
                if link.postAction:
                    try:
                        link.postAction(self.protocol_py_object, targetObj=linkedElement)
                    except Exception as e:
                        logging.getLogger('console').exception("post action")
                        raise dev_except.PostActionFail(str(e))
            else:
                if linkName in self.interface["attrEdits"] and 'postAction' in self.interface["attrEdits"][linkName]:
                    """Выполняем действия после изменением, если они указаны"""
                    postAction = self.interface["attrEdits"][linkName]['postAction']
                    params = {'targetObj': linkedElement}
                    try:
                        self.doAction(postAction, params)
                    except Exception as e:
                        logging.getLogger('console').exception("post action '%s' fail: %s" % (postAction, str(e)))
                        raise dev_except.PostActionFail(str(e))

        return True

    def getLink(self, linkName, targetObj):
        """
        Возвращает объект из мостовой таблицы, являющийся связующим между текущим объектом и targetObj
        Если объекты не связаны - будет брошено исключение dev_except.BridgeElementNotFound

        :param linkName: имя мостовой таблицы
        :param targetObj:
        :return: объект
        """
        try:
            linkClass = self.equipment.devModel.elementClasses[linkName]
            index = "%d@%s#%d" % (self.uniId, linkName, targetObj.uniId)
        except Exception as e:
            raise Exception("element <type=%s uniId=%s> getLink('%s', <%s %s>) error: %s"
                            % (self.typeName, str(self.uniId), linkName, targetObj.typeName, str(targetObj.uniId), repr(e)))
        else:
            if index in linkClass.indexes['bridge']:
                return linkClass.indexes['bridge'][index]
            else:
                raise dev_except.BridgeElementNotFound(
                    linkName, self.typeName, self.getUniID(),
                    targetObj.typeName, targetObj.getUniID(),
                    self.getDescription(), targetObj.getDescription()
                )

    def isLinked(self, linkName, targetObj):
        """
        Если объект связан с targetObj через мостовую таблицу с названием linkName - возвращает адрес

        :param linkName: имя мостовой таблицы
        :param targetObj:
        :return: адрес targetObj у текущего объекта, либо False
        """
        try:
            return self.getLink(linkName, targetObj).getAddr()
        except BaseException:
            return False

    def deleteLink(self, linkName, targetObj):
        """
        Удаляет мостовую связь linkName с объектом targetObj

        :param linkName:
        :param targetObj:
        :return:
        """
        try:
            self.checkLink(linkName, targetObj)

            link = None
            try:
                link = self.getLink(linkName, targetObj)
            except BaseException:
                pass

            if link:
                link.selfDelete()

        except Exception as e:
            raise Exception("element <type=%s uniId=%s> deleteLink('%s', <%s %s>) error: %s"
                            % (self.typeName, str(self.uniId), linkName, targetObj.typeName, str(targetObj.uniId), repr(e)))

    def checkLink(self, linkName, targetObj):
        """
        Если мостовой таблицы с названием linkName между текущим объектом и targetObj не существует - будет брошено
        исключение

        :param linkName:
        :param targetObj: НЕ ИСПОЛЬЗУЕТСЯ
        :return:
        """
        if not self.equipment.devModel.hasChildOfType(self.typeName, linkName):
            raise Exception(
                "'%s' hasn't link of '%s' type" %
                (self.typeName, linkName))

    def createLink(self, linkName, targetObj, attrs=None, addr=None, info=None, checkUnique=False):
        """
        Создает связь текущего объекта и targetObj через мостовую таблицу linkName

        :param linkName:
        :param targetObj:
        :param attrs: словарь с атрибутами, которые будут выставлены у объекта мостовой связи
        :param addr: адрес, с которым привяжется targetObj к текущему объекту
        :param info: попадет в одноименный параметр у действия preCreate объекта мостовой свзяи
        :param checkUnique: если True и уже существует объект мостовой связи для текущего объекта и
        targetObj - будет брошено исключение dev_except.BridgeMustBeUnique
        :return:
        """
        if attrs is None:
            attrs = {}
        self.checkLink(linkName, targetObj)
        linkClass = self.equipment.devModel.elementClasses[linkName]
        
        """Проверка на уникальность, нужна для работы драйвера орион про с сервером интеграции ориона"""
        # TODO: WTF есть ли еще такой драйвер и надо ли вообще это если можно выставить уникальность моста?
        if checkUnique :
            chBridgeList = self.getChildListByType(self.getTypeName()+'_'+targetObj.typeName)
            for i in chBridgeList :
                if i.getLinkedElement(targetObj.typeName) == targetObj:
                    logging.getLogger('console').info('not unique link')
                    return
        
        if hasattr(linkClass, 'brg'):
            if linkClass.brg == 'unique':
                linkAddr = self.isLinked(linkName, targetObj)
                if linkAddr > 0:
                    raise dev_except.BridgeMustBeUnique(linkAddr)
        if 'preCreate' in linkClass.actions:
            linkClass.doStaticAction(
                'preCreate', params={
                    'createAttrs': attrs, 'info': info,
                    'targetObj': targetObj, 'mainObj': self
                }
            )
        if addr is not None:
            try:
                link = self.getChildByAddr(linkName, addr)
            except dev_except.ChildNotFound as e:
                pass
            else:
                link.selfDelete()
        newLink = self.equipment.devModel.createElement(
            linkName, False, attrs=attrs, siteId=self.siteId, info=info)

        try:
            self.addChild(newLink, addr)
            newLink.bindElement(linkName.split('_')[1], targetObj)
        except Exception as e:
            self.equipment.devModel.deleteElement(newLink)
            logging.getLogger('console').info("exception: %s" % repr(e))
            raise e

        """
        СОЗДАНИЕ ИНДЕКСА
        """
        index = "%d@%s#%d" % (self.uniId, linkName, targetObj.uniId)
        if index not in linkClass.indexes['bridge']:
            linkClass.indexes['bridge'][index] = newLink
        else:
            indCont = linkClass.indexes['bridge'][index]
            if isinstance(indCont, dict):
                indCont[newLink.getAddr()] = newLink
            else:
                newIndCont = {
                    indCont.getAddr(): indCont, newLink.getAddr(): newLink
                }
                linkClass.indexes['bridge'][index] = newIndCont
        newLink.ownIndexes['bridge'] = index

        #Похоже что это сейчас не надо так как значения всех атрибутов будут отправлены в 1001 или в процессе их
        #установки
        #for attrName in newLink.interface["attrEdits"]:
        #    newLink.attrUpdated(attrName)
        #    newLink.linkUpdated(attrName)

        if 'postCreate' in newLink.actions:
            try:
                newLink.doAction('postCreate')
            except Exception as e:
                logging.getLogger('console').exception("create action fail: %s" % repr(e))
                raise dev_except.PostActionFail(str(e))

        return newLink

    def getRightFarElements(self, equipFilter, typeFilter, linkNameFilter):
        """
        Нужна для поиска у объекта из левой части дальней связи привязанных объектов из правой части дальней связи
        Например, для связи описаной так:
        'orioniso:accesspoint-common:area'		: {
            'in_area'	: {
                'relation'				: u'M:1',
                'alias'					: locale.EntryTimeZone
            }
        }
        чтобы для объекта accesspoint получить связанный объект типа common:area нужно вызвать
            accesspoint.getRightFarElements('common', 'area', 'in_area')

        :param equipFilter: название оборудования
        :param typeFilter: тип объекта внутри оборудования
        :param linkNameFilter: название ссылки
        :return:
        """
        warnings.warn("getRightFarElements() is deprecated, "
                      "use getLinkedElement because of far links now works as standard links",
                      DeprecationWarning, stacklevel=2)

        if self.isLinkedElement(linkNameFilter):
            return [self.getLinkedElement(linkNameFilter)]
        return []

    def getLeftFarElements(self, equipFilter, typeFilter, linkNameFilter):
        """
        Нужна для поиска у объекта из правой части дальней связи привязанных объектов из левой части дальней связи
        Например, для связи описаной так:
        'common:commonright-orioniso:levelaccess'	: {
            'levelaccess'			: {
                'relation'			: u'M:1',
                'alias'				: locale.IsoOrionAccessLevel
            }
        }
        чтобы для объекта levelaccess получить связанный объект типа common:commonright нужно вызвать
            levelaccess.getLeftFarElements('common', 'commonright', 'levelaccess')

        :param equipFilter: название оборудования
        :param typeFilter: тип объекта внутри оборудования
        :param linkNameFilter: название ссылки
        :return:
        """
        warnings.warn("getLeftFarElements() is deprecated, "
                      "use getBackLinkElements because of far links now works as standard links",
                      DeprecationWarning, stacklevel=2)
        return self.getBackLinkElements(typeFilter, linkNameFilter, equipFilter)

    def __walk(self, actName, elements, params=None):
        for el in elements:
            try:
                el.doAction(actName, params)
            except Exception as e:
                logging.getLogger('console').exception("action '%s' fail: %s" % (actName, str(e)))

    def walk(self, actName, childType=None, params=None):
        """
        Перебор детей у объекта и выполнение у них действия

        :param actName: имя выполняемого действия
        :param childType: тип детей, у которых будет выполнено действие, если None - то у всех типов детей
        :param params: параметры, передаваемые в действие
        :return:
        """
        if not childType:
            childTypes = self.equipment.devModel.getChildTypes(self.typeName)
            for childType in childTypes:
                self.__walk(
                    actName,
                    self.getChildListByType(childType),
                    params)
        else:
            self.__walk(actName, self.getChildListByType(childType), params)

    def walkArray(self, actName, linkName, params=None, filter=None):
        """
        Перебор объектов, связанных с текущим объектом мостовой связью с именем linkName и выполнение у них
        действия actName

        :param actName:
        :param linkName:
        :param params: передаваемые в действие параметры
        :param filter: фильтр, аналогичный фильтру функции getElementArray
        :return:
        """
        if params is None:
            params = {}
        if filter is None:
            filter = {}
        self.__walk(actName, self.getElementArray(linkName, filter), params)

    def walkBackLink(self, actName, typeName, linkName, params=None):
        """
        Перебор объектов типа typeName, к которым текущий объект привязан по ссылке с названием linkName
        и выполнение у них действия actName с параметрами params

        :param actName:
        :param typeName:
        :param linkName:
        :param params:
        :return:
        """
        self.__walk(
            actName,
            self.getBackLinkElements(
                typeName,
                linkName),
            params)

    def getBackLinkElements(self, typeName, linkName, equipName=None):
        """
        Поиск объектов типа typeName, к которым текущий объект привязан по ссылке с названием linkName

        :param typeName:
        :param linkName: если у объектов типа typeName нет ссылки с именем linkName - будет брошено исключение
        :param equipName: имя оборудования если получаются обратные ссылки из другого оборудования
        :return: массив с объектами, либо пустой массив
        """
        if equipName:
            elType = self.equipment.devModel[equipName].elementClasses[typeName]
        else:
            elType = self.equipment.devModel.elementClasses[typeName]
        if linkName not in elType.attrs or 'target' not in elType.attrs[linkName]:
            raise Exception("element <type=%s id=%s> has not backlink '%s' to %s type" %
                            (self.typeName, str(self.uniId), linkName, typeName))

        key = '%s,%s' % (typeName, linkName)
        if key in self.backLinks:
            return list(self.backLinks[key].keys())
        return []

    def getBackLinkElementsIter(self, typeName, linkName):
        """
        Поиск объектов типа typeName, к которым текущий объект привязан по ссылке с названием linkName

        :param typeName:
        :param linkName: если у объектов типа typeName нет ссылки с именем linkName - будет брошено исключение
        :return: итератор по ключам словаря с объектами, либо итератор по пустому словарю
        """
        elType = self.equipment.devModel.elementClasses[typeName]
        if linkName not in elType.attrs or 'target' not in elType.attrs[linkName]:
            raise Exception("element <type=%s id=%s> has not backlink '%s' to %s type" %
                            (self.typeName, str(self.uniId), linkName, typeName))

        key = '%s,%s' % (typeName, linkName)
        if key in self.backLinks:
            return iter(self.backLinks[key].keys())
        return iter({}.keys())

    def processEvent(self, evt):
        if 'processEvent' in self.actions:
            try:
                self.doAction('processEvent', {'event': evt})
            except BaseException:
                pass

    def selfDelete(self, deleteAsLink=False):
        """
        Удаление объекта

        :param deleteAsLink: нужна для удаления объекта мостовой связи, передается в delAction параметром, используется только в Apollo и руками трогать не нужно
        :return:
        """
        if 'preDelete' in self.actions:
            """Если указаны действия перед удалением элемента,
            выполняем их. Если они не успешны удаление не происходит"""
            try:
                self.doAction('preDelete', {'deleteAsLink': deleteAsLink})
            except:
                logging.getLogger('console').exception('delAction when selfDelete ERROR')
                raise

        self.finit()

        parentObj = None
        try:
            # Отсоединяем целевые объекты ссылок
            for attrName in self.attrs:
                if 'target' in self.attrs[attrName]:
                    try:
                        if self.flags['archive']:
                            self.unBindElement(attrName, dbCorrect=False)
                        else:
                            self.unBindElement(attrName)
                    except dev_except.PostActionFail:
                        pass

            # Отсоединяем объект от объектов, ссылающихся на него
            # Если ссылающийся объект - мост, то удаляем
            for backLinkName in self.backLinks:
                typeName, linkName = backLinkName.split(',')
                objList = []
                for obj in self.backLinks[backLinkName]:
                    objList.append(obj)
                for obj in objList:
                    if 'bridge' in obj.indexes:
                        # Нужно удалить объект мостовой связи только если он ссылался на удаляемый объект по главной ссылке
                        if linkName == typeName.split('_')[1]:
                            obj.selfDelete(deleteAsLink=True)
                        else:
                            obj.unBindElement(linkName)
                    else:
                        # Если объект архивный, корректировку в главной бд не делаем.
                        # Приследующем запуске могут возникнут "висячие" ссылки.
                        # Они корректируются вовремя загрузки
                        try:
                            if self.flags['archive']:
                                obj.unBindElement(linkName, dbCorrect=False)
                            else:
                                obj.unBindElement(linkName)
                        except dev_except.PostActionFail:
                            pass

            # Отсоединяем детей
            # Если ребенок - мост, то удаляем
            childList = []
            for childType in self.children:
                for childAddr in self.children[childType]:
                    childList.append(self.children[childType][childAddr])
            for obj in childList:
                if 'bridge' in obj.indexes:
                    obj.selfDelete(deleteAsLink=True)
                else:
                    # Если объект архивный, корректировку в главной бд не делаем.
                    # Приследующем запуске могут возникнут "висячие" ссылки на
                    # родителя. Они корректируются вовремя загрузки
                    try:
                        if self.flags['archive']:
                            self.removeChild(obj, dbCorrect=False)
                        else:
                            self.removeChild(obj)
                    except dev_except.PostActionFail:
                        pass

            # Отсоединим себя от родителя
            addr = None

            if self.parent:
                addr = self.getAddr()
                parentObj = self.parent
                # Если объект архивный, корректировку в главной бд не делаем
                try:
                    if self.flags['archive']:
                        self.parent.removeChild(self, dbCorrect=False)
                    else:
                        self.parent.removeChild(self)
                except dev_except.PostActionFail:
                    pass

            # Если объект архивный, то помечаем его как удаленный,
            # иначе удаляем запись об объекте из БД
            if self.flags['archive']:
                self.equipment.dbConn.directRequest("""
                    update %s set flags = flags | 1 where uniid = %%s
                """ % self.tblName, (self.getUniID(),), False)
            else:
                self.equipment.dbConn.directRequest("""
                    delete from %(tbl)s where uniid = %%s
                """ % {'tbl': self.tblName}, (self.getUniID(),), False)

        except Exception as e:
            logging.getLogger('console').exception('selfDelete ERROR')
            self.__correctSetIndexes()
            raise

        self.__correctClrIndexes()

        # Удаляем объект из главного списка всех объектов данного типа
        index = self.getElementIndexById(self.uniId)
        if index is not None:
            self.elements.pop(index)
        if self.remoteGUID in self.elementsGUID:
            del self.elementsGUID[self.remoteGUID]
        if 'bridge' in self.ownIndexes and self.ownIndexes['bridge'] in self.indexes['bridge']:
            indCont = self.indexes['bridge'][self.ownIndexes['bridge']]
            if isinstance(indCont, dict):
                if addr in indCont:
                    del indCont[addr]
                if len(indCont) == 1:
                    for a in indCont:
                        self.indexes['bridge'][self.ownIndexes['bridge']
                                               ] = indCont[a]
            else:
                del self.indexes['bridge'][self.ownIndexes['bridge']]

        self.equipment.devModel.mutationReportDeleteObject(self)

        try:
            params = {}
            for attrName in self.attrs:
                if 'target' not in self.attrs[attrName]:
                    params[attrName] = self.getAttribute(attrName)
            self.__doAction('postDelete', None, params)
        except dev_except.UndefinedAction:
            pass

    def getExtIdForEquip(self):
        return jsonpickle.decode(self.getAttribute('external_data'))

    def setExtIdForEquip(self, status:bool, id_obj:str, guid_root:str):
        ext_data = external_data.ExternalDataPermit(status=status, id_obj=id_obj,
                                                    guid_root=guid_root, name=self.getTypeName).to_json() \
                                                    if self.getTypeName == 'permit' else \
                                                    external_data.ExternalData(id_obj=id_obj, guid_root=guid_root,
                                                                               name=str(self.getTypeName))
        self.setAttribute('external_data', ext_data)





