# -*- coding: utf-8 -*-

import json
import time
from collections import deque
from threading import Thread
from datetime import datetime

from servicebase import ServiceBase
from customjsonencoder import CustomJsonEncoder


class StateObject(object):
    __slots__ = 'ooid', 'state', 'remote_guid', 'time'

    def __init__(self, notification):
        obsObj = notification.get('statement', {}).get('directObj', {}).get('obsObj', {})
        self.ooid = obsObj.get('id')
        self.state = obsObj.get('state')
        self.remote_guid = obsObj.get('remoteGuid')
        self.time = notification.get('notification', {}).get('time')


class StatesCache(ServiceBase):
    def __init__(self, cache_client):
        super(StatesCache, self).__init__()
        self.servicename = 'Кеш состояний объектов мониторинга'
        self.__cache_client = cache_client
        self.__thread = Thread(target=self.__process)
        self.__queue = deque()
        self.__functions = {2000: self.__onSetState,
                            2021: self.__onSetState,
                            2002: self.__onDeleteMonitoringObject}

    def processNotification(self, notif):
        self._logger.info(json.dumps(notif, cls=CustomJsonEncoder))
        if 'notifPack' in notif:
            for notification in notif['notifPack']:
                self.__processOneNotification(notification)
        else:
            self.__processOneNotification(notif)

    def __processOneNotification(self, notif):
        notification = notif.get('notification', {})
        code = notification.get('code')
        action = self.__functions.get(code)
        if not action:
            return
        action(notif)

    def __onDeleteMonitoringObject(self, notification):
        ooid = notification.get('statement', {}).get('id')
        if not ooid:
            return
        self.__cache_client.delete('oo_state_%s' % ooid)

    def __onSetState(self, notification):
        state_obj = StateObject(notification)
        if not state_obj.ooid:
            self._logger.error("Observed object id is None: '%s'" % notification)
            return
        self.__setState(state_obj)

    def __setState(self, state_obj):
        self.__queue.append(state_obj)

    def __process(self):
        while self.isRunning():
            if not self.__queue:  # очередь пуста
                time.sleep(0.5)
                continue
            state_obj = self.__queue.popleft()
            try:
                state_key = 'oo_state_%s' % state_obj.ooid
                state_value = self.__cache_client.get(state_key)
                if state_value:
                    current_state = json.loads(state_value)
                else:
                    current_state = {}
                current_state.update(state_obj.state)
                current_state['time'] = datetime.now().isoformat()
                current_state['id'] = state_obj.ooid
                current_state['remote_id'] = state_obj.remote_guid

                serialized = json.dumps(current_state)
                self.__cache_client.set(state_key, serialized)
            except Exception as e:
                self._logger.exception(e)
                self.__setState(state_obj)

    def onStart(self):
        self._setRunning(True)
        self.__thread.start()

    def onStop(self):
        self._setRunning(False)
        self.__thread.join()
