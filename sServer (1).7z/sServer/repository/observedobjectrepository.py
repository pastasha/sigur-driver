
import json
from typing import Dict, Optional, ValuesView

from esmapi.objects.obsobj import ObsObj, ObsObjLink, DevInfo

from .basicrepository import IGetObject, ISaveObject, IDeleteObject


class ObservedObjectRepository(IGetObject, ISaveObject, IDeleteObject):
    """
    Репозиторий для работы с объектами мониторинга
    """
    def __init__(self, connection, obsObjTypeGetter, mapLayerGetter):
        """
        :param connection: Объект подключение к БД
        :param obsObjTypeGetter: Объект из которого можно получать типы объектов мониторинга
        :param mapLayerGetter: Объект из которого можно получать слои на картах
        """
        self.__connection = connection
        self.__obsObjTypeGetter = obsObjTypeGetter
        self.__mapLayerGetter = mapLayerGetter
        self.__idIndex: Dict[int, ObsObj] = {}
        self.__remoteGuidIndex: Dict[int, ObsObj] = {}
        self.__devIndex: Dict[str, ObsObj] = {}
        self.__loadObjects()

    def get(self, id: int) -> Optional[ObsObj]:
        """
        Получает объект мониторинга по его идентификатору
        :param id: идентификаткор объекта мониторинга
        """
        if id in self.__idIndex:
            return self.__idIndex[id]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[ObsObj]:
        """
        Получает объект мониторинга по его GUID
        :param remoteGuid: GUID объекта мониторинга
        """
        if remoteGuid in self.__remoteGuidIndex:
            return self.__remoteGuidIndex[remoteGuid]
        return None

    def getByDevObject(self, dev: dict) -> Optional[ObsObj]:
        """
        Получает объект мониторинга связанный с объектом оборудования
        :param dev: словарь с данными об объекте оборудования
        """
        equipKey = '%s:%s#%s' % (dev['equip'], dev['type'], dev['id'])
        if equipKey in self.__devIndex:
            return self.__devIndex[equipKey]
        return None

    def getObjects(self) -> ValuesView[ObsObj]:
        """
        Получает объекты всех объект мониторинга которые есть в системе
        """
        return self.__idIndex.values()

    def save(self, obj: ObsObj) -> None:
        """
        Сохраняет объект мониторинга в БД
        :param obj: объект мониторинга для сохранения
        """
        if not obj.id:
            self.__createObject(obj)
        else:
            self.__updateObject(obj)

    def delete(self, id: int) -> None:
        """
        Удаляет данные об объекте мониторинга из БД
        :param id: идентификатор объекта мониторинга для удаления
        """
        self.__connection.directRequest("""
            update observed_objects set deletemark = 1 where id = %s;
            delete from observed_objects_brg where destobj = %s or srcobj = %s
        """, (id, id, id), extract=False)
        obj = self.__idIndex[id]
        del self.__remoteGuidIndex[obj.remoteGuid]
        del self.__idIndex[id]
        if obj.dev:
            equipKey = '%s:%s#%s' % (obj.dev.equip, obj.dev.type, obj.dev.id)
            del self.__devIndex[equipKey]

    def __createObject(self, obj: ObsObj) -> None:
        """
        Создает в БД новую запись с данными из объекта мониторинга
        :param obj: объект мониторинга для сохранения
        """
        data = self.__connection.directRequest("""
            insert into observed_objects(name, devEquipment, devType, devId, type, veracity, alertcount,
            falsealertcount, remotemonitoring, mapLayer, latitude, longitude, altitude,
            additionaldata, falsealerttime, description, remote_guid)
            values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            returning id
        """, params=(obj.name, obj.dev.equip if obj.dev else None, obj.dev.type if obj.dev else None,
                     obj.dev.id if obj.dev else None, obj.type.id, obj.veracity, obj.alertCount,
                     obj.falseAlertCount, obj.remoteMonitoring, obj.maplayer.id if obj.maplayer else None,
                     obj.latitude, obj.longitude, obj.altitude, json.dumps(obj.additionaldata),
                     json.dumps(obj.falseAlertTime), obj.description, obj.remoteGuid), extract=True)

        obj.id = data[0][0]
        self.__saveObjectLinks(obj)
        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj
        if obj.dev:
            equipKey = '%s:%s#%s' % (obj.dev.equip, obj.dev.type, obj.dev.id)
            self.__devIndex[equipKey] = obj

    def __updateObject(self, obj: ObsObj) -> None:
        """
        Обновляет в БД запись с данными из объекта мониторинга
        :param obj: объект мониторинга для сохранения
        :type obj: ObsObj
        :return:
        """
        self.__connection.directRequest("""
            update observed_objects set name = %s, devEquipment = %s, devType = %s, devId = %s, type = %s,
            veracity = %s, alertcount = %s, falsealertcount = %s, remotemonitoring = %s,
            mapLayer = %s, latitude = %s, longitude = %s, altitude = %s, additionaldata = %s,
            falsealerttime = %s, description = %s, remote_guid = %s
            where id = %s
        """, params=(obj.name, obj.dev.equip if obj.dev else None, obj.dev.type if obj.dev else None,
                     obj.dev.id if obj.dev else None, obj.type.id, obj.veracity, obj.alertCount, obj.falseAlertCount,
                     obj.remoteMonitoring, obj.maplayer.id if obj.maplayer else None,
                     obj.latitude, obj.longitude, obj.altitude, json.dumps(obj.additionaldata),
                     json.dumps(obj.falseAlertTime), obj.description, obj.remoteGuid, obj.id), extract=False)
        self.__saveObjectLinks(obj)
        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj
        if obj.dev:
            equipKey = '%s:%s#%s' % (obj.dev.equip, obj.dev.type, obj.dev.id)
            self.__devIndex[equipKey] = obj

    def __saveObjectLinks(self, obj: ObsObj) -> None:
        """
        Сохраняет в БД ссылки между объектом obj и другими объектами. obj является первым объектом
        :param obj: объект к которому прикреплены другие объекты
        """
        # Удалим из БД ссылки которых больше нет
        existsLinks = [str(lnk.id) for lnk in obj.links if lnk.id is not None]
        if existsLinks:
            self.__connection.directRequest("""
                delete from observed_objects_brg where id not in (%s) and destobj = %s
            """ % (','.join(existsLinks), obj.id), extract=False)
        else:
            self.__connection.directRequest("""
                delete from observed_objects_brg where destobj = %s 
            """, params=(obj.id,), extract=False)
        # Вставим новые ссылки
        for lnk in obj.links:
            if lnk.id is None:
                data = self.__connection.directRequest("""
                    insert into observed_objects_brg(srcobj, destobj, nameingroup) values(%s, %s, %s)
                    returning id
                """, params=(lnk.target.id, lnk.src.id, lnk.nameInGroup), extract=True)
                lnk.id = data[0][0]

    def __loadObjects(self):
        """
        Загружает в память все объекты слоев
        """
        data = self.__connection.directRequest("""
            select id, devEquipment, devType, devId, name, type, veracity, alertcount, falsealertcount,
            remotemonitoring, mapLayer, latitude, longitude, altitude, additionaldata,
            falsealerttime, description, remote_guid
            from observed_objects
            where deleteMark = 0
        """, extract=True)
        for id, devEquipment, devType, devId, name, type, veracity, alertcount, falsealertcount, remotemonitoring,\
            mapLayer, latitude, longitude, altitude, additionaldata, falsealerttime,\
            description, remote_guid in data:

            type = self.__obsObjTypeGetter.get(type)
            layer = self.__mapLayerGetter.get(mapLayer)
            dev = None
            if devEquipment:
                data = self.__connection.directRequest("""
                    select remote_guid from %s_%s where uniid = %s
                """ % (devEquipment, devType, devId), extract=True)
                dev_remote_guid = data[0][0] if data and data[0] else ''
                dev = DevInfo(equip=devEquipment, type=devType, id=devId, remoteGuid=dev_remote_guid)
            obsObj = ObsObj(id=id, name=name, type=type, veracity=veracity, alertCount=alertcount,
                            falseAlertCount=falsealertcount, dev=dev, remoteMonitoring=remotemonitoring,
                            maplayer=layer, latitude=latitude,
                            longitude=longitude, altitude=altitude, additionaldata=json.loads(additionaldata),
                            falseAlertTime=json.loads(falsealerttime), description=description, remoteGuid=remote_guid)
            self.__idIndex[id] = obsObj
            self.__remoteGuidIndex[remote_guid] = obsObj
            if obsObj.dev:
                equipKey = '%s:%s#%s' % (obsObj.dev.equip, obsObj.dev.type, obsObj.dev.id)
                self.__devIndex[equipKey] = obsObj

        data = self.__connection.directRequest("""
            select id, srcobj, destobj, nameInGroup
            from observed_objects_brg
            where deleteMark = 0
        """)
        for id, srcObj, destObj, nameInGroup in data:
            src = self.__idIndex[destObj]
            target = self.__idIndex[srcObj]
            elements = src.type.elements
            if nameInGroup not in elements:
                print('wrong link with name %s between objects %s and %s. You need to drop it from database manually' %
                      (nameInGroup, src, target))
                continue
            link = ObsObjLink(id=id, src=src, target=target, nameInGroup=nameInGroup)
            self.__idIndex[destObj].links.append(link)
            self.__idIndex[srcObj].backlinks.append(link)
