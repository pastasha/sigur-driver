
from typing import Optional, List

from esmapi.objects.observedobjectonmap import Map

from .basicrepository import IGetObject


class MapRepository(IGetObject):
    """
    Репозиторий для получения векторных карт
    """

    def __init__(self, connection):
        """
        :param connection: Объект подключение к БД
        """
        self.__connection = connection

    def get(self, id: int) -> Optional[Map]:
        """
        Получает объект карты по её идентификатору
        :param id: идентификаткор карты
        :type id: int
        :return: Map | None
        """
        res = self.__getObjects([id])
        if res:
            return res[0]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[Map]:
        """
        Получает объект карты по её GUID
        :param remoteGuid: GUID карты
        :type remoteGuid: str
        :return: Map | None
        """
        data = self.__connection.directRequest('select uniid from system_map where remote_guid = %s', (remoteGuid,))
        res = self.__getObjects([data[0][0]])
        if res:
            return res[0]
        return None

    def __getObjects(self, ids: List[int]) -> List[Map]:
        """
        Получает список карт с заданными идентификаторами
        :param ids: список идентификаторов для получения
        :type ids: list
        :return: list[Map]
        """
        res = []
        strIds = [str(id) for id in ids]
        data = self.__connection.directRequest("""
            select uniid, remote_guid
            from system_map
            where uniid in (%s)
        """ % ','.join(strIds), extract=True)
        for obsObj in data:
            res.append(Map(id=obsObj[0], remoteGuid=obsObj[1]))
        return res
