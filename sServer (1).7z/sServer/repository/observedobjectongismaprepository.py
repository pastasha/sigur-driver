
from typing import Dict, List, Optional, ValuesView

import json
import logging

from esmapi.objects.observedobjectonmap import ObservedObjectOnGisMap, Map

from .basicrepository import IGetObject, ISaveObject, IDeleteObject
from .observedobjectrepository import ObservedObjectRepository


class ObservedObjectOnGisMapRepository(IGetObject, ISaveObject, IDeleteObject):
    """
    Репозиторий для работы с объектами расположенными на ГИС картах
    """
    def __init__(self, connection, observedObjectGetter: ObservedObjectRepository):
        """
        :param connection: Объект подключение к БД
        :param observedObjectGetter: Объект из которого можно получать объекты мониторинга
        """
        self.__connection = connection
        self.__observedObjectGetter = observedObjectGetter
        self.__idIndex: Dict[int, ObservedObjectOnGisMap] = {}
        self.__remoteGuidIndex: Dict[str, ObservedObjectOnGisMap] = {}
        self.__loadObjects()

    def get(self, id: int) -> Optional[ObservedObjectOnGisMap]:
        """
        Получает объект иконки по его идентификатору
        :param id: идентификаткор объекта
        """
        if id in self.__idIndex:
            return self.__idIndex[id]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[ObservedObjectOnGisMap]:
        """
        Получает объект иконки по его GUID
        :param remoteGuid: GUID объекта
        """
        if remoteGuid in self.__remoteGuidIndex:
            return self.__remoteGuidIndex[remoteGuid]
        return None

    def getByMapId(self, mapId: int) -> List[ObservedObjectOnGisMap]:
        """
        Получает все объекты расположенные на карте с идентификатором mapId
        :param mapId: идентификатор карты
        """
        res = []
        for obj in self.__idIndex.values():
            if obj.map.id == mapId:
                res.append(obj)
        return res

    def getObjects(self) -> ValuesView[ObservedObjectOnGisMap]:
        """
        Получает объекты всех иконок которые есть в системе
        """
        return self.__idIndex.values()

    def save(self, obj: ObservedObjectOnGisMap) -> None:
        """
        Сохраняет объект иконки в БД
        :param obj: объект иконки для сохранения
        """
        if not obj.id:
            self.__createObject(obj)
        else:
            self.__updateObject(obj)

    def delete(self, id: int) -> None:
        """
        Удаляет данные об иконкииз БД
        """
        self.__connection.directRequest('delete from observed_objects_on_gismap where id = %s', (id,), extract=False)
        obj = self.__idIndex[id]
        del self.__remoteGuidIndex[obj.remoteGuid]
        del self.__idIndex[id]

    def __createObject(self, obj: ObservedObjectOnGisMap) -> None:
        """
        Создает в БД новую запись с данными из объекта иконки
        :param obj: объект иконки для сохранения
        """
        data = self.__connection.directRequest("""
            insert into observed_objects_on_gismap(map_id, obsobj_id, icon_type, icon_id, latitude, longitude,
            angle, geojson, remote_guid)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            returning id
        """, params=(obj.map.id, obj.obsObj.id, obj.iconType, obj.iconId, obj.latitude, obj.longitude,
                     obj.angle, json.dumps(obj.geojson), obj.remoteGuid), extract=True)

        obj.id = data[0][0]

        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __updateObject(self, obj: ObservedObjectOnGisMap) -> None:
        """
        Обновляет в БД запись с данными из объекта иконки
        :param obj: объект иконки для сохранения
        """
        self.__connection.directRequest("""
            update observed_objects_on_gismap set map_id = %s, obsobj_id = %s, icon_type = %s,
            icon_id = %s, latitude = %s, longitude = %s, angle = %s, geojson = %s
            where id = %s
        """, params=(obj.map.id, obj.obsObj.id, obj.iconType, obj.iconId, obj.latitude, obj.longitude,
                     obj.angle, json.dumps(obj.geojson), obj.id), extract=False)
        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __loadObjects(self):
        """
        Загружает в память все объекты слоев
        """
        data = self.__connection.directRequest("""
            select obj.id, obj.map_id, obj.obsobj_id, obj.icon_type, obj.icon_id, obj.longitude, obj.latitude,
            obj.angle, obj.geojson, obj.remote_guid, m.remote_guid
            from observed_objects_on_gismap obj, system_gismap m
            where obj.map_id = m.uniid
        """, extract=True)
        for id, mapId, obsobjId, iconType, iconId, longitude, latitude, angle, geojson, remote_guid, m_remote_guid in data:
            m = Map(id=mapId, remoteGuid=m_remote_guid)
            obsObj = self.__observedObjectGetter.get(obsobjId)
            if obsObj is None:
                logging.getLogger('console').info(
                    'Wrong link  between obsObj <id = %s> and gismap <mapid = %s>. You need to drop it from database'
                    ' manually' % (obsobjId, mapId))
                continue
            obj = ObservedObjectOnGisMap(id=id, map=m, obsObj=obsObj, iconType=iconType, iconId=iconId,
                                         latitude=latitude, longitude=longitude, geojson=geojson, angle=angle,
                                         remoteGuid=remote_guid)
            self.__idIndex[id] = obj
            self.__remoteGuidIndex[remote_guid] = obj
