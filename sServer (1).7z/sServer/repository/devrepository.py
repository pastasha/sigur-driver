
from typing import Optional, List

from esmapi.objects.equipmentobject import EquipmentObject


class DevRepository(object):
    """
    Репозиторий для получения базовой информации об объекте оборудования
    """

    def __init__(self, connection):
        """
        :param connection: Объект подключение к БД
        """
        self.__connection = connection

    def get(self, equip: str, type: str, id: int) -> Optional[EquipmentObject]:
        """
        Получает объект оборудования по данным
        :param equip: название оборудования
        :param type: название типа оборудования
        :param id: идентификаткор объекта оборудования
        """
        res = self.__getObjects(equip, type, [id])
        if res:
            return res[0]
        return None

    def getByRemoteGuid(self, equip: str, type: str, remoteGuid: str) -> Optional[EquipmentObject]:
        """
        Получает объект карты по данным и GUID
        :param equip: название оборудования
        :param type: название типа оборудования
        :param remoteGuid: GUID объекта
        """
        data = self.__connection.directRequest('select uniid from %s_%s where remote_guid = %%s' % (equip, type),
                                               (remoteGuid,))
        res = self.__getObjects(equip, type, [data[0][0]])
        if res:
            return res[0]
        return None

    def __getObjects(self, equip: str, type: str, ids: List[int]) -> List[EquipmentObject]:
        """
        Получает список объектов оборудования с заданными идентификаторами
        :param equip: название оборудования
        :type equip: str
        :param type: название типа оборудования
        :type type: str
        :param ids: список идентификаторов для получения
        :type ids: list
        :return: list[Map]
        """
        res = []
        strIds = [str(id) for id in ids]
        data = self.__connection.directRequest("""
            select uniid, remote_guid
            from %s_%s
            where uniid in (%s)
        """ % (equip, type, ','.join(strIds)), extract=True)
        for devObj in data:
            res.append(EquipmentObject(equip=equip, type=type, id=devObj[0], remoteGuid=devObj[1]))
        return res
