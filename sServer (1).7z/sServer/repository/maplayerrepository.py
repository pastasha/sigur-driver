
from typing import Dict, ValuesView, Optional

from esmapi.objects.maplayer import MapLayer

from .basicrepository import IGetObject, ISaveObject, IDeleteObject


class MapLayerRepository(IGetObject, ISaveObject, IDeleteObject):
    """
    Репозиторий для работы со слоями на картах
    """
    def __init__(self, connection):
        """
        :param connection: Объект подключение к БД
        """
        self.__connection = connection
        self.__idIndex: Dict[int, MapLayer] = {}
        self.__remoteGuidIndex: Dict[str, MapLayer] = {}
        self.__loadObjects()

    def get(self, id: int) -> Optional[MapLayer]:
        """
        Получает объект слоя по его идентификатору
        :param id: идентификаткор слоя
        """
        if id in self.__idIndex:
            return self.__idIndex[id]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[MapLayer]:
        """
        Получает объект слоя по его GUID
        :param remoteGuid: GUID слоя
        """
        if remoteGuid in self.__remoteGuidIndex:
            return self.__remoteGuidIndex[remoteGuid]
        return None

    def getObjects(self) -> ValuesView[MapLayer]:
        """
        Получает объекты всех слоев которые есть в системе
        """
        return self.__idIndex.values()

    def save(self, obj: MapLayer) -> None:
        """
        Сохраняет объект слоя в БД
        :param obj: объект слоя для сохранения
        """
        if not obj.id:
            self.__createObject(obj)
        else:
            self.__updateObject(obj)

    def delete(self, id: int) -> None:
        """
        Удаляет данные об объекте слоя из БД
        """
        self.__connection.directRequest('delete from map_layer where id = %s', (id,), extract=False)
        obj = self.__idIndex[id]
        del self.__remoteGuidIndex[obj.remoteGuid]
        del self.__idIndex[id]

    def __createObject(self, obj: MapLayer) -> None:
        """
        Создает в БД новую запись с данными из объекта слоя
        :param obj: объект слоя для сохранения
        :type obj: MapLayer
        :return:
        """
        data = self.__connection.directRequest("""
            insert into map_layer(name, icon, remote_guid)
            values(%s, %s, %s)
            returning id
        """, params=(obj.name, obj.icon, obj.remoteGuid), extract=True)

        obj.id = data[0][0]

        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __updateObject(self, obj: MapLayer) -> None:
        """
        Обновляет в БД запись с данными из объекта слоя
        :param obj: объект слоя для сохранения
        :type obj: MapLayer
        :return:
        """
        self.__connection.directRequest('update map_layer set name = %s, icon = %s where id = %s', params=(
            obj.name, obj.icon, obj.id), extract=False)
        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __loadObjects(self):
        """
        Загружает в память все объекты слоев
        """
        data = self.__connection.directRequest("""
            select id, name, icon, remote_guid
            from map_layer
        """, extract=True)
        for id, name, icon, remote_guid in data:
            layer = MapLayer(id=id, name=name, icon=icon, remoteGuid=remote_guid)
            self.__idIndex[id] = layer
            self.__remoteGuidIndex[remote_guid] = layer
