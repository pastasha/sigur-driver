
from typing import Dict, Optional, ValuesView

from esmapi.objects.event import Event
from licensemanager.licensemanager import License

from .basicrepository import IGetObject, ISaveObject, IDeleteObject


class EventRepository(IGetObject, ISaveObject, IDeleteObject):
    """
    Репозиторий для работы с типами событий
    """
    def __init__(self, connection, license: License):
        """
        :param connection: Объект подключение к БД
        :param license: Информация о лицензии
        """
        self.__connection = connection
        self.__license = license
        self.__idIndex: Dict[int, Event] = {}
        self.__remoteGuidIndex: Dict[str, Event] = {}
        self.__loadObjects()

    def get(self, id: int) -> Optional[Event]:
        """
        Получает объект типа события по его идентификатору
        :param id: идентификаткор типа события
        """
        if id in self.__idIndex:
            return self.__idIndex[id]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[Event]:
        """
        Получает объект типа событи по его GUID
        :param remoteGuid: GUID типа события
        """
        if remoteGuid in self.__remoteGuidIndex:
            return self.__remoteGuidIndex[remoteGuid]
        return None

    def getByCode(self, code: int) -> Optional[Event]:
        """
        Получает объект типа события по его коду
        :param code: код события
        """
        for _, ev in self.__idIndex.items():
            if ev.code == code:
                return ev
        return None

    def getObjects(self) -> ValuesView[Event]:
        """
        Получает объекты всех типов событий которые есть в системе
        """
        return self.__idIndex.values()

    def save(self, obj: Event) -> None:
        """
        Сохраняет объект типа события в БД
        :param obj: объект типа события для сохранения
        """
        if not obj.id:
            self.__createObject(obj)
        else:
            self.__updateObject(obj)

    def delete(self, id: int) -> None:
        """
        Удаляет данные об объекте типа события из БД
        :param id: идентификатор объекта для удаления
        :return:
        """
        self.__connection.directRequest('update event_catalog set deletemark = 1 where id = %s', (id,), extract=False)
        obj = self.__idIndex[id]
        del self.__remoteGuidIndex[obj.remoteGuid]
        del self.__idIndex[id]

    def __createObject(self, obj: Event) -> None:
        """
        Создает в БД новую запись с данными из объекта типа события
        :param obj: объект типа события для сохранения
        """
        data = self.__connection.directRequest("""
            insert into event_catalog(code, description, equipment, format, options, level, color, channel, remote_guid)
            values(%s, %s, %s, %s, %s, %s, %s, %s, %s)
            returning id
        """, params=(obj.code, obj.description, obj.equipment, obj.format, obj.options, obj.level, obj.color,
                     obj.channel, obj.remoteGuid), extract=True)

        obj.id = data[0][0]

        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __updateObject(self, obj: Event) -> None:
        """
        Обновляет в БД запись с данными из объекта типа события
        :param obj: объект типа события для сохранения
        :type obj: Event
        :return:
        """
        self.__connection.directRequest("""
            update event_catalog set description = %s, equipment = %s, format = %s, options = %s, level = %s,
            color = %s, channel = %s
            where id = %s
        """, params=(
            obj.description, obj.equipment, obj.format, obj.options, obj.level, obj.color, obj.channel, obj.id),
                                        extract=False)
        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __loadObjects(self):
        """
        Загружает в память все объекты типов событий
        """
        equipments = self.__license.getAvailableEquipments()
        # Оказывается что system и common нет в списке оборудования в линцезии. Добавим их железно
        equipments.extend(['system', 'common'])
        data = self.__connection.directRequest("""
            select id, code, description, equipment, options, format, level, color, channel, remote_guid
            from event_catalog
            where deleteMark = 0 and equipment in %s
        """, params=(tuple(equipments),), extract=True)
        for id, code, description, equipment, options, format, level, color, channel, remote_guid in data:
            event = Event(id=id, code=code, description=description, equipment=equipment, format=format,
                          options=options, level=level, channel=channel, color=color, remoteGuid=remote_guid)
            self.__idIndex[id] = event
            self.__remoteGuidIndex[remote_guid] = event
