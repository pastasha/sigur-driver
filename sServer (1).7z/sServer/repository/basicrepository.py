# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod


class ISaveObject(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def save(self, obj):
        """
        Сохраняет объект obj в БД
        :param obj: Объект который нужно сохранить
        :return:
        """


class IGetObject(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def get(self, id):
        """
        Получает объект из БД по идентификатору
        :param id: Идентификатор получаемого объекта
        :return:
        """

    @abstractmethod
    def getByRemoteGuid(self, guid):
        """
        Получает объект из БД по Guid
        :param guid: Guid получаемого объекта
        :return:
        """


class IDeleteObject(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def delete(self, id):
        """
        Удаляет объект из БД по идентификатору
        :param id: Идентификатор удаляемого объекта
        :return:
        """