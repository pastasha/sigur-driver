
import json
from typing import Dict, Optional, ValuesView

from esmapi.objects.obsobjtype import ObsObjType, ObsObjTypeEventBrg

from .basicrepository import IGetObject, ISaveObject, IDeleteObject
from .eventrepository import EventRepository


class ObservedObjectTypeRepository(IGetObject, ISaveObject, IDeleteObject):
    """
    Репозиторий для работы с типами объектов мониторинга
    """
    def __init__(self, connection, eventsGetter: EventRepository):
        """
        :param connection: Объект подключение к БД
        :param eventsGetter: Объект у которого можно получить события по кодам
        """
        self.__connection = connection
        self.__eventsGetter = eventsGetter
        self.__idIndex: Dict[int, ObsObjType] = {}
        self.__remoteGuidIndex: Dict[str, ObsObjType] = {}
        self.__loadObjects()

    def get(self, id: int) -> Optional[ObsObjType]:
        """
        Получает объект типа объекта мониторинга по его идентификатору
        :param id: идентификаткор типа объекта мониторинга
        """
        if id in self.__idIndex:
            return self.__idIndex[id]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[ObsObjType]:
        """
        Получает объект типа объекта мониторинга по его GUID
        :param remoteGuid: GUID типа объекта мониторинга
        """
        if remoteGuid in self.__remoteGuidIndex:
            return self.__remoteGuidIndex[remoteGuid]
        return None

    def getObjects(self) -> ValuesView[ObsObjType]:
        """
        Получает объекты всех типов объекта мониторинга которые есть в системе
        """
        return self.__idIndex.values()

    def save(self, obj: ObsObjType) -> None:
        """
        Сохраняет объект типа объекта мониторинга в БД
        :param obj: объект типа объекта мониторинга для сохранения
        """
        if not obj.id:
            self.__createObject(obj)
        else:
            self.__updateObject(obj)

    def delete(self, id: int) -> None:
        """
        Удаляет данные о типе объекта мониторинга из БД
        """
        self.__connection.directRequest("""
            update observed_objects_types set deletemark = 1 where id = %s;
            update obsobj_type_event_brg set deletemark = 1 where typeid = %s
        """, (id, id), extract=False)
        obj = self.__idIndex[id]
        del self.__remoteGuidIndex[obj.remoteGuid]
        del self.__idIndex[id]

    def __createObject(self, obj: ObsObjType) -> None:
        """
        Создает в БД новую запись с данными из объекта типа
        :param obj: объект типа для сохранения
        """
        data = self.__connection.directRequest("""
            insert into observed_objects_types(name, elements, actions, kind, calculation_handlers,
            falsealertlimit, falsealertcontroltime, controltimemeasure, remote_guid)
            values(%s, %s, %s, %s, %s, %s, %s, %s, %s)
            returning id
        """, params=(obj.name, json.dumps(obj.elements), json.dumps(obj.actions), obj.kind,
                     json.dumps(obj.stateCalculation), obj.falseAlertLimit, obj.falseAlertControlTime,
                     obj.controlTimeMeasure, obj.remoteGuid), extract=True)

        obj.id = data[0][0]

        for eventBrg in obj.events:
            self.__connection.directRequest("""
                insert into obsobj_type_event_brg(typeid, event_id, newevent_id)
                values(%s, %s, %s)
            """, params=(obj.id, eventBrg.event.id, eventBrg.newEvent.id), extract=False)

        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __updateObject(self, obj: ObsObjType) -> None:
        """
        Обновляет в БД запись с данными из объекта типа
        :param obj: объект типа для сохранения
        """
        self.__connection.directRequest("""
            update observed_objects_types set name = %s, elements = %s, actions = %s, kind = %s,
            calculation_handlers = %s, falsealertlimit = %s, falsealertcontroltime = %s, controltimemeasure = %s,
            remote_guid = %s
            where id = %s
        """, params=(obj.name, json.dumps(obj.elements), json.dumps(obj.actions), obj.kind,
                     json.dumps(obj.stateCalculation), obj.falseAlertLimit, obj.falseAlertControlTime,
                     obj.controlTimeMeasure, obj.remoteGuid, obj.id), extract=False)

        self.__connection.directRequest("""
            update obsobj_type_event_brg set deletemark = 1 where typeid = %s
        """, (obj.id,), extract=False)

        for eventBrg in obj.events:
            self.__connection.directRequest("""
                insert into obsobj_type_event_brg(typeid, event_id, newevent_id)
                values(%s, %s, %s)
            """, params=(obj.id, eventBrg.event.id, eventBrg.newEvent.id), extract=False)

        self.__idIndex[obj.id] = obj
        self.__remoteGuidIndex[obj.remoteGuid] = obj

    def __loadObjects(self):
        """
        Загружает в память все объекты типов объектов мониторинга
        """
        data = self.__connection.directRequest("""
            select id, name, elements, actions, kind, calculation_handlers, falsealertlimit,
            falsealertcontroltime, controltimemeasure, remote_guid
            from observed_objects_types
            where deleteMark = 0
        """, extract=True)
        for id, name, elements, actions, kind, calculation_handlers, falsealertlimit, falsealertcontroltime,\
                controltimemeasure, remote_guid in data:
            events = []
            eventsData = self.__connection.directRequest("""
                select event_id, newevent_id
                from obsobj_type_event_brg
                where deleteMark = 0 and typeId = %s
            """, params=(id,), extract=True)
            for event_id, newevent_id in eventsData:
                event = self.__eventsGetter.get(event_id)
                newEvent = self.__eventsGetter.get(newevent_id)
                events.append(ObsObjTypeEventBrg(event=event, newEvent=newEvent))

            try:
                elements = json.loads(elements)
            except:
                elements = {}
            try:
                actions = json.loads(actions)
            except:
                actions = {}
            obsObjType = ObsObjType(id=id, name=name, elements=elements, actions=actions, kind=kind,
                                    stateCalculation=json.loads(calculation_handlers), falseAlertLimit=falsealertlimit,
                                    falseAlertControlTime=falsealertcontroltime, controlTimeMeasure=controltimemeasure,
                                    events=events, remoteGuid=remote_guid)
            self.__idIndex[id] = obsObjType
            self.__remoteGuidIndex[remote_guid] = obsObjType
