
from typing import Optional, List

from esmapi.objects.observedobjectonmap import Map

from .basicrepository import IGetObject


class GisMapRepository(IGetObject):
    """
    Репозиторий для получения ГИС карт
    """

    def __init__(self, connection):
        """
        :param connection: Объект подключение к БД
        """
        self.__connection = connection

    def get(self, id: int) -> Optional[Map]:
        """
        Получает объект карты по её идентификатору
        :param id: идентификаткор карты
        """
        res = self.__getObjects([id])
        if res:
            return res[0]
        return None

    def getByRemoteGuid(self, remoteGuid: str) -> Optional[Map]:
        """
        Получает объект карты по её GUID
        :param remoteGuid: GUID карты
        """
        data = self.__connection.directRequest('select uniid from system_gismap where remote_guid = %s', (remoteGuid,))
        res = self.__getObjects([data[0][0]])
        if res:
            return res[0]
        return None

    def __getObjects(self, ids: List[int]) -> List[Map]:
        """
        Получает список карт с заданными идентификаторами
        :param ids: список идентификаторов для получения
        """
        res = []
        strIds = [str(id) for id in ids]
        data = self.__connection.directRequest("""
            select uniid, remote_guid
            from system_gismap
            where uniid in (%s)
        """ % ','.join(strIds), extract=True)
        for obsObj in data:
            res.append(Map(id=obsObj[0], remoteGuid=obsObj[1]))
        return res
