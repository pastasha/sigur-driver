
import plugins.uus as uus

ulu = uus.UluModule("\\\\.\\pipe\\SW_ORION", 123)
input()
print((ulu.command({"code": 1, "action": 3, "type": "zone",
                   "hwaddr": [8, 1, 1015], "card": 111})));
input()
ulu.close()
