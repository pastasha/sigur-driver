# -*- coding: utf-8 -*-

import psycopg2


class DBModule:
    '''Интерфейс работы с базой данных'''

    def __init__(self, conStr):
        self.conn = psycopg2.connect(conStr, application_name='sServer')
        self.conn.autocommit = True
        psycopg2.extensions.register_type(
            psycopg2.extensions.UNICODE, self.conn)

    def cursor(self):
        return self.conn.cursor()

    def commit(self):
        self.conn.commit()

    def directRequest(self, stmt, params=None, extract=True):
        if not params:
            params = []

        dbCursor = self.conn.cursor()
        dbCursor.execute(stmt, params)
        if extract:
            return dbCursor.fetchall()
        else:
            self.conn.commit()
