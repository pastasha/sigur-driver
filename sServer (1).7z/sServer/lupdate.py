# -*- coding: utf-8 -*-

# Скрипт для составления и обновления файлов переводов оборудований
# В папке каждого оборудования получается xml файл по одному файлу для каждого языка
# Перевод осуществляется с русского языка на другие

import sys
import os
from xml.dom.minidom import *
from lxml import etree as ET
import inspect
import datetime
import importlib
import importlib.util
import logging

from equipment.protocol_obj_base import property_wrapper, Attribute, Link


class Element:
    """
    Класс для представления собранной информации по оборудовнию.
    Из атрибутов этого класса формируется структура 'struct' для составления файла перевода
    """
    typeName = ''
    interface = {}
    attrs = {}
    actions = {}
    equipment = None
    parentLink = {}
    exportAttrs = []

def loadTranslateFromFile(filePath):
    translateCfg = parse(filePath)
    translateCfg = translateCfg.getElementsByTagName('equipment')[0]
    equipmentAliasEl = translateCfg.getElementsByTagName('alias')[0]
    equipmentAlias = equipmentAliasEl.getElementsByTagName('source')[
        0].childNodes[0].data
    equipmentTranslation = equipmentAliasEl.getElementsByTagName('translation')[
        0].childNodes[0].data
    translateStruct = {
        'alias'		: {
            'source'		: equipmentAlias,
            'translation'	: equipmentTranslation
        },
        'devTypes'	: {},
        'strings'	: {}
    }
    devTypes = translateCfg.getElementsByTagName(
        'devTypes')[0].getElementsByTagName('devType')
    for devTypeEl in devTypes:
        devTypeName = devTypeEl.getAttribute('name')
        devAliasEl = devTypeEl.getElementsByTagName('alias')[0]
        if len(devAliasEl.getElementsByTagName('source')[0].childNodes) != 0:
            devAlias = devAliasEl.getElementsByTagName(
                'source')[0].childNodes[0].data
        else:
            devAlias = ''
        devTranslation = devAliasEl.getElementsByTagName('translation')[
            0].childNodes[0].data
        devTypeTranslateStruct = {
            'alias'		: {
                'source'		: devAlias,
                'translation'	: devTranslation
            },
            'parent'	: None,
            'fields'	: {},
            'links'		: {},
            'unilinks'	: {},
            'actions'	: {}
        }
        devParentEl = devTypeEl.getElementsByTagName('parent')
        if len(devParentEl) != 0:
            devParentEl = devParentEl[0]
            devParentAlias = devParentEl.getElementsByTagName('source')[
                0].childNodes[0].data
            devParentTranslation = devParentEl.getElementsByTagName('translation')[
                0].childNodes[0].data
            devTypeTranslateStruct['parent'] = {
                'source'		: devParentAlias,
                'translation'	: devParentTranslation
            }
        for fieldEl in devTypeEl.getElementsByTagName('field'):
            fieldName = fieldEl.getAttribute('name')
            try:
                fieldAlias = fieldEl.getElementsByTagName(
                    'source')[0].childNodes[0].data
            except IndexError as e:
                logging.warning('WRONG: %s in %s path= %s' % (e, fieldName, filePath))
                fieldAlias = ''
            fieldTranslation = fieldEl.getElementsByTagName('translation')[
                0].childNodes[0].data
            devTypeTranslateStruct['fields'][fieldName] = {
                'source'		: fieldAlias,
                'translation'	: fieldTranslation
            }
            type = fieldEl.getElementsByTagName('type')
            if len(type) > 0:
                devTypeTranslateStruct['fields'][fieldName]['type'] = []
                for t in type:
                    typeAlias = t.getElementsByTagName(
                        'source')[0].childNodes[0].data
                    typeTranslation = t.getElementsByTagName(
                        'translation')[0].childNodes[0].data
                    devTypeTranslateStruct['fields'][fieldName]['type'].append({
                        'source': typeAlias,
                        'translation': typeTranslation,
                    })
        for linkEl in devTypeEl.getElementsByTagName('link'):
            linkName = linkEl.getAttribute('name')
            try:
                linkAlias = linkEl.getElementsByTagName(
                    'source')[0].childNodes[0].data
                linkTranslation = linkEl.getElementsByTagName(
                    'translation')[0].childNodes[0].data
            except Exception:
                linkAlias = ''
                linkTranslation = ''

            devTypeTranslateStruct['links'][linkName] = {
                'source'		: linkAlias,
                'translation'	: linkTranslation
            }
        for unilinkEl in devTypeEl.getElementsByTagName('unilink'):
            unilinkName = unilinkEl.getAttribute('name')
            unilinkAlias = unilinkEl.getElementsByTagName(
                'source')[0].childNodes[0].data
            unilinkTranslation = unilinkEl.getElementsByTagName('translation')[
                0].childNodes[0].data
            devTypeTranslateStruct['unilinks'][unilinkName] = {
                'source'		: unilinkAlias,
                'translation'	: unilinkTranslation
            }
        for actEl in devTypeEl.getElementsByTagName('action'):
            actName = actEl.getAttribute('name')
            try:
                actAlias = actEl.getElementsByTagName(
                        'source')[0].childNodes[0].data
            except Exception:
                actAlias = 'undefined'
            actTranslation = actEl.getElementsByTagName(
                'translation')[0].childNodes[0].data
            actStruct = {
                'alias'		: {
                    'source'		: actAlias,
                    'translation'	: actTranslation
                },
                'params'	: {}
            }
            for paramEl in actEl.getElementsByTagName(
                    'params')[0].getElementsByTagName('param'):
                paramName = paramEl.getAttribute('name')
                try:
                    paramAlias = paramEl.getElementsByTagName(
                        'source')[0].childNodes[0].data
                except Exception:
                    paramAlias = 'undefined'

                paramTranslation = paramEl.getElementsByTagName('translation')[
                    0].childNodes[0].data
                actStruct['params'][paramName] = {
                    'source'		: paramAlias,
                    'translation'	: paramTranslation
                }
            devTypeTranslateStruct['actions'][actName] = actStruct

        translateStruct['devTypes'][devTypeName] = devTypeTranslateStruct
    strings = translateCfg.getElementsByTagName(
        'strings')[0].getElementsByTagName('string')
    for stringEl in strings:
        stringName = stringEl.getAttribute('name')
        stringText = stringEl.getElementsByTagName(
            'source')[0].childNodes[0].data
        stringTranslation = stringEl.getElementsByTagName('translation')[
            0].childNodes[0].data
        translateStruct['strings'][stringName] = {
            'source'		: stringText,
            'translation'	: stringTranslation
        }
    return translateStruct


def makeTranslateFileForEquipment(equipment, struct, language):
    equipmentDir = '%s_protocol_config' % equipment
    tsFileName = equipmentDir + '/translate_%s.ts' % language
    tsStruct = None
    if os.path.exists(tsFileName):
        # Если файл уже есть, значит мы составляли перевод ранее. Прочитаем из него данные
        tsStruct = loadTranslateFromFile(tsFileName)
    tsRootElement = ET.Element('equipment')
    tsRootElement.set('name', equipment)
    tsAliasElement = ET.SubElement(tsRootElement, 'alias')
    ET.SubElement(tsAliasElement, 'source').text = struct['alias']
    if tsStruct and tsStruct['alias']['source'] == struct['alias']:
        # Если в структуре считанной из файла уже было переведено описание такого оборудования возьмем его для записи в итоговый файл
        ET.SubElement(
            tsAliasElement,
            'translation').text = tsStruct['alias']['translation']
    else:
        ET.SubElement(tsAliasElement, 'translation').text = 'undefined'
    tsDevTypesElement = ET.SubElement(tsRootElement, 'devTypes')
    for devType in struct['devTypes']:
        devTypeTsStruct = tsStruct['devTypes'][devType] if tsStruct and devType in tsStruct['devTypes'] else None
        tsDevTypeElement = ET.SubElement(tsDevTypesElement, 'devType')
        tsDevTypeElement.set('name', devType)
        devType = struct['devTypes'][devType]
        tsDevTypeAliasElement = ET.SubElement(tsDevTypeElement, 'alias')
        ET.SubElement(tsDevTypeAliasElement, 'source').text = devType['alias']
        if devTypeTsStruct and devTypeTsStruct['alias']['source'] == devType['alias']:
            # Если в структуре считанной из файла уже был переведено описания такого типа объекта возьмем его для записи в итоговый файл
            ET.SubElement(
                tsDevTypeAliasElement,
                'translation').text = devTypeTsStruct['alias']['translation']
        else:
            ET.SubElement(
                tsDevTypeAliasElement,
                'translation').text = 'undefined'
        if devType['parent']:
            tsDevTypeParentElement = ET.SubElement(tsDevTypeElement, 'parent')
            ET.SubElement(
                tsDevTypeParentElement,
                'source').text = devType['parent']
            if devTypeTsStruct and devTypeTsStruct['parent'] and devTypeTsStruct[
                    'parent']['source'] == devType['parent']:
                ET.SubElement(
                    tsDevTypeParentElement,
                    'translation').text = devTypeTsStruct['parent']['translation']
            else:
                ET.SubElement(
                    tsDevTypeParentElement,
                    'translation').text = 'undefined'
        fieldsTsStruct = devTypeTsStruct['fields'] if devTypeTsStruct else None
        for field in devType['fields']:
            tsFieldElement = ET.SubElement(tsDevTypeElement, 'field')
            tsFieldElement.set('name', field)
            ET.SubElement(
                tsFieldElement,
                'source').text = devType['fields'][field]['alias']
            if fieldsTsStruct and field in fieldsTsStruct and fieldsTsStruct[
                    field]['source'] == devType['fields'][field]['alias']:
                ET.SubElement(
                    tsFieldElement,
                    'translation').text = fieldsTsStruct[field]['translation']
            else:
                ET.SubElement(tsFieldElement, 'translation').text = 'undefined'
            if 'type' in devType['fields'][field]:
                for s in devType['fields'][field]['type']:
                    typeElement = ET.SubElement(tsFieldElement, 'type')
                    ET.SubElement(typeElement, 'source').text = s
                    t = 'undefined'
                    if fieldsTsStruct and field in fieldsTsStruct and 'type' in fieldsTsStruct[
                            field]:
                        for tr in fieldsTsStruct[field]['type']:
                            if tr['source'] == s:
                                t = tr['translation']
                    ET.SubElement(typeElement, 'translation').text = t
        linksTsStruct = devTypeTsStruct['links'] if devTypeTsStruct else None
        for link in devType['links']:
            tsLinkElement = ET.SubElement(tsDevTypeElement, 'link')
            tsLinkElement.set('name', link)
            ET.SubElement(
                tsLinkElement,
                'source').text = devType['links'][link]
            if linksTsStruct and link in linksTsStruct and linksTsStruct[
                    link]['source'] == devType['links'][link]:
                ET.SubElement(
                    tsLinkElement,
                    'translation').text = linksTsStruct[link]['translation']
            else:
                ET.SubElement(tsLinkElement, 'translation').text = 'undefined'
        unilinksTsStruct = devTypeTsStruct['unilinks'] if devTypeTsStruct else None
        for unilink in devType['unilinks']:
            tsUnilinkElement = ET.SubElement(tsDevTypeElement, 'unilink')
            tsUnilinkElement.set('name', unilink)
            ET.SubElement(
                tsUnilinkElement,
                'source').text = devType['unilinks'][unilink]
            if unilinksTsStruct and unilink in unilinksTsStruct and unilinksTsStruct[
                    unilink]['source'] == devType['unilinks'][unilink]:
                ET.SubElement(
                    tsUnilinkElement,
                    'translation').text = unilinksTsStruct[unilink]['translation']
            else:
                ET.SubElement(
                    tsUnilinkElement,
                    'translation').text = 'undefined'
        actionsTsStruct = devTypeTsStruct['actions'] if devTypeTsStruct else None
        for action in devType['actions']:
            tsActionElement = ET.SubElement(tsDevTypeElement, 'action')
            tsActionElement.set('name', action)
            actionName = action
            action = devType['actions'][action]
            ET.SubElement(tsActionElement, 'source').text = action['alias']
            if actionsTsStruct and actionName in actionsTsStruct and actionsTsStruct[
                    actionName]['alias']['source'] == action['alias']:
                ET.SubElement(
                    tsActionElement,
                    'translation').text = actionsTsStruct[actionName]['alias']['translation']
            else:
                ET.SubElement(
                    tsActionElement,
                    'translation').text = 'undefined'
            tsParamsElement = ET.SubElement(tsActionElement, 'params')
            paramsTsStruct = actionsTsStruct[actionName][
                'params'] if actionsTsStruct and actionName in actionsTsStruct else None
            for param in action['params']:
                tsParamElement = ET.SubElement(tsParamsElement, 'param')
                tsParamElement.set('name', param)
                ET.SubElement(tsParamElement,
                              'source').text = action['params'][param]
                if paramsTsStruct and param in paramsTsStruct and paramsTsStruct[
                        param]['source'] == action['params'][param]:
                    ET.SubElement(
                        tsParamElement,
                        'translation').text = paramsTsStruct[param]['translation']
                else:
                    ET.SubElement(
                        tsParamElement,
                        'translation').text = 'undefined'
    # Запишем в файл перевода строки из файла strings.xml если такой есть у оборудования
    tsStringsElement = ET.SubElement(tsRootElement, 'strings')
    for string in struct['strings']:
        s = struct['strings'][string]
        tsStringElement = ET.SubElement(tsStringsElement, 'string')
        tsStringElement.set('name', string)
        ET.SubElement(tsStringElement, 'source').text = s
        if tsStruct and string in tsStruct['strings'] and tsStruct['strings'][string]['source'] == s:
            # Если в структуре считанной из файла уже была переведена эта строка возьмем ее для записи в итоговый файл
            ET.SubElement(
                tsStringElement,
                'translation').text = tsStruct['strings'][string]['translation']
        else:
            ET.SubElement(tsStringElement, 'translation').text = 'undefined'

    tree = ET.ElementTree(tsRootElement)
    tree.write(
        tsFileName,
        xml_declaration=True,
        encoding='utf-8',
        pretty_print=True)


def parseEquipment(equipment):
    print('parse %s struct' % equipment)
    struct = {
        'devTypes'	: {}
    }

    equipmentDir = '%s_protocol_config' % equipment
    equip_module = __import__(equipmentDir)
    if not hasattr(equip_module, 'alias'):
        raise AttributeError('__init__.py must contain alias variable')
    else:
        struct['alias'] = getattr(equip_module, 'alias')

    moduleList = []
    for module in os.listdir(os.getcwd() + '/' + equipmentDir):
        if module.split('_')[0] == equipment:
            moduleList.append(module.split('.')[0])

    for module in moduleList:
        try:
            mod = importlib.import_module(equipmentDir + '.' + module)
            _cls = getattr(mod, module)
        except Exception as e:
            logging.warning('Wrong in import module %s' % e)
        else:
            element = Element()
            # имя модуля может состоять из 3х слов например: common_permit_commonright, поэтому отсекаем лишь первую часть
            moduleName = module.replace('{}_'.format(equipment), '')
            element.equipment = moduleName

            initClassAttrFromCls(element, _cls)
            initClassInterfaceFromCls(element, _cls)
            makeActions(element)

            struct['devTypes'][element.equipment] = {
                'alias': element.interface['alias'],
                'parent': element.parentLink['alias'],
                'fields': makeFields(element),
                'links': makeLinks(element),
                'unilinks': makeUniLinks(element),
                'actions': element.actions
            }
            # Соберем строки из strings.xml если такой файл есть
            struct['strings'] = makeStrings(equipmentDir)

    return struct

def makeFields(element):
    fields = {}
    for key, value in element.interface['attrEdits'].items():
        fields[key] = {'alias': value['alias']}
    return fields

def makeActions(element):
    actions = {}
    for key, value in element.interface['actions'].items():
        actions[key] = {'alias': value['alias'], 'params': {}}
        if value['params']:
            params = value['params']
            for k in params:
                actions[key]['params'][k] = params[k]['alias']
    element.actions = actions

def makeLinks(element):
    links = {}
    try:
        for key, value in element.attrs['links'].items():
            links[key] = value
    except KeyError:
        pass
    return links

def makeUniLinks(element):
    unilinks = {}
    try:
        for key, value in element.attrs['unilinks'].items():
            unilinks[key] = value
    except KeyError:
        pass
    return unilinks

def makeStrings(equipmentDir):
    stringsDict = {}
    if os.path.exists(equipmentDir + '/strings.xml'):
        stringsFile = parse(equipmentDir + '/strings.xml')
        strings = stringsFile.getElementsByTagName(
            'strings')[0].getElementsByTagName('string')
        for string in strings:
            name = string.getAttribute('name')
            text = string.childNodes[0].data
            stringsDict[name] = text
    return stringsDict

def initClassAttrFromCls(element, cls):
    attrs = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Attribute))
    for attr in attrs:
        attrName = attr[0]
        element.attrs[attrName] = {}

    links = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Link))
    for link in links:
        linkName = link[0]
        element.attrs['links'] = {}
        element.attrs['unilinks'] = {}
        cls = link[1].target
        if cls:
            element.attrs['links'][linkName] = link[1].alias
        else:
            element.attrs['unilinks'][linkName] = link[1].alias

def initClassInterfaceFromCls(element, cls):
    def f(x):
        if not inspect.isfunction(x):
            return False
        if hasattr(x, 'actionData'):
            return True
        return False

    element.interface = {
        'alias': getattr(cls, 'alias'),
        'attrEdits': {},
        'actions': {}
    }

    parent = getattr(cls, 'parent')
    if parent:
        element.parentTypeName = parent.typeName
        element.parentLink['alias'] = parent.alias

    fields = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Attribute))

    for field in fields:
        fieldName = field[0]
        if field[1].showInClient:
            element.exportAttrs.append(fieldName)
            element.interface["attrEdits"][fieldName] = {
                'alias'			: field[1].alias if field[1].alias else 'undefined',
            }

    fields = inspect.getmembers(cls, predicate=lambda x: isinstance(x, Link))
    for field in fields:
        fieldName = field[0]
        element.interface["attrEdits"][fieldName] = {
            'alias'			: field[1].alias if field[1].alias else 'undefined',
        }

    actions = inspect.getmembers(cls, predicate=f)
    for action in actions:
        actName = action[0]
        actionData = action[1].actionData
        newAct = {
            'alias': actionData['alias'],
            'class': actionData['class'],
            'params': {}
        }
        signature = inspect.signature(action[1])
        for param, alias in actionData['params'].items():
            parameter = signature.parameters[param]
            annotation = parameter.annotation
            default = parameter.default
            if annotation == parameter.empty or default == parameter.empty:
                raise Exception('Expected annotation and default for action %s and parameter %s' % (actName, param))
            paramType = 'str'
            newParam = {
                'alias': alias,
                'defval': default
            }
            if annotation == int:
                paramType = 'int'
            elif annotation == str:
                paramType = 'str'
            elif annotation == float:
                paramType = 'float'
            elif annotation == datetime.datetime:
                paramType = 'datetime'
            elif isinstance(annotation, property_wrapper):
                paramType = 'obj'
                newParam['typeOpt'] = {
                    'equip': annotation.__name__.split('_')[0],
                    'type': annotation.__name__.split('_')[1]
                }
            newParam['type'] = paramType
            newAct['params'][param] = newParam
        element.interface["actions"][actName] = newAct


def main(argv):
    if len(argv) != 2:
        logging.getLogger('console').info('Ошибка. Укажите язык для формирования файла перевода')
        return

    language = argv[1]
    equipments = []
    for f in os.listdir('.'):
        f = f.split('_')
        if len(f) == 3 and f[1] == 'protocol' and f[2] == 'config':
            equipments.append(f[0])
    for eq in equipments:
        if eq == 'rtls':
            continue
        struct = parseEquipment(eq)
        makeTranslateFileForEquipment(eq, struct, language)


if __name__ == "__main__":
    main(sys.argv)
