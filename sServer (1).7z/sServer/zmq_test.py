
import threading

from esmapi.auth_command_sender import AuthCommandSender
from esmapi.commands.sServerCommands import CreateEquipmentObjectCommand

sender = AuthCommandSender('127.0.0.1', 5150, 'admin', 'admin')


def func(equipType):
    cmd = CreateEquipmentObjectCommand(CreateEquipmentObjectCommand.ReqData('common', equipType))
    for _ in range(100):
        sender.send(cmd)


threads = []
equips = ['person']*30 + ['permit']*30 + ['area']*40
for i in range(100):
    threads.append(threading.Thread(target=func, args=(equips[i],)))

for t in threads:
    t.start()

for t in threads:
    t.join()
