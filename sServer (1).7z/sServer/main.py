# -*- coding: utf-8 -*-

import logging.handlers
import logging.config
import rlog
import esmapi
import threading

from event_monitor.event_monitor import *
from network.notify_pusher import NotifyPusher
from cmd_manager import CmdManager
from network.request_server import RequestServer

import xml.dom.minidom as domXml
import version

import interface_n_tools.my_console as my_console
import interface_n_tools.synchronizationtime as synchronizationtime

from equipment.equipment_interface import *
from equipment.equipment_module import EquipmentModule
from dbmodule.dbmodule import DBModule

from equipment.primitive import *
from equipment.dev_except import *


import time
import sys
import os
import redis
import gettext

import event_monitor.plugin_support as plgn

from states_cache import StatesCache
import licensemanager
from quicklock import singleton

from repository.maplayerrepository import MapLayerRepository
from repository.observedobjecttyperepository import ObservedObjectTypeRepository
from repository.eventrepository import EventRepository
from repository.observedobjectrepository import ObservedObjectRepository
from repository.observedobjectonmaprepository import ObservedObjectOnMapRepository
from repository.observedobjectongismaprepository import ObservedObjectOnGisMapRepository
from repository.maprepository import MapRepository
from repository.gismaprepository import GisMapRepository
from repository.devrepository import DevRepository

from manager.maplayermanager import MapLayerManager
from manager.eventmanager import EventManager
from manager.observedobjecttypemanager import ObservedObjectTypeManager
from manager.observedobjectmanager import ObservedObjectManager
from manager.observedobjectactionexecutor import ObservedObjectActionExecutor
from manager.observedobjectonmapmanager import ObservedObjectOnMapManager
from manager.observedobjectongismapmanager import ObservedObjectOnGisMapManager
from manager.eventcommandsmanager import EventCommandsManager

from esmapi.serializer import Serializer

evMon = None
evReg = None
equipInterface = None
equipInterfaceName = ''
working = True


# enable dumps
# TODO need change to faulthandler in python 3.x?
import cgitb

DUMPS_PATH = './dumps'
if not os.path.exists(DUMPS_PATH):
    os.mkdir(DUMPS_PATH)
cgitb.enable(display=False, logdir=DUMPS_PATH)


def printConnectionSettings(connectionString: str) -> None:
    connectionString = connectionString.replace('\'', '')
    connectionsOptions = [opt.split('=') for opt in connectionString.split(' ')]
    host = ''
    dbname = ''
    for param, value in connectionsOptions:
        if param == 'host':
            host = value
        elif param == 'dbname':
            dbname = value
    logging.info('Connect to %s on %s' % (dbname, host))


def initTranslations(language: str):
    esmapi.initTranslation(language)
    os.environ['LANGUAGE'] = language
    gettext.install('sserver', './locale')
    path = os.path.dirname(os.path.abspath(__file__))
    gettext.bindtextdomain('sserver', path + '/locale')


def main(argv):
    try:
        try:
            singleton('sServer')
        except BaseException:
            print('sServer is already running on this computer')
            return

        # WTF: зачем конфигурировать логгер в коде? надо вынести конфигурацию в конфиг
        logger = logging.getLogger('sServer')
        logger.setLevel(logging.INFO)
        handler = logging.handlers.RotatingFileHandler('logs/sServer.log', encoding='utf8', maxBytes=50 * 1024 * 1024, backupCount=1)
        handler.setLevel(logging.INFO)
        handler.setFormatter(logging.Formatter('%(levelname)-3s [%(asctime)s] %(filename)s[LINE:%(lineno)d]# %(message)s'))

        # WTF: смотрится ужасно...
        sys.path.append('.')
        settings = __import__('settings')
        initTranslations(settings.language)

        # для собранных модулей идентификатор БД постоянный
        if getattr(sys, 'frozen', False):
            settings.Redis_db = 1

        redis_handler = rlog.RedisListHandler(key='sServer', host=settings.Redis_host,
                                              password=settings.Redis_password, port=settings.Redis_port,
                                              db=settings.Redis_db
                                              , max_messages=settings.Redis_messages_per_logger)
        redis_handler.setLevel(logging.DEBUG)
        logger.addHandler(redis_handler)
        logger.addHandler(handler)

        logger.info('Start sServer ' + version.getVersion())

        config = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'driver_Console': {
                    'format': '%(asctime)s %(message)s'
                }
            },
            'handlers': {
                'driver_ConsoleHandler': {
                    'level': 'DEBUG',
                    'class': 'logging.StreamHandler',
                    'formatter': 'driver_Console'
                },
                'driver_Redis': {
                    'level': 'DEBUG',
                    'class': 'rlog.RedisListHandler',
                    'key': 'console print',
                    'host': settings.Redis_host,
                    'password': settings.Redis_password,
                    'port': settings.Redis_port,
                    'db': settings.Redis_db,
                    'max_messages': settings.Redis_messages_per_logger
                }
            },
            'loggers': {
                'console': {
                    'handlers': ['driver_Redis', 'driver_ConsoleHandler'],
                    'level': 'DEBUG'
                },
                'root': {
                    'handlers': ['driver_Redis', 'driver_ConsoleHandler'],
                    'level': 'DEBUG'
                }
            }
        }
        logging.config.dictConfig(config)
        printConnectionSettings(settings.ConnectionString)
        if getattr(sys, 'frozen', False):
            # we are running in a bundle
            bundle_dir = sys._MEIPASS + '/'
            logger.info('we are running in a bundle %s' % bundle_dir)
            haspMonitor = licensemanager.LicenseManager(errorClb=lambda: os._exit(-1))
        else:
            # we are running in a normal Python environment
            haspMonitor = licensemanager.LicenseManager(True, errorClb=lambda: os._exit(-1))
            bundle_dir = ''  # os.getcwd()
            logger.info('we are running in a normal Python environment - %s' % bundle_dir)
        license = haspMonitor.getLicense()
        if not license.isValid():
            logging.error(license.getErrorMessage())
            haspMonitor.close()
            return
        if license.getPackage() == 'demo':
            strId = "Trial license."
        else:
            strId = "HASP ID: %08x " % license.getHaspId()

        try:
            os.system("title %s. %s " %
                   (sys.argv[0].split('\\')[-1].split('.')[0], strId))
        except Exception as e:
            logger.info('Error in settings file: %s' % e)

        for plgnFileName in os.listdir(bundle_dir + 'plugins'):
            if plgnFileName[-3:] == '.py':
                __import__('plugins.%s' % plgnFileName[:-3])
        conn = None
        while conn is None:
            try:
                logger.info("Try to connect to DB...")
                conn = DBModule(settings.ConnectionString)
                logger.info("Connection to DB... success")
            except Exception as e:
                logger.exception('Cannot connect to DB: %s' % settings.ConnectionString)
                time.sleep(15)

        EquipmentInterface.init(conn, settings.language, haspMonitor.getLicense())

        try:
            allEventsFlag = settings.AllEvents
        except BaseException:
            allEventsFlag = False

        state_redis_client = redis.StrictRedis(host=settings.Redis_host, port=settings.Redis_port, db=66)
        statesCache = StatesCache(state_redis_client)

        # TODO: вынести в отдельный файл
        class NotifySplitter(object):
            def __init__(self, notifyPusher, statesCache):
                self.__notifyPusher = notifyPusher
                self.__statesCache = statesCache

            def push(self, notification):
                # TODO: надо научить push принимать не только список, но и одиночную посылку
                if len(notification) > 1:
                    notification = {'notifPack': notification}
                else:
                    notification = notification[0]
                    # TODO: пока это заглушка
                    if not isinstance(notification, dict):
                        notification = Serializer.serialize(notification)

                if self.__notifyPusher:
                    try:
                        self.__notifyPusher.push(notification)
                    except Exception as e:
                        logger.info('Cannot __notifyPusher.push: %s. Error: %s' % (notification, e))

                if self.__statesCache:
                    try:
                        self.__statesCache.processNotification(notification)
                    except Exception as e:
                        logger.info("Can`t set state: '%s'. Error: '%s' " % (notification, e))

        class EventPusher(object):
            """
            Промежуточный класс для посылки событий из ObservedObjectManager
            """
            def __init__(self):
                self.__eventMonitor = None

            def push(self, event):
                if self.__eventMonitor:
                    self.__eventMonitor.push(event)

            def setEventMonitor(self, evMon):
                self.__eventMonitor = evMon

        notifyPusher = NotifyPusher(settings.NotifyPullAddr)
        notifyPusher.start()

        notifySplitter = NotifySplitter(notifyPusher, statesCache)
        mapLayerRepository = MapLayerRepository(conn)
        eventRepository = EventRepository(conn, license)
        observedObjectTypeRepository = ObservedObjectTypeRepository(conn, eventRepository)
        observedObjectRepository = ObservedObjectRepository(conn, observedObjectTypeRepository, mapLayerRepository)
        observedObjectOnMapRepository = ObservedObjectOnMapRepository(conn, observedObjectRepository)
        observedObjectOnGisMapRepository = ObservedObjectOnGisMapRepository(conn, observedObjectRepository)
        mapRepository = MapRepository(conn)
        devRepository = DevRepository(conn)
        gisMapRepository = GisMapRepository(conn)

        eventPusher = EventPusher()
        observedObjectManager = ObservedObjectManager(observedObjectRepository, observedObjectTypeRepository,
                                                      mapLayerRepository, devRepository, notifySplitter, eventPusher,
                                                      license)

        # ининцилизация мониторинга событий
        evMon = EventMonitor(conn, haspMonitor.getLicense(), observedObjectTypeRepository, observedObjectRepository,
                             eventRepository, observedObjectManager, allEventsFlag)

        eventPusher.setEventMonitor(evMon)

        plgn.PluginObject.init(evMon)
        evMon.setNotifyServer(notifySplitter)
        evMon.start()
        statesCache.start()

        # Инициализаци¤ драйверов
        for eqName in EquipmentInterface.getInstanceNameList():
            evMon.addEquipment(EquipmentInterface.getInstance(eqName))
            if eqName == 'common':
                commonProcessor = CommonProcessor(conn)
                evMon.setCommon(commonProcessor)

        mapLayerManager = MapLayerManager(mapLayerRepository, notifySplitter)
        eventManager = EventManager(eventRepository, notifySplitter)
        obsObjTypeManager = ObservedObjectTypeManager(observedObjectTypeRepository, eventRepository, notifySplitter)
        observedObjectActionExecutor = ObservedObjectActionExecutor(observedObjectRepository, notifySplitter, evMon.getEquipments())
        observedObjectOnMapManager = ObservedObjectOnMapManager(observedObjectOnMapRepository, observedObjectRepository,
                                                                mapRepository, notifySplitter)
        observedObjectOnGisMapManager = ObservedObjectOnGisMapManager(observedObjectOnGisMapRepository,
                                                                      observedObjectRepository, gisMapRepository,
                                                                      notifySplitter)
        eventCommandsManager = EventCommandsManager(observedObjectRepository, observedObjectTypeRepository, eventPusher,
                                                    conn)

        cmdManager = CmdManager(evMon, notifyPusher, license, mapLayerManager, eventManager, obsObjTypeManager,
                                observedObjectManager, observedObjectActionExecutor, observedObjectOnMapManager,
                                observedObjectOnGisMapManager, eventCommandsManager)
        requestServer = RequestServer("tcp://localhost:%s" % (settings.RequestServerPort,), "sServer", cmdManager)
        requestServer.start()

        cons = my_console.MyConsole(None)

        synch = synchronizationtime.SynchronizationTime(EquipmentInterface)
        synch.start()

        evMon.equipInit()
        logging.getLogger('console').info('Server successfully started')
        cons.mainLoop()

        evMon.equipFinit()
        notifyPusher.stop()
        synch.stop()
        statesCache.stop()
        requestServer.stop()

        haspMonitor.close()
        evMon.stop()

        logging.getLogger('console').info('exit')
    except Exception as e:
        # make html dump
        sys.excepthook.handle()
        
        logging.getLogger('console').exception('main execution critical error')
        os._exit(-1)


if __name__ == "__main__":
    main(sys.argv)
