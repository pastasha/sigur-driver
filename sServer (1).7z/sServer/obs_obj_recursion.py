
import psycopg2


settings = __import__('settings')

dbconn = psycopg2.connect(settings.ConnectionString)
cursor = dbconn.cursor()

cursor.execute("""
    select id from observed_objects where deletemark = 0
""")

obsObjIds = [row[0] for row in cursor]
n = max(obsObjIds) + 1
g = [None] * n
p = [None] * n
cl = [None] * n
cycle_st = -1
cycle_end = 0

for id in obsObjIds:
    g[id] = []
    p[id] = -1
    cl[id] = 0
    
cursor.execute("""
    select srcobj, destobj
    from observed_objects_brg
    where deletemark = 0
""")

for srcobj, destobj in cursor:
    g[destobj].append(srcobj)


def dfs(ver):
    global cycle_end
    global cycle_st
    cl[ver] = 1
    for to in g[ver]:
        if cl[to] == 0:
            p[to] = ver
            if dfs(to):
                return True
        else:
            if cl[to] == 1:
                cycle_end = ver
                cycle_st = to
                return True
    cl[ver] = 2
    return False


for id in obsObjIds:
    if dfs(id):
        break
if cycle_st == -1:
    print("OK")
else:
    print("CYCLE")
    cycle = [cycle_st]
    v = cycle_end
    while v != cycle_st:
        cycle.append(v)
        v = p[v]
    cycle.append(cycle_st)
    print(cycle)
