# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, ParentStruct


class common_securlevel(protocol_obj_base, alias='Уровень безопасности',
                        parent=ParentStruct(typeName='root', alias='Уровни безопасности')):

    OBSOBJTYPE = 'dev'

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Описание', fieldType=str, defval='')
    color = Attribute(alias='Цвет', fieldType=str, defval='', editorType='color')
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
