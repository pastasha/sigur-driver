# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, index_decorator, action_decorator
from equipment import dev_except
from equipment.methods_for_equipment import get_subsystem_ids


class common_idcode(protocol_obj_base, alias='Идентификатор', archive=True):
    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')
            
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    @index_decorator('ccure_id')
    def ccure_id_calc(self):
        return get_subsystem_ids(self, 'ccure')

    def __calcFormatIndex(self, bits):
        name = self.name
        try:
            name = int(name)
        except:
            return None
        return name & (2**bits - 1)

    @index_decorator('name')
    def nameIndexFunc(self):
        return self.name

    @index_decorator('format16')
    def format16IndexFunc(self):
        return self.__calcFormatIndex(16)

    @index_decorator('format24')
    def format24IndexFunc(self):
        return self.__calcFormatIndex(24)

    @index_decorator('format32')
    def format32IndexFunc(self):
        return self.__calcFormatIndex(32)

    @index_decorator('format48')
    def format48IndexFunc(self):
        return self.__calcFormatIndex(48)

    @index_decorator('format64')
    def format64IndexFunc(self):
        return self.__calcFormatIndex(64)

    @index_decorator('format128')
    def format128IndexFunc(self):
        return self.__calcFormatIndex(128)

    def postCreate(self, ignore_create_objects=False):
        self.checkUnique()
        self.attrUpdated('description')
        self.__correctDescription(None)

    def __nameChanged(self, oldValue, oldValues):
        self.name = self.name.lower()
        self.checkUnique()
        self.attrUpdated('description')
        self.__correctDescription(oldValue)
        self.attrUpdated('format16text')
        self.attrUpdated('format24text')
        self.attrUpdated('format32text')
        self.attrUpdated('format48text')
        self.attrUpdated('format64text')
        self.attrUpdated('format128text')

    def __codeTypeChanged(self, oldValue, oldValues):
        self.attrUpdated('mask')

    def __correctDescription(self, oldName=None):
        if oldName:
            for id, idObj in self.getElementsByIndex('name', {'name': oldName}).items():
                idObj.attrUpdated('description')

        for id, idObj in self.getElementsByIndex('name', {'name': self.name}).items():
            idObj.attrUpdated('description')

    def __checkCodeUnique(self, value, field):
        # Проверка уникальности кода
        # Предвариетельно проверим что код в правильном формате, если codeType=0 то value должен привестись к int
        if self.codeType == 0:
            try:
                int(value)
            except:
                raise dev_except.TerminateAction(self._core.getString('IdWrongFormat'))
        value = value.lower()
        if value and value != '0':
            for id, idObj in self.getElementsByIndex('name', {'name': value}).items():
                raise dev_except.TerminateAction(
                    self._core.getString('IdExists') % (value, id)
                )

    def checkUnique(self):
        if self.codeType != 1 and int(self.name) != 0:
            if self.format16 == 1:
                if not self.checkUniqueIndex('format16'):
                    self.format16 = 0
            if self.format24 == 1:
                if not self.checkUniqueIndex('format24'):
                    self.format24 = 0
            if self.format32 == 1:
                if not self.checkUniqueIndex('format32'):
                    self.format32 = 0
            if self.format48 == 1:
                if not self.checkUniqueIndex('format48'):
                    self.format48 = 0
            if self.format64 == 1:
                if not self.checkUniqueIndex('format64'):
                    self.format64 = 0
            if self.format128 == 1:
                if not self.checkUniqueIndex('format128'):
                    self.format128 = 0

    def __checkUnique_format16(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format16'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique16'))

    def __checkUnique_format24(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format24'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique24'))

    def __checkUnique_format32(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format32'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique32'))

    def __checkUnique_format48(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format48'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique48'))

    def __checkUnique_format64(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format64'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique64'))

    def __checkUnique_format128(self, value, field):
        if int(value) != 0:
            if not self.checkUniqueIndex('format128'):
                raise dev_except.TerminateAction(self._core.getString('idNotUnique128'))

    def __getDescription(self, field):
        return '%s%s' % (self.name, (self._core.getString('NotUnique')) if not self.checkUniqueIndex('name') else '')

    @classmethod
    def postDelete(cls, name):
        for id, idObj in cls._core.getElementsByIndex('idcode', 'name', {'name': name}).items():
            idObj.attrUpdated('description')

    def __getFormat16Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFF
            codeS = code >> 16
            codeM = code & 0xFFFF
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    def __getFormat24Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFFFF
            codeS = str(code >> 16)
            codeM = code & 0xFFFF
            codeS = codeS.zfill(3)
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    def __getFormat32Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFFFFFF
            codeS = str(code >> 16)
            codeM = code & 0xFFFF
            codeS = codeS.zfill(5)
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    def __getFormat48Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFFFFFFFFFF
            codeS = str(code >> 16)
            codeM = code & 0xFFFF
            codeS = codeS.zfill(10)
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    def __getFormat64Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFFFFFFFFFFFFFF
            codeS = str(code >> 16)
            codeM = code & 0xFFFF
            codeS = codeS.zfill(15)
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    def __getFormat128Text(self, field):
        if self.codeType != 1:
            code = int(self.name)
            code = code & 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
            codeS = str(code >> 16)
            codeM = code & 0xFFFF
            codeS = codeS.zfill(35)
            return '%s-%s' % (codeS, codeM)
        else:
            return self.name

    @classmethod
    def getFormatEditor(cls):
        return {
            cls._core.getString('enabled'): 1,
            cls._core.getString('disabled'): 0
        }

    def __getFieldMask(self, field):
        result = 'name,description,codeType,'
        if self.codeType == 0:
            result += 'format16,format16text,format24,format24text,format32,format32text,format48,format48text,' \
                      'format64,format64text,format128,format128text'
        return result

    @classmethod
    @action_decorator(alias='Обновить уникальность всех карт', actionClass='static')
    def updateUniqueAll(cls):
        for idcode in cls._core.getElements('idcode'):
            for attr in ('format16', 'format24', 'format32', 'format48', 'format64', 'format128'):
                try:
                    idcode.setAttr(attr, 1)
                except:
                    pass

    name = Attribute(alias='Код', fieldType=str, defval='0', index=1, preAction=__checkCodeUnique,
                     postAction=__nameChanged)
    description = Attribute(alias='Имя/Название', index=2, fget=__getDescription, readOnly=True, storeInDb=False)
    codeType = Attribute(alias='Текстовый', fieldType=int, defval=0, index=3, postAction=__codeTypeChanged,
                         editorType='treeSelect(getFormatEditor)')
    format16 = Attribute(alias='Формат16', fieldType=int, defval=1, index=4, preAction=__checkUnique_format16,
                         editorType='treeSelect(getFormatEditor)')
    format16text = Attribute(alias='Формат16 вид', index=5, fget=__getFormat16Text, readOnly=True, storeInDb=False)
    format24 = Attribute(alias='Формат24', fieldType=int, defval=1, index=6, preAction=__checkUnique_format24,
                         editorType='treeSelect(getFormatEditor)')
    format24text = Attribute(alias='Формат24 вид', index=7, fget=__getFormat24Text, readOnly=True, storeInDb=False)
    format32 = Attribute(alias='Формат32', fieldType=int, defval=1, index=8, preAction=__checkUnique_format32,
                         editorType='treeSelect(getFormatEditor)')
    format32text = Attribute(alias='Формат32 вид', index=9, fget=__getFormat32Text, readOnly=True, storeInDb=False)
    format48 = Attribute(alias='Формат48', fieldType=int, defval=1, index=10, preAction=__checkUnique_format48,
                         editorType='treeSelect(getFormatEditor)')
    format48text = Attribute(alias='Формат48 вид', index=11, fget=__getFormat48Text, readOnly=True, storeInDb=False)
    format64 = Attribute(alias='Формат64', fieldType=int, defval=1, index=12, preAction=__checkUnique_format64,
                         editorType='treeSelect(getFormatEditor)')
    format64text = Attribute(alias='Формат64 вид', index=13, fget=__getFormat64Text, readOnly=True, storeInDb=False)
    format128 = Attribute(alias='Формат128', fieldType=int, defval=1, index=14, preAction=__checkUnique_format128,
                          editorType='treeSelect(getFormatEditor)')
    format128text = Attribute(alias='Формат128 вид', index=15, fget=__getFormat128Text, readOnly=True, storeInDb=False)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=17)

    mask = Attribute(alias='', fget=__getFieldMask, storeInDb=False)
