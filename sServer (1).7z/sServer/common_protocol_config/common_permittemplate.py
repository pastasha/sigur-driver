# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_permittemplate(protocol_obj_base, alias='Шаблон пропуска'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    src = Attribute(alias='Файл', fieldType=str, defval='', index=2)
    template_type = Attribute(alias='Тип шаблона', fieldType=int, defval=0, index=3,
                              editorType='enum(Шаблон пропуска, Шаблон верификации)')
