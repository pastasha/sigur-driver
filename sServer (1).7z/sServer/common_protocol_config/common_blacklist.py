# -*- coding: utf-8 -*-

import time
import re

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, action_decorator, index_decorator
from equipment import dev_except

from .common_subject import common_subject
from .common_blacklisttype import common_blacklisttype


class common_blacklist(protocol_obj_base, alias='Нарушение', archive=True):

    @index_decorator('openForSubject')
    def openForSubjectIndexBuilder(self):
        if self.state == 1:
            if self.subject:
                return self.subject.getUniID()
        return None
    
    def __checkNewBreach(self, **kwargs):
        if 'closeBreach' not in self or not self['closeBreach']:
            if self.state != 0:
                raise dev_except.TerminateAction(self._core.getString('Attributecantbechanged'))

    def __checkOpenBreach(self, **kwargs):
        if 'closeBreach' not in self or not self['closeBreach']:
            if self.state != 1:
                raise dev_except.TerminateAction(self._core.getString('Attributecantbechanged'))

    def __setState(self, value, field):
        value = int(value)
        oldVal = self.state
        if value < oldVal:
            raise dev_except.TerminateAction(self._core.getString('Statechangeerror'))
        if value == 1:
            self.timeopen = time.time()
        if value == 2:
            self.timeclose = time.time()
        if value == 1 and not self.commentopen:
            raise dev_except.TerminateAction(self._core.getString('Nocomment'))
        if value == 1 and not self.isLinkedElement('subject'):
            raise dev_except.TerminateAction(self._core.getString('Nosubject'))
        if value == 1 and not self.isLinkedElement('operatoropen'):
            raise dev_except.TerminateAction(self._core.getString('NoOperatorLink'))
        if value == 1 and not self.isLinkedElement('breachtype'):
            raise dev_except.TerminateAction(self._core.getString('NoViolationType'))
        if value == 2 and not self.commentclose:
            raise dev_except.TerminateAction(self._core.getString('NoViolationType'))
        if value == 2 and not self.isLinkedElement('operatorclose'):
            raise dev_except.TerminateAction(self._core.getString('NoOperatorLink'))

    def __closeBreach(self, oldValue, oldValues):
        if self.subject:
            self.subject.attrUpdated('isIntruder')

        if self.state == 2:
            self['closeBreach'] = True
            self.selfDelete()

    def preDelete(self, deleteAsLink=False):
        if self.state == 1:
            raise dev_except.TerminateAction(self._core.getString('ViolationDeletionRestricted'))

    def closeBlackListInWantedface(self, subject=None):
        root = self._core.getElements('root')[0]
        if root.getAttribute('add_face_to_recognition_list_when_add_to_blacklist') is True \
                and root.getAttribute('add_face_to_recognition_list_when_activate_permit') is False:
            if subject is not None:
                person = subject.getChildListByType('person')[0]
                if person is not None:
                    root.doAction('delete_face_by_person', {'person': person})
        elif root.getAttribute('add_face_to_recognition_list_when_add_to_blacklist') is True \
                and root.getAttribute('add_face_to_recognition_list_when_activate_permit') is True:
            if subject is not None:
                person = subject.getChildListByType('person')[0]
                if person is not None:
                    root.doAction('create_face_by_person', {'person': person})

    @action_decorator(alias='Закрыть нарушение', operatorclose='Оператор закрывший запись',
                      commentclose='Комментарий закрытия')
    def closeBlackList(self, operatorclose: int = 0, commentclose: str = ''):
        operatorclose = self._core.getElementById('subject', operatorclose)
        subject = self.getLinkedElement('subject')
        if not operatorclose:
            raise dev_except.TerminateAction(self._core.getString('OperatorsSubjectNotFound'))

        if not re.search(r'\S+', commentclose):
            raise dev_except.TerminateAction(self._core.getString('CommentNotSet'))

        self.operatorclose = operatorclose
        self.commentclose = commentclose
        self.timeclose = time.time()
        self.state = 2
        self.closeBlackListInWantedface(subject)
        self.__closeBreach(None, None)

    @action_decorator(alias='Открыть нарушение', operatoropen='Оператор открывший запись',
                      commentopen='Комментарий открытия нарушения')
    def openBlackList(self, operatoropen: int = 0, commentopen: str = ''):
        operatoropen = self._core.getElementById('subject', operatoropen)
        if not operatoropen:
            raise dev_except.TerminateAction(self._core.getString('OperatorsSubjectNotFound'))

        if not re.search(r'\S+', commentopen):
            raise dev_except.TerminateAction(self._core.getString('OpenCommentNotSet'))

        if not self.subject:
            raise dev_except.TerminateAction(self._core.getString('SubjectNotFound'))

        if not self.breachtype:
            raise dev_except.TerminateAction(self._core.getString('ViolationTypeNotExists'))

        self.operatoropen = operatoropen
        self.commentopen = commentopen
        self.timeopen = time.time()
        self.state = 1

        self.subject.attrUpdated('isIntruder')

        root = self._core.getElements('root')[0]
        if root.getAttribute('add_face_to_recognition_list_when_add_to_blacklist') is True:
            if self.isLinkedElement('subject') is True:
                person = self.getLinkedElement('subject').getChildListByType('person')[0]
                if person is not None:
                    root.doAction('create_face_by_person', {'person': person})

    def __getNumber(self, field):
        return self.getUniID()

    number = Attribute(alias='Номер', fget=__getNumber, index=1, readOnly=True, storeInDb=False)
    timeopen = Attribute(alias='Время открытия записи', fieldType=int, defval=0, index=2, preAction=__checkNewBreach,
                         editorType='datetime')
    subject = Link(alias='Субъект', target=common_subject, index=3, preAction=__checkNewBreach)
    breachtype = Link(alias='Тип нарушения', target=common_blacklisttype, index=4, preAction=__checkNewBreach)
    operatoropen = Link(alias='Оператор открывший запись', target=common_subject, index=5, preAction=__checkNewBreach)
    commentopen = Attribute(alias='Коментарий о нарушении', fieldType=str, defval='', index=6,
                            preAction=__checkNewBreach)
    block = Attribute(alias='Блокировка', fieldType=int, defval=0, index=7, preAction=__checkNewBreach,
                      editorType='enum(Блокировать выдачу пропуска, Не блокировать выдачу пропуска)')
    timeclose = Attribute(alias='Время закрытия записи', fieldType=int, defval=0, index=8, preAction=__checkOpenBreach,
                          editorType='datetime')
    operatorclose = Link(alias='Оператор закрывший запись', target=common_subject, index=9, preAction=__checkOpenBreach)
    commentclose = Attribute(alias='Коментарий о закрытии нарушения', fieldType=str, defval='', index=10,
                             preAction=__checkOpenBreach)
    state = Attribute(alias='Состояние', fieldType=int, defval=0, index=11, preAction=__setState,
                      postAction=__closeBreach, editorType='enum(Новое нарушение, Открыто, Закрыто)')
