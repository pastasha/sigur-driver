<?xml version='1.0' encoding='UTF-8'?>
<equipment name="common">
  <alias>
    <source>Общие объекты</source>
    <translation>Common</translation>
  </alias>
  <devTypes>
    <devType name="area">
      <alias>
        <source>Зона доступа</source>
        <translation>Access zone</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="areatype">
        <source>Тип зоны доступа</source>
        <translation>Access zone type</translation>
      </field>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="geometry">
        <source>Геометрия</source>
        <translation>Geometry</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>Monitored object type</translation>
      </field>
      <field name="persons_count">
        <source>Количество людей в зоне</source>
        <translation>Number of persons inside</translation>
      </field>
      <field name="map">
        <source>Векторная карта</source>
        <translation>Vector map</translation>
      </field>
      <link name="map">
        <source>Векторная карта</source>
        <translation>Vector map</translation>
      </link>
      <action name="clearPersonsInArea">
        <source>Сбросить число людей в зоне</source>
        <translation>Reset the number of persons inside</translation>
        <params/>
      </action>
      <action name="decrementPersonsInArea">
        <source>Уменьшить число людей в зоне на 1</source>
        <translation>Decrease the number of persons inside by 1</translation>
        <params/>
      </action>
      <action name="incrementPersonsInArea">
        <source>Увеличить число людей в зоне на 1</source>
        <translation>Increase the number of persons inside by 1</translation>
        <params/>
      </action>
      <action name="setPersonsInArea">
        <source>Установить число людей в зоне</source>
        <translation>Set the number of persons inside</translation>
        <params>
          <param name="count">
            <source>Количество</source>
            <translation>Number</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="blacklist">
      <alias>
        <source>Нарушение</source>
        <translation>Violation</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="block">
        <source>Блокировка</source>
        <translation>Lock</translation>
      </field>
      <field name="commentclose">
        <source>Коментарий о закрытии нарушения</source>
        <translation>Comment about the violation closing</translation>
      </field>
      <field name="commentopen">
        <source>Коментарий о нарушении</source>
        <translation>Comment about the violation</translation>
      </field>
      <field name="number">
        <source>Номер</source>
        <translation>Number</translation>
      </field>
      <field name="state">
        <source>Состояние</source>
        <translation>State</translation>
      </field>
      <field name="timeclose">
        <source>Время закрытия записи</source>
        <translation>Time of closing</translation>
      </field>
      <field name="timeopen">
        <source>Время открытия записи</source>
        <translation>Opening time</translation>
      </field>
      <field name="breachtype">
        <source>Тип нарушения</source>
        <translation>Violation type</translation>
      </field>
      <field name="operatorclose">
        <source>Оператор закрывший запись</source>
        <translation>Operator who closed</translation>
      </field>
      <field name="operatoropen">
        <source>Оператор открывший запись</source>
        <translation>Operator who opened</translation>
      </field>
      <field name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
      <action name="closeBlackList">
        <source>Закрыть нарушение</source>
        <translation>Close the violation</translation>
        <params>
          <param name="operatorclose">
            <source>Оператор закрывший запись</source>
            <translation>Operator, who closed</translation>
          </param>
          <param name="commentclose">
            <source>Комментарий закрытия</source>
            <translation>Closing comment</translation>
          </param>
        </params>
      </action>
      <action name="openBlackList">
        <source>Открыть нарушение</source>
        <translation>Open violation</translation>
        <params>
          <param name="subject">
            <source>Субъект</source>
            <translation>Subject</translation>
          </param>
          <param name="breachtype">
            <source>Тип нарушения</source>
            <translation>Violation type</translation>
          </param>
          <param name="operatoropen">
            <source>Оператор открывший запись</source>
            <translation>Operator, who opened</translation>
          </param>
          <param name="commentopen">
            <source>Комментарий открытия нарушения</source>
            <translation>Opening comment</translation>
          </param>
          <param name="block">
            <source>Блокировка пропуска</source>
            <translation>Permit lock</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="blacklisttype">
      <alias>
        <source>Тип нарушения КПР</source>
        <translation>Violation type</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="description">
        <source>Название</source>
        <translation>Name</translation>
      </field>
      <field name="kind">
        <source>Вид списка</source>
        <translation>List type</translation>
      </field>
      <field name="level">
        <source>Уровень тревожности</source>
        <translation>Alarm level</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
    </devType>
    <devType name="commonright">
      <alias>
        <source>Право</source>
        <translation>Access right</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="antipassbackFlag">
        <source>Контроль повторного прохода</source>
        <translation>Antipassback</translation>
      </field>
      <field name="comment">
        <source>Комментарий</source>
        <translation>Comment</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External Id</translation>
      </field>
      <field name="icon">
        <source>Иконка</source>
        <translation>Icon</translation>
      </field>
      <field name="keyword">
        <source>Ключевое слово поиска</source>
        <translation>Keyword</translation>
      </field>
      <field name="operatorFlag">
        <source>Оператор</source>
        <translation>Operator</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="acc_bcp_tz">
        <source>Рубеж-08: Временная зона доступа к БЦП</source>
        <translation>Rubezh-08: Temporary access area</translation>
      </field>
      <field name="accesslevel">
        <source>Уровень доступа Apollo</source>
        <translation>Apollo access level</translation>
      </field>
      <field name="alevel">
        <source>Уровень доступа Рубеж-08</source>
        <translation>Rubezh-08 access level</translation>
      </field>
      <field name="boschauthorization">
        <source>Авторизация BOSCH</source>
        <translation>BOSCH authorization</translation>
      </field>
      <field name="hkright">
        <source>Право доступа электронного сейфа ЭВС</source>
        <translation>Access right for electronic safe</translation>
      </field>
      <field name="levelaccess">
        <source>Уровень доступа ИСО Орион</source>
        <translation>Orion ISO access level</translation>
      </field>
      <field name="mainarea">
        <source>Основная зона доступа</source>
        <translation>Main access zone</translation>
      </field>
      <field name="marshrut">
        <source>Маршрут TSS</source>
        <translation>TSS route</translation>
      </field>
      <field name="rlist">
        <source>Полномочия PCE</source>
        <translation>PCE authorities</translation>
      </field>
      <field name="rzone">
        <source>Рубеж-08: Пользовательская зона</source>
        <translation>Rubezh 08: User zone</translation>
      </field>
      <field name="rzone_tz">
        <source>Рубеж-08: Временная зона для управления ТС в пользовательской зоне</source>
        <translation>Rubezh-08: Time zone for vehicle control in the user zone</translation>
      </field>
      <field name="schedule_srv">
        <source>Уровень доступа Модуля интеграции Орион Про</source>
        <translation>Orion Pro Integration module access level</translation>
      </field>
      <field name="threshold1">
        <source>Допустимый уровень безопасности</source>
        <translation>Allowable security level</translation>
      </field>
      <field name="type">
        <source>Тип права</source>
        <translation>Right type</translation>
      </field>
      <field name="uldright">
        <source>Права доступа УЛУ</source>
        <translation>ULD access rights</translation>
      </field>
      <link name="uldright">
        <source>Права доступа УЛУ</source>
        <translation>ULD access rights</translation>
      </link>
    </devType>
    <devType name="commonrightoo">
      <alias>
        <source>Права на ОМ</source>
        <translation>Rights for logical objects</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="obsobj">
        <source>Объекты мониторинга</source>
        <translation>Logical objects</translation>
      </field>
      <link name="uldright">
        <source>Права доступа УЛУ</source>
        <translation>ULD access rights</translation>
      </link>
    </devType>
    <devType name="commonrighttemplate">
      <alias>
        <source>Шаблон прав</source>
        <translation>Rights template</translation>
      </alias>
      <parent>
        <source>Внутренние зоны</source>
        <translation>Internal zones</translation>
      </parent>
      <field name="description">
        <source>Название</source>
        <translation>Name</translation>
      </field>
      <link name="uldright">
        <source>Права доступа УЛУ</source>
        <translation>ULD access rights</translation>
      </link>
    </devType>
    <devType name="commonrighttemplate_commonright">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Права</source>
        <translation>Rights</translation>
      </parent>
      <field name="commonright">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="commonright">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="commonrighttype">
      <alias>
        <source>Тип права</source>
        <translation>Right type</translation>
      </alias>
      <parent>
        <source>Права</source>
        <translation>Rights</translation>
      </parent>
      <field name="description">
        <source>Название</source>
        <translation>Description</translation>
      </field>
      <link name="commonright">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="commonright_area">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Дополнительные зоны</source>
        <translation>Additional zones</translation>
      </parent>
      <field name="area">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="area">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="commonright_commonrightoo">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Права на ОМ</source>
        <translation>Rights for logical objects</translation>
      </parent>
      <field name="commonrightoo">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="commonrightoo">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="customcatalog">
      <alias>
        <source>Справочники</source>
        <translation>Directories</translation>
      </alias>
      <parent>
        <source>Права на ОМ</source>
        <translation>Rights for MO</translation>
      </parent>
      <field name="description">
        <source>Вид справочника</source>
        <translation>Directory type</translation>
      </field>
      <link name="commonrightoo">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="customcatalogvalue">
      <alias>
        <source>Записи справочников</source>
        <translation>Directory entries</translation>
      </alias>
      <parent>
        <source>Записи</source>
        <translation>Entries</translation>
      </parent>
      <field name="description">
        <source>Значение</source>
        <translation>Value</translation>
      </field>
      <link name="commonrightoo">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="department">
      <alias>
        <source>Подразделение</source>
        <translation>Department</translation>
      </alias>
      <parent>
        <source>Дочерние подразделения</source>
        <translation>Subsidiaries</translation>
      </parent>
      <field name="archived">
        <source>Архивное</source>
        <translation>Archival</translation>
      </field>
      <field name="description">
        <source>Название</source>
        <translation>Name</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External Id</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="commonrighttemplate">
        <source>Шаблон прав</source>
        <translation>Right template</translation>
      </field>
      <field name="organization">
        <source>Организация</source>
        <translation>Organization</translation>
      </field>
      <field name="schedule">
        <source>График работы УРВ</source>
        <translation>Work schedule</translation>
      </field>
      <link name="schedule">
        <source>График работы УРВ</source>
        <translation>Working time tracking shedule</translation>
      </link>
      <action name="archivate">
        <source>Архивировать</source>
        <translation>Backup</translation>
        <params/>
      </action>
      <action name="unarchivate">
        <source>Разархивировать</source>
        <translation>Restore</translation>
        <params/>
      </action>
    </devType>
    <devType name="department_scheduletemplate">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Расписания</source>
        <translation>Shedules</translation>
      </parent>
      <field name="begin_date">
        <source>Дата начала</source>
        <translation>Beginning date</translation>
      </field>
      <field name="end_date">
        <source>Дата окончания</source>
        <translation>End date</translation>
      </field>
      <field name="scheduletemplate">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="scheduletemplate">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="deviatinsfromschedules">
      <alias>
        <source>Отклонения от рабочего расписания</source>
        <translation>Working shedule deviations</translation>
      </alias>
      <parent>
        <source>Расписания</source>
        <translation>Schedules</translation>
      </parent>
      <field name="begin_date">
        <source>Дата начала</source>
        <translation>Beginning date</translation>
      </field>
      <field name="doc_date">
        <source>Дата создания</source>
        <translation>Creation date</translation>
      </field>
      <field name="end_date">
        <source>Дата окончания</source>
        <translation>End date</translation>
      </field>
      <field name="note">
        <source>Примечание</source>
        <translation>Note</translation>
      </field>
      <field name="reason">
        <source>Номер заявки</source>
        <translation>Requisition number</translation>
      </field>
      <field name="author">
        <source>Создатель</source>
        <translation>Creator</translation>
      </field>
      <field name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </field>
      <field name="tzone">
        <source>Временная зона</source>
        <translation>Time zone</translation>
      </field>
      <link name="tzone">
        <source>Временная зона</source>
        <translation>Time zone</translation>
      </link>
    </devType>
    <devType name="idcode">
      <alias>
        <source>Идентификатор</source>
        <translation>Id</translation>
      </alias>
      <parent>
        <source>Расписания</source>
        <translation>Schedules</translation>
      </parent>
      <field name="codeType">
        <source>Текстовый</source>
        <translation>Text</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="format128">
        <source>Формат128</source>
        <translation>format128</translation>
      </field>
      <field name="format128text">
        <source>Формат128 вид</source>
        <translation>format128 view</translation>
      </field>
      <field name="format16">
        <source>Формат16</source>
        <translation>format16</translation>
      </field>
      <field name="format16text">
        <source>Формат16 вид</source>
        <translation>format16 view</translation>
      </field>
      <field name="format24">
        <source>Формат24</source>
        <translation>format24</translation>
      </field>
      <field name="format24text">
        <source>Формат24 вид</source>
        <translation>format24 view</translation>
      </field>
      <field name="format32">
        <source>Формат32</source>
        <translation>format32</translation>
      </field>
      <field name="format32text">
        <source>Формат32 вид</source>
        <translation>format32 view</translation>
      </field>
      <field name="format48">
        <source>Формат48</source>
        <translation>format48</translation>
      </field>
      <field name="format48text">
        <source>Формат48 вид</source>
        <translation>format48 view</translation>
      </field>
      <field name="format64">
        <source>Формат64</source>
        <translation>format64</translation>
      </field>
      <field name="format64text">
        <source>Формат64 вид</source>
        <translation>format64 view</translation>
      </field>
      <field name="mask">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="name">
        <source>Код</source>
        <translation>Code</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <link name="tzone">
        <source>Временная зона</source>
        <translation>Time zone</translation>
      </link>
    </devType>
    <devType name="mobile">
      <alias>
        <source>Транспортные средства</source>
        <translation>Vehicles</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="brand">
        <source>Марка, модель</source>
        <translation>Brand, model</translation>
      </field>
      <field name="color">
        <source>Цвет</source>
        <translation>Color</translation>
      </field>
      <field name="description">
        <source>Гос. номер</source>
        <translation>License plate</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External id</translation>
      </field>
      <field name="mobiletype">
        <source>Вид ТС</source>
        <translation>Vehicle type</translation>
      </field>
      <field name="mode">
        <source>Режим</source>
        <translation>Mode</translation>
      </field>
      <field name="note">
        <source>Примечание</source>
        <translation>Note</translation>
      </field>
      <field name="trailer">
        <source>Прицеп</source>
        <translation>Trailer</translation>
      </field>
      <field name="trailernumber">
        <source>Номер прицепа</source>
        <translation>Trailer number</translation>
      </field>
      <field name="owner">
        <source>Владелец</source>
        <translation>Owner</translation>
      </field>
      <unilink name="owner">
        <source>Владелец</source>
        <translation>Owner</translation>
      </unilink>
    </devType>
    <devType name="organization">
      <alias>
        <source>Организация</source>
        <translation>Organization</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="archived">
        <source>Архивное</source>
        <translation>Archive</translation>
      </field>
      <field name="description">
        <source>Название</source>
        <translation>Name</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External Id</translation>
      </field>
      <field name="note1">
        <source>Краткое имя</source>
        <translation>Short name</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="commonrighttemplate">
        <source>Шаблон прав</source>
        <translation>Right template</translation>
      </field>
      <link name="commonrighttemplate">
        <source>Шаблон прав</source>
        <translation>Rights template</translation>
      </link>
      <action name="archivate">
        <source>Архивировать</source>
        <translation>Archivate</translation>
        <params/>
      </action>
      <action name="unarchivate">
        <source>Разархивировать</source>
        <translation>Restore</translation>
        <params/>
      </action>
    </devType>
    <devType name="permit">
      <alias>
        <source>Пропуск</source>
        <translation>Permit</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="actdt">
        <source>Время активации</source>
        <translation>Activating time</translation>
      </field>
      <field name="beginDT">
        <source>Дата начала</source>
        <translation>Valid from</translation>
      </field>
      <field name="blockcomment">
        <source>Причина блокировки</source>
        <translation>Blocking reason</translation>
      </field>
      <field name="blockdt">
        <source>Время блокировки</source>
        <translation>Block time</translation>
      </field>
      <field name="createdt">
        <source>Время создания</source>
        <translation>Creation time</translation>
      </field>
      <field name="deactdt">
        <source>Время деактивации</source>
        <translation>Time of deactivation</translation>
      </field>
      <field name="endDT">
        <source>Дата конца</source>
        <translation>Valid to</translation>
      </field>
      <field name="equipment_export">
        <source>Оборудование на вынос</source>
        <translation>Equipment to bring out</translation>
      </field>
      <field name="equipment_import">
        <source>Оборудование на внос</source>
        <translation>Equipment to bring in</translation>
      </field>
      <field name="insearch">
        <source>В розыске</source>
        <translation>Wanted</translation>
      </field>
      <field name="lost">
        <source>Утерян</source>
        <translation>Lost</translation>
      </field>
      <field name="note">
        <source>Примечание</source>
        <translation>Note</translation>
      </field>
      <field name="note2">
        <source>Примечание 2</source>
        <translation>Note 2</translation>
      </field>
      <field name="note3">
        <source>Примечание 3</source>
        <translation>Note 3</translation>
      </field>
      <field name="note4">
        <source>Примечание 4</source>
        <translation>Note 4</translation>
      </field>
      <field name="note5">
        <source>Примечание 5</source>
        <translation>Note 5</translation>
      </field>
      <field name="note6">
        <source>Примечание 6</source>
        <translation>Note 6</translation>
      </field>
      <field name="note_mobile">
        <source>Дополнительные данные об автомобиле</source>
        <translation>Additional vehicle data</translation>
      </field>
      <field name="note_thing">
        <source>Дополнительные данные о грузе</source>
        <translation>Additional data</translation>
      </field>
      <field name="number">
        <source>Номер</source>
        <translation>Number</translation>
      </field>
      <field name="permitput">
        <source>Дата сдачи пропуска</source>
        <translation>Permit return date</translation>
      </field>
      <field name="pin">
        <source>Пин</source>
        <translation>Pin code</translation>
      </field>
      <field name="prolongationhistory">
        <source>История продления пропуска</source>
        <translation>Prolongation history</translation>
      </field>
      <field name="requisition">
        <source>Id заявки</source>
        <translation>Pre-registration Id</translation>
      </field>
      <field name="requisitionagreeing">
        <source>Кто согласовал</source>
        <translation>Who approved</translation>
      </field>
      <field name="requisitiondate">
        <source>Дата заявки</source>
        <translation>Pre-registration date</translation>
      </field>
      <field name="requisitionnumber">
        <source>Номер заявки</source>
        <translation>Pre-registration number</translation>
      </field>
      <field name="requisitionreceiving">
        <source>Принимающий</source>
        <translation>Receiving</translation>
      </field>
      <field name="requisitionsignatory">
        <source>Кто подписал</source>
        <translation>Who signed</translation>
      </field>
      <field name="state">
        <source>Состояние</source>
        <translation>Status</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="visitaim">
        <source>Цель визита</source>
        <translation>Visit goal</translation>
      </field>
      <field name="wheregoingto">
        <source>К кому идет</source>
        <translation>Host</translation>
      </field>
      <field name="actsecurlevel">
        <source>Уровень безопасности при активации</source>
        <translation>Activation security level</translation>
      </field>
      <field name="declarer_department">
        <source>Подразделение заявителя</source>
        <translation>Applicant department</translation>
      </field>
      <field name="declarer_organization">
        <source>Организация заявителя</source>
        <translation>Applicant organization</translation>
      </field>
      <field name="idcode">
        <source>Идентификатор</source>
        <translation>Identifier</translation>
      </field>
      <field name="ownpart">
        <source>Свой раздел охранной сигнализации PCE</source>
        <translation>Own PCE alarm section</translation>
      </field>
      <field name="permitType">
        <source>Тип</source>
        <translation>Type</translation>
      </field>
      <field name="schedule">
        <source>Расписание</source>
        <translation>Schedule</translation>
      </field>
      <field name="subjact">
        <source>Активировал</source>
        <translation>Activated</translation>
      </field>
      <field name="subjblock">
        <source>Заблокировал</source>
        <translation>Blocked</translation>
      </field>
      <field name="subjcreate">
        <source>Создал</source>
        <translation>Created</translation>
      </field>
      <field name="subjdeact">
        <source>Деактивировал</source>
        <translation>Deactivated</translation>
      </field>
      <field name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
      <action name="activate">
        <source>Активировать</source>
        <translation>Activate</translation>
        <params/>
      </action>
      <action name="activateFromRequisition">
        <source>Активировать по заявке</source>
        <translation>Activate by pre-registration</translation>
        <params>
          <param name="requisition">
            <source>Заявка</source>
            <translation>Pre-registration</translation>
          </param>
        </params>
      </action>
      <action name="activateOnApacsBio">
        <source>Активировать пропуск в ApacsBio</source>
        <translation>Activate permit in ApacsBio</translation>
        <params/>
      </action>
      <action name="activateOnApollo">
        <source>Активировать пропуск в Apollo</source>
        <translation>Activate permit in Apollo</translation>
        <params/>
      </action>
      <action name="activateOnDevice">
        <source>Активировать в оборудовании</source>
        <translation>Activate on device</translation>
        <params/>
      </action>
      <action name="activateOnHouseKeeper">
        <source>Активировать пропуск в ключнице</source>
        <translation>Activate permit in keyholder</translation>
        <params/>
      </action>
      <action name="activateOnPCE">
        <source>Активировать пропуск в PCE</source>
        <translation>Activate permit in PCE</translation>
        <params/>
      </action>
      <action name="activateOnRubej08">
        <source>Активировать пропуск в Рубеж-08</source>
        <translation>Activate permit in Rubezh-08</translation>
        <params/>
      </action>
      <action name="activateOnUld">
        <source>Активировать пропуск в УЛУ</source>
        <translation>Activate permit in ULD</translation>
        <params/>
      </action>
      <action name="activateOrionIntgrSrv">
        <source>Активировать пропуск в Орион Про</source>
        <translation>Activate permit in ORION Pro</translation>
        <params/>
      </action>
      <action name="block">
        <source>Блокировать</source>
        <translation>Lock</translation>
        <params>
          <param name="commentary">
            <source>Коментарий</source>
            <translation>Comment</translation>
          </param>
        </params>
      </action>
      <action name="clone">
        <source>Клонировать</source>
        <translation>Clone</translation>
        <params/>
      </action>
      <action name="deactivate">
        <source>Деактивировать</source>
        <translation>Deactivate</translation>
        <params/>
      </action>
      <action name="deblock">
        <source>Разблокировать</source>
        <translation>Unblock</translation>
        <params/>
      </action>
      <action name="prolongate">
        <source>Продлить</source>
        <translation>Prolong</translation>
        <params>
          <param name="enddt">
            <source>Дата окончания</source>
            <translation>Expiration date</translation>
          </param>
          <param name="reason">
            <source>Причина продления</source>
            <translation>Prolongation reason</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="permitprolongationreason">
      <alias>
        <source>Причина продления пропуска</source>
        <translation>Permit prolongation reason</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="description">
        <source>Название</source>
        <translation>Description</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
    </devType>
    <devType name="permittemplate">
      <alias>
        <source>Шаблон пропуска</source>
        <translation>Permit template</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="src">
        <source>Файл</source>
        <translation>Source</translation>
      </field>
      <field name="template_type">
        <source>Тип шаблона</source>
        <translation>Template type</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
    </devType>
    <devType name="permittype">
      <alias>
        <source>Тип пропуска</source>
        <translation>Permit type</translation>
      </alias>
      <parent>
        <source>Транспортное средство</source>
        <translation>Vehicle</translation>
      </parent>
      <field name="actionStartDay">
        <source>Начало действия</source>
        <translation>Validity period beginning</translation>
      </field>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="duration">
        <source>Время действия</source>
        <translation>Validity period</translation>
      </field>
      <field name="durationRestriction">
        <source>Ограничение срока действия</source>
        <translation>Validity period duration</translation>
      </field>
      <field name="form_template">
        <source>Шаблон редактирования</source>
        <translation>Edition template</translation>
      </field>
      <field name="infoFlag1">
        <source>Дополнительный флаг 1</source>
        <translation>Additional flag 1</translation>
      </field>
      <field name="infoFlag2">
        <source>Дополнительный флаг 2</source>
        <translation>Additional flag 2</translation>
      </field>
      <field name="infoFlag3">
        <source>Дополнительный флаг 3</source>
        <translation>Additional flag 3</translation>
      </field>
      <field name="infoFlag4">
        <source>Дополнительный флаг 4</source>
        <translation>Additional flag 4</translation>
      </field>
      <field name="infoFlag5">
        <source>Дополнительный флаг 5</source>
        <translation>Additional flag 5</translation>
      </field>
      <field name="infoFlag6">
        <source>Дополнительный флаг 6</source>
        <translation>Additional flag 6</translation>
      </field>
      <field name="needRequest">
        <source>Обязательна заявка</source>
        <translation>Pre-registration is necessary</translation>
      </field>
      <field name="oneTime">
        <source>Разовый</source>
        <translation>One-time</translation>
      </field>
      <field name="saveLinkToId">
        <source>При клонировании сохранять ссылку на идентификатор</source>
        <translation>Save reference to id while clonong</translation>
      </field>
      <field name="visitortype">
        <source>Тип субъекта</source>
        <translation>Visitor type</translation>
      </field>
      <field name="withoutIdcode">
        <source>Без идентификатора</source>
        <translation>Without Id</translation>
      </field>
      <field name="default_template">
        <source>Шаблон по умолчанию</source>
        <translation>Default template</translation>
      </field>
      <link name="default_template">
        <source>Шаблон по умолчанию</source>
        <translation>Default template</translation>
      </link>
    </devType>
    <devType name="permittype_permittemplate">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Шаблоны пропусков</source>
        <translation>Permit templates</translation>
      </parent>
      <field name="permittemplate">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="permittemplate">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="permit_commonright">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Права</source>
        <translation>Rights</translation>
      </parent>
      <field name="resolution">
        <source>Резолюция</source>
        <translation>Resolution</translation>
      </field>
      <field name="valid_from">
        <source>Действует с</source>
        <translation>Valid from</translation>
      </field>
      <field name="valid_to">
        <source>Действует до</source>
        <translation>Valid until</translation>
      </field>
      <field name="assigned_subject">
        <source>Назначил</source>
        <translation>Assigned by</translation>
      </field>
      <field name="commonright">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="commonright">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="permit_permit">
      <alias>
        <source></source>
        <translation>Permit</translation>
      </alias>
      <parent>
        <source>Связанные пропуска</source>
        <translation>Related permits</translation>
      </parent>
      <field name="permit">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="permit">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="person">
      <alias>
        <source>Частные лица</source>
        <translation>Persons</translation>
      </alias>
      <parent>
        <source>Частное лицо</source>
        <translation>Person</translation>
      </parent>
      <field name="birthPlace">
        <source>Место рождения</source>
        <translation>Birthplace</translation>
      </field>
      <field name="birthday_v2">
        <source>Дата рождения</source>
        <translation>Birthday</translation>
      </field>
      <field name="category">
        <source>Категория</source>
        <translation>Category</translation>
      </field>
      <field name="citizenship">
        <source>Гражданство</source>
        <translation>Citizenship</translation>
      </field>
      <field name="description">
        <source>Ф.И.О.</source>
        <translation>Full name</translation>
      </field>
      <field name="docNumber">
        <source>Номер</source>
        <translation>Document number</translation>
      </field>
      <field name="document">
        <source>Документ</source>
        <translation>Document</translation>
      </field>
      <field name="documentscan">
        <source>Скан документа</source>
        <translation>Document scan</translation>
      </field>
      <field name="email">
        <source>Адрес электронной почты</source>
        <translation>E-mail</translation>
      </field>
      <field name="employeeNumber">
        <source>Табельный номер</source>
        <translation>Personnel number</translation>
      </field>
      <field name="employmentContract">
        <source>Трудовой договор</source>
        <translation>Employment contract</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External id</translation>
      </field>
      <field name="fingerPrint1">
        <source>Отпечаток 1</source>
        <translation>Fingerprint 1</translation>
      </field>
      <field name="fingerPrint10">
        <source>Отпечаток 10</source>
        <translation>Fingerprint 10</translation>
      </field>
      <field name="fingerPrint2">
        <source>Отпечаток 2</source>
        <translation>Fingerprint 2</translation>
      </field>
      <field name="fingerPrint3">
        <source>Отпечаток 3</source>
        <translation>Fingerprint 3</translation>
      </field>
      <field name="fingerPrint4">
        <source>Отпечаток 4</source>
        <translation>Fingerprint 4</translation>
      </field>
      <field name="fingerPrint5">
        <source>Отпечаток 5</source>
        <translation>Fingerprint 5</translation>
      </field>
      <field name="fingerPrint6">
        <source>Отпечаток 6</source>
        <translation>Fingerprint 6</translation>
      </field>
      <field name="fingerPrint7">
        <source>Отпечаток 7</source>
        <translation>Fingerprint 7</translation>
      </field>
      <field name="fingerPrint8">
        <source>Отпечаток 8</source>
        <translation>Fingerprint 8</translation>
      </field>
      <field name="fingerPrint9">
        <source>Отпечаток 9</source>
        <translation>Fingerprint 9</translation>
      </field>
      <field name="issuedBy">
        <source>Кем выдан</source>
        <translation>Issued by</translation>
      </field>
      <field name="issuedWhen">
        <source>Дата выдачи</source>
        <translation>Date of issue</translation>
      </field>
      <field name="note">
        <source>Примечание</source>
        <translation>Note</translation>
      </field>
      <field name="note2">
        <source>Примечание 2</source>
        <translation>Note 2</translation>
      </field>
      <field name="note3">
        <source>Примечание 3</source>
        <translation>Note 3</translation>
      </field>
      <field name="note4">
        <source>Примечание 4</source>
        <translation>Note 4</translation>
      </field>
      <field name="note5">
        <source>Примечание 5</source>
        <translation>Note 5</translation>
      </field>
      <field name="note6">
        <source>Примечание 6</source>
        <translation>Note 6</translation>
      </field>
      <field name="phone">
        <source>Мобильный телефон</source>
        <translation>Mobile phone</translation>
      </field>
      <field name="phone2">
        <source>Мобильный телефон (доп.)</source>
        <translation>Mobile phone (add.)</translation>
      </field>
      <field name="phoneNumber">
        <source>Рабочий (внутренний) телефон</source>
        <translation>Business (internal) phone</translation>
      </field>
      <field name="placeOfActualResidence">
        <source>Адрес проживания</source>
        <translation>Residence address</translation>
      </field>
      <field name="placeOfResidence">
        <source>Адрес регистрации</source>
        <translation>Registration address</translation>
      </field>
      <field name="series">
        <source>Серия</source>
        <translation>Document series</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="postref">
        <source>Должность</source>
        <translation>Job title</translation>
      </field>
      <link name="postref">
        <source>Должность</source>
        <translation>Job title</translation>
      </link>
      <action name="clrAllFingerPrints">
        <source>Удалить все отпечатки</source>
        <translation>Clear all fingerprints</translation>
        <params/>
      </action>
      <action name="clrFingerPrint">
        <source>Удалить отпечаток пальца</source>
        <translation>Clear fingerPrint</translation>
        <params>
          <param name="printNum">
            <source>Номер отпечатка</source>
            <translation>Fingerprint number</translation>
          </param>
        </params>
      </action>
      <action name="deactivateAllPermits">
        <source>Деактивировать все пропуска</source>
        <translation>Deactivate all permits</translation>
        <params/>
      </action>
      <action name="getAllFingerPrints">
        <source></source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="getFingerPrint">
        <source></source>
        <translation>undefined</translation>
        <params>
          <param name="printNum">
            <source></source>
            <translation>undefined</translation>
          </param>
        </params>
      </action>
      <action name="hasFingerPrint">
        <source>Проверить, есть ли отпечаток</source>
        <translation>Check if fingerprint exists</translation>
        <params>
          <param name="printNum">
            <source></source>
            <translation>undefined</translation>
          </param>
        </params>
      </action>
      <action name="setFingerPrint">
        <source>Установить отпечаток пальца</source>
        <translation>Set fingerprint</translation>
        <params>
          <param name="printNum">
            <source>Номер отпечатка</source>
            <translation>Fingerprint number</translation>
          </param>
          <param name="fingerPrint">
            <source>Отпечаток</source>
            <translation>Fingerprint</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="post">
      <alias>
        <source>Должность</source>
        <translation>Job title</translation>
      </alias>
      <parent>
        <source>Частное лицо</source>
        <translation>Person</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External Id</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <link name="postref">
        <source>Должность</source>
        <translation>Job title</translation>
      </link>
    </devType>
    <devType name="respondresource">
      <alias>
        <source>Ресурс реагирования</source>
        <translation>Respond resource</translation>
      </alias>
      <parent>
        <source>Частное лицо</source>
        <translation>Person</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="type">
        <source>Тип ресура</source>
        <translation>Resource type</translation>
      </field>
      <field name="navigationdevice">
        <source>Навигационное устройство</source>
        <translation>Navigation device</translation>
      </field>
      <field name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </field>
      <link name="subject">
        <source>Субъект</source>
        <translation>Subject</translation>
      </link>
    </devType>
    <devType name="root">
      <alias>
        <source>Настройки</source>
        <translation>Settings</translation>
      </alias>
      <parent>
        <source>Частное лицо</source>
        <translation>Person</translation>
      </parent>
      <field name="add_face_to_recognition_list_when_activate_permit">
        <source>Добавить лицо в список распознавания при активации пропуска</source>
        <translation>Add face to recognition list at the moment of permit activation</translation>
      </field>
      <field name="add_face_to_recognition_list_when_add_to_blacklist">
        <source>Добавить лицо в список распознавания при открытии нарушения</source>
        <translation>Add face to recognition list at the moment of violation activation</translation>
      </field>
      <field name="archive_face_when_deactivate_permit">
        <source>Архивировать лицо в списке распознавания при деактивации пропуска</source>
        <translation>Add face to recognition list at the moment of permit deactivation</translation>
      </field>
      <field name="create_person_from_third_face">
        <source>Создавать персону при выгрузке лиц из стороних систем?</source>
        <translation>Create person when uploading from third-party systems</translation>
      </field>
      <field name="currentpin">
        <source>Текущий код авторизации</source>
        <translation>Current PIN</translation>
      </field>
      <field name="lastpin">
        <source>Предыдущий код авторизации</source>
        <translation>Last PIN</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>Monitored object type</translation>
      </field>
      <field name="upload_face_to_intellect">
        <source>Загружать лица для распознавания в Интеллект</source>
        <translation>Load faces for recognition to Intellect</translation>
      </field>
      <field name="upload_face_to_securos">
        <source>Загружать лица для распознавания в SecurOs</source>
        <translation>Load faces for recognition to SecurOs</translation>
      </field>
      <field name="upload_face_to_vizir">
        <source>Загружать лица для распознавания в Визирь</source>
        <translation>Load faces for recognition to Vizir</translation>
      </field>
      <field name="defaultPermitType">
        <source>Тип пропуска по умолчанию</source>
        <translation>Default permit type</translation>
      </field>
      <field name="gsmmodem">
        <source>GSM модем</source>
        <translation>GSM modem</translation>
      </field>
      <field name="securLevel">
        <source>Уровень безопасности</source>
        <translation>Security level</translation>
      </field>
      <link name="securLevel">
        <source>Уровень безопасности</source>
        <translation>Security level</translation>
      </link>
      <action name="create_face_by_person">
        <source>Добавить личность</source>
        <translation>Add person</translation>
        <params>
          <param name="person">
            <source>Субъект</source>
            <translation>Subject</translation>
          </param>
          <param name="description">
            <source>Описание</source>
            <translation>Description</translation>
          </param>
          <param name="photo">
            <source>Фотография</source>
            <translation>Photo</translation>
          </param>
          <param name="round_photo">
            <source>Круглое фото</source>
            <translation>Round photo</translation>
          </param>
        </params>
      </action>
      <action name="create_person_with_wantedface">
        <source>Добавить известную личность</source>
        <translation>Add a known person</translation>
        <params>
          <param name="description">
            <source>Имя</source>
            <translation>Name</translation>
          </param>
          <param name="photo">
            <source>Фотография</source>
            <translation>Photo</translation>
          </param>
        </params>
      </action>
      <action name="create_unknown_wantedface">
        <source>Добавить неизвестную личность</source>
        <translation>Add an unknown person</translation>
        <params>
          <param name="description">
            <source>Имя</source>
            <translation>Name</translation>
          </param>
          <param name="blacklist">
            <source>В черном списке</source>
            <translation>In black list</translation>
          </param>
          <param name="photo">
            <source>Фотография</source>
            <translation>Photo</translation>
          </param>
        </params>
      </action>
      <action name="deactivateOneTimePermitByNum">
        <source>Деактивировать разовый пропуск</source>
        <translation>Deactivate one-time permit</translation>
        <params>
          <param name="permitId">
            <source>Номер пропуска</source>
            <translation>Permit number</translation>
          </param>
        </params>
      </action>
      <action name="deactivatePermitByNum">
        <source>Деактивировать пропуск</source>
        <translation>Deactivate permit</translation>
        <params>
          <param name="permitId">
            <source>Номер пропуска</source>
            <translation>Permit number</translation>
          </param>
        </params>
      </action>
      <action name="delete_face_by_person">
        <source>Удаление личности</source>
        <translation>Delete person</translation>
        <params>
          <param name="person">
            <source>Субъект</source>
            <translation>Subject</translation>
          </param>
        </params>
      </action>
      <action name="edit_face_by_person">
        <source>Изменение личности</source>
        <translation>Edit person</translation>
        <params>
          <param name="person">
            <source>Субъект</source>
            <translation>Subject</translation>
          </param>
          <param name="description">
            <source>Описание</source>
            <translation>Description</translation>
          </param>
          <param name="photo">
            <source>Фотография</source>
            <translation>Photo</translation>
          </param>
          <param name="round_photo">
            <source>Круглое фото</source>
            <translation>Round photo</translation>
          </param>
        </params>
      </action>
      <action name="import_wantedface">
        <source>Загрузить лица из стороних систем</source>
        <translation>Import faces form third party systems</translation>
        <params/>
      </action>
      <action name="sendSMS">
        <source>Отправить СМС</source>
        <translation>Send SMS</translation>
        <params>
          <param name="number">
            <source>Номер телефона</source>
            <translation>Phone number</translation>
          </param>
          <param name="message">
            <source>Текст сообщения</source>
            <translation>Message text</translation>
          </param>
        </params>
      </action>
      <action name="setSecurLevel">
        <source>Установить уровень безопасности</source>
        <translation>Set security level</translation>
        <params>
          <param name="level">
            <source>Уровень безопасности</source>
            <translation>Security level</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="root_tinterval">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Отслеживаемые временные интервалы</source>
        <translation>Logical time intervals</translation>
      </parent>
      <field name="tinterval">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="tinterval">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="rschedule">
      <alias>
        <source>Регулярное расписание</source>
        <translation>Regular schedule</translation>
      </alias>
      <parent>
        <source>Отслеживаемые временные интервалы</source>
        <translation>Tracked time intervals</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="tzones_map">
        <source>Временные зоны</source>
        <translation>Time zones</translation>
      </field>
      <field name="year">
        <source>Год</source>
        <translation>Year</translation>
      </field>
      <link name="tinterval">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="rschedule_tzone">
      <alias>
        <source></source>
        <translation>Regular schedule tzone</translation>
      </alias>
      <parent>
        <source>Временные зоны</source>
        <translation>Time zones</translation>
      </parent>
      <field name="tzone">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="tzone">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="schedule">
      <alias>
        <source>Расписание</source>
        <translation>Schedule</translation>
      </alias>
      <parent>
        <source>Временные зоны</source>
        <translation>Time zones</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="external_id">
        <source>Внешний идентификатор</source>
        <translation>External id</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="timezone">
        <source>Временная зона TSS</source>
        <translation>TSS time zone</translation>
      </field>
      <link name="timezone">
        <source>Временная зона TSS</source>
        <translation>TSS time zone</translation>
      </link>
    </devType>
    <devType name="scheduletemplate">
      <alias>
        <source>Шаблон расписания</source>
        <translation>Shedule template</translation>
      </alias>
      <parent>
        <source>Временные зоны</source>
        <translation>Time zones</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <link name="timezone">
        <source>Временная зона TSS</source>
        <translation>TSS time zone</translation>
      </link>
    </devType>
    <devType name="scheduletemplate_rschedule">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Регулярные расписания</source>
        <translation>Regular shedules</translation>
      </parent>
      <field name="rschedule">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="rschedule">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="schedule_rschedule">
      <alias>
        <source></source>
        <translation>Schedules</translation>
      </alias>
      <parent>
        <source>Регулярные расписания</source>
        <translation>Regular schedules</translation>
      </parent>
      <field name="endDate">
        <source>Конец</source>
        <translation>Valid to</translation>
      </field>
      <field name="startDate">
        <source>Начало</source>
        <translation>Valid from</translation>
      </field>
      <field name="rschedule">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="rschedule">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="securlevel">
      <alias>
        <source>Уровень безопасности</source>
        <translation>Security level</translation>
      </alias>
      <parent>
        <source>Уровни безопасности</source>
        <translation>Security levels</translation>
      </parent>
      <field name="color">
        <source>Цвет</source>
        <translation>Color</translation>
      </field>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>undefined</translation>
      </field>
      <link name="rschedule">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="subject">
      <alias>
        <source>Субъект</source>
        <translation>Subject</translation>
      </alias>
      <parent>
        <source>Уровни безопасности</source>
        <translation>Security level</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="external_id">
        <source>Внешний ключ</source>
        <translation>External id</translation>
      </field>
      <field name="isIntruder">
        <source>Нарушитель</source>
        <translation>Violator</translation>
      </field>
      <field name="photo">
        <source>Фотография</source>
        <translation>Photo</translation>
      </field>
      <field name="photo2">
        <source>Дополнительное фото 1</source>
        <translation>Additional photo 1</translation>
      </field>
      <field name="photo3">
        <source>Дополнительное фото 2</source>
        <translation>Additional photo 2</translation>
      </field>
      <field name="photo4">
        <source>Дополнительное фото 3</source>
        <translation>Additional photo 3</translation>
      </field>
      <field name="photo5">
        <source>Дополнительное фото 4</source>
        <translation>Additional photo 4</translation>
      </field>
      <field name="photo6">
        <source>Дополнительное фото 5</source>
        <translation>Additional photo 5</translation>
      </field>
      <field name="round_photo">
        <source>Круглое фото</source>
        <translation>Round photo</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Id from external system</translation>
      </field>
      <field name="department">
        <source>Подразделение</source>
        <translation>Department</translation>
      </field>
      <field name="navigationdevice">
        <source>Навигационное устройство</source>
        <translation>Navigatino device</translation>
      </field>
      <field name="organization">
        <source>Организация</source>
        <translation>Organization</translation>
      </field>
      <field name="schedule">
        <source>Расписание УРВ</source>
        <translation>Time tracking schedule</translation>
      </field>
      <link name="schedule">
        <source>Расписание УРВ</source>
        <translation>Time tracking schedule</translation>
      </link>
      <action name="deleteFromSearch">
        <source>Удалить субъект из розыска</source>
        <translation>Remove subject from wanted list</translation>
        <params/>
      </action>
      <action name="inSearch">
        <source>Добавить субъект в розыск</source>
        <translation>Add subject to wanted list</translation>
        <params/>
      </action>
      <action name="insertIntoVizir">
        <source>Добавить субъект в Визирь</source>
        <translation>Add subject to Vizir</translation>
        <params/>
      </action>
    </devType>
    <devType name="subject_scheduletemplate">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Расписания</source>
        <translation>Shedules</translation>
      </parent>
      <field name="begin_date">
        <source>Дата начала</source>
        <translation>Beginning date</translation>
      </field>
      <field name="end_date">
        <source>Дата окончания</source>
        <translation>End date</translation>
      </field>
      <field name="scheduletemplate">
        <source>Шаблон расписания</source>
        <translation>Schedule template</translation>
      </field>
      <link name="scheduletemplate">
        <source>Шаблон расписания</source>
        <translation>Shedule template</translation>
      </link>
    </devType>
    <devType name="thing">
      <alias>
        <source>Материальные ценности</source>
        <translation>Things</translation>
      </alias>
      <parent>
        <source>Материальная ценность</source>
        <translation>Thing</translation>
      </parent>
      <field name="description">
        <source>Наименование</source>
        <translation>Description</translation>
      </field>
      <field name="packaging">
        <source>Упаковка</source>
        <translation>Package</translation>
      </field>
      <field name="placecount">
        <source>Количество мест</source>
        <translation>Number of places</translation>
      </field>
      <field name="somedate">
        <source>Дата</source>
        <translation>Date</translation>
      </field>
      <link name="scheduletemplate">
        <source>Шаблон расписания</source>
        <translation>Schedule template</translation>
      </link>
    </devType>
    <devType name="tinterval">
      <alias>
        <source>Временной интервал</source>
        <translation>Time interval</translation>
      </alias>
      <parent>
        <source>Материальная ценность</source>
        <translation>Thing</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="endTime">
        <source>Время конца</source>
        <translation>End time</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>Monitored object type</translation>
      </field>
      <field name="startTime">
        <source>Время начала</source>
        <translation>Beginning time</translation>
      </field>
      <link name="scheduletemplate">
        <source>Шаблон расписания</source>
        <translation>Schedule template</translation>
      </link>
    </devType>
    <devType name="tzone">
      <alias>
        <source>Временная зона</source>
        <translation>Time zone</translation>
      </alias>
      <parent>
        <source>Материальная ценность</source>
        <translation>Thing</translation>
      </parent>
      <field name="color">
        <source>Цвет</source>
        <translation>Color</translation>
      </field>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="deviatinflag">
        <source>Зона из отклонения</source>
        <translation>Zone from a deviation</translation>
      </field>
      <field name="short_title">
        <source>Краткое наименование</source>
        <translation>Short title</translation>
      </field>
      <field name="working_type_classifier">
        <source>Классификатор раб. времени</source>
        <translation>Work time classifier</translation>
      </field>
      <link name="working_type_classifier">
        <source>Классификатор раб. времени</source>
        <translation>Working time qualifier</translation>
      </link>
    </devType>
    <devType name="tzone_tinterval">
      <alias>
        <source></source>
        <translation>tzone_tinterval</translation>
      </alias>
      <parent>
        <source>Временные интервалы</source>
        <translation>Time intervals</translation>
      </parent>
      <field name="tinterval">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="tinterval">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="wantedface">
      <alias>
        <source>Распознаваемые лица</source>
        <translation>Recognized faces</translation>
      </alias>
      <parent>
        <source>Временные интервалы</source>
        <translation>Time intervals</translation>
      </parent>
      <field name="blacklist">
        <source>Черный список (для неизвестных лиц)</source>
        <translation>Blacklist (for unknown persons)</translation>
      </field>
      <field name="description">
        <source>Имя (для неизвестных лиц)</source>
        <translation>Name (for unknown persons)</translation>
      </field>
      <field name="photos">
        <source>Фотографии (для неизвестных лиц)</source>
        <translation>Photos (for unknown persons)</translation>
      </field>
      <field name="subsystem_ids">
        <source>Ключи в сторонних системах</source>
        <translation>Keys in third-party systems</translation>
      </field>
      <field name="sync">
        <source>Синхронизирован</source>
        <translation>Synchronized</translation>
      </field>
      <field name="person">
        <source>Человек</source>
        <translation>Person</translation>
      </field>
      <link name="person">
        <source>Человек</source>
        <translation>Person</translation>
      </link>
      <action name="operation_wantedface">
        <source>Добавить/Изменить/Удалить неизвестную личность</source>
        <translation>Add/Modify/Delete an unknown person</translation>
        <params>
          <param name="description">
            <source>Имя</source>
            <translation>Name</translation>
          </param>
          <param name="blacklist">
            <source>В черном списке</source>
            <translation>In black List</translation>
          </param>
          <param name="photos">
            <source>Фотография</source>
            <translation>photo</translation>
          </param>
          <param name="type_operation">
            <source>Тип операции(create/delete)</source>
            <translation>Action type(create/delete)</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="workingtypeclassifier">
      <alias>
        <source>Классификатор рабочего времени</source>
        <translation>Working time qualifier</translation>
      </alias>
      <parent>
        <source>Временные интервалы</source>
        <translation>Time intervals</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="digital_code">
        <source>Цифровой код</source>
        <translation>Digital code</translation>
      </field>
      <field name="letter_code">
        <source>Буквенный код</source>
        <translation>Letter code</translation>
      </field>
      <field name="name">
        <source>Краткое наименование</source>
        <translation>Short title</translation>
      </field>
      <field name="work_flag">
        <source>Рабочее время</source>
        <translation>Wirking time</translation>
      </field>
      <link name="person">
        <source>Человек</source>
        <translation>Person</translation>
      </link>
    </devType>
  </devTypes>
  <strings>
    <string name="preCreateRootError">
      <source>Объект настроек может быть только один</source>
      <translation>Only one object of settings can exist</translation>
    </string>
    <string name="yes">
      <source>Да</source>
      <translation>Yes</translation>
    </string>
    <string name="no">
      <source>Нет</source>
      <translation>No</translation>
    </string>
    <string name="notDefined">
      <source>Не задано</source>
      <translation>Not set</translation>
    </string>
    <string name="limitedInDays">
      <source>Ограничен в днях</source>
      <translation>Limited in days</translation>
    </string>
    <string name="limitedInHours">
      <source>Ограничен в часах</source>
      <translation>Limited in hours</translation>
    </string>
    <string name="CurrentDay">
      <source>Текущий день</source>
      <translation>Current day</translation>
    </string>
    <string name="NextDay">
      <source>Следующий день</source>
      <translation>Next day</translation>
    </string>
    <string name="credentialAlreadyActivated">
      <source>Пропуск уже активирован</source>
      <translation>Permit already activated</translation>
    </string>
    <string name="root_credentialNotFound">
      <source>Пропуск №%s не найден</source>
      <translation>Permit No.%s not found</translation>
    </string>
    <string name="Internal">
      <source>Внутренний</source>
      <translation>Internal</translation>
    </string>
    <string name="External">
      <source>Внешний</source>
      <translation>External</translation>
    </string>
    <string name="Attributecantbechanged">
      <source>Нельзя изменять этот атрибут в данном состоянии</source>
      <translation>It is not possible to change this attribute in current state</translation>
    </string>
    <string name="Statechangeerror">
      <source>Ошибка изменения состояния</source>
      <translation>Error of state change</translation>
    </string>
    <string name="Nocomment">
      <source>Нет комментария</source>
      <translation>No comment</translation>
    </string>
    <string name="Nosubject">
      <source>Нет субъекта</source>
      <translation>No subject</translation>
    </string>
    <string name="NoOperatorLink">
      <source>Нет ссылки на оператора</source>
      <translation>No reference to operator</translation>
    </string>
    <string name="NoViolationType">
      <source>Нет комментария закрытия записи</source>
      <translation>No closing comment</translation>
    </string>
    <string name="ViolationDeletionRestricted">
      <source>Нельзя удалять открытые нарушения</source>
      <translation>It is impossible to delete open violations</translation>
    </string>
    <string name="OperatorsSubjectNotFound">
      <source>Субъект оператора не найден</source>
      <translation>Operator subject not found</translation>
    </string>
    <string name="CommentNotSet">
      <source>Комментарий закрытия нарушения не задан</source>
      <translation>Violation closing comment not set</translation>
    </string>
    <string name="OpenCommentNotSet">
      <source>Комментарий открытия нарушения не задан</source>
      <translation>Violation opening comment not set</translation>
    </string>
    <string name="SubjectNotFound">
      <source>Субъект не найден</source>
      <translation>Subject not found</translation>
    </string>
    <string name="ViolationTypeNotExists">
      <source>Такого типа нарушения не существует</source>
      <translation>Violation type does not exist</translation>
    </string>
    <string name="WrongCredentialIssueBlock">
      <source>Неверное задание блокировки выдачи пропуска</source>
      <translation>Incorrect permit issue blocking</translation>
    </string>
    <string name="UnableToDeleteViolationType">
      <source>Нельзя удалить данный тип нарушения так как есть открытое нарушение с данным типом</source>
      <translation>Violation type can not be deleted, because there is an active violation with this type</translation>
    </string>
    <string name="KeywordError">
      <source>Длина ключевого слова не может превышать 8 символов</source>
      <translation>Keyword length can't be more than 8 characters</translation>
    </string>
    <string name="AlreadyArchived">
      <source>Архивация не возможна. Подразделение уже архивировано.</source>
      <translation>Archiving is not possible. Department already archived.</translation>
    </string>
    <string name="Archiving">
      <source>Архивация</source>
      <translation>Archivation</translation>
    </string>
    <string name="ImpossibleThereAreActive">
      <source>не возможна. Есть активные пропуска с этом подразделением заявителем.</source>
      <translation>is not possible. </translation>
    </string>
    <string name="ImpossibleThereAreActive1">
      <source>не возможна. У людей из этого подразделения есть активные пропуска.</source>
      <translation>is not possible. People from this department have active permits.</translation>
    </string>
    <string name="DepArchived">
      <source>Подразделение архивировано</source>
      <translation>Department archived</translation>
    </string>
    <string name="ImpossibleOfChild">
      <source>не возможна так как не возможно архивировать одно из дочерних подразделений.</source>
      <translation>is not possible, because one of child departments can not be archived.</translation>
    </string>
    <string name="IdExists">
      <source>Идентификатор с кодом %s уже существует (#%s)</source>
      <translation>Id with code %s already exists (#%S)</translation>
    </string>
    <string name="IdWrongFormat">
      <source>Не корректный формат идентификатора</source>
      <translation>Invalid identifier format</translation>
    </string>
    <string name="idNotUnique16">
      <source>Идентификатор не уникален в формате 16</source>
      <translation>Id is not unique in format 16</translation>
    </string>
    <string name="idNotUnique24">
      <source>Идентификатор не уникален в формате 24</source>
      <translation>Id is not unique in format 24</translation>
    </string>
    <string name="idNotUnique32">
      <source>Идентификатор не уникален в формате 32</source>
      <translation>Id is not unique in format 32</translation>
    </string>
    <string name="idNotUnique48">
      <source>Идентификатор не уникален в формате 48</source>
      <translation>Id is not unique in format 48</translation>
    </string>
    <string name="idNotUnique64">
      <source>Идентификатор не уникален в формате 64</source>
      <translation>Id is not unique in format 64</translation>
    </string>
    <string name="idNotUnique128">
      <source>Идентификатор не уникален в формате 128</source>
      <translation>Id is not unique in format 128</translation>
    </string>
    <string name="NotUnique">
      <source> - НЕ УНИКАЛЕН</source>
      <translation> - NOT UNIQUE</translation>
    </string>
    <string name="orgAsOwner">
      <source>В качестве владельца может выступать только частное лицо или организация</source>
      <translation>Only person or organization can be the owner</translation>
    </string>
    <string name="onlyDraftAttach">
      <source>Прикрепть можно только черновик пропуска</source>
      <translation>Only permit draft can be attached</translation>
    </string>
    <string name="AlarmLvlNotDef">
      <source>Уровень тревожности не определен</source>
      <translation>Alarm level not defined</translation>
    </string>
    <string name="DeletionFailedActiveCred">
      <source>Удаление не возможно. Существует активированный пропуск.</source>
      <translation>Deletion is not possible. There is an activate permit.</translation>
    </string>
    <string name="DeletionFailedDeactivatedCred">
      <source>Удаление не возможно. Существует деактивированный пропуск.</source>
      <translation>Deletion is not possible. There is a deactivated permit.</translation>
    </string>
    <string name="DeletionFailedBlockCred">
      <source>Удаление не возможно. Существует заблокированный пропуск.</source>
      <translation>Deletion is not possible. There is a blocked permit.</translation>
    </string>
    <string name="DeletionFailedActivatedByCred">
      <source>Удаление не возможно. Существует пропуск, активированный данным человеком.</source>
      <translation>Deletion is not possible. There is a permit activated by this person.</translation>
    </string>
    <string name="DeletionFailedBlackList">
      <source>Удаление не возможно. Существует открытое нарушение.</source>
      <translation>Deletion is not possible. There is an open violation.</translation>
    </string>
    <string name="DelCompleted">
      <source>Удаление запрещено</source>
      <translation>Deletion is forbidden</translation>
    </string>
    <string name="WrngNum">
      <source>Номер указан неверно</source>
      <translation>Number specified incorrectly</translation>
    </string>
    <string name="CredentialNotOneTime">
      <source>Пропуск №%s не разовый</source>
      <translation>Permit No.%s is not onetime</translation>
    </string>
    <string name="Individual">
      <source>Частное лицо</source>
      <translation>Person</translation>
    </string>
    <string name="Vehicle">
      <source>Транспортное средство</source>
      <translation>Vehicle</translation>
    </string>
    <string name="Materialvalue">
      <source>Материальная ценность</source>
      <translation>Thing</translation>
    </string>
    <string name="OrgNameExists">
      <source>Организация с таким именем уже существует</source>
      <translation>Organization with this name already exists</translation>
    </string>
    <string name="OrgNotChangedBOSCH">
      <source>Организация не изменена в BOSCH</source>
      <translation>Organization was not changed in BOSCH</translation>
    </string>
    <string name="OrgAlreadyArch">
      <source>Архивация не возможна. Организация уже архивирована.</source>
      <translation>Archivation is not possible. Organization already archived.</translation>
    </string>
    <string name="ActiveCredsOrg">
      <source>не возможна. Есть активные пропуска с этой организацией заявителем.</source>
      <translation>not possible. There are active permits with this applicant organizaation.</translation>
    </string>
    <string name="ThereareactiveCreds">
      <source>не возможна. У людей из этой организации есть активные пропуска.</source>
      <translation>is not possible. People from this organization have active credentails.</translation>
    </string>
    <string name="OrgNotDelBOSCH">
      <source>Организация не удалена в BOSCH</source>
      <translation>Organization was not deleted from BOSCH</translation>
    </string>
    <string name="OrgArchived">
      <source>Организация архивирована.</source>
      <translation>Organization archived.</translation>
    </string>
    <string name="oneDepFailedToArc">
      <source>не возможна так как не возможно архивировать одно из подразделений.</source>
      <translation>is not possible, because one of departments can not be actvated.</translation>
    </string>
    <string name="thisIdSetFor">
      <source>Такой табельный номер указан у сотрудника</source>
      <translation>This employee id set for employee</translation>
    </string>
    <string name="CredDraft">
      <source>Пропуск является черновиком</source>
      <translation>Permit is a draft</translation>
    </string>
    <string name="CredDeact">
      <source>Пропуск уже деактивирован</source>
      <translation>Permit already deactivated</translation>
    </string>
    <string name="NeedReq">
      <source>Необходима заявка</source>
      <translation>Requisition required</translation>
    </string>
    <string name="CredActThisReq">
      <source>По этой заявке уже активирован пропуск %s</source>
      <translation>Permit %s already activated by this request</translation>
    </string>
    <string name="NeedSubj">
      <source>Необходимо указать субъект</source>
      <translation>It is necessary to specify the subject</translation>
    </string>
    <string name="NeedId">
      <source>Необходимо присвоить идентификатор</source>
      <translation>It is necessary to set the Id</translation>
    </string>
    <string name="IsIsForCred">
      <source>Идентификатор уже принадлежит активированному пропуску %s</source>
      <translation>Id already set for activated permit %s</translation>
    </string>
    <string name="CredentialActivated">
      <source>Пропуск %s активирован</source>
      <translation>Permit %s activated</translation>
    </string>
    <string name="CredNotAct">
      <source>Пропуск не активирован</source>
      <translation>Permit was not activated</translation>
    </string>
    <string name="ReactActCred">
      <source>Активировать повторно можно только активированные пропуска</source>
      <translation>Only activated permit can be reactivated</translation>
    </string>
    <string name="CredActInEquip">
      <source>Пропуск %s активирован в оборудовании</source>
      <translation>Permit %s activated in equipment</translation>
    </string>
    <string name="CredNotActPCE">
      <source>Пропуск не активирован в PCE</source>
      <translation>Permit was not activated in PCE</translation>
    </string>
    <string name="CredNotActApollo">
      <source>Пропуск не активирован в Apollo</source>
      <translation>Permit was not activated in Apollo</translation>
    </string>
    <string name="CredNotActOrion">
      <source>Пропуск не активирован в Орион Про</source>
      <translation>Permit was not activated in Orion Pro</translation>
    </string>
    <string name="CredNotActOrionIso">
      <source>Пропуск не активирован в Орион ИСО</source>
      <translation>Permit was not activated in Orion ISO</translation>
    </string>
    <string name="AcrErrorToKEy">
      <source>Ошибка при активации пропуска %s в ключницу: %s (попытка %s)</source>
      <translation>Error of activating the permit %s into Keyholder: %s (attempt %s)</translation>
    </string>
    <string name="CredNotActUlu">
      <source>Пропуск не активирован в УЛУ</source>
      <translation>Permit was not activated in ULD</translation>
    </string>
    <string name="CredNotActRubej">
      <source>Пропуск не активирован в Рубеж-08</source>
      <translation>Permit was not activated in Rubej-08</translation>
    </string>
    <string name="CredNotActRubezhGlobal">
      <source>Пропуск не активирован в Рубеж Глобал</source>
      <translation>Permit was not activated in Rubezh Global</translation>
    </string>
    <string name="CredNotActBOSCH">
      <source>Пропуск не активирован в BOSCH</source>
      <translation>Permit was not activated in BOSCH</translation>
    </string>
    <string name="CredNotActRusguard">
      <source>Пропуск не активирован в RusGuard</source>
      <translation>Permit was not activated in RusGuard</translation>
    </string>
    <string name="CredNotActRemote">
      <source>Пропуск не активирован на удаленном сервере</source>
      <translation>Permit was not activated on remote server</translation>
    </string>
    <string name="NosenseToactivate">
      <source>Не имеет смысла активировать пропуск без идентификатора</source>
      <translation>It is not possible to activate the permit withiout Id</translation>
    </string>
    <string name="CredIdNotFound">
      <source>Не найден идентификатор пропуска</source>
      <translation>Permit id not found</translation>
    </string>
    <string name="IdLenghtLess15">
      <source>Длина идентификатора не может быть больше 15 символов</source>
      <translation>Identifier length can't be more than 15 characters</translation>
    </string>
    <string name="CredActKeyholder">
      <source>Пропуск %s активирован в ключнице</source>
      <translation>Permit %s activated in Keyholder</translation>
    </string>
    <string name="IdNeedNum">
      <source>Необходим числовой идентификатор</source>
      <translation>Numeriacal Id required</translation>
    </string>
    <string name="IndiviNotFound">
      <source>Частное лицо не найдено</source>
      <translation>Person not found</translation>
    </string>
    <string name="CredNotActESM">
      <source>Пропуск не активирован в ESM</source>
      <translation>Permit was not archived in ESM</translation>
    </string>
    <string name="UluloadErrr">
      <source>Ошибка при прогрузке пропуска в УЛУ: %s</source>
      <translation>Error of permit loading to ULD: %s</translation>
    </string>
    <string name="ULUNorights">
      <source>Недостаточно прав на прогрузку в УЛУ</source>
      <translation>No rights for loading to ULD</translation>
    </string>
    <string name="UludeactErr">
      <source>Ошибка при деактивации пропуска в УЛУ: %s</source>
      <translation>Error of deactivating the permit in ULD: %s</translation>
    </string>
    <string name="cardCodeIdneed">
      <source>Необходим числовой идентификатор кода карты</source>
      <translation>Card code Id is required</translation>
    </string>
    <string name="credDeactInEquip">
      <source>Пропуск %s деактивирован в оборудовании</source>
      <translation>Permit %s deactivated in equipment</translation>
    </string>
    <string name="OnlyDeactCredAct">
      <source>Деактивировать можно только активированный пропуск</source>
      <translation>Only activated permit can be eactivated</translation>
    </string>
    <string name="CredNotDeactApollo">
      <source>Пропуск не деактивирован в Apollo</source>
      <translation>Permit was not deactivated in Apollo</translation>
    </string>
    <string name="CredNotDeactInInOrionPro">
      <source>Пропуск не деактивирован в Орион Про</source>
      <translation>Permit was not deactivated in Orion Pro</translation>
    </string>
    <string name="CredNotDeacInPce">
      <source>Пропуск не деактивирован в PCE %s</source>
      <translation>Permit was not deactivated in PCE %s</translation>
    </string>
    <string name="CredNotDeactInPCE1">
      <source>Пропуск не деактивирован в PCE</source>
      <translation>Permit was not deactivated in PCE</translation>
    </string>
    <string name="CredNotDeactInKEy">
      <source>Пропуск не деактивирован в ключнице</source>
      <translation>Permit was not deactivated in Keyholder</translation>
    </string>
    <string name="CredNotDeactInUld">
      <source>Пропуск не деактивирован в ULD</source>
      <translation>Permit was not deactivated in ULD</translation>
    </string>
    <string name="CredNotDeactInrubej">
      <source>Пропуск не деактивирован в Рубеж-08</source>
      <translation>Permit was not deactivated in Rubej-08</translation>
    </string>
    <string name="CredNotDeactRubezhGlobal">
      <source>Пропуск не деактивирован в Рубеж Глобал</source>
      <translation>Permit was not deactivated in Rubezh Global</translation>
    </string>
    <string name="CredNotDeactInOrionIso">
      <source>Пропуск не деактивирован в Орион ИСО</source>
      <translation>Permit was not deactivated in Orion ISO</translation>
    </string>
    <string name="CredNotDeactInBOSCH">
      <source>Пропуск не деактивирован в BOSCH</source>
      <translation>Permit was not deactivated in BOSCH</translation>
    </string>
    <string name="CredNotDeactRusGuard">
      <source>Пропуск не деактивирован в RusGuard</source>
      <translation>Permit was not deactivated in RusGuard</translation>
    </string>
    <string name="CredEDitRestricted">
      <source>Редактирование пропуска #%s запрещено</source>
      <translation>Permit #%s editing is forbidden</translation>
    </string>
    <string name="DublicatePermitsPIN">
      <source>Ошибка: заданный ПИН код уже используется в пропуске#%s</source>
      <translation>Error: The specified PIN is already assigned to permit #%s</translation>
    </string>
    <string name="EmptyIdRestricted">
      <source>Запрещено присваивать пустой идентификатор</source>
      <translation>It is not possible to set empty Id</translation>
    </string>
    <string name="NotUniqueIdRestricted">
      <source>Запрещено присваивать неуникальный идентификатор %s</source>
      <translation>It is forbidden to set the nonunique Id %s</translation>
    </string>
    <string name="CopyCreated">
      <source>Создана копия (№%s) пропуска №%s</source>
      <translation>Copy (No.%s) of permit No.%s created</translation>
    </string>
    <string name="UnknownDevice">
      <source>Неизвестное оборудование %s</source>
      <translation>Unknown equipment %s</translation>
    </string>
    <string name="CredAlreadyDeact">
      <source>Пропуск %s уже деактивирован</source>
      <translation>Permit %s already deactivated</translation>
    </string>
    <string name="CredNotActYet">
      <source>Пропуск %s еще не активирован</source>
      <translation>Permit %s is not activated yet</translation>
    </string>
    <string name="CredReactFromAttempt">
      <source>Пропуск %s реактивирован с %s попытки</source>
      <translation>Permit #s reacticated from %s attempt</translation>
    </string>
    <string name="ErrOfCredAct">
      <source>Ошибка при активации пропуска %s: %s (попытка %s)</source>
      <translation>Permit activation error %s: %s (attempt %s)</translation>
    </string>
    <string name="UnknOperator">
      <source>Неизвестный оператор</source>
      <translation>Unknown operator</translation>
    </string>
    <string name="NeedComment">
      <source>Необходим комментарий</source>
      <translation>Comment required</translation>
    </string>
    <string name="CredBlocked">
      <source>Пропуск %s заблокирован</source>
      <translation>Permit %s blocked</translation>
    </string>
    <string name="CredNotBlockedPCe">
      <source>Пропуск не блокирован в PCE</source>
      <translation>Permit was not blocked in PCE</translation>
    </string>
    <string name="CredNotBlockedOrionPro">
      <source>Пропуск не блокирован в Орион Про</source>
      <translation>Permit was not blocked in Orion Pro</translation>
    </string>
    <string name="CredNotBlockedKey">
      <source>Пропуск не блокирован в Ключнице</source>
      <translation>Permit was not blocked in Keyholder</translation>
    </string>
    <string name="CredNotBlockedUlu">
      <source>Пропуск не блокирован в УЛУ</source>
      <translation>Permit was not blocked in ULD</translation>
    </string>
    <string name="CredNotBlockedOrion">
      <source>Пропуск не блокирован в Орион ИСО</source>
      <translation>Permit was not blocked in Orion ISO</translation>
    </string>
    <string name="CredNotBlockedRubej">
      <source>Пропуск не блокирован в Рубеж-08</source>
      <translation>Permit was not blocked in Rubej-08</translation>
    </string>
    <string name="CredNotBlockedRubezhGlobal">
      <source>Пропуск не блокирован в Рубеж Глобал</source>
      <translation>Permit was not blocked in Rubezh Global</translation>
    </string>
    <string name="CredNotBlockedBOSCH">
      <source>Пропуск не блокирован в BOSCH</source>
      <translation>Permit was not blocked in Apollo</translation>
    </string>
    <string name="CredNotBlockRusGuard">
      <source>Пропуск не блокирован в RusGuard</source>
      <translation>Permit was not blocked in RusGuard</translation>
    </string>
    <string name="CredNotBlocked">
      <source>Пропуск не блокирован</source>
      <translation>Permit was not blocked</translation>
    </string>
    <string name="CredUblckd">
      <source>Пропуск %s разблокирован</source>
      <translation>Permit %s unblocked</translation>
    </string>
    <string name="TextIDsNotUs">
      <source>Текстовые идентификаторы не используются в Apollo</source>
      <translation>Text Idintifiers not used in Apollo</translation>
    </string>
    <string name="CredHasNoRightsForApolloPanels">
      <source>У пропуска нет прав ни на одну панель Apollo</source>
      <translation>Permit has no rights for Apollo panels</translation>
    </string>
    <string name="CredNotUnblckdPCE">
      <source>Пропуск не разблокирован в PCE</source>
      <translation>Permit was not unblocked in PCE</translation>
    </string>
    <string name="CredNotUnblckdOrionPro">
      <source>Пропуск не разблокирован в Орион Про</source>
      <translation>Permit was not unblocked in Orion Pro</translation>
    </string>
    <string name="ErrWhenUnblckCredToKey">
      <source>Ошибка при разблокировке пропуска %s в ключницу: %s (попытка %s)</source>
      <translation>Error of unblocking the permit %s into Keuholder: %s (attempt %s)</translation>
    </string>
    <string name="CredNotUnblckdUlu">
      <source>Пропуск не разблокирован в УЛУ</source>
      <translation>Permit was not unblocked in ULD</translation>
    </string>
    <string name="CredNotUnblckdRubej">
      <source>Пропуск не разблокирован в Рубеж-08</source>
      <translation>Permit was not unblocked in Rubej-08</translation>
    </string>
    <string name="CredNotUnblckdRubezhGlobal">
      <source>Пропуск не разблокирован в Рубеж Глобал</source>
      <translation>Permit was not unlocked at Rubezh Global</translation>
    </string>
    <string name="CredNotActbiostar">
      <source>Пропуск не активирован в BioStar</source>
      <translation>Permit was not activated in BioStar</translation>
    </string>
    <string name="CredNotActapacsbio">
      <source>Пропуск не активирован в ApacsBio</source>
      <translation>Permit was not activated in ApacsBio</translation>
    </string>
    <string name="CredNotBlockbiostar">
      <source>Пропуск не блокирован в BioStar</source>
      <translation>Permit was not blocked in BioStar</translation>
    </string>
    <string name="CredNotBlockapacsbio">
      <source>Пропуск не блокирован в ApacsBio</source>
      <translation>Permit was not blocked in ApacsBio</translation>
    </string>
    <string name="CredNotDeactbiostar">
      <source>Пропуск не деактивирован в BioStar</source>
      <translation>Permit was not deactivated in BioStar</translation>
    </string>
    <string name="CredNotDeactapacsbio">
      <source>Пропуск не деактивирован в ApacsBio</source>
      <translation>Permit was not deactivated in ApacsBio</translation>
    </string>
    <string name="CredNotUnblckdbiostar">
      <source>Пропуск не разблокирован в BioStar</source>
      <translation>Permit was not unblocked in BioStar</translation>
    </string>
    <string name="CredNotUnblckdapacsbio">
      <source>Пропуск не разблокирован в ApacsBio</source>
      <translation>Permit was not unblocked in ApacsBio</translation>
    </string>
    <string name="CredNotUnblckdBOSCH">
      <source>Пропуск не разблокирован в BOSCH</source>
      <translation>Permit was not unblocked in BOSCH</translation>
    </string>
    <string name="CredNotUnblockdRusguard">
      <source>Пропуск не разблокирован в RusGuard</source>
      <translation>Permit was not unblocked in RusGuard</translation>
    </string>
    <string name="CredLicenceNotValid">
      <source>Пропуск не может быть активирован, превышены лицензионные ограничения</source>
      <translation>Permit can not be activated because of license restrictions</translation>
    </string>
    <string name="CredCopyCreated">
      <source>Создана копия (№%s) пропуска №%s</source>
      <translation>Copy (#%s) of permit #%s created</translation>
    </string>
    <string name="activateOrionIntgrSrv">
      <source>Пропуск активирован в Модуле интеграции Орион Про</source>
      <translation>Permit activated in Orion Pro integration module</translation>
    </string>
    <string name="notActivateOrionIntgrSrv">
      <source>Пропуск не активирован в Модуле интеграции Орион Про</source>
      <translation>Permit was not activated in Orion Pro integration module</translation>
    </string>
    <string name="notActivateOrionIntgrSrvTabNum">
      <source>Пропуск не активирован в Модуле интеграции Орион Про. Табельный номер уже присвоен - %s </source>
      <translation>Permit was not activated in orion Pro integration module. Personnel number already assigned - %s </translation>
    </string>
    <string name="notActivateOrionIntgrSrvNoCon">
      <source>Пропуск не активирован в Модуле интеграции Орион Про. Нет связи с сервером интеграции Орион </source>
      <translation>Permit was not activated in Orion Pro integration module. NO connection with Orion integration server </translation>
    </string>
    <string name="OIS_AL_NOT_SET">
      <source>Уровень доступа для Модуля интеграции Орион Про не задан.</source>
      <translation>Access level for ORION Pro integration module is not set</translation>
    </string>
    <string name="permitProlongationReason">
      <source>Пропуск продлен %s по причине "%s"</source>
      <translation>Permit prolonged %s for reason "%s"</translation>
    </string>
    <string name="permitProlongationResult">
      <source>Пропуск %s продлен</source>
      <translation>Permit %s prolonged</translation>
    </string>
    <string name="enabled">
      <source>Включен</source>
      <translation>Enabled</translation>
    </string>
    <string name="disabled">
      <source>Выключен</source>
      <translation>Disabled</translation>
    </string>
    <string name="Subject_added_to_wanted_list">
      <source>Субъект добавлен в розыск</source>
      <translation>Subject added to wanted list</translation>
    </string>
    <string name="Subject_not_added_to_wanted_list">
      <source>Субект невозможно добавить в розыск</source>
      <translation>Subject can not be added to wanted list</translation>
    </string>
    <string name="SubjectDeletedFromWanted">
      <source>Субъект удален из розыска</source>
      <translation>Subject removed from wanted list</translation>
    </string>
    <string name="FailedToDeleteSubjectFromWanted">
      <source>Субъект невозможно удалить из розыска</source>
      <translation>Subject can not be removed from wanted list</translation>
    </string>
    <string name="respondResourcePerson">
      <source>Оператор</source>
      <translation>Operator</translation>
    </string>
    <string name="respondResourceGBR">
      <source>Группа быстрого реагирования</source>
      <translation>Rapid response team</translation>
    </string>
    <string name="pinLength">
      <source>Длинна пин-кода должна быть от 4 до 6 знаков</source>
      <translation>PIN must be 4 to 6 characters long.</translation>
    </string>
    <string name="greyList">
      <source>Серый список</source>
      <translation>Gray list</translation>
    </string>
    <string name="blackList">
      <source>Черный список</source>
      <translation>Black list</translation>
    </string>
    <string name="ApolloPermitNeedStartDate">
      <source>Необходимо указать дату начала действия</source>
      <translation>It is neccessary to specify a validity period start date</translation>
    </string>
    <string name="ApolloPermitNeedEndDate">
      <source>Необходимо указать дату окончания действия</source>
      <translation>It is neccessary to specify a validity period end date</translation>
    </string>
    <string name="TimeZoneShortTitleLengthError">
      <source>Длина краткого наименования не может быть больше 2 символов</source>
      <translation>Short name can not exceed 2 characters</translation>
    </string>
  </strings>
</equipment>
