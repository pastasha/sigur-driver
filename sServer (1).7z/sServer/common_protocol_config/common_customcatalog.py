# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_customcatalog(protocol_obj_base, alias='Справочники'):

    description = Attribute(alias='Вид справочника', fieldType=str, defval='', index=1)
