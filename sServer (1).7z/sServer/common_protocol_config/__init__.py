# -*- coding: utf-8 -*-

alias = 'Общие объекты'
