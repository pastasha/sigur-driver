# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, index_decorator, action_decorator
from equipment import dev_except
from equipment.methods_for_equipment import get_subsystem_ids

from .common_commonrighttemplate import common_commonrighttemplate


class common_organization(protocol_obj_base, alias='Организация'):
    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')

    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')
    
    @index_decorator('descriptionTSS')
    def descriptionIndexFunc(self):
        return self.description

    def __checkValidDescription(self, value, field):
        if value:
            cur = self._core.sql("""
                select count(*) from common_organization where description = %s and uniid != %s
            """, (value, self.getUniID()))
            if cur.fetchone()[0]:
                raise dev_except.TerminateAction(self._core.getString('OrgNameExists'))

    def __edit(self, oldValue, oldValues):
        if 'bosch' in self._core['...']:
            for ace in self._core['bosch'].getElements('ace'):
                flags = self.flags
                if flags & 1 == 0:
                    res = ace.doAction('exportOrganization',
                                       {'oldName': oldValue, 'newName': self.description})
                    if res != 0:
                        raise dev_except.TerminateAction(self._core.getString('OrgNotChangedBOSCH'))

    def __deleteDepartments(self):
        for department in self._core.getElements('department'):
            try:
                org = department.getLinkedElement('organization')
                if org.getUniID() == self.getUniID():
                    department.selfDelete()
            except:
                pass

    def __checkArchive(self):
        if self.flags & 1:
            raise dev_except.EquipmentException(self._core.getString('OrgAlreadyArch'))
        cur = self._core.sql("""
            select count(*) from common_permit where (state = 1 or state = 3) and declarer_organization = %s
        """ % self.getUniID())
        count = cur.fetchone()[0]
        if count != 0:
            raise dev_except.TerminateAction(self._core.getString('Archiving') + self.description +
                                             self._core.getString('ActiveCredsOrg'))
        cur = self._core.sql("""
            select count(*) from common_permit cp, common_subject cs
            where cs.uniid = cp.subject and cs.organization = %s and (state = 1 or state = 3)
        """ % self.getUniID())
        count = cur.fetchone()[0]
        if count != 0:
            raise dev_except.TerminateAction(self._core.getString('Archiving') + self.description +
                                             self._core.getString('ThereareactiveCreds'))

    def preDelete(self, deleteAsLink=False):
        self.__deleteDepartments()

        if 'bosch' in self._core['...']:
            for ace in self._core['bosch'].getElements('ace'):
                res = ace.doAction('deleteOrganization', {'name': self.description})
                if res != 0:
                    raise dev_except.TerminateAction(self._core.getString('OrgNotDelBOSCH'))

    def __archivateDepartments(self):
        result = {
            'canSelfDelete': True,
            'childMessages': ''
        }
        for department in self._core.getElements('department'):
            try:
                org = department.getLinkedElement('organization')
                if org.getUniID() == self.getUniID():
                    try:
                        department.doAction('archivate')
                    except dev_except.TerminateAction as e:
                        result['childMessages'] += ' ' + str(e)
                        result['canSelfDelete'] = False
                    except dev_except.EquipmentException as e:
                        pass
            except:
                pass
        return result

    @action_decorator(alias='Архивировать')
    def archivate(self):
        depResult = self.__archivateDepartments()
        if not depResult['canSelfDelete']:
            raise dev_except.TerminateAction(self._core.getString('Archiving') + self.description +
                                             self._core.getString('oneDepFailedToArc') + depResult['childMessages'])
        self.__checkArchive()
        self.flags = self.flags | 1
        self.attrUpdated('archived')
        if 'bosch' in self._core['...']:
            for ace in self._core['bosch'].getElements('ace'):
                ace.doAction('deleteOrganization', {'name': self.description})
        raise dev_except.EquipmentException(self._core.getString('OrgArchived'))

    @action_decorator(alias='Разархивировать')
    def unarchivate(self):
        self.flags = 0
        self.attrUpdated('archived')

    def __updateArchive(self, value, field):
        if value == 0:
            self.unarchivate()
        else:
            self.archivate()

    @classmethod
    @action_decorator(alias='Удалить все из БД', actionClass='static')
    def eraseAll(cls):
        while True:
            org = cls._core['common'].getFirst('organization')
            if org:
                org.selfDelete()
            else:
                break

    def __getArchived(self, field):
        return self.flags & 1

    description = Attribute(alias='Название', fieldType=str, defval='', index=1, preAction=__checkValidDescription,
                            postAction=__edit)
    note1 = Attribute(alias='Краткое имя', fieldType=str, defval='', index=2, postAction=__edit)
    archived = Attribute(alias='Архивное', index=3, fget=__getArchived, fset=__updateArchive, editorType="checkBox",
                         storeInDb=False)
    commonrighttemplate = Link(alias='Шаблон прав', target=common_commonrighttemplate, index=4)

    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=5)
    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=6)
    flags = Attribute(alias='Состояние', fieldType=int, defval=0, showInClient=False)
