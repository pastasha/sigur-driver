# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_rschedule(protocol_obj_base, alias='Регулярное расписание'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    tzones_map = Attribute(alias='Временные зоны', fieldType=str, defval='', index=2)
    year = Attribute(alias='Год', fieldType=int, defval=0, index=3)
