# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_permit import common_permit


class common_permit_permit(protocol_obj_base, alias='',
                           parent=ParentStruct(typeName='permit', alias='Связанные пропуска',
                                               addr=(1, constants.MAX_UINT32))):

    permit = Link(alias='', target=common_permit)
