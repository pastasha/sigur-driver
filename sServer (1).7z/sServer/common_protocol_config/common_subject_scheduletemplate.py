# -*- coding: utf-8 -*-

import datetime

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
import equipment.constants as constants

from .common_scheduletemplate import common_scheduletemplate


class common_subject_scheduletemplate(protocol_obj_base, alias='',
                                      parent=ParentStruct(typeName='subject', alias='Расписания',
                                                          addr=(1, constants.MAX_UINT16))):
    @classmethod
    def __checkSheduleDates(cls, objID, begin_date, end_date):
        if begin_date > end_date:
            raise Exception("Invalid date interval")

        # проверим возможность задания указанных интервалов
        begin = cls.__dateFromTimestamp(begin_date)
        end = cls.__dateFromTimestamp(end_date)

        if not cls.__checkIntervalEditState(begin, end):
            raise Exception("Cannot set this interval: SCHEDULE CONSTANT ERROR")

        # проверка пересечения интервалов
        res = cls.__checkScheduleIntersect(
            objID,
            "subject_scheduletemplate",
            begin_date,
            end_date)
        if res:
            raise Exception("INTERSECTION OF INTERVALS: %s" % res)

    @classmethod
    def __dateFromTimestamp(cls, timestamp):
        _date = datetime.date.fromtimestamp(timestamp)

        return _date

    @classmethod
    def __checkEditState(cls, _date):
        constant = cls.__schedulesConstant()

        now = datetime.datetime.now()

        if _date.year > now.year:
            return True
        if _date.year == now.year:
            if _date.month >= now.month:
                return True
            else:
                if _date.month == now.month - 1:
                    if now.day < constant:
                        return True
        return False

    @classmethod
    def __checkIntervalEditState(cls, begin, end):
        # проверка возможности указания данного временного отрезка
        return cls.__checkEditState(begin) and cls.__checkEditState(end)

    @classmethod
    def __schedulesConstant(cls):
        # получаем константу редактирования
        cur = cls._core.sql('select get_schedule_constant()')
        constant = cur.fetchone()[0]

        return constant

    @classmethod
    def __checkScheduleIntersect(cls, objID, objType, beginDt, endDt):
        data = {
            'objID': objID,
            'objType': objType,
            'begin': beginDt,
            'end': endDt
        }

        checkQuery = """
            select uniid from common_%(objType)s
            where devparent = %(objID)s and (
                (begin_date >= %(begin)s and begin_date <= %(end)s) or
                (end_date >= %(begin)s and end_date <= %(end)s) or
                (begin_date <= %(begin)s and end_date >= %(end)s) or
                (begin_date >= %(begin)s and end_date <= %(end)s)
            )
        """ % data

        cur = cls._core.sql(checkQuery)

        schedules = cur.fetchone()

        if schedules and len(schedules):
            return schedules[0]

        return None

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        # проверка дат
        begin_date = createAttrs["begin_date"]
        end_date = createAttrs["end_date"]

        if not (begin_date and end_date):
            raise Exception("Invalid interval")

        cls.__checkSheduleDates(mainObj.getUniID(), begin_date, end_date)

    def __checkDate(self, field, value):
        begin = end = oldValue = None

        if field == 'begin_date':
            # изменилась дата начала
            begin = value
            end = self.end_date
            oldValue = self.begin_date

        if field == 'end_date':
            # изменилась дата окончания
            begin = self.begin_date
            end = value
            oldValue = self.end_date

        if begin and end and oldValue:
            # если изменять было нельзя
            if not self.__checkEditState(self.__dateFromTimestamp(oldValue)):
                raise Exception(u"Cannot modify date: SCHEDULE CONSTANT ERROR")

            # проверка нового интервала
            self.__checkSheduleDates(self.getUniID(), begin, end)

    def __checkSchedule(self, targetObj):
        # проверим возможность редактирования  расписания
        begin_date = self.begin_date
        end_date = self.end_date

        self.__checkSheduleDates(self.getUniID(), begin_date, end_date)

    def delAction(self):
        # TODO: мне кажется что не используется
        # проверка возможности удаления расписания
        begin_date = self.__dateFromTimestamp(self.begin_date)
        end_date = self.__dateFromTimestamp(self.end_date)

        if not self.__checkIntervalEditState(begin_date, end_date):
            raise Exception(u"Cannot delete schedule: SCHEDULE CONSTANT ERROR")

    scheduletemplate = Link(alias='Шаблон расписания', target=common_scheduletemplate, index=1,
                            preAction=__checkSchedule)
    begin_date = Attribute(alias='Дата начала', fieldType=int, defval=0, index=2, preAction=__checkDate)
    end_date = Attribute(alias='Дата окончания', fieldType=int, defval=0, index=3, preAction=__checkDate)
