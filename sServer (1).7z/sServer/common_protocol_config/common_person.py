# -*- coding: utf-8 -*-

import json
import datetime

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link, action_decorator,\
    index_decorator
from equipment import dev_except

from . import event_packet
from .common_post import common_post


class common_person(protocol_obj_base, alias='Частные лица', archive=True,
                    parent=ParentStruct(typeName='subject', alias='Частное лицо', addr=(1, 1))):

    def postCreate(self, ignore_create_objects=False):
        if not ignore_create_objects:
            self._core.createElement('subject', siteId=self.siteId).addChild(self._obj)

    def preDelete(self, deleteAsLink=False):
        try:
            if len(self._obj.getBackLinkElements('wantedface', 'person')) > 0:
                self._obj.getBackLinkElements('wantedface', 'person')[0].doAction('operation_wantedface_by_person',
                                                                                  {'type_operation': 'delete'})
            if 'subjectDeleted' not in self or not self['subjectDeleted']:
                self['subjectDeleted'] = False
                self.getParent().selfDelete()
        except dev_except.ParentNotFound:
            pass

    def postChangeParent(self, oldParent=None, info=None):
        if self.hasParent():
            self.getParent().attrUpdated('description')

    @index_decorator('employeeNumberTSS')
    def employeeNumberTSSIndexBuilder(self):
        return self.employeeNumber

    @action_decorator(alias='Установить отпечаток пальца', printNum='Номер отпечатка', fingerPrint='Отпечаток')
    def setFingerPrint(self, printNum: int = 1, fingerPrint: str = ''):
        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            self._core.sql("""
                    update common_person set finger_print%d = %%s
                    where uniid = %%s
                """ % printNum, (fingerPrint, self.getUniID()))
            self._core.dbCommit()

        fingerPrintMask = self.fingerprint_mask
        fingerPrintMask = fingerPrintMask | (1 << (printNum - 1))
        self.fingerprint_mask = fingerPrintMask

        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            self.attrUpdated('fingerPrint%s' % printNum)

    @action_decorator(alias='', actionClass='hidden', printNum='')
    def getFingerPrint(self, printNum: int = 1):
        result = None
        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            cur = self._core.sql("""
                    select finger_print%d from common_person
                    where uniid = %%s
                """ % printNum, (self.getUniID(),))
            for row in cur:
                result = row[0]
                break
        return result

    @action_decorator(alias='', actionClass='hidden')
    def getAllFingerPrints(self):
        result = None
        cur = self._core.sql("""
                select	finger_print1,
                        finger_print2,
                        finger_print3,
                        finger_print4,
                        finger_print5,
                        finger_print6,
                        finger_print7,
                        finger_print8,
                        finger_print9,
                        finger_print10 from common_person
                where uniid = %s
            """, (self.getUniID(),))
        for row in cur:
            result = row
            break
        return result

    @action_decorator(alias='Удалить отпечаток пальца', printNum='Номер отпечатка')
    def clrFingerPrint(self, printNum: int = 1):
        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            self._core.sql("""
                    update common_person set finger_print%d = null
                    where uniid = %%s
                """ % printNum, (self.getUniID(),))
            self._core.dbCommit()

        fingerPrintMask = self.fingerprint_mask
        fingerPrintMask = fingerPrintMask ^ (1 << (printNum - 1))
        self.fingerprint_mask = fingerPrintMask

        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            self.attrUpdated('fingerPrint%s' % printNum)

    @action_decorator(alias='Удалить все отпечатки')
    def clrAllFingerPrints(self):
        self._core.sql("""
                update common_person
                set finger_print1 = null,
                    finger_print2 = null,
                    finger_print3 = null,
                    finger_print4 = null,
                    finger_print5 = null,
                    finger_print6 = null,
                    finger_print7 = null,
                    finger_print8 = null,
                    finger_print9 = null,
                    finger_print10 = null
                where uniid = %s
            """, (self.getUniID(),))
        self._core.dbCommit()

        self.fingerprint_mask = 0

        for i in range(1, 11):
            self.attrUpdated('fingerPrint%s' % i)

    @action_decorator(alias='Проверить, есть ли отпечаток', printNum='')
    def hasFingerPrint(self, printNum: int = 1):
        result = False
        if printNum in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
            fingerPrintMask = self.fingerprint_mask
            if fingerPrintMask & (1 << (printNum - 1)):
                result = True
        return result

    def __hasFingerPrint(self, field):
        printNum = int(field[11:])
        return self.hasFingerPrint(printNum)

    def __descriptionChanged(self, oldValue, oldValues):
        if self.hasParent():
            self.getParent().attrUpdated('description')

    def checkEmployeeNumber(self, value):
        return self.__checkEmployeeNumber(value, '')

    def __checkEmployeeNumber(self, value, field):
        if event_packet.isCheckEmployeeNum():
            if value:
                if value.isdigit() and int(value) != 0:
                    cur = self._core.sql("""
                            select cp.description from common_person cp, common_subject cs
                            where cs.uniid = cp.devparent and cp.employeeNumber = %s and cp.uniid &lt;&gt; %s and cp.flags = 0
                            and cs.organization = (select organization from common_subject where uniid = %s)
                        """, (value, self.getUniID(), self.getParent().getUniID()))
                    res = cur.fetchone()
                    if res:
                        raise dev_except.TerminateAction(self._core.getString('thisIdSetFor') % res)

    @action_decorator(alias='Деактивировать все пропуска')
    def deactivateAllPermits(self):
        if self.hasParent():
            subjectId = self.getParent().getUniID()
            for permit in self._core.getElements('permit'):
                if permit.isLinkedElement('subject'):
                    subj = permit.getLinkedElement('subject').getUniID()
                    if subj == subjectId:
                        try:
                            permit.doAction('deactivate')
                        except Exception as e:
                            print(repr(e))

    description = Attribute(alias='Ф.И.О.', fieldType=str, defval='', index=1, postAction=__descriptionChanged)
    category = Attribute(alias='Категория', fieldType=int, defval=0, index=2,
                         editorType='enum(Сотрудник, Подрядчик, Охранник, Посетитель)')
    postref = Link(alias='Должность', target=common_post, index=3)
    employeeNumber = Attribute(alias='Табельный номер', fieldType=str, defval='', index=4,
                               preAction=__checkEmployeeNumber)
    employmentContract = Attribute(alias='Трудовой договор', fieldType=str, defval='', index=5)
    birthday_v2 = Attribute(alias='Дата рождения', fieldType=datetime.date, defval=datetime.date(1901, 1, 1), index=6,
                            editorType='date')
    birthPlace = Attribute(alias='Место рождения', fieldType=str, defval='', index=7)
    citizenship = Attribute(alias='Гражданство', fieldType=str, defval='', index=8)
    document = Attribute(alias='Документ', fieldType=str, defval='', index=9)
    series = Attribute(alias='Серия', fieldType=str, defval='', index=10)
    docNumber = Attribute(alias='Номер', fieldType=str, defval='0', index=11)
    issuedBy = Attribute(alias='Кем выдан', fieldType=str, defval='', index=12)
    issuedWhen = Attribute(alias='Дата выдачи', fieldType=int, defval=0, index=13, editorType='datetime')
    placeOfResidence = Attribute(alias='Адрес регистрации', fieldType=str, defval='', index=14)
    placeOfActualResidence = Attribute(alias='Адрес проживания', fieldType=str, defval='', index=15)
    note = Attribute(alias='Примечание', fieldType=str, defval='', index=16)
    note2 = Attribute(alias='Примечание 2', fieldType=str, defval='', index=17)
    note3 = Attribute(alias='Примечание 3', fieldType=str, defval='', index=18)
    note4 = Attribute(alias='Примечание 4', fieldType=str, defval='', index=19)
    note5 = Attribute(alias='Примечание 5', fieldType=str, defval='', index=20)
    note6 = Attribute(alias='Примечание 6', fieldType=str, defval='', index=21)
    phoneNumber = Attribute(alias='Рабочий (внутренний) телефон', fieldType=str, defval='', index=22)
    phone = Attribute(alias='Мобильный телефон', fieldType=str, defval='', index=23)
    phone2 = Attribute(alias='Мобильный телефон (доп.)', fieldType=str, defval='', index=24)
    email = Attribute(alias='Адрес электронной почты', fieldType=str, defval='', index=25)
    fingerPrint1 = Attribute(alias='Отпечаток 1', fget=__hasFingerPrint, index=26, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint2 = Attribute(alias='Отпечаток 2', fget=__hasFingerPrint, index=27, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint3 = Attribute(alias='Отпечаток 3', fget=__hasFingerPrint, index=28, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint4 = Attribute(alias='Отпечаток 4', fget=__hasFingerPrint, index=28, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint5 = Attribute(alias='Отпечаток 5', fget=__hasFingerPrint, index=30, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint6 = Attribute(alias='Отпечаток 6', fget=__hasFingerPrint, index=31, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint7 = Attribute(alias='Отпечаток 7', fget=__hasFingerPrint, index=32, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint8 = Attribute(alias='Отпечаток 8', fget=__hasFingerPrint, index=33, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint9 = Attribute(alias='Отпечаток 9', fget=__hasFingerPrint, index=34, editorType='checkBox', readOnly=True,
                             storeInDb=False)
    fingerPrint10 = Attribute(alias='Отпечаток 10', fget=__hasFingerPrint, index=35, editorType='checkBox',
                              readOnly=True, storeInDb=False)
    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=36)
    documentscan = Attribute(alias='Скан документа', fieldType=str, defval='', index=37)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=38)

    fingerprint_mask = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
    insearch = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
    invizir = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
