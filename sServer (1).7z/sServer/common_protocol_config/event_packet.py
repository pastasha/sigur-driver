# -*- coding: utf-8 -*-

# TODO: импорт делается неправильно
import settings

from equipment import dev_except


def isCheckEmployeeNum():
    if settings.checkEmployeeNumber:
        return True
    return False


def threshold1Request(permitId, rightId, rightDescription):
    return """
<html>
<head>
<style>
.txt    {
    color           :   orange;
    font-family     :   Arial
}
.btn    {
    border          :   2px solid darkgray;
    background-color:   lightgrey;
    border-radius   :   4px;
    color           :   black;
    display         :   inline;
    font-family     :   Arial
}
.btn:active {
    border          :   2px solid darkgray;
    background-color:   lightgrey;
    border-radius   :   4px;
    color           :   black;
    left            :   1px;
    top             :   1px;
    position        :   relative;
    display         :   inline;
    font-family     :   Arial
}
</style>
<script type="text/javascript">
function no(){
    core.close()
}
function yes(){
    core.cmd('createEquipLink', {
        'equip'     :   'common',
        'obj'       :   {
            'type'      :   'permit',
            'id'        :   %(permitId)s
        },
        'linkedObj' :   {
            'type'      :   'commonright',
            'id'        :   %(rightId)s
        },
        'linkName'  :   'permit_commonright',
        'addr'      :   0,
        'dlg'       :   true
    })
    core.close()
}
</script>
</head>
<body>
    <h3 align="center" class="txt">Добавление права &quot;%(descr)s&quot;</h3>
    <h1 align="center" class="txt">При текущем уровне безопасности требуется документ</h1>
    <h2 align="center" class="txt">Документ в наличии?</h2>
    <div    align="center">
        <div    class="btn" onclick="yes()">&nbsp;&nbsp;&nbsp;Да&nbsp;&nbsp;&nbsp;</div>
        <div    class="btn" onclick="no()">&nbsp;&nbsp;Нет&nbsp;&nbsp;</div>
    </div>
</body>
</html>
""" % {'permitId': permitId, 'rightId': rightId, 'descr': rightDescription}


class EventPacketException(Exception):
    pass


def decodeCommandResult(core, rootElement, cmdRes, cmdName):
    return cmdRes


def syncOnOrionIso(obj, core, action):
    if action in (0, 1):
        updateOnOrionIso(obj, core, action)
    elif action == 2:
        deleteOnOrionIso(obj, core)
    else:
        raise dev_except.TerminateAction(u'Не известная команда управления пропуском')


def updateOnOrionIso(obj, core, action):
    print('Update Card on Orion Iso')

    """ Готовим параметры для добавления пользователя """
    paramsPerson = {
        'TableList': [
            {
                'Action': action,
                'TableName'	: 'Persons',
                'DataList'	: [{
                    'ID'		: '',
                    'Name'		: '',
                    'FirstName'	: '',
                    'MidName'	: ''
                }]

            },
            {
                    'Action' 	: action,
                    'TableName'	: 'Passwords',
                    'DataList'	: []
            }
        ]
    }
    subj = obj.getLinkedElement('subject')
    subjName = subj.doAction('getDescription')
    subjNameVal = subjName.split()

    paramsPerson['TableList'][0]['DataList'][0]['Name'] = '' if len(subjNameVal) < 1 else subjNameVal[0]
    paramsPerson['TableList'][0]['DataList'][0]['FirstName'] = '' if len(subjNameVal) < 2 else subjNameVal[1]
    paramsPerson['TableList'][0]['DataList'][0]['MidName'] = '' if len(subjNameVal) < 3 else subjNameVal[2]
    paramsPerson['TableList'][0]['DataList'][0]['ID'] = subj.getUniID()

    orion_controls = core['orioniso'].getElements('control')
    for orion_control in orion_controls:
        """ Готовим параметры для добавления карты """
        dataPermit = orion_control.doAction('getDataForKey',  params={'permit': obj})
        if dataPermit:
            paramsPerson['TableList'][1]['DataList'] = [dataPermit]
            orion_control.doAction('RefreshTablesData', params={'params': paramsPerson})
            print('Orion iso Sync one key for permit %s complete'%obj.getUniID())
        else:
            print('Orion iso Sync one for permit %s failed becos key not found'%obj.getUniID())
    print('Orion iso Sync one key complete')


def check_dublicate_pin(core, value):
    result = None
    for permitId, permit in core.getElementsByIndex('permit', 'permitsWithoutIdCodeFromPIN', None,
                                                    keyValue='pin#%s' % value).items():
        result = permitId
        break
    return result


def deleteOnOrionIso(obj, core):
    print('Delete Card on Orion Iso')
    paramsCard = {
        'TableList': [
            {
                    'Action' 	: 2,
                    'TableName'	: 'Passwords',
                    'DataList'	: []
            }
        ]
    }
    orion_controls = core['orioniso'].getElements('control')
    for orion_control in orion_controls:
        """ Готовим параметры для удаления карты """
        dataPermit = orion_control.doAction('getDataForKey', {'permit': obj})
        if dataPermit:
            paramsCard['TableList'][0]['DataList'] = [dataPermit]
            orion_control.doAction('RefreshTablesData', params={'params': paramsCard})
            print('Orion iso  Delete one key for permit %s complete' % obj.getUniID())
        else:
            print('Orion iso Delete one for permit %s failed because key not found' % obj.getUniID())
    print('Orion iso Delete one key complete')
