# -*- coding: utf-8 -*-

import json
import time
import datetime
import os
import http

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, index_decorator, action_decorator
from equipment.methods_for_equipment import get_subsystem_ids

from . import event_packet
from .common_subject import common_subject
from .common_permittype import common_permittype
from .common_idcode import common_idcode
from .common_securlevel import common_securlevel
from .common_schedule import common_schedule
from .common_organization import common_organization
from .common_department import common_department
from pce_protocol_config.pce_part import pce_part

from rubej08_protocol_config.r08core import *


class common_permit(protocol_obj_base, alias='Пропуск'):

    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('permitsWithoutIdCodeFromPIN')
    def permitsWithoutIdCodeFromPIN(self):
        result = None
        if self.permitType:
            if self.permitType.getAttribute('withoutIdcode') == 1:
                if self.state != 2:
                    result = 'pin#%s' % self.pin
        return result

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')
            
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    @index_decorator('ccure_id')
    def ccure_id_calc(self):
        return str(get_subsystem_ids(self, 'ccure'))

    @index_decorator('ownerOrganization')
    def ownerOrganization(self):
        if self.subject:
            if self.subject.isLinkedElement('organization'):
                org = self.subject.organization
                return 'organization#%s' % org.getUniID()
            else:
                return None
        else:
            return None

    @index_decorator('activeIdcode')
    def activateIdCodeIndexBuilder(self):
        if self.state == 1:
            if self.idcode and len(self.idcode.getAttribute('name')) > 0:
                return self.idcode.getAttribute('name')
        return None

    @index_decorator('blockedIdcode')
    def blockedIdcodeCodeIndexBuilder(self):
        if self.state == 3:
            if self.idcode and len(self.idcode.getAttribute('name')) > 0:
                return self.idcode.getAttribute('name')
        return None

    @index_decorator('pin')
    def pinIndexBuilder(self):
        if self.state == 1:
            return self.pin
        return None

    @index_decorator('owner')
    def ownerIndexBuilder(self):
        if self.subject:
            return '%s#%s' % (self.subject.getUniID(), self.state)
        return None

    @index_decorator('cache')
    def cacheIndexBuilder(self):
        if self.state != 2:
            return self.state
        return None

    @index_decorator('activateSubject')
    def activateSubjectIndexBuilder(self):
        if self.subjact:
            return self.subjact.getUniID()
        return None

    def postCreate(self, ignore_create_objects=False):
        self.createdt = time.time()
        # У пропуска уже может быть какой-то тип, если он был передан параметром запроса creareEquipDev
        if not self.permitType:
            if self._core.getFirst('root').isLinkedElement('defaultPermitType'):
                print("There is a root link to deafault permittype")
                self.permitType = self._core.getFirst('root').getLinkedElement('defaultPermitType')
            else:
                print("There is no root link to default permittype")
        op = self.getCurrOperatorSubject()
        if op:
            self.subjcreate = op

        # Определяем даты начала и конца срока действия пропуска
        if self.permitType:
            self.definePermitDuration()
        self.attrUpdated('number')

    def preDelete(self, deleteAsLink=False):
        self.__checkNewOrDraftPermitPermit()

    @action_decorator(alias='Активировать по заявке', requisition='Заявка')
    def activateFromRequisition(self, requisition: int = 0):
        result = self.activate()

        self._core.sql("update requisition set activated_permit = %s, status = 'processed' where id = %s", (
            self.getUniID(), requisition
        ))
        self._core.dbCommit()
        print('activateFromRequisition end')
        return result

    @action_decorator(alias='Активировать')
    def activate(self):
        # Если превышены лицензионные ограничения
        if not self.equipment.checkActPermitsCount():
            raise dev_except.TerminateAction(self._core.getString('CredLicenceNotValid'))

        # Активировать можно только свежесозданный пропуск
        if self.state == 4:
            raise dev_except.TerminateAction(self._core.getString('CredDraft'))

        if self.state != 0:
            if self.state == 1:
                raise dev_except.TerminateAction(self._core.getString('credentialAlreadyActivated'))
            else:
                raise dev_except.TerminateAction(self._core.getString('CredDeact'))

        # Проверка: Существует ли другой активированный/деактивированный пропуск по этой заявке
        # print 'requisition= ',obj.getAttribute('requisition')
        if self.requisition != 0:
            cur = self._core.sql("""
                select uniid from common_permit
                where state != 0 and requisition = %s and (flags & 1) = 0
            """, (self.requisition,))
            for row in cur:
                raise dev_except.TerminateAction(self._core.getString('CredActThisReq') % row[0])

        # Пропуск без субъекта или без идентификатора невозможно активировать
        if not self.subject:
            raise dev_except.TerminateAction(self._core.getString('NeedSubj'))
        # Проверим можно ли активировать пропуск без идентификатора
        if self.permitType and int(self.permitType.getAttribute('withoutIdcode')) == 0:
            if not self.idcode:
                raise dev_except.TerminateAction(self._core.getString('NeedId'))

        if self.idcode:
            # Проверка: Существует ли другой активированный/заблокированный пропуск с этим идентификатором
            cur = self._core.sql("""
                select uniid from common_permit
                where (state = 1 or state = 3) and idcode = %s and (flags & 1) = 0
            """, (self.idcode.getUniID(),))
            for row in cur:
                raise dev_except.TerminateAction(self._core.getString('IsIsForCred') % row[0])

        op = self.getCurrOperatorSubject()
        if op:
            self.subjact = op

        self.state = 1

        self.actdt = time.time()
        try:
            se = self._core.getFirst('root').getLinkedElement('securLevel')
            if se:
                self.actsecurlevel = se
        except Exception as e:
            print("Secur Level not set : %s" % repr(e))

        txt = self._core.getString('CredentialActivated') % self.getUniID()
        timeout = 5000
        tp = 'info'

        try:
            res = self.activateOnDevice(True)
            timeout = res['timeout']
            tp = res['type']
            txt = res['txt']
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotAct')

        self._core.sql("update requisition set activated_permit = %s, status = 'processed' where id = %s", (
            self.getUniID(), self.requisition
        ))
        self._core.dbCommit()

        return {
            'txt'	:	txt,
            'timeout'	:	timeout,
            'type'		:	tp
        }

    @action_decorator(alias='Активировать в оборудовании')
    def activateOnDevice(self, firstActivate=False):
        if self.state != 1:
            raise dev_except.TerminateAction(self._core.getString('ReactActCred'))

        txt = self._core.getString('CredActInEquip') % self.getUniID()
        timeout = 5000
        tp = 'info'
        
        root = self._core.getElements('root')[0]
        if root.getAttribute('add_face_to_recognition_list_when_activate_permit') is True:
            if self.isLinkedElement('subject') is True:
                person = self.getLinkedElement('subject').getChildListByType('person')[0]
                if person is not None:
                    root.doAction('create_face_by_person', {'person': person})
        
        try:
            if 'pce' in self._core['...']:
                self.activateOnPCE()
        except dev_except.TerminateAction as e:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;%s %s' % (txt, self._core.getString('CredNotActPCE'), e)
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActPCE')

        try:
            if 'apollo' in self._core['...']:
                self.activateOnApollo()
        except dev_except.TerminateAction as e:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;%s %s' % (txt, self._core.getString('CredNotActApollo'), str(e))
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActApollo')

        try:
            if 'orioniso' in self._core['...']:
                self.activateOnOrionIso()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActOrionIso')

        try:
            if 'orionintgrsrv' in self._core['...']:
                self.activateOrionIntgrSrv(1)
        except Exception as e:
            timeout = -1
            str_err = str(e)
            tp = 'warning'
            txt = '%s&lt;br/&gt; &lt;br/&gt; %s' % (txt + self._core.getString('notActivateOrionIntgrSrv'), str_err)

        res = ''
        for effort in range(1, 4):
            try:
                if 'housekeeper' in self._core['...']:
                    self.activateOnHouseKeeper()
                break
            except Exception as e:
                timeout = -1
                tp = 'warning'
                txt = txt + '%s&lt;div style="color: red;"&gt;' % res + self._core.getString('AcrErrorToKEy') % (
                    self.getUniID(), e, effort) + '&lt;/div&gt;'
            # time.sleep(1)

        try:
            if 'uld' in self._core['...']:
                self.activateOnUld()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActUlu')

        try:
            self.activateOnRubej08()
        except Exception as e:
            print(e)
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActRubej')

        try:
            if 'bosch' in self._core['...']:
                self.activateOnBOSCH()
        except Exception as e:
            print(e)
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActBOSCH')

        try:
            if 'rubezhglobal' in self._core['...']:
                self._core['rubezhglobal'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActRubezhGlobal')

        try:
            if 'rusguard' in self._core['...']:
                self._core['rusguard'].getFirst('server').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotActRusguard')
            
        try:
            if 'biostar' in self._core['...']:
                self._core['biostar'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactbiostar')

        try:
            if 'apacsbio' in self._core['...']:
                self.doAction('activateOnApacsBio')
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotActapacsbio')
        
        return {
            'txt'	:	txt,
            'timeout'	:	timeout,
            'type'		:	tp
        }

    def _activateOnApollo(self):
        if self.state != 1:
            raise dev_except.TerminateAction()
        self.activateOnApollo_internal()

    @action_decorator(alias='Активировать пропуск в Apollo')
    def activateOnApollo(self):
        root = self._core['apollo'].getFirst('mainpanel')
        if not root:
            return
        if self.beginDT == 0:
            raise dev_except.TerminateAction(self._core.getString('ApolloPermitNeedStartDate'))
        if self.endDT == 0:
            raise dev_except.TerminateAction(self._core.getString('ApolloPermitNeedEndDate'))
        # формируем список уровней доступа
        rightList = set()
        antipassbackFlag = False  # Прогружать ли на шину флаг проверки повторного прохода
        for pr in self.getChildListByType('permit_commonright'):
            right = pr.getLinkedElement('commonright')
            if right.getAttribute('attrflags') & 0x01 == 1:
                antipassbackFlag = True
            if right.isLinkedElement('accesslevel'):
                rightList.add(right.getLinkedElement('accesslevel'))
        # ищем главные панели с этими правами
        aclvlOnPanel = {}
        for r in rightList:
            for br in r.getBackLinkElements('mainpanel_accesslevel', 'accesslevel'):
                panel = br.getParent()
                if panel not in aclvlOnPanel:
                    aclvlOnPanel[panel] = set()
                aclvlOnPanel[panel].add(br.getAddr())
        # Если у пропуска нет прав ни от одной панели - нет смысла что то дальше делать
        if len(aclvlOnPanel) == 0:
            raise dev_except.TerminateAction(self._core.getString('CredHasNoRightsForApolloPanels'))
        idcode = self.idcode
        if not idcode:
            raise dev_except.TerminateAction(self._core.getString('NosenseToactivate'))
        apollo = self._core["apollo"]
        # ищем идентификатор апполо с таким же кодом, что и в идентификаторе пропуска
        code = str(idcode.getAttribute('name'))
        # Если идентификатор текстовый - не активируем
        if not code.isdigit():
            raise dev_except.TerminateAction(self._core.getString('TextIDsNotUs'))
        cur = apollo.sql("SELECT uniid FROM apollo_cardholder WHERE code=" + code)
        cardholder_uiid = cur.fetchone()
        # если нашли
        if cardholder_uiid:
            cardholder = apollo.getElementById("cardholder", int(cardholder_uiid[0]))
            for bridge in cardholder.getChildListByType('cardholder_accesslevel'):
                bridge.selfDelete()
        # Если не нашли - надо создавать
        else:
            cardholder = apollo.createElement("cardholder")
            cardholder.setAttribute('code', int(idcode.getAttribute('name')))
        # заполняем поля идентификатора апполовского
        for r in rightList:
            cardholder.createLink('cardholder_accesslevel', r)

        cardholder.setAttribute('datestart', datetime.datetime.fromtimestamp(self.beginDT))
        cardholder.setAttribute('dateend', datetime.datetime.fromtimestamp(self.endDT))
        cardholder.setAttribute('pin', self.pin)
        if antipassbackFlag:
            cardholder.setAttribute('apbtype', 1)
        else:
            cardholder.setAttribute('apbtype', 2)
        # и привяжем свежеиспеченный идентификатор к главным панелям апполо, у которых есть какие то права
        for panel in aclvlOnPanel:
            try:
                if panel.isLinked('mainpanel_cardholder', cardholder):
                    panel.getChildByAddr('mainpanel_cardholder',
                                         panel.isLinked('mainpanel_cardholder', cardholder)).doAction('addID')
                else:
                    panel.createLink('mainpanel_cardholder', cardholder)
            except dev_except.PortNotFound:
                pass
            except Exception as e:
                print('activateOnApollo error:', repr(e))
                raise

    def deactivateOnApollo(self):
        idcode = self.idcode
        if not idcode:
            raise dev_except.TerminateAction(self._core.getString('CredIdNotFound'))
        apollo = self._core["apollo"]
        # ищем идентификатор апполо с таким же кодом, что и в идентификаторе пропуска
        cur = apollo.sql("SELECT uniid FROM apollo_cardholder WHERE code=" + str(idcode.getAttribute('name')))
        cardholder_uiid = cur.fetchone()
        # если нашли - отвязываем от всех главных панелей
        if cardholder_uiid:
            cardholder = apollo.getElementById("cardholder", int(cardholder_uiid[0]))
            for bridge in cardholder.getBackLinkElements('mainpanel_cardholder', 'cardholder'):
                bridge.selfDelete()

    @action_decorator(alias='Активировать пропуск в ApacsBio')
    def activateOnApacsBio(self):
        if 'apacsbio' in self._core['...']:
            if self.getAttribute("state") != 1:
                raise dev_except.TerminateAction()
            self._core['apacsbio'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})

    @action_decorator(alias='Активировать пропуск в PCE')
    def activateOnPCE(self):
        if 'pce' in self._core['...']:
            if self.state != 1:
                raise dev_except.TerminateAction()
            idcode = self.idcode
            if idcode.getAttribute('codeType'):
                if len(idcode.getAttribute('name')) > 15:
                    raise dev_except.TerminateAction(self._core.getString('IdLenghtLess15'))

            self.activateOnPCE_internal()

    def activateOnPCE_internal(self):
        self.deleteFromPCE()
        rightList = set()
        antipassbackFlag = False  # Прогружать ли на шину флаг проверки повторного прохода
        for pr in self.getChildListByType('permit_commonright'):
            right = pr.getLinkedElement('commonright')
            if right.getAttribute('attrflags') & 0x01 == 1:
                antipassbackFlag = True
            for r in right.getRightFarElements(equipFilter='pce', typeFilter='rlist', linkNameFilter='rlist'):
                rightList.add(r)

        rlistOnBus = {}
        for r in rightList:
            for br in r.getBackLinkElements('bus_rlist', 'rlist'):
                bus = br.getParent()
                if bus not in rlistOnBus:
                    rlistOnBus[bus] = set()
                rlistOnBus[bus].add(br.getAddr())

        for bus in rlistOnBus:
            try:
                bus.doAction('createUser', {
                    'rights': rlistOnBus[bus], 'permit': self, 'antipassbackFlag': antipassbackFlag
                })
            except dev_except.PortNotFound:
                pass
            except Exception as e:
                import traceback
                traceback.print_exc()
                print('activateOnPCE error:', repr(e))
                raise

    @action_decorator(alias='Активировать пропуск в ключнице')
    def activateOnHouseKeeper(self):
        root = self._core['housekeeper'].getFirst('housekeeper')
        if root:
            # print 'start activating on housekeeper:
            if self.state != 1:
                raise dev_except.TerminateAction()

            if not self.subject:
                raise dev_except.TerminateAction()

            card = self.idcode.getAttribute("name")
            codeType = self.idcode.getAttribute("codeType")
            # print 'codeType ',codeType
            if codeType == 0:
                for permitCommonRight in self.getChildListByType("permit_commonright"):
                    commonRight = permitCommonRight.getLinkedElement("commonright")
                    for hkRight in commonRight.getRightFarElements("housekeeper", "hkright", "hkright"):
                        # print 'hkright del card ',card
                        hkRight.doAction('delCard', {"card": card})

                for permitCommonRight in self.getChildListByType("permit_commonright"):
                    commonRight = permitCommonRight.getLinkedElement("commonright")
                    try:
                        card = int(card)
                    except:
                        raise dev_except.TerminateAction()

                    for hkRight in commonRight.getRightFarElements("housekeeper", "hkright", "hkright"):
                        print('hkright add card ', card)
                        hkRight.doAction('addCard', {"card": card})
            else:
                print('idcode is a string and will not activate on housekeeper')

            # print 'end activating on housekeeper'

            return {
                'txt'	:	self._core.getString('CredActKeyholder') % self.getUniID(),
                'timeout'	:	5000,
                'type'		:	'info'
            }

    @action_decorator(alias='Активировать пропуск в Рубеж-08')
    def activateOnRubej08(self):
        alevel_lst = []
        zone = None
        acc_bcp_tz = None
        for permitCommonRight in self.getChildListByType("permit_commonright"):
            commonRight = permitCommonRight.getLinkedElement("commonright")
            for alevel in commonRight.getRightFarElements("rubej08", "alevel", "alevel"):
                print('R08 right alevel')
                alevel_lst.append(alevel)
                if len(alevel_lst) >= 2:
                    break
            zones = commonRight.getRightFarElements("rubej08", "zone", "rzone")
            if zone:
                zone = zones[0]
                print('R08 right zone')
            acc_bcp_tzs = commonRight.getRightFarElements("rubej08", "timezone", "acc_bcp_tz")
            if acc_bcp_tzs:
                acc_bcp_tz = acc_bcp_tzs[0]
                print('R08 right acc_bcp_tz')
            if zone:
                rzone_tzs = commonRight.getRightFarElements("rubej08", "timezone", "rzone_tz")
                if rzone_tzs:
                    print('R08 right rzone_tz')
        r08 = self._core["rubej08"]
        bcp_table = {}
        if len(alevel_lst) >= 1:
            alvl_bcp_tbl = alevel_lst[0].doAction("update")
            for bcp_id in alvl_bcp_tbl:
                bcp_table[bcp_id] = r08.getElementById("bcp", bcp_id)
        if len(alevel_lst) >= 2:
            alvl_bcp_tbl = alevel_lst[1].doAction("update")
            for bcp_id in alvl_bcp_tbl:
                bcp_table[bcp_id] = r08.getElementById("bcp", bcp_id)
        if zone and zone.hasParent():
            bcp = zone.getParent()
            bcp_table[bcp.getUniID()] = bcp

        try:
            card = int(self.idcode.getAttribute("name"))
        except:
            card = 0

        use_alevel = [True, True]
        for bcp_id in bcp_table:
            bcp = bcp_table[bcp_id]
            cur = r08.sql("SELECT uniid FROM rubej08_user WHERE permit=" + str(self.getUniID()) + " AND bcp=" + str(bcp_id));
            user_bcp_uiid = cur.fetchone()
            if user_bcp_uiid:
                create = 0
                user_bcp = r08.getElementById("user", user_bcp_uiid[0])
                user_idx = user_bcp.getAttribute("bcp_idx")
                alevel_num = 1
                for alevel in alevel_lst:
                    alevel_link_str = "alevel" + str(alevel_num)
                    if user_bcp.isLinkedElement(alevel_link_str):
                        user_bcp_alevel = user_bcp.getLinkedElement(alevel_link_str)
                        if user_bcp_alevel.getUniID() != alevel.getUniID():
                            for alvl_bcp in alevel.getChildListByType("alevel_bcp"):
                                if alvl_bcp.getLinkedElement("bcp").getUniID() == bcp.getUniID():
                                    alvl_bcp.doAction("unload")
                                    break
                            user_bcp.bindElement(alevel_link_str, alevel)
                        else:
                            use_alevel[alevel_num - 1] = False
                    else:
                        user_bcp.bindElement(alevel_link_str, alevel)
                    alevel_num += 1
            else:
                create = 1
                user_idx = AllocObjectIndex(bcp, "user")
                if user_idx == -1:
                    continue
                user_bcp = r08.createElement("user")
                user_bcp.setAttribute("permit", self.getUniID())
                user_bcp.bindElement("bcp", bcp)
                user_bcp.setAttribute("bcp_idx", user_idx)
                if len(alevel_lst) >= 1:
                    user_bcp.bindElement("alevel1", alevel_lst[0])
                if len(alevel_lst) >= 2:
                    user_bcp.bindElement("alevel2", alevel_lst[1])
            alevel_bcp_idx = [0, 0]
            alevel_idx = 0
            for alevel in alevel_lst:
                for alvl_bcp in alevel.getChildListByType("alevel_bcp"):
                    if alvl_bcp.getLinkedElement("bcp").getUniID() == bcp.getUniID():
                        alevel_bcp_idx[alevel_idx] = alvl_bcp.getAttribute("bcp_idx")
                        if use_alevel[alevel_idx]:
                            alvl_bcp.doAction("use")
                        break
                alevel_idx += 1
            zone_num = 11184810
            acc_bcp_tz_idx = 0
            if zone and zone.hasParent():
                if zone.getParent().getUniID() == bcp.getUniID():
                    zone_num = zone.bcp.getAttribute("object_number")
            rzone_tz_idx = GetTimezoneIndex(r08, bcp, acc_bcp_tz)
            cmd_params = {
                "bcp_idx": user_idx,
                "card": card,
                "pincode": self.pin,
                "alevel1": alevel_bcp_idx[0],
                "alevel2": alevel_bcp_idx[1],
                "zone": zone_num,
                "end_time": self.endDT,
                "acc_bcp_tz": acc_bcp_tz_idx,
                "rzone_tz": rzone_tz_idx,
                "block": 0,
                "create": create
            }
            bcp.doAction("loadUser", cmd_params)

    def deactivateOnRubej08(self, block=False):
        r08 = self._core["rubej08"]
        cur = r08.sql("SELECT uniid FROM rubej08_user WHERE permit=" + str(self.getUniID()))
        for row in cur:
            user_bcp = r08.getElementById("user", row[0])
            bcp = user_bcp.getLinkedElement("bcp")
            user_idx = user_bcp.getAttribute("bcp_idx")
            FreeObjectIndex(bcp, "user", user_idx)
            for alevel_idx in range(0, 2):
                alevel_link_str = "alevel" + str(alevel_idx + 1)
                if user_bcp.isLinkedElement(alevel_link_str):
                    alevel = user_bcp.getLinkedElement(alevel_link_str)
                    for alevel_bcp in alevel.getChildListByType("alevel_bcp"):
                        if alevel_bcp.getLinkedElement("bcp").getUniID() == bcp.getUniID():
                            alevel_bcp.doAction("unload")
                            break
            cmd_params = {
                "bcp_idx": user_idx,
            }
            if not block:
                bcp.doAction("deleteUser", cmd_params)
                user_bcp.selfDelete()
            else:
                try:
                    card = int(self.idcode.getAttribute("name"))
                except:
                    card = 0
                cmd_params = {
                    "bcp_idx": user_idx,
                    "card": card,
                    "pincode": self.pin,
                    "alevel1": 0,
                    "alevel2": 0,
                    "zone": 0,
                    "end_time": self.endDT,
                    "acc_bcp_tz": 0,
                    "rzone_tz": 0,
                    "block": 1
                }
                bcp.doAction("loadUser", cmd_params)

    def blockOnRubej08(self):
        self.deactivateOnRubej08(True)

    def deblockOnRubej08(self):
        self.activateOnRubej08()

    @action_decorator(alias='Активировать пропуск в УЛУ')
    def activateOnUld(self):
        root = self._core['uld'].getFirst('root')
        if root:
            print('start activating on Uld')
            params = {
                'UserID'	:	0,
                'UserRight'		:	'',
                'UserPIN'		:	0,
                'Flags'			:	0,
                'StartTime'		:	0,
                'EndTime'		:	0,
                'Name'			:	'',
                'BirthDay'		:	0,
                'Handle'		:	0,
                'Comments'		:	'',
                'Firm'			:	'',
                'Department'	:	'',
                'Number'		:	0,
                'Post'			:	'',
                'BirthPlace'	:	'',
                'DocType'		:	'',
                'DocSeries'		:	'',
                'DocNumber'		:	'',
                'Issuer'		:	'',
                'IssueDate'		:	0,
                'Model'			:	'',
                'Colour'		:	'',
                'TrailerNumer'	:	'',
                'PackageSort'	:	'',
                'Amount'		:	'',
                'Photo'			:	'',
            }
            subjectType = 0

            if self.state not in (1, 3):
                raise dev_except.TerminateAction(self._core.getString('CredNotActESM'))

            try:
                idCode = self.idcode
                card = idCode.getAttribute("name")
                params['UserID'] = card
            except:
                raise dev_except.TerminateAction(self._core.getString('IdNeedNum'))

            subj = self.subject
            subjName = subj.doAction('getDescription')

            params['Name'] = subjName

            photo = subj.getAttribute('photo')
            if photo != '':
                try:
                    conn = httplib.HTTPConnection("127.0.0.1")
                    conn.request("GET", '/img/%s/' % photo)
                    resp = conn.getresponse()
                    if resp.status == 200:
                        data = resp.read()
                        params['Photo'] = bytearray(data)
                except Exception as e:
                    print('getting photo error: ', repr(e))
            else:
                print('no photo')
            try:
                department = subj.getLinkedElement('department').getAttribute('description').replace(',', '').replace(';', '')
                params['Department'] = department
            except:
                print('department fail')

            try:
                org = subj.getLinkedElement('organization').getAttribute('description')
                params['Firm'] = org
            except:
                print('organization fail')

            try:
                oneTime = self.permitType.getAttribute('oneTime')
                # print 'oneTime= ',oneTime
                if oneTime == 1:
                    params['Flags'] = params['Flags'] | (1 << 4)
            except Exception as e:
                print(repr(e))

            params['StartTime'] = self.beginDT
            params['EndTime'] = self.endDT
            if self.beginDT != 0 and self.endDT != 0:
                params['Flags'] = params['Flags'] | (1 << 0)  # wtf ???

            params['UserPIN'] = self.pin

            res = self.attrflags >> 0 & 1  # wtf ???
            if res == 1:
                params['Flags'] = params['Flags'] | (1 << 2)

            if self.state == 3:
                params['Flags'] = params['Flags'] | (1 << 1)

            try:
                for person in subj.getChildListByType("person"):
                    subjectType = 0
                    post = person.getLinkedElement('postref').getAttribute('description')
                    params['Post'] = post
                    birthday = datetime.datetime.combine(person.getAttribute("birthday_v2"), datetime.time())
                    params['BirthDay'] = (birthday - datetime.datetime(1970, 1, 1)).total_seconds()
                    params['BirthPlace'] = person.getAttribute("birthPlace")
                    params['DocType'] = person.getAttribute("document")
                    params['DocSeries'] = person.getAttribute("series")
                    params['DocNumber'] = person.getAttribute("docNumber")
                    params['Issuer'] = person.getAttribute("issuedBy")
                    params['IssueDate'] = person.getAttribute("issuedWhen")
            except Exception as e:
                print('person data fail : ', repr(e))

            try:
                for mobile in subj.getChildListByType("mobile"):
                    subjectType = 1
                    params['Model'] = mobile.getAttribute("brand")
                    params['Colour'] = mobile.getAttribute("color")
                    params['TrailerNumber'] = mobile.getAttribute("trailernumber")
            except Exception as e:
                print('mobile data fail : ', repr(e))

            try:
                for thing in subj.getChildListByType("thing"):
                    subjectType = 2
                    params['PackageSort'] = thing.getAttribute("packaging")
                    params['Amount'] = thing.getAttribute("placecount")
                    somedate = thing.getAttribute("somedate")
                    params['BirthDay'] = (somedate - datetime.datetime(1970, 1, 1)).total_seconds()
            except Exception as e:
                print('thing data fail : ', repr(e))

            uldRights = []
            rightList = []
            for permitCommonRight in self.getChildListByType("permit_commonright"):
                commonRight = permitCommonRight.getLinkedElement("commonright")
                for uldRight in commonRight.getRightFarElements("uld", "uldright", "uldright"):
                    uldRights.append(uldRight.getAttribute('description'))
                    rightList.append(uldRight)

            UserRight = "\r".join(uldRights)
            params['UserRight'] = UserRight

            rightsOnRoot = {}
            for r in rightList:
                for br in r.getBackLinkElements('root_uldright', 'uldright'):
                    root = br.getParent()
                    if root not in rightsOnRoot:
                        rightsOnRoot[root] = set()
                    rightsOnRoot[root].add(br.getAddr())
            for root in rightsOnRoot:
                try:
                    if subjectType == 0:
                        root.doAction('createUser', {
                            'rights': rightsOnRoot[root], 'params': params
                        })
                    if subjectType == 1:
                        root.doAction('createMobile', {
                            'rights': rightsOnRoot[root], 'params': params
                        })
                    if subjectType == 2:
                        root.doAction('createThing', {
                            'rights': rightsOnRoot[root], 'params': params
                        })
                except dev_except.CommandExecError as e:
                    errMsg = ''
                    try:
                        errMsg = str(e)
                    except:
                        pass
                    raise dev_except.TerminateAction(self._core.getString('UluloadErrr') % errMsg)

    def deactivateOnUld(self):
        print('start deactivating on Uld')
        params = {
            'UserID'	:	0,
            'UserRight'		:	'',
        }

        try:
            idCode = self.idcode
            card = idCode.getAttribute("name")
            params['UserID'] = card
        except:
            raise dev_except.TerminateAction(self._core.getString('IdNeedNum'))

        userRights = []
        rightList = []
        for permitCommonRight in self.getChildListByType("permit_commonright"):
            commonRight = permitCommonRight.getLinkedElement("commonright")
            userRights.append(commonRight.getAttribute('description'))
            for uldRight in commonRight.getRightFarElements("uld", "uldright", "uldright"):
                rightList.append(uldRight)

        rightsOnRoot = {}
        for r in rightList:
            for br in r.getBackLinkElements('root_uldright', 'uldright'):
                root = br.getParent()
                if root not in rightsOnRoot:
                    rightsOnRoot[root] = set()
                rightsOnRoot[root].add(br.getAddr())
        action = False
        for root in rightsOnRoot:
            try:
                action = True
                root.doAction('deactivate', {
                    'rights': rightsOnRoot[root], 'params': params
                })
            except dev_except.CommandExecError as e:
                errMsg = ''
                try:
                    errMsg = str(e)
                except:
                    pass
                raise dev_except.TerminateAction(self._core.getString('UludeactErr') % errMsg)
        if not action:
            raise dev_except.TerminateAction(self._core.getString('ULUNorights'))

    def activateOnOrionIso(self):
        return event_packet.syncOnOrionIso(self, self._core, 0)

    def deactivateOnOrionIso(self):
        return event_packet.syncOnOrionIso(self, self._core, 2)

    @action_decorator(alias='Активировать пропуск в Орион Про')
    def activateOrionIntgrSrv(self, state=1):
        root = self._core['orionintgrsrv'].getFirst('master')
        if root:
            print('start activating on ARM Orion Pro')
            params = {
                'PermitID'	:	self.getUniID(),
                'State'			:	state,
                'CardCode'		:	0,
                'Name'			:	'',
                'Photo'			:	'',
                'Org'			:	'',
                'StartTime'		:	0,
                'EndTime'		:	0,
                'BirthDay'		:	'1900-01-01',
                'Handle'		:	0,
                'Comments'		:	'',
                'Department'	:	'',
                'Number'		:	0,
                'Post'			:	'',
                'BirthPlace'	:	'',
                'DocType'		:	'',
                'DocSeries'		:	'',
                'DocNumber'		:	'',
                'Issuer'		:	'',
                'IssueDate'		:	'1900-01-01',
                'Model'			:	'',
                'Colour'		:	'',
                'TrailerNumer'	:	'',
                'PackageSort'	:	'',
                'Amount'		:	'',
                'GroupID'		:	[],
                'ScheduleID'	:	0,
                'ScheduleName'	:	'',
                'employeeNumber':	'',
                'Address'       :	'',
                'Phone  '       :	'',
                'EmailList'     :	'',
                'HomePhone'     :	'',
                'blockcomment':	self.blockcomment,
                'dismissed'		: self._obj.getAttribute('note5'),  # кастомное поле отметки об увольнении
                'addKeyString': '',
                'stop': bool(self.attrflags & 0x01 == 0x01)
            }

            """ Получение кода карты"""
            try:
                idCode = self.idcode
                params['CardCode'] = int(idCode.getAttribute('name'))
                params['CardCodeID'] = idCode. getUniID()
            except Exception:
                raise dev_except.TerminateAction(self._core.getString('cardCodeIdneed'))

            """ получение уровня доступа (идентификатор рабочего графика в Орион)"""
            for pr in self.getChildListByType('permit_commonright'):
                right = pr.getLinkedElement('commonright')
                params['addKeyString'] += right.getAttribute('keyword')+'|'
                for r in right.getRightFarElements(equipFilter='orionintgrsrv', typeFilter='schedule',
                                                   linkNameFilter='schedule_srv'):
                    params['GroupID'].append(r.getAttribute('code'))

            if len(params['GroupID']) == 0:
                raise dev_except.TerminateAction(self._core.getString('OIS_AL_NOT_SET'))

            """ получение субьекта пропуска """
            subj = self.subject
            subjName = subj.doAction('getDescription')
            params['Name'] = subjName
            params['SubjectID'] = subj.getUniID()
            params['Photo'] = subj.getAttribute('photo')

            try:
                department = subj.getLinkedElement('department').getAttribute('description')
                params['Department'] = department
            except:
                print('department fail')

            try:
                schedule = subj.getLinkedElement('schedule')
                ScheduleID = 0
                if schedule:
                    ScheduleID = int(schedule.getAttribute('external_id'))
                if ScheduleID:
                    params['ScheduleID'] = ScheduleID
                else:
                    department = subj.getLinkedElement('department')
                    if department:
                        schedule = department.getLinkedElement('schedule')
                        if schedule:
                            ScheduleID = int(schedule.getAttribute('external_id'))
                            if ScheduleID:
                                params['ScheduleID'] = ScheduleID

            except:
                print('ScheduleID fail')

            try:
                org = subj.getLinkedElement('organization').getAttribute('description')
                params['Org'] = org
            except:
                print('organization fail')

            params['StartTime'] = self.beginDT
            params['EndTime'] = self.endDT
            print("StartTime = %s",params ['StartTime'])
            print("EndTime = %s",params ['EndTime'])

            params['UserPIN'] = self.pin

            try:
                for person in subj.getChildListByType("person"):
                    params['ExtID'] = '%s' % (person.getAttribute('external_id'))
                    # Дата рождения не требуется, в портс заменяется на дату окончания пропуска
                    # params['BirthDay'] = str(person.getAttribute("birthday_v2"))
                    params['BirthPlace'] = person.getAttribute("birthPlace")
                    params['DocType'] = person.getAttribute("document")
                    params['DocSeries'] = person.getAttribute("series")
                    params['DocNumber'] = person.getAttribute("docNumber")
                    params['Issuer'] = person.getAttribute("issuedBy")
                    params['IssueDate'] = str(person.getAttribute("issuedWhen"))
                    params['employeeNumber'] = person.getAttribute("employeeNumber")
                    # В поле адрес записываем значение временной регистрации
                    params['Address'] = person.getAttribute("placeOfActualResidence")
                    params['Phone'] = person.getAttribute("phone")
                    params['EmailList'] = person.getAttribute("email")
                    params['HomePhone'] = person.getAttribute("phoneNumber")

                    try:
                        post = person.getLinkedElement('postref').getAttribute('description')
                        params['Post'] = post
                    except Exception as e:
                        print('get post fail: ', repr(e))

            except Exception as e:
                print('person data fail : ', repr(e))

            try:
                for mobile in subj.getChildListByType("mobile"):
                    ownerDescr = mobile.getLinkedElement('owner').getAttribute('description')
                    if mobile.getLinkedElement('owner').getTypeName() == 'person':
                        names = ownerDescr.split()
                        if len(names) == 0:
                            names = [' ', ' ', ' ']
                        name = names[0]
                        if len(names) > 1:
                            name2 = names[1]
                        else:
                            name2 = ' '
                        if len(names) > 2:
                            name3 = ''.join(names[2:])
                        else:
                            name3 = ' '
                        ownerDescr = '%s %s. %s.' % (name, name2[:1], name3[:1])
                    params['Model'] = mobile.getAttribute("brand") if mobile.getAttribute("brand") != '' else '???'
                    params['Name'] = '%s %s %s' % (subj.doAction('getDescription'), params['Model'], ownerDescr)
                    params['ExtID'] = '%s' % mobile.getAttribute('external_id')
                    params['Colour'] = mobile.getAttribute("color")
                    params['TrailerNumber'] = mobile.getAttribute("trailernumber")
            except Exception as e:
                print('mobile data fail : ', repr(e))

            try:
                for thing in subj.getChildListByType("thing"):
                    params['ExtID'] = '%s' % thing.getAttribute('external_id')
                    params['PackageSort'] = thing.getAttribute("packaging")
                    params['Amount'] = thing.getAttribute("placecount")

            except Exception as e:
                print('thing data fail : ', repr(e))

            # print 'permit parameters for orion: ', params

            orion_buses = self._core['orionintgrsrv'].getElements('master')
            for orion in orion_buses:
                orion.doAction('createUserAsync', {
                    'permitParams': params,
                    'permit':	self,
                })

    @action_decorator(alias='Деактивировать')
    def deactivate(self):
        txt = self._core.getString('credDeactInEquip') % self.getUniID()
        timeout = 5000
        tp = 'info'

        if self.state not in (1, 2, 3):
            print("permit #%d has not activated" % self.getUniID())
            raise dev_except.TerminateAction(self._core.getString('OnlyDeactCredAct'))
        
        root = self._core.getElements('root')[0]
        if root.getAttribute('archive_face_when_deactivate_permit') is True:
            if self.isLinkedElement('subject') is True:
                person = self.getLinkedElement('subject').getChildListByType('person')[0]
                if person is not None:
                    root.doAction('delete_face_by_person', {'person': person})
        
        try:
            if 'apollo' in self._core['...']:
                self.deactivateOnApollo()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactApollo')
        try:
            if 'pce' in self._core['...']:
                self.desactivateOnPCE_internal()
        except dev_except.TerminateAction as e:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeacInPce') % e
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInPCE1')
        try:
            if 'housekeeper' in self._core['...']:
                self.desactivateOnHK_internal()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInKEy')

        try:
            if 'uld' in self._core['...']:
                self.deactivateOnUld()
        except Exception:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInUld')

        try:
            if 'orionintgrsrv' in self._core['...']:
                # для удаление карты таке команда
                self.activateOrionIntgrSrv(2)
        except Exception as e:
            timeout = -1
            tp = 'warning'
            str_err = str(e)
            txt = '%s&lt;br/&gt; %s' % (txt + self._core.getString('notActivateOrionIntgrSrv'), str_err)

        try:
            if 'rubej08' in self._core['...']:
                self.deactivateOnRubej08()
        except Exception:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInrubej')

        try:
            if 'orioniso' in self._core['...']:
                self.deactivateOnOrionIso()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInOrionIso')

        try:
            if 'bosch' in self._core['...']:
                self.deactivateOnBOSCH()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactInBOSCH')

        try:
            if 'rubezhglobal' in self._core['...']:
                self._core['rubezhglobal'].getFirst('driver').doAction('deactivatePermit', {
                    'permit': self, 'reason': 'Deactivate by ESM'})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactRubezhGlobal')

        try:
            if 'rusguard' in self._core['...']:
                self._core['rusguard'].getFirst('server').doAction('deactivatePermit', {
                    'permit': self._obj, 'reason': 'Deactivate by ESM'})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactRusGuard')
            
        try:
            if 'biostar' in self._core['...']:
                self._core['biostar'].getFirst('driver').doAction('blockPermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactbiostar')
        try:
            if 'apacsbio' in self._core['...']:
                self._core['apacsbio'].getFirst('driver').doAction('blockPermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockapacsbio')
        
        if self.state == 1 or self.state == 3:
            for pr in self.getChildListByType('permit_commonright'):
                pr.clearIndexes()
            self.state = 2
            self.deactdt = time.time()
            op = self.getCurrOperatorSubject()
            if op:
                self.subjdeact = op
        for pr in self.getChildListByType('permit_commonright'):
            pr.loadingCorrectIndexes()
        return {
            'txt':	txt,
            'timeout':	timeout,
            'type':	tp
        }

    def desactivateOnPCE_internal(self):
        idcode = self.idcode
        if idcode.getAttribute('codeType'):
            if len(idcode.getAttribute('name')) > 15:
                raise dev_except.TerminateAction(self._core.getString('IdLenghtLess15'))
        self.deleteFromPCE()

    def deleteFromPCE(self):
        for bus in self._core['pce'].getElements('bus'):
            try:
                bus.doAction('deleteUser', {
                    'permit': self
                })
            except dev_except.PortNotFound:
                print('bus %s port not found' % bus.getAttribute('description'))
            except Exception as e:
                print('deactivateOnPCE error:', e, bus.getAttribute('description'))
                raise e

    def desactivateOnHK_internal(self):
        idcode = self.idcode.getAttribute("name")
        intIdcode = None
        try:
            intIdcode = int(idcode)
        except:
            pass

        for pr in self.getChildListByType("permit_commonright"):
            right = pr.getLinkedElement("commonright")
            if intIdcode:
                for hkRight in right.getRightFarElements("housekeeper", "hkright", "hkright"):
                    hkRight.doAction('delCard', {"card": idcode})

    def activateOnBOSCH(self):
        self._core['bosch'].getFirst('ace').doAction('createPermit', {'permitObj': self._obj})

    def deactivateOnBOSCH(self):
        self._core['bosch'].getFirst('ace').doAction('deletePermit', {'permitObj': self._obj})

    def blockOnBOSCH(self, commentary):
        self._core['bosch'].getFirst('ace').doAction('blockPermit', {'permitObj': self._obj, 'commentary': commentary})

    def deblockOnBOSCH(self):
        self._core['bosch'].getFirst('ace').doAction('deblockPermit', {'permitObj': self._obj})

    def __checkValidSubject(self, targetObj=None):
        self.__checkNewPermit()
        if targetObj:
            blackLists = self._core.getElementsByIndex('blacklist', 'openForSubject', keyValueDict=None,
                                                       keyValue=targetObj.getUniID())
            for blackListId in blackLists:
                if blackLists[blackListId].getAttribute('block') == 0:
                    raise dev_except.TerminateAction(self._core.getString('SubjectHasBlockedBlackList'))

    def __checkNewPermit(self, targetObj=None):
        if self.state != 0:
            raise dev_except.TerminateAction(self._core.getString('CredEDitRestricted') % self.getUniID())

    def __checkDublicatePIN(self, value, field):
        self.__checkNewPermit()
        if int(value) != 0:
            size = len(str(value))
            if size > 6 or 4 > size:
                raise dev_except.TerminateAction(self._core.getString('pinLength'))
            res = event_packet.check_dublicate_pin(self._core, value)
            if res:
                raise dev_except.TerminateAction(self._core.getString('DublicatePermitsPIN') % res)

    def __checkNewOrDraftPermitPermit(self, targetObj=None):
        if self.state != 0 and self.state != 4:
            raise dev_except.TerminateAction(self._core.getString('CredEDitRestricted') % self.getUniID())

    def __checkNewOpenPermit(self, **kwargs):
        if self.state == 2:
            raise dev_except.TerminateAction(self._core.getString('CredEDitRestricted') % self.getUniID())

    def __checkIdcodeAssignment(self, targetObj):
        self.__checkNewPermit()
        if targetObj:
            code = targetObj.getAttribute('name')
            if not code or str(code) == '0':
                raise dev_except.TerminateAction(self._core.getString('EmptyIdRestricted'))
            if not targetObj.checkUniqueIndex('name'):
                raise dev_except.TerminateAction(self._core.getString('NotUniqueIdRestricted') % code)

    def __setInSearchFlag(self, value, field):
        oldVal = self.attrflags
        if value:
            self.attrflags = oldVal | 0x01
        else:
            self.attrflags = oldVal & 0xE
        self.attrUpdated('insearch')
        if 'orionintgrsrv' in self._core['...']:
            return self.activateOrionIntgrSrv()

    def __getInSearchFlag(self, field):
        return self.attrflags & 0x01 == 0x01

    def __setLostFlag(self, value, field):
        oldVal = self.attrflags
        if value:
            self.attrflags = oldVal | 0x02
        else:
            self.attrflags = oldVal & 0xD
        self.attrUpdated('lost')

    def __getLostFlag(self, field):
        return self.attrflags & 0x02 == 0x02

    def definePermitDuration(self):
        #  Определение срока действия пропуска.
        actionStartDay = self.permitType.getAttribute('actionStartDay')
        duration = self.permitType.getAttribute('duration')
        durationRestriction = self.permitType.getAttribute('durationRestriction')

        begin_seconds = -1
        end_seconds = -1
        multiplier = 0
        # По умолчанию определяем дату с точностью до дня
        begin_date = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        # Если параметр "Ограничение срока действия" у типа пропуска имеет значение "Ограничен в днях"
        if durationRestriction == 1:
            # Количество секунд в одних сутках
            multiplier = 86400
        # Если параметр "Ограничение срока действия" у типа пропуска имеет значение "Ограничен в часах"
        elif durationRestriction == 2:
            # Определяем дату с точностью до часа
            begin_date = begin_date.replace(hour=datetime.datetime.now().hour)
            # Кличество секунд в часе
            multiplier = 3600
        # Если параметр "Начало действия" у типа пропуска имеет значение "Текущий день"
        if actionStartDay == 1:
            begin_seconds = time.mktime(begin_date.timetuple())
        # Если параметр "Начало действия" у типа пропуска имеет значение "Следующий день"
        elif actionStartDay == 2:
            # Если срок действия пропуска начинается со следующего дня, то время начала пусть будет равно 00:00:00
            begin_seconds = time.mktime(datetime.date.today().timetuple()) + 86400
        # Дата конца срока действия не может быть определена без даты начала срока действия.
        if begin_seconds > 0 and durationRestriction != 0:
            end_seconds = begin_seconds + duration * multiplier - 1

        # Если другая дата начала срока действия не была установлен в запросе создания
        if begin_seconds > 0 and self.beginDT == 0:
            self.setAttr('beginDT', begin_seconds)
        # Если другая дата начала срока действия не была установлен в запросе создания
        if end_seconds > 0 and self.endDT == 0:
            self.setAttr('endDT', end_seconds)

    @action_decorator(alias='Клонировать')
    def clone(self):
        clone = self._core.createElement('permit', attrs={
            'note_mobile': self.note_mobile,
            'note_thing': self.note_thing,
            'note': self.note,
            'note2': self.note2,
            'note3': self.note3,
            'note4': self.note4,
            'note5': self.note5,
            'note6': self.note6,
            'equipment_export': self.equipment_export,
            'equipment_import': self.equipment_import,
            'visitaim': self.visitaim,
            'wheregoingto': self.wheregoingto
        })

        for pr in self.getChildListByType('permit_commonright'):
            clone.createLink(
                'permit_commonright', pr.getLinkedElement('commonright'), info=('dlg',)
            )

        if self.isLinkedElement('subject'):
            clone.bindElement('subject', self.subject)

        if self.permitType:
            permitType = self.permitType
            clone.bindElement('permitType', permitType)
            clone.doAction('definePermitDuration')
            if permitType.getAttribute('saveLinkToId') == 1 and self.idcode:
                clone.bindElement('idcode', self.idcode)

        if self.declarer_organization:
            clone.bindElement('declarer_organization', self.declarer_organization)
        if self.declarer_department:
            clone.bindElement('declarer_department', self.declarer_department)

        if self.getCurrOperatorSubject():
            clone.bindElement('subjcreate', self.getCurrOperatorSubject())

        return {
            'txt'		: self._core.getString('CredCopyCreated') % (clone.getUniID(), self.getUniID()),
            'timeout'	: 1000,
            'type'		: 'info',
            'cloneId': clone.getUniID()
        }

    @classmethod
    @action_decorator(alias='Активировать все пропуска', actionClass='static',
                      equipmentName='Оборудование (pce, hk, uld, bosch, apollo, orionintgrsrv)')
    def activateAll(cls, equipmentName: str = 'pce'):
        equipMap = {
            'pce'	:	'activateOnPCE',
            'apollo'	:	'activateOnApollo',
            'hk'		:	'activateOnHouseKeeper',
            'uld'		:	'activateOnUld',
            'bosch'		:	'activateOnBOSCH',
            'orionintgrsrv': 'activateOrionIntgrSrv',
        }
        if equipmentName not in equipMap:
            raise dev_except.TerminateAction(cls._core.getString('UnknownDevice') % equipmentName)

        equipCmd = equipMap[equipmentName]

        res = ''
        for permit in cls._core.getElements('permit'):
            if permit.getAttribute('state') == 0:
                res = '%s&lt;div style="color: blue;"&gt; ' % res +\
                      cls._core.getString('CredNotActYet') % permit.getUniID() + '&lt;/div&gt;'
            elif permit.getAttribute('state') == 1:
                for effort in range(1, 4):
                    try:
                        params = {
                            'async': 'True'
                        }
                        permit.doAction(equipCmd, params)
                        res = '%s&lt;div style="color: green;"&gt;' % res +\
                              cls._core.getString('CredReactFromAttempt') % (permit.getUniID(), effort) + '&lt;/div&gt;'
                        break
                    except Exception as e:
                        res = '%s&lt;div style="color: red;"&gt;' % res +\
                              cls._core.getString('ErrOfCredAct') % (permit.getUniID(), e, effort) + '&lt;/div&gt;'
            else:
                res = '%s&lt;div style="color: brown;"&gt;' % res + cls._core.getString('CredAlreadyDeact') % (
                    permit.getUniID()) + '&lt;/div&gt;'

        return {
            'txt': res,
            'timeout': -1,
            'type': 'info'
        }

    @action_decorator(alias='Блокировать', commentary='Коментарий')
    def block(self, commentary: str = ''):
        # Блокировать можно только активированный пропуск
        if self.state == 4:
            raise dev_except.TerminateAction(self._core.getString('CredDraft'))

        if self.state != 1:
            if self.state == 0:
                raise dev_except.TerminateAction(self._core.getString('CredNotAct'))
            else:
                raise dev_except.TerminateAction(self._core.getString('CredAlreadyDeact'))

        op = self.getCurrOperatorSubject()
        if op:
            self.subjblock = op
        else:
            raise dev_except.TerminateAction(self._core.getString('UnknOperator'))

        if commentary == "":
            raise dev_except.TerminateAction(self._core.getString('NeedComment'))

        self.state = 3
        self.blockcomment = commentary

        self.blockdt = time.time()

        txt = self._core.getString('CredBlocked') % self.getUniID()
        timeout = 5000
        tp = 'info'

        try:
            if 'pce' in self._core['...']:
                self.desactivateOnPCE_internal()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedPCe')

        try:
            if 'housekeeper' in self._core['...']:
                self.desactivateOnHK_internal()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedKey')

        try:
            if 'uld' in self._core['...']:
                self.deactivateOnUld()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedUlu')

        try:
            if 'orioniso' in self._core['...']:
                self.deactivateOnOrionIso()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedOrion')

        try:
            if 'orionintgrsrv' in self._core['...']:
                self.activateOrionIntgrSrv(3)
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('notActivateOrionIntgrSrvNoCon')

        try:
            if 'rubej08' in self._core['...']:
                self.blockOnRubej08()
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedRubej')

        try:
            if 'bosch' in self._core['...']:
                self.blockOnBOSCH(commentary)
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedBOSCH')

        try:
            if 'rubezhglobal' in self._core['...']:
                self._core['rubezhglobal'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockedRubezhGlobal')

        try:
            if 'rusguard' in self._core['...']:
                self._core['rusguard'].getFirst('server').doAction('deactivatePermit', {
                    'permit': self._obj, 'reason': 'Deactivate by ESM'})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotBlockRusGuard')
            
        try:
            if 'biostar' in self._core['...']:
                self._core['biostar'].getFirst('driver').doAction('deactivatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactbiostar')

        try:
            if 'apacsbio' in self._core['...']:
                self._core['apacsbio'].getFirst('driver').doAction('deactivatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactapacsbio')
        
        return {
            'txt': txt,
            'timeout': timeout,
            'tp': tp
        }

    @action_decorator(alias='Разблокировать')
    def deblock(self):
        # Разблокировать можно только блокированный пропуск
        if self.state != 3:
            raise dev_except.TerminateAction(self._core.getString('CredNotBlocked'))

        op = self.getCurrOperatorSubject()
        if op:
            self.subjblock = op
        else:
            raise dev_except.TerminateAction(self._core.getString('UnknOperator'))

        self.state = 1
        self.blockcomment = ''
        self.blockdt = time.time()

        txt = self._core.getString('CredUblckd') % self.getUniID()
        timeout = 5000
        tp = 'info'

        try:
            if 'pce' in self._core['...']:
                self.activateOnPCE()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdPCE')

        try:
            if 'orionintgrsrv' in self._core['...']:
                self.activateOrionIntgrSrv(1)
        except Exception as e:
            timeout = -1
            tp = 'warning'
            str_err = str(e)
            txt = '%s&lt;br/&gt; &lt;br/&gt; %s' % (txt + self._core.getString('notActivateOrionIntgrSrv'), str_err)

        res = ''
        if 'housekeeper' in self._core['...']:
            for effort in range(1, 4):
                try:
                    self.activateOnHouseKeeper()
                    break
                except Exception as e:
                    timeout = -1
                    tp = 'warning'
                    txt = txt + '%s&lt;div style="color: red;"&gt;' % res +\
                          self._core.getString('ErrWhenUnblckCredToKey') % (self.getUniID(), e, effort) + '&lt;/div&gt;'

        try:
            if 'uld' in self._core['...']:
                self.activateOnUld()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdUlu')

        try:
            if 'rubej08' in self._core['...']:
                self.deblockOnRubej08()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdRubej')

        try:
            if 'bosch' in self._core['...']:
                self.deblockOnBOSCH()
        except:
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdBOSCH')

        try:
            if 'rubezhglobal' in self._core['...']:
                self._core['rubezhglobal'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdRubezhGlobal')

        try:
            if 'rusguard' in self._core['...']:
                self._core['rusguard'].getFirst('server').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = '%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblockdRusguard')
            
        try:
            if 'biostar' in self._core['...']:
                self._core['biostar'].getFirst('driver').doAction('activateCard', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotDeactbiostar')
        
        try:
            if 'apacsbio' in self._core['...']:
                self._core['apacsbio'].getFirst('driver').doAction('activatePermit', {'permit': self._obj})
        except Exception as e:
            print(repr(e))
            timeout = -1
            tp = 'warning'
            txt = u'%s&lt;br/&gt;' % txt + self._core.getString('CredNotUnblckdapacsbio')

        return {
            'txt'		:	txt,
            'timeout'	:	timeout,
            'type'		:	tp
        }

    def __activateOnPCE(self, oldValue, oldValues):
        return self.activateOnPCE()

    @action_decorator(alias='Продлить', enddt='Дата окончания', reason='Причина продления')
    def prolongate(self, enddt: int = 0, reason: str = ''):
        n = datetime.datetime.now().strftime('%d.%m.%y')
        self.endDT = enddt
        r = self.prolongationhistory
        reas = self._core.getString('permitProlongationReason') % (n, reason)
        if r == '':
            r = reas
        else:
            r += ';' + reas
        self.prolongationhistory = r
        self.activateOnDevice()
        return {
            'txt'	:	self._core.getString('permitProlongationResult') % self.getUniID(),
            'timeout'	:	5000,
            'type'		:	'info'
        }

    def __getNumber(self, field):
        return self.getUniID()

    number = Attribute(alias='Номер', index=1, fget=__getNumber, readOnly=True, storeInDb=False)
    subject = Link(alias='Субъект', target=common_subject, index=2, preAction=__checkValidSubject)
    state = Attribute(alias='Состояние', fieldType=int, defval=0, index=3,
                      editorType='enum(Создан, Активирован, Деактивирован, Заблокирован, Черновик)')
    permitType = Link(alias='Тип', target=common_permittype, index=4)
    beginDT = Attribute(alias='Дата начала', fieldType=int, defval=0, index=5, preAction=__checkNewOpenPermit,
                        editorType='UnixDateTime')
    endDT = Attribute(alias='Дата конца', fieldType=int, defval=0, index=6, preAction=__checkNewOpenPermit,
                      editorType='UnixDateTime')
    idcode = Link(alias='Идентификатор', target=common_idcode, index=7, preAction=__checkIdcodeAssignment)
    pin = Attribute(alias='Пин', fieldType=int, defval=0, index=8, preAction=__checkDublicatePIN)
    createdt = Attribute(alias='Время создания', fieldType=int, defval=0, index=9, editorType='datetime')
    subjcreate = Link(alias='Создал', target=common_subject, index=10, preAction=__checkNewOrDraftPermitPermit)
    actdt = Attribute(alias='Время активации', fieldType=int, defval=0, index=11, editorType='datetime')
    subjact = Link(alias='Активировал', target=common_subject, index=12, preAction=__checkNewPermit)
    deactdt = Attribute(alias='Время деактивации', fieldType=int, defval=0, index=13, editorType='datetime')
    subjdeact = Link(alias='Деактивировал', target=common_subject, index=14)
    blockdt = Attribute(alias='Время блокировки', fieldType=int, defval=0, index=15, editorType='datetime')
    subjblock = Link(alias='Заблокировал', target=common_subject, index=16)
    blockcomment = Attribute(alias='Причина блокировки', fieldType=str, defval='', index=17)
    insearch = Attribute(alias='В розыске', index=18, fget=__getInSearchFlag, fset=__setInSearchFlag,
                         postAction=__activateOnPCE, editorType='checkBox', storeInDb=False)
    lost = Attribute(alias='Утерян', index=19, fget=__getLostFlag, fset=__setLostFlag, postAction=__activateOnPCE,
                     editorType='checkBox', storeInDb=False)
    attrflags = Attribute(alias='Флагосостояние', fieldType=int, defval=0, showInClient=False)
    actsecurlevel = Link(alias='Уровень безопасности при активации', target=common_securlevel, index=20)
    requisition = Attribute(alias='Id заявки', fieldType=int, defval=0, index=21)
    requisitionnumber = Attribute(alias='Номер заявки', fieldType=int, defval=0, index=22)
    requisitiondate = Attribute(alias='Дата заявки', fieldType=int, defval=0, index=23,
                                editorType='UnixDateTime')
    requisitionagreeing = Attribute(alias='Кто согласовал', fieldType=str, defval='', index=24)
    requisitionsignatory = Attribute(alias='Кто подписал', fieldType=str, defval='', index=25)
    requisitionreceiving = Attribute(alias='Принимающий', fieldType=str, defval='', index=26)
    equipment_import = Attribute(alias='Оборудование на внос', fieldType=str, defval='', index=27)
    equipment_export = Attribute(alias='Оборудование на вынос', fieldType=str, defval='', index=28)
    permitput = Attribute(alias='Дата сдачи пропуска', fieldType=int, defval=0, index=29, editorType='UnixDateTime')
    prolongationhistory = Attribute(alias='История продления пропуска', fieldType=str, defval='', index=30)
    note = Attribute(alias='Примечание', fieldType=str, defval='', index=31)
    note2 = Attribute(alias='Примечание 2', fieldType=str, defval='', index=32)
    note3 = Attribute(alias='Примечание 3', fieldType=str, defval='', index=33)
    note5 = Attribute(alias='Примечание 5', fieldType=str, defval='', index=35)
    note4 = Attribute(alias='Примечание 4', fieldType=str, defval='', index=34)
    note6 = Attribute(alias='Примечание 6', fieldType=str, defval='', index=36)
    wheregoingto = Attribute(alias='К кому идет', fieldType=str, defval='', index=37)
    visitaim = Attribute(alias='Цель визита', fieldType=str, defval='', index=38)
    schedule = Link(alias='Расписание', target=common_schedule, index=39)
    declarer_organization = Link(alias='Организация заявителя', target=common_organization, index=40)
    declarer_department = Link(alias='Подразделение заявителя', target=common_department, index=41)
    note_mobile = Attribute(alias='Дополнительные данные об автомобиле', fieldType=str, defval='', index=42)
    note_thing = Attribute(alias='Дополнительные данные о грузе', fieldType=str, defval='', index=43)
    ownpart = Link(alias='Свой раздел охранной сигнализации PCE', target=pce_part, index=44)

    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=51, readOnly=True)
