# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, index_decorator, action_decorator
from equipment.methods_for_equipment import get_subsystem_ids


class common_post(protocol_obj_base, alias='Должность'):
    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')
            
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')

    @index_decorator('descriptionTSS')
    def descriptionIndexFunc(self):
        return self.getAttribute('description')

    @classmethod
    @action_decorator(alias='Удалить все из БД', actionClass='static')
    def eraseAll(cls):
        while True:
            item = cls._core['common'].getFirst('post')
            if item:
                item.selfDelete()
            else:
                break

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=2)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах',  fieldType=str, defval='{}', index=3)
