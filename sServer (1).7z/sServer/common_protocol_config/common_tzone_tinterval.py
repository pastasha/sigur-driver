# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_tinterval import common_tinterval


class common_tzone_tinterval(protocol_obj_base, alias='',
                             parent=ParentStruct(typeName='tzone', alias='Временные интервалы',
                                                 addr=(1, constants.MAX_UINT8))):

    tinterval = Link(alias='', target=common_tinterval, index=1)
