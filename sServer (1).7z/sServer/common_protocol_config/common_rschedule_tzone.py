# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link

from .common_tzone import common_tzone


class common_rschedule_tzone(protocol_obj_base, alias='',
                             parent=ParentStruct(typeName='rschedule', alias='Временные зоны')):

    tzone = Link(alias='', target=common_tzone)
