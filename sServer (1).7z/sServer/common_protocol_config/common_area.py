# -*- coding: utf-8 -*-

import time

from equipment.protocol_obj_base import protocol_obj_base, action_decorator, ParentStruct, Attribute, Link
import equipment.constants as constants

from system_protocol_config.system_map import system_map


class common_area(protocol_obj_base, alias='Зона доступа',
                  parent=ParentStruct('area', 'Внутренние зоны', (1, constants.MAX_UINT32))):

    OBSOBJTYPE = 'dev'

    def init(self):
        self.__pushStateEvent()

    @classmethod
    def areaTypeSelect(cls):
        return {
            cls._core.getString('Internal'): 'internal',
            cls._core.getString('External'): 'external'
        }

    @action_decorator(alias='Увеличить число людей в зоне на 1')
    def incrementPersonsInArea(self):
        p = self.persons_count
        p += 1
        self.setAttribute('persons_count', p)
        self.__pushStateEvent()

    @action_decorator(alias='Уменьшить число людей в зоне на 1')
    def decrementPersonsInArea(self):
        p = self.persons_count
        p -= 1
        if p < 0:
            p = 0
        self.setAttribute('persons_count', p)
        self.__pushStateEvent()

    @action_decorator(alias='Сбросить число людей в зоне')
    def clearPersonsInArea(self):
        self.setAttribute('persons_count', 0)
        self.__pushStateEvent()

    @action_decorator(alias='Установить число людей в зоне', count='Количество')
    def setPersonsInArea(self, count:int=0):
        p = int(count)
        if p > 0:
            self.setAttribute('persons_count', p)
            self.__pushStateEvent()

    def __pushStateEvent(self):
        self.pushEvent({
            'notification': {
                'code': 1000
            },
            'statement': {
                'adverbialTime': {
                    'param': time.time()
                },
                'directObj': {
                    'dev': {
                        'equip': 'common',
                        'type': 'area',
                        'id': self.getUniID(),
                        'state': {
                            'CONF': {
                                'count': self.persons_count
                            }
                        }
                    }
                }
            }
        })

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    areatype = Attribute(alias='Тип зоны доступа', fieldType=str, defval='internal', index=2,
                         editorType='treeSelect(areaTypeSelect)')
    persons_count = Attribute(alias='Количество людей в зоне', fieldType=int, defval=0, index=3, editorType='int')
    geometry = Attribute(alias='Геометрия', fieldType=str, defval='{}', index=4)
    map = Link(alias='Векторная карта', target=system_map, index=5)
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
