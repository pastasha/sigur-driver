# -*- coding: utf-8 -*-

import json
from datetime import date

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except


class common_thing(protocol_obj_base, alias='Материальные ценности',
                   parent=ParentStruct('subject', 'Материальная ценность', (1, 1))):
    def postCreate(self, ignore_create_objects=False):
        if not ignore_create_objects:
            # TODO: пока это костыль. Если оставить addChild(self) то он не сможет найти __correctClrIndexes
            self._core.createElement('subject', siteId=self.siteId).addChild(self._obj)

    def preDelete(self, deleteAsLink=False):
        try:
            if 'subjectDeleted' not in self or not self['subjectDeleted']:
                self['subjectDeleted'] = False
                self.getParent().selfDelete()
        except dev_except.ParentNotFound:
            pass

    def postChangeParent(self, oldParent=None, info=None):
        if self.hasParent():
            self.getParent().attrUpdated('description')

    def __descriptionChanged(self, oldValue, oldValues):
        if self.hasParent():
            self.getParent().attrUpdated('description')

    description = Attribute(alias='Наименование', fieldType=str, defval='', index=1, postAction=__descriptionChanged)
    packaging = Attribute(alias='Упаковка', fieldType=str, defval='', index=2)
    placecount = Attribute(alias='Количество мест', fieldType=str, defval='', index=3)
    somedate = Attribute(alias='Дата', fieldType=date, defval=date(1961, 4, 12), index=4, editorType='date')
