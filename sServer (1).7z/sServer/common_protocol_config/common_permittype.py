# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link

from .common_permittemplate import common_permittemplate


class common_permittype(protocol_obj_base, alias='Тип пропуска'):
    @classmethod
    def visitorTypeSelect(cls):
        return {
            cls._core.getString('Individual'): 'person',
            cls._core.getString('Vehicle'):	'vehicle',
            cls._core.getString('Materialvalue'): 'thing'
        }

    @classmethod
    def durationRestrictionSelect(cls):
        return {
            cls._core.getString('notDefined'): 0,
            cls._core.getString('limitedInDays'): 1,
            cls._core.getString('limitedInHours'): 2
        }

    @classmethod
    def actionStartDaySelect(cls):
        return {
            cls._core.getString('notDefined'): 0,
            cls._core.getString('CurrentDay'): 1,
            cls._core.getString('NextDay'): 2
        }

    @classmethod
    def saveLinkToIdSelect(cls):
        return {
            cls._core.getString('no'): 0,
            cls._core.getString('yes'): 1
        }

    def __validatePermitDuration(self, value, field):
        if value not in range(0, 65536):
            raise ArithmeticError('Value %s does not locate between 0 and 65535!' % value)

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    needRequest = Attribute(alias='Обязательна заявка', fieldType=int, defval=0, index=2, editorType='checkBox')
    withoutIdcode = Attribute(alias='Без идентификатора', fieldType=int, defval=0, index=3, editorType='checkBox')
    oneTime = Attribute(alias='Разовый', fieldType=int, defval=0, index=4, editorType='checkBox')
    infoFlag1 = Attribute(alias='Дополнительный флаг 1', fieldType=int, defval=0, index=5, editorType='checkBox')
    infoFlag2 = Attribute(alias='Дополнительный флаг 2', fieldType=int, defval=0, index=6, editorType='checkBox')
    infoFlag3 = Attribute(alias='Дополнительный флаг 3', fieldType=int, defval=0, index=7, editorType='checkBox')
    infoFlag4 = Attribute(alias='Дополнительный флаг 4', fieldType=int, defval=0, index=8, editorType='checkBox')
    infoFlag5 = Attribute(alias='Дополнительный флаг 5', fieldType=int, defval=0, index=9, editorType='checkBox')
    infoFlag6 = Attribute(alias='Дополнительный флаг 6', fieldType=int, defval=0, index=10, editorType='checkBox')
    visitortype = Attribute(alias='Тип субъекта', fieldType=str, defval='person', index=11,
                            editorType='treeSelect(visitorTypeSelect)')
    default_template = Link(alias='Шаблон по умолчанию', target=common_permittemplate, index=12)
    form_template = Attribute(alias='Шаблон редактирования', fieldType=str, defval='', index=13)
    durationRestriction = Attribute(alias='Ограничение срока действия', fieldType=int, defval=0, index=14,
                                    editorType='treeSelect(durationRestrictionSelect)')
    duration = Attribute(alias='Время действия', fieldType=int, defval=0, index=15,
                         preAction=__validatePermitDuration, editorType='int')
    actionStartDay = Attribute(alias='Начало действия', fieldType=int, defval=0, index=16,
                               editorType='treeSelect(actionStartDaySelect)')
    saveLinkToId = Attribute(alias='При клонировании сохранять ссылку на идентификатор', fieldType=int, defval=1,
                             index=17, editorType='treeSelect(saveLinkToIdSelect)')
