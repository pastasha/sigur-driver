# -*- coding: utf-8 -*-

from equipment.methods_for_testing import *
from common_protocol_config.test.equipment_dicts import list_equipment


def main():
    class_methods = MethodsForTesting()
    class_methods.list_equipment = list_equipment
    class_methods.equipment_name = 'common'
    class_methods.create_and_delete_equipments()

    area = class_methods.get_reqData('area')
    blacklist = class_methods.get_reqData('blacklist')
    blacklisttype = class_methods.get_reqData('blacklisttype')
    commonright = class_methods.get_reqData('commonright')
    commonrightoo = class_methods.get_reqData('commonrightoo')
    commonrighttemplate = class_methods.get_reqData('commonrighttemplate')
    commonrighttype = class_methods.get_reqData('commonrighttype')
    customcatalog = class_methods.get_reqData('customcatalog')
    customcatalogvalue = class_methods.get_reqData('customcatalogvalue')
    department = class_methods.get_reqData('department')
    deviatinsfromschedules = class_methods.get_reqData('deviatinsfromschedules')
    idcode = class_methods.get_reqData('idcode')
    mobile = class_methods.get_reqData('mobile')
    root = class_methods.get_reqData('root')
    organization = class_methods.get_reqData('organization')
    permit = class_methods.get_reqData('permit')
    permitprolongationreason = class_methods.get_reqData('permitprolongationreason')
    permittemplate = class_methods.get_reqData('permittemplate')
    permittype = class_methods.get_reqData('permittype')
    person = class_methods.get_reqData('person')
    post = class_methods.get_reqData('post')
    respondresource = class_methods.get_reqData('respondresource')

    rschedule = class_methods.get_reqData('rschedule')
    schedule = class_methods.get_reqData('schedule')
    scheduletemplate = class_methods.get_reqData('scheduletemplate')
    securlevel = class_methods.get_reqData('securlevel')
    subject = class_methods.get_reqData('subject')
    thing = class_methods.get_reqData('thing')
    tinterval = class_methods.get_reqData('tinterval')
    tzone = class_methods.get_reqData('tzone')
    wantedface = class_methods.get_reqData('wantedface')
    workingtypeclassifier = class_methods.get_reqData('workingtypeclassifier')

    class_methods.set_link(blacklist, subject, 'subject')
    class_methods.set_link(blacklist, blacklisttype, 'breachtype')
    class_methods.set_link(blacklist, subject, 'operatoropen')
    class_methods.set_link(blacklist, subject, 'operatorclose')

    class_methods.set_link(commonright, commonrighttype, 'type')
    class_methods.set_link(commonright, securlevel, 'threshold1')
    class_methods.set_link(commonright, area, 'mainarea')

    class_methods.set_bribge(commonright, area, 'commonright_area')
    class_methods.set_bribge(commonright, commonrightoo, 'commonright_commonrightoo')

    class_methods.set_bribge(commonrighttemplate, commonright, 'commonrighttemplate_commonright')

    class_methods.add_childr_equipments(customcatalog, customcatalogvalue)

    class_methods.set_link(department, organization, 'organization')
    class_methods.set_link(department, commonrighttemplate, 'commonrighttemplate')
    class_methods.set_link(department, schedule, 'schedule')

    class_methods.set_bribge(department, scheduletemplate, 'department_scheduletemplate')

    class_methods.set_link(deviatinsfromschedules, subject, 'subject')
    class_methods.set_link(deviatinsfromschedules, tzone, 'tzone')
    class_methods.set_link(deviatinsfromschedules, subject, 'authonr')

    class_methods.add_childr_equipments(subject, mobile)

    class_methods.set_link(organization, commonrighttemplate, 'commonrighttemplate')

    class_methods.set_link(permit, subject, 'subject')
    class_methods.set_link(permit, permittype, 'permitType')
    class_methods.set_link(permit, idcode, 'idcode')
    class_methods.set_link(permit, subject, 'subjcreate')
    class_methods.set_link(permit, subject, 'subjact')
    class_methods.set_link(permit, subject, 'subjdeact')
    class_methods.set_link(permit, subject, 'subjblock')
    class_methods.set_link(permit, securlevel, 'actsecurlevel')
    class_methods.set_link(permit, schedule, 'schedule')
    class_methods.set_link(permit, organization, 'declarer_organization')
    class_methods.set_link(permit, department, 'declarer_department')

    class_methods.set_bribge(permit, commonright, 'permit_commonright')

    class_methods.set_bribge(permit, permit, 'permit_permit')

    class_methods.set_link(permittype, permittemplate, 'default_template')

    class_methods.set_bribge(permittype, permittemplate, 'permittype_permittemplate')

    class_methods.add_childr_equipments(subject, person)
    class_methods.set_link(person, post, 'postref')

    class_methods.set_link(respondresource, subject, 'subject')

    class_methods.set_link(root, permittype, 'defaultPermitType')
    class_methods.set_link(root, securlevel, 'securLevel')

    class_methods.set_bribge(root, tinterval, 'root_tinterval')

    class_methods.set_bribge(rschedule, tzone, 'rschedule_tzone')

    class_methods.set_bribge(schedule, rschedule, 'schedule_rschedule')

    class_methods.set_bribge(scheduletemplate, rschedule, 'scheduletemplate_rschedule')

    class_methods.set_link(subject, organization, 'organization')
    class_methods.set_link(subject, department, 'department')
    class_methods.set_link(subject, schedule, 'schedule')
    class_methods.set_bribge(subject, scheduletemplate, 'subject_scheduletemplate')

    class_methods.add_childr_equipments(subject, thing)

    class_methods.set_bribge(tzone, tinterval, 'tzone_tinterval')

    class_methods.set_link(wantedface, person, 'person')

    input("Press Enter to continue...")
    class_methods.delete_childr__equipments(person)
    class_methods.delete_childr__equipments(department)

    class_methods.delete_equipments(area)
    class_methods.delete_equipments(blacklist)
    class_methods.delete_equipments(blacklisttype)
    class_methods.delete_equipments(commonright)
    class_methods.delete_equipments(commonrightoo)
    class_methods.delete_equipments(commonrighttemplate)
    class_methods.delete_equipments(commonrighttype)
    class_methods.delete_equipments(customcatalog)
    class_methods.delete_equipments(customcatalogvalue)
    class_methods.delete_equipments(department)
    class_methods.delete_equipments(deviatinsfromschedules)
    class_methods.delete_equipments(idcode)
    class_methods.delete_equipments(mobile)
    class_methods.delete_equipments(organization)
    class_methods.delete_equipments(permit)
    class_methods.delete_equipments(permitprolongationreason)
    class_methods.delete_equipments(permittemplate)
    class_methods.delete_equipments(permittype)
    class_methods.delete_equipments(post)
    class_methods.delete_equipments(respondresource)
    class_methods.delete_equipments(root)
    class_methods.delete_equipments(rschedule)
    class_methods.delete_equipments(schedule)
    class_methods.delete_equipments(scheduletemplate)
    class_methods.delete_equipments(securlevel)
    class_methods.delete_equipments(thing)
    class_methods.delete_equipments(tinterval)
    class_methods.delete_equipments(tzone)
    class_methods.delete_equipments(wantedface)
    class_methods.delete_equipments(workingtypeclassifier)
    class_methods.delete_equipments(person)
    class_methods.delete_equipments(subject)


if __name__ == '__main__':
    main()
