list_equipment = [
    {
        'name': 'area',
        'attributes': {
            'description': 'area',
            'persons_count': 10,
            'geometry': 'geometry'
        }
    },

    {
        'name': 'blacklist',
        'attributes': {
            'timeopen': 5,
            'commentopen': 'commentopen',
            'block': 5,
            'timeclose': 545454545,
            'commentclose': 'commentclose',
            'state': 0
        }
    },

    {
        'name': 'blacklisttype',
        'attributes': {
            'description': 'blacklisttype',
            'level': 1
        }
    },

    {
        'name': 'commonright',
        'attributes': {
            'description': 'commonright',
            'icon': 'icon',
            'comment': 'comment',
            'keyword': 'keyword',
            'antipassbackFlag': None,
            'operatorFlag': None,
            'external_id': 'external_id',
            'subsystem_ids': 'subsystem_ids'
        }
    },

    {
        'name': 'commonrightoo',
        'attributes': {
            'description': 'commonrightoo'
        }
    },

    {
        'name': 'commonrighttemplate',
        'attributes': {
            'description': 'commonrighttemplate'
        }
    },

    {
        'name': 'commonrighttype',
        'attributes': {
            'description': 'commonrighttype'
        }
    },

    {
        'name': 'customcatalog',
        'attributes': {
            'description': 'customcatalog'
        }
    },

    {
        'name': 'customcatalogvalue',
        'attributes': {
            'description': 'customcatalogvalue'
        }
    },

    {
        'name': 'department',
        'attributes': {
            'description': 'department',
            'subsystem_ids': 'subsystem_ids',
            'external_id': 'external_id'
        }
    },

    {
        'name': 'deviatinsfromschedules',
        'attributes': {
            'begin_date': 54545454,
            'end_date': 454545455,
            'reason': 5,
            'note': 'NOTE',
            'doc_date': 10
        }
    },

    {
        'name': 'idcode',
        'attributes': {
            'name': '1',
            'description': 'idcode',
            'subsystem_ids': 'subsystem_ids'
        }
    },

    {
        'name': 'mobile',
        'attributes': {
            'description': 'mobile',
            'brand': 'марка',
            'color': 'Желтый',
            'trailer': 'прицеп',
            'trailernumber': '5545AD',
            'mode': 'Режим',
            'note': 'Заметка',
            'external_id': 5555
        }
    },

    {
        'name': 'organization',
        'attributes': {
            'description': 'organization',
            'note1': 'notel',
            'subsystem_ids': 'subsystem_ids',
            'external_id': 'external',
        }
    },

    {
        'name': 'root',
        'attributes': {
            'lastpin': 'Предыдущий код авторизации',
            'currentpin': ''
        }
    },

    {
        'name': 'permit',
        'attributes': {
            'state': 0,
            'beginDT': 0,
            'endDT': 0,
            'pin': 5000,
            'createdt': 0,
            'actdt': 0,
            'deactdt': 0,
            'blockdt': 0,
            'blockcomment': 'Блокировка',
            'requisition': 0,
            'requisitionnumber': 0,
            'requisitiondate': 0,
            'requisitionagreeing': 'кто-то',
            'requisitionsignatory': 'кто-то',
            'requisitionreceiving': 'кто-то',
            'equipment_import': 'оборудование',
            'equipment_export': 'Оборудование на вынос',
            'permitput': 0,
            'prolongationhistory': 'История продления пропуска',
            'note': 'Примечание',
            'note2': 'Примечание 2',
            'note3': 'Примечание 3',
            'note5': 'Примечание 5',
            'note4': 'Примечание 4',
            'note6': 'Примечание 6',
            'wheregoingto': 'К кому идет',
            'visitaim': 'Цель визита',
            'note_mobile': 'Дополнительные данные об автомобиле',
            'note_thing': 'Дополнительные данные о грузе',
            'subsystem_ids': 'Ключи в сторонних системах'
        }
    },

    {
        'name': 'permitprolongationreason',
        'attributes': {
            'description': 'permitprolongationreason'
        }
    },

    {
        'name': 'permittemplate',
        'attributes': {
            'description': 'permittemplate',
            'src': 'source',
            'template_type': 0
        }
    },

    {
        'name': 'permittype',
        'attributes': {
            'description': 'permittype',
            'needRequest': 2,
            'withoutIdcode': 3,
            'oneTime': 4,
            'infoFlag1': 5,
            'infoFlag2': 6,
            'infoFlag3':  7,
            'infoFlag4': 8,
            'infoFlag5': 9,
            'infoFlag6': 10,
            'form_template': 'Шаблон редактирования',
            'duration': 15,
        }
    },

    {
        'name': 'person',
        'attributes': {
            'description': 'person',
            'category': 0,
            'employeeNumber': 'Табельный номер',
            'employmentContract': 'Трудовой договор',
            'birthday_v2': '1970.10.10',
            'birthPlace': 'Место рождения',
            'citizenship': 'Гражданство',
            'document': 'Документ',
            'series': 'Серия',
            'docNumber': '0',
            'issuedBy': 'Кем выдан',
            'issuedWhen': 0,
            'placeOfResidence': 'Адрес регистрации',
            'placeOfActualResidence': 'Адрес проживания',
            'note': 'Примечание',
            'note2': 'Примечание 2',
            'note3': 'Примечание 3',
            'note4': 'Примечание 4',
            'note5': 'Примечание 5',
            'note6': 'Примечание 6',
            'phoneNumber': 'Рабочий (внутренний) телефон',
            'phone': 'Мобильный телефон',
            'phone2': 'Мобильный телефон (доп.)',
            'email': 'Адрес электронной почты',
            'external_id': 'Внешний ключ',
            'documentscan': 'Скан документа',
            'subsystem_ids': 'Ключи в сторонних системах',
        }
    },

    {
        'name': 'post',
        'attributes': {
            'description': 'post',
            'external_id': 'Внешний ключ',
            'subsystem_ids': 'Ключи в сторонних системах'
        }
    },

    {
        'name': 'respondresource',
        'attributes': {
            'description': 'respondresource',
        }
    },



    {
        'name': 'rschedule',
        'attributes': {
            'description': 'rschedule',
            'tzones_map': 'Временные зоны',
            'year': 2019
        }
    },

    {
        'name': 'schedule',
        'attributes': {
            'description': 'schedule',
            'external_id': 'Внешний идентификатор',
            'subsystem_ids': 'Ключи в сторонних системах'
        }
    },

    {
        'name': 'scheduletemplate',
        'attributes': {
            'description': 'sscheduletemplate',
        }
    },

    {
        'name': 'securlevel',
        'attributes': {
            'description': 'securlevel',
            'color': 'green'
        }
    },

    {
        'name': 'subject',
        'attributes': {
            'description': 'subject',
            'photo': 'Фотография',
            'photo2': 'Дополнительное фото 1',
            'photo3': 'Дополнительное фото 2',
            'photo4': 'Дополнительное фото 3',
            'photo5': 'Дополнительное фото 4',
            'photo6': 'Дополнительное фото 5',
            'round_photo': 'Круглое фото',
            'external_id': 'Внешний ключ',
            'subsystem_ids': 'Ключи в сторонних системах'
        }
    },

    {
        'name': 'thing',
        'attributes': {
            'description': 'thing',
            'packaging': 'Упаковка',
            'placecount': 'Количество мест',
            'somedate': '2019 10 11'
        }

    },

    {
        'name': 'tinterval',
        'attributes': {
            'description': 'tinterval',
            'startTime': 345353535,
            'endTime': 45454545
        }

    },

    {
        'name': 'tzone',
        'attributes': {
            'description': 'tzone',
            'short_title': '',
            'color': '',
            'deviatinflag': True

        }
    },

    {
        'name': 'wantedface',
        'attributes': {
            'description': 'wantedface',
            'photos': 'Фотографии (для неизвестных лиц)',
            'subsystem_ids': 'Ключи в сторонних системах',
        }
    },

    {
        'name': 'workingtypeclassifier',
        'attributes': {
            'description': 'workingtypeclassifier',
            'name': 'Краткое наименование',
            'letter_code': 'Буквенный код',
            'digital_code': 'Цифровой код',
            'work_flag': True
        }
    }
]
