# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_permitprolongationreason(protocol_obj_base, alias='Причина продления пропуска'):

    description = Attribute(alias='Название', fieldType=str, defval='', index=1)
