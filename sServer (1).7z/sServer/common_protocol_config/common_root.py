# -*- coding: utf-8 -*-

import time
from apscheduler.schedulers.background import BackgroundScheduler
from equipment.methods_for_equipment import *

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, action_decorator
from equipment import dev_except

from .common_permittype import common_permittype
from .common_securlevel import common_securlevel
from .common_person import common_person
from gsm_protocol_config.gsm_modem import gsm_modem


class common_root(protocol_obj_base, alias='Настройки'):

    OBSOBJTYPE = 'system'

    class TimeTrigger(object):
        __slots__ = ['obj', 'id']

        def __init__(self, obj, id):
            self.obj = obj
            self.id = id

        def start(self):
            self.obj.intervalStarted(self.id)

        def stop(self):
            self.obj.intervalStopped(self.id)

    def postCreate(self, ignore_create_objects=False):
        self.updateScheduler()

    def finit(self):
        if 'scheduler' in self:
            self['scheduler'].shutdown()

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        try:
            obj = cls._core.getFirst('root')
        except dev_except.ElementNotFound:
            pass
        else:
            if obj:
                raise dev_except.TerminateAction(cls._core.getString('preCreateRootError'))

    @action_decorator(alias='Деактивировать пропуск', permitId='Номер пропуска')
    def deactivatePermitByNum(self, permitId: int=0):
        permit = self._core.getElementById('permit', permitId)
        if permit:
            return permit.doAction('deactivate')
        else:
            return {
                'txt'	:	self._core.getString('root_credentialNotFound') % permitId,
                'timeout'	:	8000,
                'type'		:	'error'
            }

    @action_decorator(alias='Деактивировать разовый пропуск', permitId='Номер пропуска')
    def deactivateOneTimePermitByNum(self, permitId: int=0):
        try:
            permitId = int(permitId)
        except:
            raise dev_except.TerminateAction(self._core.getString('WrngNum'))
        permit = self._core.getElementById('permit', permitId)
        if permit:
            permitType = permit.getLinkedElement('permitType')

            if permitType and permitType.getAttribute('oneTime') == 1:
                return permit.doAction('deactivate')
            else:
                return {
                    'txt'	:	self._core.getString('CredentialNotOneTime') % permitId,
                    'timeout'	:	8000,
                    'type'		:	'error'
                }
        else:
            return {
                'txt'		:	self._core.getString('root_credentialNotFound' ) %permitId,
                'timeout'	:	8000,
                'type'		:	'error'
            }

    def __securLevelChanged(self, targetObj):
        if 'pce' in self._core['...']:
            pce = self._core['pce']
            for bus in pce.getElements('bus'):
                if bus.isLinkedElement('securLevelVar'):
                    securLevelVar = bus.getLinkedElement('securLevelVar')
                    securLevelVar.doAction('varAssignConst', {'value': targetObj.getAddr()})

        securLevel = self.getLinkedElement('securLevel')

        self.pushEvent({
            'notification': {
                'code': 700
            },
            'statement': {
                'adverbialTime': {
                    'param': time.time()
                },
                'directObj': {
                    'dev': {
                        'description': securLevel.getAttribute('description'),
                        'id': securLevel.getUniID(),
                        'equip': 'common',
                        'type': 'securlevel',
                    }
                }
            }
        })

    @action_decorator(alias='Отправить СМС', number='Номер телефона', message='Текст сообщения')
    def sendSMS(self, number: str='', message: str=''):
        modem = self.getRightFarElements('gsm', 'modem', 'gsmmodem')
        if modem and len(modem) > 0:
            return modem[0].doAction('sendSMS', {
                'number': number,
                'message': message
            })

    @action_decorator(alias='Установить уровень безопасности', level='Уровень безопасности')
    def setSecurLevel(self, level: int=1):
        level = int(level)  # TODO: так надо потому что по реакции из клиента посылается строка. Надо пнуть Кирилла
        currentSecurLevel = self.getLinkedElement('securLevel')
        if currentSecurLevel.getAddr() == level:
            # TODO: Если текущий уровень безопастности совпадает с устанавливаемым то ничего не будем делать. Это не
            #  позволит поменять уровень в остальных мастерах pce если их несколько (если это действие вызывается по
            #  реакции а сам увроень был поменян из клиента). Но я пока не понял как это сделать.
            #  Если тут раскомментировать то в клиенте будет несколько раз вылезать сообщение о смене уровня
            return
        newSecurLevel = self.getChildByAddr('securlevel', level)
        self.bindElement('securLevel', newSecurLevel)

    def intervalStarted(self, intervalid):
        self.__sendEvent(763, intervalid)

    def intervalStopped(self, intervalid):
        self.__sendEvent(764, intervalid)

    def __sendEvent(self, code, intervalid):
        self.pushEvent({
            'notification': {
                'code': code
            },
            'statement': {
                'adverbialTime': {
                    'param': time.time()
                },
                'directObj': {
                    'dev': {
                        'equip': 'common',
                        'type': 'tinterval',
                        'id': intervalid
                    }
                }
            }
        })

    def updateScheduler(self):
        if 'scheduler' in self:
            self['scheduler'].shutdown()
        self['scheduler'] = BackgroundScheduler()
        tintervals = self.getElementArray('root_tinterval')
        for tinterval in tintervals:
            startTime = tinterval.getAttribute('startTime')
            endTime = tinterval.getAttribute('endTime')
            uniid = tinterval.getUniID()
            startTimeH = startTime / 3600
            startTimeM = startTime / 60 % 60
            startTimeS = startTime % 3600 % 60
            endTimeH = endTime / 3600
            endTimeM = endTime / 60 % 60
            endTimeS = endTime % 3600 % 60
            cronTime = {
                'second': startTimeS,
                'minute': startTimeM,
                'hour': startTimeH,
                'day_of_week': '*',
                'week': '*',
                'day': '*',
                'month': '*',
                'year': '*'
            }
            self['scheduler'].add_job(common_root.TimeTrigger(self, uniid).start, 'cron', **cronTime)
            cronTime['minute'] = endTimeM
            cronTime['hour'] = endTimeH
            cronTime['second'] = endTimeS
            self['scheduler'].add_job(common_root.TimeTrigger(self, uniid).stop, 'cron', **cronTime)
        self['scheduler'].start()

    @action_decorator(alias='Добавить личность', person='Субъект', description='Описание', photo='Фотография', round_photo='Круглое фото')
    def create_face_by_person(self, person: common_person = None, description: str='', photo: str='', round_photo: str=''):
        if len(person.getBackLinkElements('wantedface', 'person')) > 0:
            self.edit_face_by_person(person, description, photo, round_photo)
        else:
            wantedface = self._core['common'].createElement('wantedface')
            wantedface.bindElement('person', person)
            wantedface.doAction('operation_wantedface_by_person', {'person_element': person, 'type_operation': 'create'})

    @action_decorator(alias='Добавить известную личность', description='Имя', photo='Фотография')
    def create_person_with_wantedface(self, description: str='', photo: str=''):
        person = self._core.createElement('person')
        if description != '':
            person.setAttribute('description', description)
        subject = person.getParent()
        if photo != '':
            set_photo_to_obj(subject, photo)
        self.create_face_by_person(person, description, photo)

    @action_decorator(alias='Добавить неизвестную личность', description='Имя', blacklist='В черном списке', photo='Фотография')
    def create_unknown_wantedface(self, description: str='', blacklist: bool=False, photo: str=''):
        wantedface = self._core.createElement('wantedface')
        wantedface.doAction('operation_wantedface', {
                                                        'description': description,
                                                        'blacklist': blacklist,
                                                        'photos': photo
                                                    })

    @action_decorator(alias='Изменение личности', person='Субъект', description='Описание', photo='Фотография', round_photo='Круглое фото')
    def edit_face_by_person(self, person: common_person = None, description: str='', photo: str='', round_photo: str=''):
        if description != '':
            person.setAttribute('description', description)
        subject = person.getParent()
        if photo != '':
            set_photo_to_obj(subject, photo)
        if round_photo != '':
            set_photo_to_obj(subject, photo, 'round_photo')
        if len(person.getBackLinkElements('wantedface', 'person')) > 0:
            person.getBackLinkElements('wantedface', 'person')[0].doAction('operation_wantedface_by_person',
                                                                           {'person_element': person,
                                                                            'type_operation': 'update'})
        else:
            self.create_face_by_person(person, description, photo, round_photo)

    @action_decorator(alias='Удаление личности', person='Субъект')
    def delete_face_by_person(self, person: common_person = None):
        if len(person.getBackLinkElements('wantedface', 'person')) > 0:
            person.getBackLinkElements('wantedface', 'person')[0].doAction('operation_wantedface_by_person',
                                                                           {'type_operation': 'delete'})

    @action_decorator(alias='Загрузить лица из стороних систем')
    def import_wantedface(self):
        if self.getAttribute('upload_face_to_intellect') is True:
            core_recognition = self._core['intellect']
            firserver_list = core_recognition.getElements('firserver')
            for firserver in firserver_list:
                if firserver.hasParent():
                    firserver.doAction('getCards')

        elif self.getAttribute('upload_face_to_vizir') is True:
            core_recognition = self._core['vizir']
            firserver_list = core_recognition.getElements('server')
            for firserver in firserver_list:
                firserver.doAction('getCards')

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    lastpin = Attribute(alias='Предыдущий код авторизации', fieldType=str, defval='', index=1)
    currentpin = Attribute(alias='Текущий код авторизации', fieldType=str, defval='', index=2)
    defaultPermitType = Link(alias='Тип пропуска по умолчанию', target=common_permittype, index=3)
    securLevel = Link(alias='Уровень безопасности', target=common_securlevel, index=4, postAction=__securLevelChanged)

    gsmmodem = Link(alias='GSM модем', target=gsm_modem, index=8)
    add_face_to_recognition_list_when_activate_permit = Attribute(
        alias='Добавить лицо в список распознавания при активации пропуска', fieldType=bool, defval=False, index=9,
        editorType='treeSelect(getBooleanType)')
    archive_face_when_deactivate_permit = Attribute(
        alias='Архивировать лицо в списке распознавания при деактивации пропуска', fieldType=bool, defval=False,
        index=10, editorType='treeSelect(getBooleanType)')
    add_face_to_recognition_list_when_add_to_blacklist = Attribute(
        alias='Добавить лицо в список распознавания при открытии нарушения',
        fieldType=bool, defval=False, index=11, editorType='treeSelect(getBooleanType)')
    create_person_from_third_face = Attribute(alias='Создавать персону при выгрузке лиц из стороних систем?',
                                              fieldType=bool, defval=False, index=12,
                                              editorType='treeSelect(getBooleanType)')
    upload_face_to_intellect = Attribute(alias='Загружать лица для распознавания в Интеллект', fieldType=bool,
                                         defval=False, index=13, editorType='treeSelect(getBooleanType)')
    upload_face_to_securos = Attribute(alias='Загружать лица для распознавания в SecurOs', fieldType=bool,
                                       defval=False, index=14, editorType='treeSelect(getBooleanType)')
    upload_face_to_vizir = Attribute(alias='Загружать лица для распознавания в Визирь', fieldType=bool, defval=False,
                                     index=15, editorType='treeSelect(getBooleanType)')
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
