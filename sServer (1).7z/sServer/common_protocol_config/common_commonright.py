# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, index_decorator
from equipment import dev_except
from equipment.methods_for_equipment import get_subsystem_ids

from .common_securlevel import common_securlevel
from .common_area import common_area
from .common_commonrighttype import common_commonrighttype
from pce_protocol_config.pce_rlist import pce_rlist
from apollo_protocol_config.apollo_accesslevel import apollo_accesslevel
from housekeeper_protocol_config.housekeeper_hkright import housekeeper_hkright
from orioniso_protocol_config.orioniso_levelaccess import orioniso_levelaccess
from tss_protocol_config.tss_marshrut import tss_marshrut
from uld_protocol_config.uld_uldright import uld_uldright
from rubej08_protocol_config.rubej08_alevel import rubej08_alevel
from rubej08_protocol_config.rubej08_zone import rubej08_zone
from rubej08_protocol_config.rubej08_timezone import rubej08_timezone
from bosch_protocol_config.bosch_authorization import bosch_authorization
from orionintgrsrv_protocol_config.orionintgrsrv_schedule import orionintgrsrv_schedule


class common_commonright(protocol_obj_base, alias='Право', archive=True):
    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')
            
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    @index_decorator('ccure_id')
    def ccure_id_calc(self):
        return get_subsystem_ids(self, 'ccure')

    def __setAntipassbackFlag(self, value, field):
        oldVal = self.attrflags
        if value:
            self.attrflags = oldVal | 0x01
        else:
            self.attrflags = oldVal & 0xFE
        self.attrUpdated('antipassbackFlag')

    def __setOperatorFlag(self, value, field):
        oldVal = self.attrflags
        if value:
            self.setAttribute('attrflags', oldVal | 0x02)
        else:
            self.setAttribute('attrflags', oldVal & 0xFD)
        self.attrUpdated('operatorFlag')

    def __boschAuthorizationConnected(self, targetObj=None):
        if targetObj is not None:
            targetObj.attrUpdated('common_right')

    def __checkKeywordLength(self, value, field):
        if len(value) > 8:
            raise dev_except.TerminateAction(self._core.getString('KeywordError'))

    def __getAntipassbackFlag(self, field):
        return self.attrflags & 0x01 == 0x01

    def __getOperatorFlag(self, field):
        return self.attrflags & 0x02 == 0x02

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    icon = Attribute(alias='Иконка', fieldType=str, defval='', index=2, editorType='fileiconico')
    comment = Attribute(alias='Комментарий', fieldType=str, defval='', index=3)
    keyword = Attribute(alias='Ключевое слово поиска', fieldType=str, defval='', index=4,
                        preAction=__checkKeywordLength)
    type = Link(alias='Тип права', target=common_commonrighttype, index=5)
    threshold1 = Link(alias='Допустимый уровень безопасности', target=common_securlevel, index=6)
    antipassbackFlag = Attribute(alias='Контроль повторного прохода', index=7, fget=__getAntipassbackFlag,
                                 fset=__setAntipassbackFlag, editorType='checkBox', storeInDb=False)
    operatorFlag = Attribute(alias='Оператор', index=8, fget=__getOperatorFlag, fset=__setOperatorFlag,
                             editorType='checkBox', storeInDb=False)
    attrflags = Attribute(alias='Флагосостояние', fieldType=int, defval=0, showInClient=False)
    mainarea = Link(alias='Основная зона доступа', target=common_area, index=9)

    rlist = Link(alias='Полномочия PCE', target=pce_rlist, index=11)
    accesslevel = Link(alias='Уровень доступа Apollo', target=apollo_accesslevel, index=12)
    hkright = Link(alias='Право доступа электронного сейфа ЭВС', target=housekeeper_hkright, index=13)
    levelaccess = Link(alias='Уровень доступа ИСО Орион', target=orioniso_levelaccess, index=15)
    marshrut = Link(alias='Маршрут TSS', target=tss_marshrut, index=16)
    uldright = Link(alias='Права доступа УЛУ', target=uld_uldright, index=17)
    alevel = Link(alias='Уровень доступа Рубеж-08', target=rubej08_alevel, index=18)
    rzone = Link(alias='Рубеж-08: Пользовательская зона', target=rubej08_zone, index=19)
    acc_bcp_tz = Link(alias='Рубеж-08: Временная зона доступа к БЦП', target=rubej08_timezone, index=20)
    rzone_tz = Link(alias='Рубеж-08: Временная зона для управления ТС в пользовательской зоне', target=rubej08_timezone,
                    index=21)
    boschauthorization = Link(alias='Авторизация BOSCH', target=bosch_authorization, index=22,
                              postAction=__boschAuthorizationConnected)
    schedule_srv = Link(alias='Уровень доступа Модуля интеграции Орион Про', target=orionintgrsrv_schedule, index=23)

    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=24)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=100, readOnly=True)
