# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link


class common_workingtypeclassifier(protocol_obj_base, alias='Классификатор рабочего времени'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    name = Attribute(alias='Краткое наименование', fieldType=str, defval='', index=2)
    letter_code = Attribute(alias='Буквенный код', fieldType=str, defval='', index=3)
    digital_code = Attribute(alias='Цифровой код', fieldType=str, defval='', index=4)
    work_flag = Attribute(alias='Рабочее время', fieldType=bool, defval=False, index=5)
