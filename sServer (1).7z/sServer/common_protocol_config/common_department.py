# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link, index_decorator,\
    action_decorator
import equipment.constants as constants
from equipment import dev_except
from equipment.methods_for_equipment import get_subsystem_ids

from .common_organization import common_organization
from .common_commonrighttemplate import common_commonrighttemplate
from .common_schedule import common_schedule


class common_department(protocol_obj_base, alias='Подразделение',
                        parent=ParentStruct('department', 'Дочерние подразделения', (1, constants.MAX_UINT32))):
    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('descriptionTSS')
    def descriptionIndexFunc(self):
        return self.description
        
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')
        
    @index_decorator('notArchived')
    def notArchived(self):
        if self.getAttribute('flags') & 1 == 1:
            return None
        else:
            return '%s' % self.getAttribute('flags')

    def __deleteChilds(self):
        for childDep in self.getChildListByType('department'):
            childDep.selfDelete()

    def __checkArchive(self):
        if self.flags & 1:
            raise dev_except.EquipmentException(self._core.getString('AlreadyArchived'))
        cur = self._core.sql("""
            select count(*) from common_permit where (state = 1 or state = 3) and declarer_department = %s
        """ % self.getUniID())
        count = cur.fetchone()[0]
        if count != 0:
            raise dev_except.TerminateAction('%s%s%s' % (
                self._core.getString('Archiving'), self.description,
                self._core.getString('ImpossibleThereAreActive')))
        cur = self._core.sql("""
            select count(*) from common_permit cp, common_subject cs
            where cs.uniid = cp.subject and cs.department = %s and (state = 1 or state = 3)
        """ % self.getUniID())
        count = cur.fetchone()[0]
        if count != 0:
            raise dev_except.TerminateAction('%s%s%s' % (
                self._core.getString('Archiving'), self.description,
                self._core.getString('ImpossibleThereAreActive1')))

    def preDelete(self, deleteAsLink=False):
        self.__deleteChilds()

    def __archivateChilds(self):
        result = {
            'canSelfDelete'	: True,
            'childMessages'	: ''
        }
        for childDep in self.getChildListByType('department'):
            try:
                childDep.doAction('delete')
            except dev_except.TerminateAction as e:
                result['childMessages'] += ' ' + str(e)
                result['canSelfDelete'] = False
            except dev_except.EquipmentException as e:
                pass
        return result

    @action_decorator(alias='Архивировать')
    def archivate(self):
        depResult = self.__archivateChilds()
        if not depResult['canSelfDelete']:
            raise dev_except.TerminateAction('%s%s%s%s' % (
            self._core.getString('Archiving'), self.description,
            self._core.getString('ImpossibleOfChild'), depResult['childMessages']))
        self.__checkArchive()
        self.flags = self.flags | 1
        self.attrUpdated('archived')
        raise dev_except.EquipmentException(self._core.getString('DepArchived'))

    @action_decorator(alias='Разархивировать')
    def unarchivate(self):
        try:
            self.getParent().doAction('unarchivate')
        except:
            pass
        try:
            self.getLinkedElement('organization').doAction('unarchivate')
        except:
            pass
        self.flags = 0
        self.attrUpdated('archived')

    def __updateArchive(self, value, field):
        if value == 0:
            self.unarchivate()
        else:
            self.archivate()

    @classmethod
    @action_decorator(alias='Удалить все из БД', actionClass='static')
    def eraseAll(cls):
        while True:
            dep = cls._core['common'].getFirst('department')
            if dep:
                dep.selfDelete()
            else:
                break

    def __getArchived(self, field):
        return self.flags & 1

    description = Attribute(alias='Название', fieldType=str, defval='', index=1)
    organization = Link(alias='Организация', target=common_organization, index=2)
    archived = Attribute(alias='Архивное', index=3, fget=__getArchived, fset=__updateArchive, editorType="checkBox",
                         storeInDb=False)
    commonrighttemplate = Link(alias='Шаблон прав', target=common_commonrighttemplate, index=4)
    schedule = Link(alias='График работы УРВ', target=common_schedule, index=5)

    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=6)
    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=7)
    flags = Attribute(alias='Состояние', fieldType=int, defval=0, showInClient=False)
