# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_commonrightoo import common_commonrightoo


class common_commonright_commonrightoo(protocol_obj_base, alias='',
                                       parent=ParentStruct(typeName='commonright', alias='Права на ОМ',
                                                           addr=(1, constants.MAX_UINT32))):
    commonrightoo = Link(alias='', target=common_commonrightoo)
