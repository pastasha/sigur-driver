# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_area import common_area


class common_commonright_area(protocol_obj_base, alias='',
                              parent=ParentStruct(typeName='commonright', alias='Дополнительные зоны',
                                                  addr=(1, constants.MAX_UINT8))):
    area = Link(alias='', target=common_area)
