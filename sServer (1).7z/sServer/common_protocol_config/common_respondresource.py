# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link
from .common_subject import common_subject
from navigation_protocol_config.navigation_device import navigation_device


class common_respondresource(protocol_obj_base, alias='Ресурс реагирования', archive=True):

    @classmethod
    def getTypeResource(cls):
        return {
            cls._core.getString('respondResourcePerson')	: 0,
            cls._core.getString('respondResourceGBR')	: 1
        }

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    type = Attribute(alias='Тип ресура', fieldType=int, defval=0, index=3, editorType='treeSelect(getTypeResource)')
    subject = Link(alias='Субъект', target=common_subject, index=3)
    navigationdevice = Link(alias='Навигационное устройство', target=navigation_device, index=4)
