# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link
from equipment.dev_except import TerminateAction

from .common_workingtypeclassifier import common_workingtypeclassifier


class common_tzone(protocol_obj_base, alias='Временная зона'):

    def __checkShortTileLength(self, field, value):
        if len(value) > 2:
            raise TerminateAction(self._core.getString('TimeZoneShortTitleLengthError'))

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    short_title = Attribute(alias='Краткое наименование', fieldType=str, defval='', index=2,
                            preAction=__checkShortTileLength)
    color = Attribute(alias='Цвет', fieldType=str, defval='', index=3)
    working_type_classifier = Link(alias='Классификатор раб. времени', target=common_workingtypeclassifier, index=4)
    deviatinflag = Attribute(alias='Зона из отклонения', fieldType=bool, defval=False, index=5, editorType='checkBox')
