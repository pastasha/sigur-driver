# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute
from equipment import dev_except


class common_blacklisttype(protocol_obj_base, alias='Тип нарушения КПР', archive=True):
    def preDelete(self, deleteAsLink=False):
        if len(self.getBackLinkElements('blacklist', 'breachtype')) != 0:
            raise dev_except.TerminateAction(self._core.getString('UnableToDeleteViolationType'))

    @classmethod
    def getKinds(cls):
        return {
            cls._core.getString('greyList'): 0,
            cls._core.getString('blackList'): 1
        }

    description = Attribute(alias='Название', fieldType=str, defval='', index=1)
    level = Attribute(alias='Уровень тревожности', fieldType=int, defval=0, index=2,
                      editorType='enum(Не тревожный, Низкий, Средний, Высокий, Критический)')
    kind = Attribute(alias='Вид списка', fieldType=int, defval=0, index=3, editorType='treeSelect(getKinds)')
