# -*- coding: utf-8 -*-

import threading

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, action_decorator, index_decorator
from equipment.methods_for_equipment import *

from .common_person import common_person

settings = __import__('settings')
photoDir = settings.photoPath


class AsyncOperations(threading.Thread):
    def __init__(self, wantedface_class):
        super(AsyncOperations, self).__init__()
        self.__wantedface_class = wantedface_class

    def run(self):
        self.run_command()

    def run_command(self):
        while len(self.__wantedface_class.command_list) > 0:
            method = self.__wantedface_class.command_list[0]
            method[0](method[1])
            del self.__wantedface_class.command_list[0]


class common_wantedface(protocol_obj_base, alias='Распознаваемые лица'):

    def __init__(self):
        super().__init__()
        self.comment = ''
        self.person_element = None
        self.subject = None
        self.photo = ''

        self.uuid = str(uuid.uuid1())
        self.command_list = []
        self.param_type = [
            ['upload_face_to_intellect', 'intellect'],
            ['upload_face_to_securos', 'securos'],
            ['upload_face_to_vizir', 'vizir'],
        ]

    @index_decorator('vizir_id')
    def vizir_id_calc(self):
        return get_subsystem_ids(self, 'vizir')

    @index_decorator('intellect_id')
    def intellect_id_calc(self):
        try:
            data = json.loads(self.subsystem_ids)['intellect']
            return data['id']
        except:
            return None

    @index_decorator('intellect_uniid')
    def intellect_uniid_calc(self):
        try:
            data = json.loads(self.subsystem_ids)['intellect']
            return data['uuid']
        except:
            return None

    @index_decorator('securos_id')
    def securos_id_calc(self):
        return get_subsystem_ids(self, 'securos')

    def __check_synch(self, oldValue, oldValues):
        for param in self.param_type:
            self.set_flag_synch(param[0], param[1])

    def set_flag_synch(self, type_flag, type_system):
        com_root = self._core.getElements('root')[0]
        if com_root.getAttribute(type_flag) is True and get_subsystem_ids(self, type_system):
            self.setAttribute('sync', True)
        elif com_root.getAttribute(type_flag) is True and not get_subsystem_ids(self, type_system):
            self.setAttribute('sync', False)

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    def start_operation_face(self, type_operation):
        com_root = self._core.getElements('root')[0]
        if com_root.getAttribute('upload_face_to_intellect') is True:
            self.operation_face_in_system_recognition('intellect', 'Сервер распознания лиц', 'firserver',
                                                      'create_face_in_intellect' if type_operation == 'create' else
                                                      'update_face_in_intellect')
        if com_root.getAttribute('upload_face_to_securos') is True:
            self.operation_face_in_system_recognition('securos', 'face', 'idobject',
                                                      'create_face_in_securos' if type_operation == 'create' else
                                                      'update_face_in_securos')
        if com_root.getAttribute('upload_face_to_vizir') is True:
            self.operation_face_in_system_recognition('vizir', '', 'server', 'create_face_in_vizir' if
                                                      type_operation == 'create' else 'update_face_in_vizir')
        asynch_oper = AsyncOperations(self)
        asynch_oper.start()

    def start_delete_wantedface(self):
        com_root = self._core.getElements('root')[0]
        if com_root.getAttribute('upload_face_to_intellect') is True:
            self.operation_face_in_system_recognition('intellect', 'Сервер распознания лиц', 'firserver',
                                                      'delete_face_in_intellect')
        if com_root.getAttribute('upload_face_to_securos') is True:
            self.operation_face_in_system_recognition('securos', 'face', 'idobject', 'delete_face_in_securos')
        if com_root.getAttribute('upload_face_to_vizir') is True:
            self.operation_face_in_system_recognition('vizir', '', 'server', 'delete_face_in_vizir')
        asynch_oper = AsyncOperations(self)
        asynch_oper.start()

    def operation_wantedface_by_person(self, person_element=None, type_operation='create'):
        if type_operation == 'delete':
            self.setAttribute('sync', False)
            self.start_delete_wantedface()
        else:
            self.person_element = person_element
            self.subject = self.person_element.getParent()
            self.photo = get_subj_photo(self.subject.getAttribute('photo'))
            self.setAttribute('photos', self.subject.getAttribute('photo'))
            black_list_list = self.subject.getBackLinkElements('blacklist', 'subject')
            if len(black_list_list) > 0:
                for blacklist in black_list_list:
                    if blacklist.isLinkedElement('breachtype'):
                        blacklis_type = blacklist.getLinkedElement('breachtype')
                        if blacklis_type.getAttribute('kind') == 1 and blacklist.getAttribute('state') == 1:
                            self.setAttribute('blacklist', True)
                        elif blacklis_type.getAttribute('kind') == 1 and blacklist.getAttribute('state') == 2:
                            self.setAttribute('blacklist', False)
                    self.comment = blacklist.getAttribute('commentopen')
            else:
                self.setAttribute('blacklist', False)
            self.start_operation_face(type_operation)

    @action_decorator(alias='Добавить/Изменить/Удалить неизвестную личность', description='Имя',
                      blacklist='В черном списке', photos='Фотография', type_operation='Тип операции(create/delete)')
    def operation_wantedface(self, description: str = '', blacklist: bool = False, photos: str = '',
                             type_operation: str = 'create'):
        if type_operation == 'delete':
            self.setAttribute('sync', False)
            self.start_delete_wantedface()
        else:
            self.setAttribute('blacklist', blacklist)
            self.setAttribute('description', description)
            if photos != '':
                set_photo_to_obj(self, photos, 'photos')
            self.photo = get_subj_photo(self.getAttribute('photos'))
            self.start_operation_face(type_operation)

    def operation_face_in_system_recognition(self, system_rec, description_rec, server_rec, type_operation):
        core_recognition = None
        if system_rec in self._core['...']:
            core_recognition = self._core[system_rec]
        method = getattr(self, type_operation)
        if core_recognition:
            firserver_slave = core_recognition.getElements(server_rec)
            for param_firserver in firserver_slave:
                if system_rec == 'vizir':
                    self.command_list.append((method, param_firserver))
                else:
                    if param_firserver.getAttribute('description') == description_rec:
                        if not param_firserver.hasParent() or \
                        (param_firserver.hasParent() and not param_firserver.hasParent().hasParent()):
                            pass
                        else:
                            if system_rec == 'intellect':
                                self.command_list.append((method, param_firserver))
                            elif system_rec == 'securos':
                                self.command_list.append((method, param_firserver))

    def get_fio_person(self):
        if self.person_element is not None:
            return self.person_element.getAttribute('description').split(' ')
        else:
            if self.getAttribute('description') == '':
                self.setAttribute('description', 'wantedface' + str(self.getUniID()))
                return ['wantedface' + str(self.getUniID())]
            else:
                return [self.getAttribute('description')]

    def delete_face_in_intellect(self, param_firserver):
        id_face = None
        if get_subsystem_ids(self, 'intellect'):
            id_face = get_subsystem_ids(self, 'intellect')['uuid']
        if id_face:
            params = {
                'server_id': param_firserver.getAttribute('id'),
                'objectType': "PERSON",
                'id': id_face,
            }
            param_firserver.doAction('working_with_faces', {'command_name': 'deleteFace',
                                                            'params': params})
            delete_subsystem_id(self, 'intellect')

    def update_face_in_intellect(self, param_firserver):
        id_face = get_subsystem_ids(self, 'intellect')
        if id_face:
            self.delete_face_in_intellect(param_firserver)
            self.create_face_in_intellect(param_firserver)
        else:
            self.create_face_in_intellect(param_firserver)

    def delete_face_in_securos(self, param_firserver):
        id_face = get_subsystem_ids(self, 'securos')
        if id_face:
            param = {
                'objID': param_firserver.getAttribute('id'),
                'id': id_face.upper()
            }
            param_firserver.doAction('working_with_faces', {'command_name': 'deleteFace', 'action': 'REMOVE_FACE',
                                                            'params': param})

    def update_face_in_securos(self, param_firserver):
        id_face = get_subsystem_ids(self, 'securos')
        if id_face:
            id_server = param_firserver.getAttribute('id')
            list_photo = {'list_photo': self.get_list_photo()}
            fio = self.get_fio_person()
            param = {
                'external_id': self.getUniID(),
                'last_name': fio[0],
                'first_name': fio[1] if len(fio) > 1 else '',
                'middle_name': fio[2] if len(fio) > 2 else '',
                'is_blacklisted': 1 if self.getAttribute('blacklist') is True else 0,
                'comment': self.comment,
                'image_paths': json.dumps(list_photo),
                'is_user_in_ESM': 1,
                'id': get_subsystem_ids(self, 'securos'),
                'objID': id_server
            }
            param_firserver.doAction('working_with_faces', {'command_name': 'editFace', 'action': 'UPDATE_FACE',
                                                            'params': param})
        else:
            self.create_face_in_securos(param_firserver)

    def create_face_in_vizir(self, param_firserver):
        param_firserver.doAction('createPersonAndVizirCard', {'wantedface': self._obj})

    def create_face_in_securos(self, param_firserver):
        id_server = param_firserver.getAttribute('id')
        list_photo = {'list_photo': self.get_list_photo()}
        fio = self.get_fio_person()
        param = {
            'external_id': self.getUniID(),
            'last_name':  fio[0],
            'first_name': fio[1] if len(fio) > 1 else '',
            'middle_name': fio[2] if len(fio) > 2 else '',
            'is_blacklisted': 1 if self.getAttribute('blacklist') is True else 0,
            'comment': self.comment,
            'image_paths': json.dumps(list_photo),
            'is_user_in_ESM': 1,
            'uuidid': self.uuid,
            'objID': id_server
        }
        param_firserver.doAction('working_with_faces', {'command_name': 'addFace', 'action': 'CREATE_FACE',
                                                        'params': param})

    def get_list_photo(self):
        list_photo = []
        if self.subject is not None:
            for n in range(7):
                if n > 0 and get_subj_photo(self.subject.getAttribute('photo%s' % n if n > 1 else 'photo')) != '':
                    list_photo.append(get_subj_photo(self.subject.getAttribute('photo%s' % n if n > 1 else 'photo')))
        else:
            list_photo.append(get_subj_photo(self.getAttribute('photos')))
        return list_photo

    def create_face_in_intellect(self, param_firserver):
        id_server = param_firserver.getAttribute('id')
        fio = self.get_fio_person()
        param = {
            'id':  self.uuid,
            'objectType': 'PERSON',
            'surname': u'%s' % fio[0] if len(fio) > 0 else 'wantedface' + str(self.getUniID()),
            'name': u'%s' % fio[1] if len(fio) > 1 else '',
            'patronymic': u'%s' % fio[2] if len(fio) > 2 else '',
            # 'blacklist': 0 if self.getAttribute('blacklist') is True else 1,
            'comment': self.comment,
            'image': self.photo,
            'department': self.subject.getLinkedElement('organization').getAttribute('description')
            if self.subject is not None and self.subject.isLinkedElement('organization') else '',
            'createPersonInIntellect': 1,
            'server_id': id_server
        }
        dict_id = {
            'uuid': self.uuid
        }
        save_subsystem_ids(self, dict_id, 'intellect')
        answer = param_firserver.doAction('working_with_faces', {'command_name': 'addFace', 'params': param})
        if answer is None:
            delete_subsystem_id(self, 'intellect')
        elif ('Status' in answer and answer['Status'] != 'SUCCESS') or 'Status' not in answer:
            delete_subsystem_id(self, 'intellect')

    def update_face_in_vizir(self, param_firserver):
        param_firserver.doAction('updatePersonAndVizirCard', {'wantedface': self._obj})

    def delete_face_in_vizir(self, param_firserver):
        param_firserver.doAction('deletePersonAndVizirCard', {'wantedface': self._obj})

    person = Link(alias='Человек', target=common_person, index=1)
    description = Attribute(alias='Имя (для неизвестных лиц)', fieldType=str, defval='', index=2)
    blacklist = Attribute(alias='Черный список (для неизвестных лиц)', fieldType=bool, defval=False, index=3,
                          editorType='treeSelect(getBooleanType)')
    photos = Attribute(alias='Фотографии (для неизвестных лиц)', fieldType=str, defval='', index=4)
    sync = Attribute(alias='Синхронизирован', fieldType=bool, defval=False, index=5,
                     editorType='treeSelect(getBooleanType)')

    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', postAction=__check_synch,
                              index=100)
