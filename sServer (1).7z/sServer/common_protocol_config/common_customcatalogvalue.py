# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
import equipment.constants as constants


class common_customcatalogvalue(protocol_obj_base, alias='Записи справочников',
                                parent=ParentStruct(typeName='customcatalog', alias='Записи',
                                                    addr=(1, constants.MAX_UINT8))):

    description = Attribute(alias='Значение', fieldType=str, defval='', index=1)
