# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
import equipment.constants as constants

from .common_scheduletemplate import common_scheduletemplate


class common_department_scheduletemplate(protocol_obj_base, alias='',
                                         parent=ParentStruct(typeName='department', alias='Расписания',
                                                             addr=(1, constants.MAX_UINT16))):

    scheduletemplate = Link(alias='', target=common_scheduletemplate)
    begin_date = Attribute(alias='Дата начала', fieldType=int, defval=0)
    end_date = Attribute(alias='Дата окончания', fieldType=int, defval=0)
