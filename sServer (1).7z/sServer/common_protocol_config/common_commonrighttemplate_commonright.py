# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_commonright import common_commonright


class common_commonrighttemplate_commonright(protocol_obj_base, alias='',
                                             parent=ParentStruct(typeName='commonrighttemplate', alias='Права',
                                                                 addr=(1, constants.MAX_UINT8))):
    commonright = Link(alias='', target=common_commonright)
