# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, index_decorator, action_decorator
from equipment import dev_except
from equipment.methods_for_equipment import get_subsystem_ids

from .common_organization import common_organization
from .common_department import common_department
from .common_schedule import common_schedule
from navigation_protocol_config.navigation_device import navigation_device
# TODO: раскомментировать после переписывания rtls
# from rtls_protocol_config.rtls_tag import rtls_tag


class common_subject(protocol_obj_base, alias='Субъект', archive=True):

    @index_decorator('rubezhglobal_id')
    def rubezhglobal_id_calc(self):
        return get_subsystem_ids(self, 'rubezhglobal')

    @index_decorator('rusguard_id')
    def rusguard_id_calc(self):
        return get_subsystem_ids(self, 'rusguard')

    @index_decorator('biostar_id')
    def biostar_id_calc(self):
        return get_subsystem_ids(self, 'biostar')
            
    @index_decorator('vizir_id')
    def vizir_id_calc(self):
        return get_subsystem_ids(self, 'vizir')
    
    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    @index_decorator('ccure_id')
    def ccure_id_calc(self):
        return get_subsystem_ids(self, 'ccure')

    def getDescription(self, field=''):
        try:
            return self.getChildByAddr(('person', 'mobile', 'thing'), 1).getAttribute('description')
        except:
            return '[#%s]' % self.getUniID()

    def preDelete(self, deleteAsLink=False):
        if len(self._core.getElementsByIndex('permit', 'owner', None, keyValue='%s#1' % self.getUniID())) != 0:
            raise dev_except.TerminateAction(self._core.getString('DeletionFailedActiveCred'))
        elif len(self._core.getElementsByIndex('permit', 'owner', None, keyValue='%s#2' % self.getUniID())) != 0:
            raise dev_except.TerminateAction(self._core.getString('DeletionFailedDeactivatedCred'))
        elif len(self._core.getElementsByIndex('permit', 'owner', None, keyValue='%s#3' % self.getUniID())) != 0:
            raise dev_except.TerminateAction(self._core.getString('DeletionFailedBlockCred'))
        elif len(self._core.getElementsByIndex('permit', 'activateSubject', None, keyValue=self.getUniID())) != 0:
            raise dev_except.TerminateAction(self._core.getString('DeletionFailedActivatedByCred'))
        elif len(self._core.getElementsByIndex('blacklist', 'openForSubject', None, keyValue=self.getUniID())) != 0:
            raise dev_except.TerminateAction(self._core.getString('DeletionFailedBlackList'))
        else:
            try:
                ch = self.getChildByAddr(('person', 'mobile', 'thing'), 1)
                ch['subjectDeleted'] = True
                ch.selfDelete()
            except:
                pass

    def getAnyCard(self):
        result = u'0'
        for permitId, permit in self._core.getElementsByIndex('permit', 'owner', None,
                                                              keyValue='%s#1' % self.getUniID()).items():
            try:
                result = permit.getLinkedElement('idcode').getAttribute('name')
                break
            except:
                pass
        return result

    def __getIsIntruder(self, field):
        cur = self._core.sql("""
            select count(*) from common_blacklist
            where subject = %s and state = 1 and (flags & 1) = 0
        """, (self.getUniID(),))
        result = cur.fetchone()
        if result:
            result = result[0]
        return result

    def __organizationChanged(self, targetObj):
        # Вызовем проверку по табельному номеру после смены организации потому, что табельный номер должен быть
        # уникален в пределах организации
        try:
            person = self.getChildByAddr('person', 1)
            try:
                person.doAction('checkEmployeeNumber', {'value': person.getAttribute('employeeNumber')})
            except dev_except.TerminateAction as e:
                person.setAttribute('employeeNumber', '')
                raise e
        except dev_except.ChildNotFound:
            pass

    @action_decorator(alias='Добавить субъект в Визирь', actionClass='hidden')
    def insertIntoVizir(self):
        vizir = self._core['vizir']
        flag = False
        for server in vizir.getElements('server'):
            for person in self.getChildListByType('person'):
                if self.photo == '':
                    break

                server.doAction('insertIntoVizir', {
                    'human_name': str(person.getUniID()),
                    'img_name': self.photo
                })
                person.setAttribute('invizir', 1)
                flag = True
        if not flag:
            return {
                'txt': 'Субект невозможно добавить в Визирь',
                'timeout': 30000,
                'type': 'info'
            }

    @action_decorator(alias='Добавить субъект в розыск', actionClass='hidden')
    def inSearch(self):
        flag = False
        for person in self.getChildListByType('person'):
            person.setAttribute('insearch', 1)
            flag = True
        if flag:
            return {
                'txt': self._core.getString('Subject_added_to_wanted_list'),
                'timeout': 30000,
                'type': 'info'
            }
        else:
            return {
                'txt': self._core.getString('Subject_not_added_to_wanted_list'),
                'timeout': 30000,
                'type': 'error'
            }

    @action_decorator(alias='Удалить субъект из розыска', actionClass='hidden')
    def deleteFromSearch(self):
        flag = False
        for person in self.getChildListByType('person'):
            person.setAttribute('insearch', 0)
            flag = True
        if flag:
            return {
                'txt': self._core.getString('SubjectDeletedFromWanted'),
                'timeout': 30000,
                'type': 'info'
            }
        else:
            return {
                'txt': self._core.getString('FailedToDeleteSubjectFromWanted'),
                'timeout': 30000,
                'type': 'error'
            }

    description = Attribute(alias='Описание', fget=getDescription, index=1, storeInDb=False)
    photo = Attribute(alias='Фотография', fieldType=str, defval='', index=2)
    photo2 = Attribute(alias='Дополнительное фото 1', fieldType=str, defval='', index=3)
    photo3 = Attribute(alias='Дополнительное фото 2', fieldType=str, defval='', index=4)
    photo4 = Attribute(alias='Дополнительное фото 3', fieldType=str, defval='', index=5)
    photo5 = Attribute(alias='Дополнительное фото 4', fieldType=str, defval='', index=6)
    photo6 = Attribute(alias='Дополнительное фото 5', fieldType=str, defval='', index=7)
    round_photo = Attribute(alias='Круглое фото', fieldType=str, defval='', index=8)
    organization = Link(alias='Организация', target=common_organization, index=9, postAction=__organizationChanged)
    department = Link(alias='Подразделение', target=common_department, index=10)
    schedule = Link(alias='Расписание УРВ', target=common_schedule, index=11)
    isIntruder = Attribute(alias='Нарушитель', fget=__getIsIntruder, index=12, storeInDb=False)
    navigationdevice = Link(alias='Навигационное устройство', target=navigation_device, index=13)
    # TODO: раскомментировать после переписывания rtls
    # rtlstag = Link(alias='РТЛС метка', target=rtls_tag, index=14)

    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=99)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах', fieldType=str, defval='{}', index=100)
