# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_tinterval(protocol_obj_base, alias='Временной интервал'):

    OBSOBJTYPE = 'dev'

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    startTime = Attribute(alias='Время начала', fieldType=int, defval=0, index=2, editorType='time')
    endTime = Attribute(alias='Время конца', fieldType=int, defval=1, index=3, editorType='time')
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
