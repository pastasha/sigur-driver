# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_scheduletemplate(protocol_obj_base, alias='Шаблон расписания'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
