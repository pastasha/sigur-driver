# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import dev_except


class common_mobile(protocol_obj_base, alias='Транспортные средства',
                    parent=ParentStruct('subject', 'Транспортное средство', (1, 1))):
    def postCreate(self, ignore_create_objects=False):
        if not ignore_create_objects:
            self._core.createElement('subject', siteId=self.siteId).addChild(self._obj)

    def preDelete(self, deleteAsLink=False):
        try:
            if 'subjectDeleted' not in self or not self['subjectDeleted']:
                self['subjectDeleted'] = False
                self.getParent().selfDelete()
        except dev_except.ParentNotFound:
            pass

    def postChangeParent(self, oldParent=None, info=None):
        self.__updateParentDescription(None, None)

    def __checkOwner(self, targetObj):
        if targetObj and targetObj.getTypeName() not in ('person', 'organization'):
            raise dev_except.TerminateAction(self._core.getString('orgAsOwner'))

    @classmethod
    def getTypeVehicle(cls):
        cur = cls._core.sql("select type, id from vehicle_types")
        vTypes = cur.fetchall()
        res = {}
        for t in vTypes:
            res[t[0]] = t[1]
        return res

    def __updateParentDescription(self, oldValue, oldValues):
        try:
            self.getParent().attrUpdated('description')
        except:
            pass

    description = Attribute(alias='Гос. номер', fieldType=str, defval='', index=1, postAction=__updateParentDescription)
    mobiletype = Attribute(alias='Вид ТС', fieldType=int, defval=0, index=2, editorType='treeSelect(getTypeVehicle)')
    brand = Attribute(alias='Марка, модель', fieldType=str, defval='', index=3)
    color = Attribute(alias='Цвет', fieldType=str, defval='', index=4)
    trailer = Attribute(alias='Прицеп', fieldType=str, defval='', index=5)
    trailernumber = Attribute(alias='Номер прицепа', fieldType=str, defval='', index=6)
    mode = Attribute(alias='Режим', fieldType=str, defval='', index=7)
    owner = Link(alias='Владелец', target=None, index=8, preAction=__checkOwner)
    note = Attribute(alias='Примечание', fieldType=str, defval='', index=9)
    external_id = Attribute(alias='Внешний ключ', fieldType=str, defval='', index=10)
