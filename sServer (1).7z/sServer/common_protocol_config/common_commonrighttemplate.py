# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_commonrighttemplate(protocol_obj_base, alias='Шаблон прав'):

    description = Attribute(alias='Название', fieldType=str, defval='', index=1)
