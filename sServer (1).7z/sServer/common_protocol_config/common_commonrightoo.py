# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class common_commonrightoo(protocol_obj_base, alias='Права на ОМ'):
    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        if createAttrs and 'obsobj' in createAttrs:
            value = createAttrs['obsobj']
            newValue = []
            if isinstance(value, list):  # Так может быть если мы просто скопировали объект
                for v in value:
                    newValue.append(v['id'])
            else:
                values = value.split(', ')
                for v in values:
                    try:
                        id = int(v)
                        newValue.append(id)
                    except:
                        # Если у нас не привелось к числу значит тут не id а remote_guid объекта
                        id = cls.__getObjIdByRemoteGuid(v)
                        if id != 0:
                            newValue.append(id)
            createAttrs['obsobj'] = ', '.join([str(v) for v in newValue])

    def __getObsObjAttr(self, field):
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        obsobj = common_commonrightoo.obsobj.defaultGet(self)
        ids = obsobj.split(', ')
        result = []
        for objId in ids:
            cur = self._core.sql('select remote_guid from observed_objects where id = %s' % objId)
            row = cur.fetchone()
            remote_guid = ''
            if row:
                remote_guid = row[0]
            result.append({
                'id' : objId,
                'remote_guid': remote_guid
            })
        return result

    def __setObsObjAttr(self, value, field):
        newValue = []
        values = value.split(', ')
        for v in values:
            try:
                newValue.append(int(v))
            except:
                # Если у нас не привелось к числу значит тут не id а remote_guid объекта
                objId = self.__getObjIdByRemoteGuid(v)
                if objId != 0:
                    newValue.append(objId)
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        common_commonrightoo.obsobj.defaultSet(self, ', '.join(map(str, newValue)))

    @classmethod
    def __getObjIdByRemoteGuid(cls, guid):
        cur = cls._core.sql("select id from observed_objects where remote_guid = '%s'" % guid)
        row = cur.fetchone()
        if row:
            id = row[0]
        else:
            id = 0
        return id

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    obsobj = Attribute(alias='Объекты мониторинга', fieldType=str, defval='-1', index=2, fget=__getObsObjAttr,
                       fset=__setObsObjAttr, editorType='obsObjMultiSelect()')
