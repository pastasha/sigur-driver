# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link, index_decorator
import equipment.constants as constants
from equipment import dev_except

from . import event_packet
from .common_commonright import common_commonright
from .common_subject import common_subject


class common_permit_commonright(protocol_obj_base, alias='', archive=True,
                                parent=ParentStruct(typeName='permit', alias='Права', addr=(1, constants.MAX_UINT8))):

    @index_decorator('cache')
    def cacheIndexBuilder(self):
        permit = self.getParent()
        if permit.getAttribute('state') == 2:
            return None
        else:
            return permit.getAttribute('state')

    @index_decorator('permit')
    def permitKey(self):
        permit = self.getParent()
        return 'permit#%d' % permit.getUniID()

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        # TODO: это вообще надо, и работает ли это?
        if cls._core.getFirst('root').isLinked('securLevel', 'securlevel'):
            threshold = 0
            try:
                threshold = targetObj.getLinkedElement('threshold1').getAddr()
            except dev_except.EquipmentException:
                pass
            try:
                level = cls._core.getFirst('root').getLinkedElement('securLevel').getAddr()
            except dev_except.EquipmentException:
                raise dev_except.TerminateAction(cls._core.getString('AlarmLvlNotDef'))
            if threshold <= level:
                # TODO: raise TerminateAction
                if 'dlg' not in info:
                    raise dev_except.NeedAnswers(
                        event_packet.threshold1Request(
                            mainObj.getUniID(), targetObj.getUniID(),
                            targetObj.getAttribute('description')
                        )
                    )

    def postCreate(self, ignore_create_objects=False):
        op = self.getCurrOperatorSubject()
        if op:
            self.assigned_subject = op

    commonright = Link(alias='', target=common_commonright)
    assigned_subject = Link(alias='Назначил', target=common_subject, index=1)
    valid_from = Attribute(alias='Действует с', fieldType=int, defval=0, index=2, editorType='datetime')
    valid_to = Attribute(alias='Действует до', fieldType=int, defval=0, index=3, editorType='datetime')
    resolution = Attribute(alias='Резолюция', fieldType=str, defval='', index=4)
