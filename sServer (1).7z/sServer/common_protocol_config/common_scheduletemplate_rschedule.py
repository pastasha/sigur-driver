# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
import equipment.constants as constants

from .common_rschedule import common_rschedule


class common_scheduletemplate_rschedule(protocol_obj_base, alias='',
                                        parent=ParentStruct(typeName='scheduletemplate', alias='Регулярные расписания',
                                                            addr=(1, constants.MAX_UINT16))):

    rschedule = Link(alias='', target=common_rschedule, index=1)
