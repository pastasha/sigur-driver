# -*- coding: utf-8 -*-
import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, action_decorator, index_decorator
from equipment.methods_for_equipment import get_subsystem_ids

from tss_protocol_config.tss_timezone import tss_timezone


class common_schedule(protocol_obj_base, alias='Расписание'):

    @classmethod
    @action_decorator(alias='Удалить все из БД', actionClass='static')
    def eraseAll(cls):
        while True:
            sch = cls._core['common'].getFirst('schedule')
            if sch:
                sch.selfDelete()
            else:
                break

    @index_decorator('apacsbio_id')
    def apacsbio_id_calc(self):
        return get_subsystem_ids(self, 'apacsbio')

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    timezone = Link(alias='Временная зона TSS', target=tss_timezone, index=2)

    external_id = Attribute(alias='Внешний идентификатор', fieldType=str, defval='', index=3)
    subsystem_ids = Attribute(alias='Ключи в сторонних системах',  fieldType=str, defval='{}', index=4)
