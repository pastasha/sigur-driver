# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link

from .common_subject import common_subject
from .common_tzone import common_tzone


class common_deviatinsfromschedules(protocol_obj_base, alias='Отклонения от рабочего расписания'):

    begin_date = Attribute(alias='Дата начала', fieldType=int, defval=0, index=1)
    end_date = Attribute(alias='Дата окончания', fieldType=int, defval=0, index=2)
    reason = Attribute(alias='Номер заявки', fieldType=int, defval=0, index=3)
    note = Attribute(alias='Примечание', fieldType=str, defval='', index=4)
    doc_date = Attribute(alias='Дата создания', fieldType=int, defval=0, index=5)
    subject = Link(alias='Субъект', target=common_subject, index=6)
    tzone = Link(alias='Временная зона', target=common_tzone, index=7)
    author = Link(alias='Создатель', target=common_subject, index=8)
