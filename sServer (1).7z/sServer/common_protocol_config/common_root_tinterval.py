# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
import equipment.constants as constants

from .common_tinterval import common_tinterval


class common_root_tinterval(protocol_obj_base, alias='',
                            parent=ParentStruct(typeName='root', alias='Отслеживаемые временные интервалы',
                                                addr=(1, constants.MAX_UINT16))):
    def postChangeParent(self, oldParent=None, info=None):
        if oldParent:
            oldParent.doAction('updateScheduler')
        if self.isLinkedElement('tinterval'):
            if self.hasParent():
                self.getParent().doAction('updateScheduler')

    def __updateRootIntervals(self, targetObj):
        if self.isLinkedElement('tinterval') and self.hasParent():
            self.getParent().doAction('updateScheduler')

    tinterval = Link(alias='', target=common_tinterval, postAction=__updateRootIntervals)
