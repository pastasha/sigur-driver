
from datetime import date
from equipment.dev_obj_model_element import BaseElement
import json


class CustomJsonEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, date):
            return tuple(o.timetuple())
        if isinstance(o, BaseElement):
            return [o.equipment.getName(), o.typeName, o.getUniID(), o.getRemoteGUID()]

        return json.JSONEncoder.default(self, o)
