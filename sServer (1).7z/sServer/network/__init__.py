__author__ = "cherkasov"
__date__ = "$10.08.2011 11:35:38$"
