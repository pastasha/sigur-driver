# -*- coding: utf-8 -*-

import threading
import zmq
import json
import time
from collections import deque

from servicebase import ServiceBase

from esmapi.serializer import Serializer
from esmapi.commands.baseCommandReply import Reply as BaseReply

from customjsonencoder import CustomJsonEncoder


class Request:
    def __init__(self, cmdName, idClient, requestKey, isServer, request):
        self.cmdName = cmdName
        self.idClient = idClient
        self.requestKey = requestKey
        self.isServer = isServer
        self.request = request


class Reply:
    def __init__(self, cmdName, idClient, replyKey, isServer, reply):
        self.cmdName = cmdName
        self.idClient = idClient
        self.replyKey = replyKey
        self.isServer = isServer
        self.reply = reply


class ProcessingSender(ServiceBase):
    def __init__(self, requestServer, requestQueue, requestQueueLock, sendPeriod):
        super(ProcessingSender, self).__init__()
        self.__thread = threading.Thread(target=self.__process)
        self.__thread.setName("ProcessingSender")
        self.__requestServer = requestServer
        self.__requestQueue = requestQueue
        self.__requestQueueLock = requestQueueLock
        self.__sendPeriod = sendPeriod

    def __process(self):
        while self.isRunning():
            with self.__requestQueueLock:
                copyQueue = [x for x in self.__requestQueue]
            for request in copyQueue:
                reply = BaseReply(status='ok', msg=BaseReply.Msg('sServerProcessing'))
                # TODO: наверное туда можно передавать весь request а не по отдельности
                self.__requestServer.sendReply(request.idClient, request.requestKey, request.isServer, request.cmdName,
                                               Serializer.serialize(reply))
            time.sleep(self.__sendPeriod)

    def onStart(self):
        self._setRunning(True)
        self.__thread.start()

    def onStop(self):
        self._setRunning(False)
        self.__thread.join()


class RequestProcessor(ServiceBase):
    def __init__(self, cmdManager, requestQueue, requestQueueLock, replyQueue, replyQueueLock):
        super(RequestProcessor, self).__init__()
        self.__thread = threading.Thread(target=self.__process)
        self.__thread.setName("RequestProcessor")
        self.__cmdManager = cmdManager
        self.__requestQueue = requestQueue
        self.__requestQueueLock = requestQueueLock
        self.__replyQueue = replyQueue
        self.__replyQueueLock = replyQueueLock

    def __process(self):
        while self.isRunning():
            requestObj = None
            with self.__requestQueueLock:
                if len(self.__requestQueue) > 0:
                    requestObj = self.__requestQueue[0]

            if requestObj is not None:
                reply = self.__cmdManager.runCommand(requestObj.request)
                # Послыаем ответ
                with self.__replyQueueLock:
                    self.__replyQueue.append(
                        Reply(
                            requestObj.cmdName,
                            requestObj.idClient,
                            requestObj.requestKey,
                            requestObj.isServer,
                            reply
                        )
                    )

                with self.__requestQueueLock:
                    self.__requestQueue.popleft()

            time.sleep(0.01)

    def onStart(self):
        self._setRunning(True)
        self.__thread.start()

    def onStop(self):
        self._setRunning(False)
        self.__thread.join()


class RequestServer(ServiceBase):
    def __init__(self, conStr, serverName, cmdManager):
        super(RequestServer, self).__init__()
        self.__thread = threading.Thread(target=self.__process)
        self.__thread.setName("RequestServer")

        # Создание zmq контекста
        context = zmq.Context()
        # Создание сокета типа DEALER
        # Сокет данного типа может асинхронно отправлять и принимать сообщения,
        # но не может отправлять сообщения по имени
        # и определять имя того, от кого пришло сообщение
        self.__socket = context.socket(zmq.XREQ)
        # Задание имени сервера в качестве имени, на которое слать сообщения
        # Если задана опция zmq.IDENTITY, то кроме того, что сокет теперь имеет
        # сетевое имя (которое должно быть уникальным), мы имеем гарантию, что
        # отправляющий сокет будет буферизировать сообщения, если соединение оборвется
        self.__socket.setsockopt_string(zmq.IDENTITY, serverName)
        # Подключаемся к backend брокера
        self.__socket.connect(conStr)
        # Задание объекта для обработки сообщений сразу от нескольких подключений
        # Несмотря на то, что тут только одно подключение, асинхронное получение сообщений
        # для сокета типа DEALER должно происходить посредством использования poll
        self.__poll = zmq.Poller()
        # Регистрация сокета в объекте poll
        self.__poll.register(self.__socket, zmq.POLLIN)

        self.__requestQueue = deque()
        self.__requestQueueLock = threading.Lock()

        self.__replyQueue = deque()
        self.__replyQueueLock = threading.Lock()

        self.__requestProcessor = RequestProcessor(cmdManager, self.__requestQueue, self.__requestQueueLock,
                                                   self.__replyQueue, self.__replyQueueLock)
        self.__processingSender = ProcessingSender(self, self.__requestQueue, self.__requestQueueLock, 0.2)

    def sendReply(self, idClient, replyKey, isServer, cmdName, reply):
        # Брокер ожидает ответ, состоящий из нескольких частей. Посылаем такой ответ.
        self.__socket.send_string(json.dumps({
            "cmdName": cmdName,
            "idClient": idClient,
            "replyKey": replyKey,
            "isServer": isServer,
            "reply": reply
        }, cls=CustomJsonEncoder))

    def __process(self):
        while self.isRunning():
            # Получаем ассоциативный массив флагов для сокетов, в которых есть сообщения,
            # либо еще что-то, я не знаю что
            # Если значением массива для данного сокета является zmq.POLLIN,
            # значит в сокет пришло сообщение
            # Если значение zmq.POLLOUT, то это тоже что-то значит, но нам не нужно=)
            sockets = dict(self.__poll.poll(1))
            # Смотрим, случилось ли что-то новое с нашим сокетом
            if self.__socket in sockets:
                # Смотрим, пришло ли новое сообщение
                if sockets[self.__socket] == zmq.POLLIN:
                    message = json.loads(self.__socket.recv())
                    cmdName = message["cmdName"]
                    idClient = message["idClient"]
                    requestKey = message["requestKey"]
                    isServer = message["isServer"]
                    request = message["request"]

                    with self.__requestQueueLock:
                        self.__requestQueue.append(
                            Request(
                                cmdName,
                                idClient,
                                requestKey,
                                isServer,
                                request)
                        )

            reply = None
            with self.__replyQueueLock:
                if len(self.__replyQueue) > 0:
                    reply = self.__replyQueue[0]
                    self.__replyQueue.popleft()

            if reply is not None:
                self.sendReply(reply.idClient, reply.replyKey, reply.isServer, reply.cmdName, reply.reply)

    def onStart(self):
        self._setRunning(True)
        self.__requestProcessor.start()
        self.__processingSender.start()
        self.__thread.start()

    def onStop(self):
        self.__processingSender.stop()
        self.__requestProcessor.stop()

        self._setRunning(False)
        self.__thread.join()
