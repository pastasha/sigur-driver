# -*- coding: utf-8 -*-

import zmq
import json
import collections
import logging
import threading
import time

from interface_n_tools.speedmeter import SpeedMeter
from servicebase import ServiceBase
from esmapi.serializer import Serializer
from customjsonencoder import CustomJsonEncoder


class NotifyPusher(ServiceBase):
    def __init__(self, addr):
        super(NotifyPusher, self).__init__()
        print('\nZMQ ver %s\n' % zmq.zmq_version())
        self.__context = zmq.Context()
        self.__socket = self.__context.socket(zmq.PUSH)
        self.__socket.connect("tcp://%s" % addr)
        self._sm = SpeedMeter('NotifyPusher')

        self.__notifQueue = collections.deque()
        self.__stop_event = threading.Event()

        self.__thread = threading.Thread(target=self.__process)
        self.__thread.setName('NotifyPusher')

    def push(self, notification):
        # TODO: пока это заглушка, но я не помню зачем
        if not isinstance(notification, dict):
            notification = Serializer.serialize(notification)
        self.__notifQueue.append(json.dumps(notification, cls=CustomJsonEncoder))

    def __process(self):
        while self.isRunning():
            try:
                notif = self.__notifQueue.popleft()
                self.__socket.send_string(notif)
                self._sm.update()
            except IndexError:
                time.sleep(0.0001)
            except Exception as e:
                logging.getLogger('sServer').exception('Error send notif')

    def onStart(self):
        self._setRunning(True)
        self.__thread.start()

    def onStop(self):
        self._setRunning(False)
        self.__thread.join()
