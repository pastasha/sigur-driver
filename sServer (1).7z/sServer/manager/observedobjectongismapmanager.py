# -*- coding: utf-8 -*-

import uuid

from esmapi.objects.observedobjectonmap import ObservedObjectOnGisMap, Map
from esmapi.notifications.sServerNotifications import ObservedObjectOnGisMapCreatedNotification,\
    ObservedObjectOnGisMapEditedNotification, ObservedObjectOnGisMapDeletedNotification


class ObservedObjectOnGisMapManager(object):
    """
    Класс для работы с объектами на картах
    """
    def __init__(self, observedObjectOnGisMapRepository, observedObjectGetter, mapGetter, notifyPusher):
        """
        Создает объект класса
        :param observedObjectOnGisMapRepository: Репозиторий объектов
        :param observedObjectGetter: Объект из которого можно получать объекты мониторинга
        :type observedObjectGetter: basicrepository.IGetObject
        :param mapGetter: Объект из которого можно получать объекты карт
        :type mapGetter: basicrepository.IGetObject
        :param notifyPusher: объект для посылки нотификаций
        """
        self.__observedObjectOnGisMapRepository = observedObjectOnGisMapRepository
        self.__observedObjectGetter = observedObjectGetter
        self.__mapGetter = mapGetter
        self.__notifyPusher = notifyPusher

    def getObjects(self):
        """
        Возвращает список сериализованных объектов на всех картах
        :return: list[ObservedObjectOnGisMap]
        """
        return self.__observedObjectOnGisMapRepository.getObjects()

    def getObjectsOnMap(self, cmd):
        """
        Возвращает список сериализованных объектов на конкретной карте
        :return: list[ObservedObjectOnGisMap]
        """
        mapId = cmd.reqData.mapId
        objects = self.__observedObjectOnGisMapRepository.getObjects()
        return [object for object in objects if object.map.id == mapId]

    def addObjectToMap(self, cmd):
        """
        Добавить объект на карту
        :param cmd: Класс команды добавления объекта на карту
        :type cmd: AddObjectToGisMapCommand
        :return: ObservedObjectOnGisMap
        """
        objectData = cmd.reqData
        remote_guid = objectData.remoteGuid

        if remote_guid:
            if self.__observedObjectOnGisMapRepository.getByRemoteGuid(remote_guid):
                return self.__editObjectOnMap(objectData)

        return self.__addObjectToMap(objectData)

    def __addObjectToMap(self, objectData):
        mapData = objectData.map
        mapId = mapData.id
        mapGuid = mapData.remoteGuid
        obsObjData = objectData.obsObj
        obsObjId = obsObjData.id
        obsObjGuid = obsObjData.remoteGuid
        remoteGuid = objectData.remoteGuid

        if obsObjGuid:
            obsObj = self.__observedObjectGetter.getByRemoteGuid(obsObjGuid)
        else:
            obsObj = self.__observedObjectGetter.get(obsObjId)
        if mapGuid:
            map = self.__mapGetter.getByRemoteGuid(mapGuid)
        else:
            map = self.__mapGetter.get(mapId)

        if remoteGuid == '':
            siteId = '.'.join(map.remoteGuid.split('.')[1:])
            remoteGuid = str(uuid.uuid4())
            if siteId:
                remoteGuid = '%s.%s' % (remoteGuid, siteId)

        obj = ObservedObjectOnGisMap(id=None, map=map, obsObj=obsObj, iconType=objectData.iconType,
                                     iconId=objectData.iconId, latitude=objectData.latitude,
                                     longitude=objectData.longitude, geojson=objectData.geojson, angle=objectData.angle,
                                     remoteGuid=remoteGuid)

        self.__observedObjectOnGisMapRepository.save(obj)
        self.__notifyPusher.push([ObservedObjectOnGisMapCreatedNotification(obj)])

        return obj

    def editObjectOnMap(self, cmd):
        """
        Изменить объект на карте
        :param cmd: Класс команды изменения объета на карте
        :type cmd: EditObjectOnGisMapCommand
        :return: ObservedObjectOnGisMap | None
        """
        reqData = cmd.reqData
        return self.__editObjectOnMap(reqData)

    def __editObjectOnMap(self, objectData):
        objId = objectData.id
        mapData = objectData.map
        mapId = mapData.id
        mapGuid = mapData.remoteGuid
        obsObjData = objectData.obsObj
        obsObjId = obsObjData.id
        obsObjGuid = obsObjData.remoteGuid
        remote_guid = objectData.remoteGuid

        if remote_guid:
            obj = self.__observedObjectOnGisMapRepository.getByRemoteGuid(remote_guid)
        else:
            obj = self.__observedObjectOnGisMapRepository.get(objId)
        if obj is None:
            return None

        if obsObjGuid:
            obsObj = self.__observedObjectGetter.getByRemoteGuid(obsObjGuid)
        else:
            obsObj = self.__observedObjectGetter.get(obsObjId)
        if mapGuid:
            map = self.__mapGetter.getByRemoteGuid(mapGuid)
        else:
            map = self.__mapGetter.get(mapId)

        obj.map = map
        obj.obsObj = obsObj
        obj.latitude = objectData.latitude
        obj.longitude = objectData.longitude
        obj.iconType = objectData.iconType
        obj.iconId = objectData.iconId
        obj.angle = objectData.angle
        obj.geojson = objectData.geojson

        self.__observedObjectOnGisMapRepository.save(obj)
        self.__notifyPusher.push([ObservedObjectOnGisMapEditedNotification(obj)])

        return obj

    def deleteObjectFromMap(self, cmd):
        """
        Удалить объект с карты
        :param cmd: Класс команды удаления объекта с карты
        :type cmd: DeleteObjectFromGisMapCommand
        :return: bool
        """
        reqData = cmd.reqData
        objId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            obj = self.__observedObjectOnGisMapRepository.getByRemoteGuid(remote_guid)
        else:
            obj = self.__observedObjectOnGisMapRepository.get(objId)
        if obj is None:
            return False

        self.__observedObjectOnGisMapRepository.delete(obj.id)
        self.__notifyPusher.push([ObservedObjectOnGisMapDeletedNotification(obj)])

        return True

    def saveObjectsOnMap(self, cmd):
        """
        Установить на карте все объекты из команды
        :param cmd: Класс команды сохранения объектов на карте
        :type cmd: SaveObjectsOnGisMapCommand
        :return: None
        """
        reqData = cmd.reqData
        mapId = reqData.mapId
        newObjects = reqData.objects

        oldObjects = self.__observedObjectOnGisMapRepository.getByMapId(mapId)
        ids = [obj.id for obj in oldObjects]
        newIds = [obj.id for obj in newObjects if obj.id > 0]
        objectsForDelete = [id for id in ids if id not in newIds]
        for rec_id in objectsForDelete:
            delObj = self.__observedObjectOnGisMapRepository.get(rec_id)
            self.__observedObjectOnGisMapRepository.delete(rec_id)
            self.__notifyPusher.push([ObservedObjectOnGisMapDeletedNotification(delObj)])
        for obj in newObjects:
            rec_id = obj.id
            if rec_id < 0:  # Для новых объектов клиент посылает id < 0
                obj.map = Map(id=mapId)
                self.__addObjectToMap(obj)
            else:
                objOnMap = self.__observedObjectOnGisMapRepository.get(rec_id)
                objOnMap.latitude = obj.latitude
                objOnMap.longitude = obj.longitude
                objOnMap.angle = obj.angle
                objOnMap.geojson = obj.geojson
                objOnMap.iconType = obj.iconType
                objOnMap.iconId = obj.iconId
                self.__observedObjectOnGisMapRepository.save(objOnMap)
                self.__notifyPusher.push([ObservedObjectOnGisMapEditedNotification(objOnMap)])

    def deleteObjectFromAllMaps(self, obsObj):
        """
        Удалять объект мониторинга со всех карт на которых он есть
        :param obsObj: Объект мониторинга
        """
        objectId = obsObj.id
        remote_guid = obsObj.remoteGuid
        if remote_guid:
            obj = self.__observedObjectGetter.getByRemoteGuid(remote_guid)
        else:
            obj = self.__observedObjectGetter.get(objectId)
        if obj is None:
            return
        allObjects = list(self.__observedObjectOnGisMapRepository.getObjects())
        for objOnMap in allObjects:
            if objOnMap.obsObj.id == obj.id:
                self.__observedObjectOnGisMapRepository.delete(objOnMap.id)
                self.__notifyPusher.push([ObservedObjectOnGisMapEditedNotification(objOnMap)])
