# -*- coding: utf-8 -*-

import uuid

from esmapi.objects.obsobjtype import ObsObjType, ObsObjTypeEventBrg
from esmapi.notifications.sServerNotifications import ObsObjTypeCreatedNotification, ObsObjTypeEditedNotification,\
    ObsObjTypeDeletedNotification


class ObservedObjectTypeManager(object):
    """
    Класс для работы с типами объектов мониторинга
    """
    def __init__(self, obsObjTypeRepository, eventsGetter, notifyPusher):
        """
        Создает объект класса
        :param obsObjTypeRepository: Репозиторий типов
        :param eventsGetter: Объект из которого можно получать типы событий
        :type eventsGetter: basicrepository.IGetObject
        :param notifyPusher: объект для посылки нотификаций
        """
        self.__obsObjTypeRepository = obsObjTypeRepository
        self.__eventsGetter = eventsGetter
        self.__notifyPusher = notifyPusher

    def getTypes(self):
        """
        Возвращает список сериализованных типов объектов мониторинга
        :return: list[ObsObjType]
        """
        return self.__obsObjTypeRepository.getObjects()

    def addType(self, cmd):
        """
        Добавить тип объекта мониторинга
        :param cmd: Класс команды создания типа объекта мониторинга
        :type cmd: AddObservedObjectTypeCommand
        :return: ObsObjType
        """
        reqData = cmd.reqData
        obsObjTypeData = reqData.obsObjType
        remote_guid = obsObjTypeData.remoteGuid
        events = obsObjTypeData.events
        siteId = reqData.siteId

        if remote_guid:
            if self.__obsObjTypeRepository.getByRemoteGuid(remote_guid):
                return self.__editType(obsObjTypeData)

        if remote_guid == '':
            remote_guid = str(uuid.uuid4())
            if siteId != '':
                remote_guid = '%s.%s' % (remote_guid, siteId)

        eventsObj = []
        for evt in events:
            if evt.event.remoteGuid:
                oldEvent = self.__eventsGetter.getByRemoteGuid(evt.event.remoteGuid)
            else:
                oldEvent = self.__eventsGetter.get(evt.event.id)
            if evt.newEvent.remoteGuid:
                newEvent = self.__eventsGetter.getByRemoteGuid(evt.newEvent.remoteGuid)
            else:
                newEvent = self.__eventsGetter.get(evt.newEvent.id)
            eventsObj.append(ObsObjTypeEventBrg(event=oldEvent, newEvent=newEvent))

        objType = ObsObjType(id=None, name=obsObjTypeData.name, elements=obsObjTypeData.elements,
                             actions=obsObjTypeData.actions, kind=obsObjTypeData.kind,
                             stateCalculation=obsObjTypeData.stateCalculation,
                             falseAlertLimit=obsObjTypeData.falseAlertLimit,
                             falseAlertControlTime=obsObjTypeData.falseAlertControlTime,
                             controlTimeMeasure=obsObjTypeData.controlTimeMeasure,
                             events=eventsObj, remoteGuid=remote_guid)

        self.__obsObjTypeRepository.save(objType)
        self.__notifyPusher.push([ObsObjTypeCreatedNotification(objType)])

        return objType

    def editType(self, cmd):
        """
        Изменить тип объекта мониторинга
        :param cmd: Класс команды изменения типа объекта мониторинга
        :type cmd: EditObservedObjectTypeCommand
        :return: ObsObjType | None
        """
        reqData = cmd.reqData
        return self.__editType(reqData)

    def __editType(self, obsObjTypeData):
        typeId = obsObjTypeData.id
        remote_guid = obsObjTypeData.remoteGuid

        if remote_guid:
            objType = self.__obsObjTypeRepository.getByRemoteGuid(remote_guid)
        else:
            objType = self.__obsObjTypeRepository.get(typeId)
        if objType is None:
            return None

        objType.name = obsObjTypeData.name
        objType.elements = obsObjTypeData.elements
        objType.stateCalculation = obsObjTypeData.stateCalculation
        objType.actions = obsObjTypeData.actions
        objType.falseAlertLimit = obsObjTypeData.falseAlertLimit
        objType.falseAlertControlTime = obsObjTypeData.falseAlertControlTime
        objType.controlTimeMeasure = obsObjTypeData.controlTimeMeasure
        objType.kind = obsObjTypeData.kind

        events = obsObjTypeData.events
        eventsObj = []
        for evt in events:
            if evt.event.remoteGuid:
                oldEvent = self.__eventsGetter.getByRemoteGuid(evt.event.remoteGuid)
            else:
                oldEvent = self.__eventsGetter.get(evt.event.id)
            if evt.newEvent.remoteGuid:
                newEvent = self.__eventsGetter.getByRemoteGuid(evt.newEvent.remoteGuid)
            else:
                newEvent = self.__eventsGetter.get(evt.newEvent.id)
            eventsObj.append(ObsObjTypeEventBrg(event=oldEvent, newEvent=newEvent))
        objType.events = eventsObj

        self.__obsObjTypeRepository.save(objType)
        self.__notifyPusher.push([ObsObjTypeEditedNotification(objType)])

        return objType

    def deleteType(self, cmd):
        """
        Удалить тип объекта мониторинга
        :param cmd: Класс команды удаления типа объекта мониторинга
        :type cmd: DeleteObservedObjectTypeCommand
        :return: bool
        """
        reqData = cmd.reqData
        typeId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            objType = self.__obsObjTypeRepository.getByRemoteGuid(remote_guid)
        else:
            objType = self.__obsObjTypeRepository.get(typeId)
        if objType is None:
            return False

        self.__obsObjTypeRepository.delete(objType.id)
        self.__notifyPusher.push([ObsObjTypeDeletedNotification(objType)])

        return True

    def deleteEventsRedirection(self, reqData):
        """
        Удаляет переопределнные события у типа объекта мониторинга при удалении одного из событий
        :param reqData: удаляемое событие
        :type reqData: Event
        """
        eventId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            event = self.__eventsGetter.getByRemoteGuid(remote_guid)
        else:
            event = self.__eventsGetter.get(eventId)
        if event is None:
            return False
        objTypes = self.__obsObjTypeRepository.getObjects()
        for objType in objTypes:
            # Список событий которые нужно удалить
            delEvents = []
            for elemEvents in objType.events:
                if elemEvents.event and elemEvents.event.id == event.id:
                    delEvents.append(elemEvents)
                elif elemEvents.newEvent and elemEvents.newEvent.id == event.id:
                    delEvents.append(elemEvents)
            objType.events = [event for event in objType.events if event not in delEvents]
            self.__obsObjTypeRepository.save(objType)
            self.__notifyPusher.push([ObsObjTypeEditedNotification(objType)])

        return True
