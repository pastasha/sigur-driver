# -*- coding: utf-8 -*-

import logging
import time
import datetime


class EventCommandsManager(object):
    """
    Класс обслуживающий выполнение команд по обработке и генерации событий
    """
    def __init__(self, observedObjectRepository, observedObjectTypeGetter, eventPusher, conn):
        """
        Создает объекта класса
        :param observedObjectRepository: Объект через который можно получать и сохранять объекты мониторинга
        :param observedObjectTypeGetter: Объект из которого можно получать типы объекты мониторинга
        :param eventPusher: Объект для посылки событий
        :return:
        """
        self.__observedObjectRepository = observedObjectRepository
        self.__observedObjectTypeGetter = observedObjectTypeGetter
        self.__eventPusher = eventPusher
        self.__conn = conn
        # TODO: не очень круто что сюда передается подключение к БД. наверное надо будет потом заменить на репозиторий

    def simulateAlarm(self, cmd):
        obj = self.__observedObjectRepository.get(cmd.reqData.id)
        # Поиск местонахождения  ОМ
        placeObj = None
        elements = obj.type.elements
        # собираем состояния элементов группы
        for nameInGroup in elements:
            if elements[nameInGroup]['type'] == 'place' and placeObj is None:
                for lnk in obj.links:
                    if lnk.nameInGroup == nameInGroup:
                        placeObj = lnk.target
                        break
        logging.getLogger('console').info('simulate event to %s in place %s' % (
            obj.name.encode('utf-8'), placeObj.name.encode('utf-8') if placeObj else 'None'))

        notif = {
            'notification': {
                'code': 7777777,
                'clock': time.clock(),
                'module': 'sServer'
            },
            'statement': {
                'directObj': {
                    'obsObj': {
                        'id': obj.id,
                        'name': obj.name,
                        'type': obj.type.id,
                        'veracity': obj.veracity
                    },
                    'name': obj.name
                },
                'adverbialTime': {
                    'param': time.time()
                }
            }
        }
        if placeObj:
            notif['statement']['adverbialPlace'] = {
                'obsObj': {
                    'id': placeObj.id,
                    'name': placeObj.name,
                    'type': placeObj.type.id
                },
                'name': placeObj.name,
            }
        self.__eventPusher.push(notif)

    def generateEvent(self, cmd):
        reqData = cmd.reqData
        source = None
        place = None
        if reqData.source:
            source = self.__observedObjectRepository.get(reqData.source)
        if reqData.place:
            place = self.__observedObjectRepository.get(reqData.place)
        notif = {
            'adverbialTime': {
                'param': time.time()
            }
        }
        if source:
            notif['directObj'] = {
                'obsObj': {
                    'id': source.id,
                    'name': source.name,
                    'type': source.type.id,
                    'veracity': source.veracity
                },
                'name': source.name
            }
        if place:
            notif['adverbialPlace'] = {
                'obsObj': {
                    'id': place.id,
                    'name': place.name,
                    'type': place.type.id
                },
                'name': place.name
            }
        if reqData.params:
            # Так надо чтобы в события не попадали роли в которых значение None
            for key, value in reqData.params.items():
                if value:
                    notif[key] = value
        event = {
            'notification': {
                'code': reqData.code,
                'clock': time.clock(),
                'module': 'sServer'
            },
            'statement': notif
        }
        # TODO: возможно это не совсем правильно
        self.__eventPusher.push(event)

    def markEventAsFalse(self, cmd):
        evnum = cmd.reqData.evnum
        rows2 = self.__conn.directRequest("""
            SELECT flags, directobj_obsobjid, adverbialtime_value
            FROM event_register_v2
            WHERE evnum = %s
        """ % evnum, extract=True)
        for row2 in rows2:
            if row2[0] and row2[0] & (1 << 0):
                return

            if row2[0] is None:
                self.__conn.directRequest("""
                    UPDATE event_register_v2 SET flags = 1 WHERE evnum = %s
                """ % evnum, extract=False)
            else:
                self.__conn.directRequest("""
                    update event_register_v2 set flags = flags | 1 where evnum = %s
                """ % evnum, extract=False)

            try:
                obj = self.__observedObjectRepository.get(row2[1])
                obj.falseAlertCount = obj.falseAlertCount + 1
                self.__emitFalseAlert(evnum, obj)

                objType = self.__observedObjectTypeGetter.get(obj.type)
                falsealertlimit = objType.falseAlertLimit
                falsealertcontroltime = objType.falseAlertControlTime
                controltimemeasure = objType.controlTimeMeasure
                if falsealertlimit > 0:
                    falseAlertTime = obj.falseAlertTime
                    falseAlertTime.append(row2[2].strftime('%d.%m.%Y %H:%M'))
                    if len(falseAlertTime) > falsealertlimit:
                        falseAlertTime = falseAlertTime[-falsealertlimit:]
                    if len(falseAlertTime) == falsealertlimit:
                        startTime = datetime.datetime.strptime(falseAlertTime[0], '%d.%m.%Y %H:%M')
                        delta = row2[2] - startTime
                        if controltimemeasure == 1:
                            mydelta = datetime.timedelta(minutes=falsealertcontroltime)
                        else:
                            mydelta = datetime.timedelta(hours=falsealertcontroltime)
                        if delta < mydelta:
                            self.__emitFalseAlertsLimit(obj)
                            # Сбросим время возникновения последних ложных тревог
                            falseAlertTime = []
                    obj.falseAlertTime = falseAlertTime
                self.__observedObjectRepository.save(obj)
            except Exception as e:
                logging.getLogger('console').exception(str(e))

    def __emitFalseAlert(self, evnum, obj):
        notif = {
            'notification': {
                'code': 750,
                'clock': time.clock(),
                'module': 'sServer'
            },
            'statement': {
                'directObj': {
                    'obsObj': {
                        'id': obj.id,
                        'name': obj.name,
                        'type': obj.type.id,
                        'veracity': obj.veracity
                    },
                    'name': obj.name
                },
                'adverbialTime': {
                    'param': time.time()
                },
                'adverbialMode': {
                    'param': evnum
                }
            }
        }
        self.__eventPusher.push(notif)

    def __emitFalseAlertsLimit(self, obj):
        notif = {
            'notification': {
                'code': 752,
                'clock': time.clock(),
                'module': 'sServer'
            },
            'statement': {
                'directObj': {
                    'obsObj': {
                        'id': obj.id,
                        'name': obj.name,
                        'type': obj.type.id,
                        'veracity': obj.veracity
                    },
                    'name': obj.name
                },
                'adverbialTime': {
                    'param': time.time()
                }
            }
        }
        self.__eventPusher.push(notif)
