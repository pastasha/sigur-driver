# -*- coding: utf-8 -*-

import copy
import uuid
import time
import logging
from typing import ValuesView, List, Optional, Union, Tuple

from licensemanager.licensemanager import License

from esmapi.objects.obsobj import ObsObj, ObsObjLink, DevInfo
from esmapi.objects.obsobjtype import ObsObjType
from esmapi.objects.maplayer import MapLayer
from esmapi.notifications.sServerNotifications import ObsObjCreatedNotification, ObsObjEditedNotification,\
    ObsObjDeletedNotification, ObsObjConnectedNotification, ObsObjDisconnectedNotification
from esmapi.commands.sServerCommands import GetObservedObjectInfoCommand, AddObservedObjectCommand,\
    EditObservedObjectCommand, DeleteObservedObjectCommand, ConnectObservedObjectsCommand,\
    DisconnectObservedObjectsCommand, SetObservedObjectStateCommand

from repository.observedobjectrepository import ObservedObjectRepository
from repository.observedobjecttyperepository import ObservedObjectTypeRepository
from repository.maplayerrepository import MapLayerRepository
from repository.devrepository import DevRepository
from translation import mygettext as _


logger = logging.getLogger('sServer')


class LicenseLimitException(Exception):
    def __init__(self, kind: str, count: int):
        super(LicenseLimitException, self).__init__('License limit exceeded for kind %s. Max count %s' % (kind, count))
        self.kind = kind
        self.count = count


class ConnectionLoopException(Exception):
    def __init__(self, srcId: int, targetId: int):
        super(ConnectionLoopException, self).__init__('loop detected %s %s' % (srcId, targetId))
        self.srcId = srcId
        self.targetId = targetId


class ConnectionExistsException(Exception):
    def __init__(self, srcId: int, targetId: int):
        super(ConnectionExistsException, self).__init__('objects (%d %d) already connected' % (srcId, targetId))
        self.srcId = srcId
        self.targetId = targetId


class InvalidNameInGroupException(Exception):
    def __init__(self, srcObj: ObsObj, nameInGroup: str):
        super(InvalidNameInGroupException, self).__init__('group \'%s\' cannot has element with name \'%s\'' % (
            srcObj, nameInGroup))
        self.srcObj = srcObj
        self.nameInGroup = nameInGroup


class ObservedObjectManager(object):
    """
    Класс для работы с объектами мониторинга
    """
    def __init__(self, observedObjectRepository: ObservedObjectRepository,
                 obsObjTypeGetter: ObservedObjectTypeRepository, mapLayerGetter: MapLayerRepository,
                 devGetter: DevRepository, notifyPusher, eventPusher, license: License):
        """
        Создает объект класса
        :param observedObjectRepository: Репозиторий объектов мониторинга
        :param obsObjTypeGetter: Объект из которого можно получать типы объектов мониторинга
        :param mapLayerGetter: Объект из которого можно получать слои на карте
        :param devGetter: Объект из которого можно получать базовую информацию об объекте оборудования
        :param notifyPusher: объект для посылки нотификаций
        :param eventPusher: Объект для посылки событий
        :param license: лицензионные органичения
        """
        self.__observedObjectRepository = observedObjectRepository
        self.__obsObjTypeGetter = obsObjTypeGetter
        self.__mapLayerGetter = mapLayerGetter
        self.__devGetter = devGetter
        self.__notifyPusher = notifyPusher
        self.__eventPusher = eventPusher
        self.__license = license

    def getObjects(self) -> ValuesView[ObsObj]:
        """
        Возвращает список всех объектов мониторинга
        """
        return self.__observedObjectRepository.getObjects()

    def getInformation(self, cmd: GetObservedObjectInfoCommand) -> List[ObsObj]:
        """
        Возвращает информацию об объектах мониторинга
        :param cmd: Класс команды получения информации
        """
        reqData = cmd.reqData
        ids = reqData.ids
        res = [self.__observedObjectRepository.get(id) for id in ids]
        # На всякий случай удалим пустые объекты из ответа
        return [obj for obj in res if obj]

    def addObject(self, cmd: AddObservedObjectCommand) -> Tuple[Optional[ObsObj], str]:
        """
        Добавить объект мониторинга
        :param cmd: Класс команды добавления
        """
        reqData = cmd.reqData
        obsObj = reqData.obsObj
        objType = obsObj.type
        typeId = objType.id
        type_guid = objType.remoteGuid
        mapLayer = obsObj.maplayer
        mapLayerId = mapLayer.id if mapLayer else None
        mapLayer_guid = mapLayer.remoteGuid if mapLayer else None
        backlinks = obsObj.backlinks
        dev = obsObj.dev
        dev_guid = dev.remoteGuid if dev else None
        dev_id = dev.id if dev else None
        siteId = reqData.siteId
        remote_guid = obsObj.remoteGuid

        msg = self.__checkObservedObjectParam(obsObj)
        # если в параметрах ОМ выявилась ошибка, вернем ее и прекратим выполнение команды
        if msg:
            return None, msg

        if remote_guid:
            if self.__observedObjectRepository.getByRemoteGuid(remote_guid):
                return self.__editObject(obsObj)

        if remote_guid == '':
            remote_guid = str(uuid.uuid4())
            if siteId != '':
                remote_guid = '%s.%s' % (remote_guid, siteId)

        layer = None
        if type_guid:
            type = self.__obsObjTypeGetter.getByRemoteGuid(type_guid)
        else:
            type = self.__obsObjTypeGetter.get(typeId)

        checkLicenseResult, kindCount = self.__checkObsObjTypeMaxCountExceeded(type)
        if not checkLicenseResult:
            raise LicenseLimitException(type.kind, kindCount)

        if mapLayer_guid:
            layer = self.__mapLayerGetter.getByRemoteGuid(mapLayer_guid)
        elif mapLayerId:
            layer = self.__mapLayerGetter.get(mapLayerId)

        if dev_guid:
            dev = self.__devGetter.getByRemoteGuid(dev.equip, dev.type, dev.remoteGuid)
        elif dev_id:
            dev = self.__devGetter.get(dev.equip, dev.type, dev.id)
        devObj = DevInfo(equip=dev.equip, type=dev.type, id=dev.id, remoteGuid=dev.remoteGuid) if dev else None
        obj = ObsObj(id=None, name=obsObj.name, type=type, veracity=obsObj.veracity, dev=devObj,
                     remoteMonitoring=obsObj.remoteMonitoring, maplayer=layer, latitude=obsObj.latitude,
                     longitude=obsObj.longitude, altitude=obsObj.altitude, additionaldata=obsObj.additionaldata,
                     description=obsObj.description, remoteGuid=remote_guid)

        self.__observedObjectRepository.save(obj)
        self.__notifyPusher.push([ObsObjCreatedNotification(obj)])

        if backlinks:
            srcId = backlinks[0].src.id
            srcGuid = backlinks[0].src.remoteGuid
            nameInGroup = backlinks[0].nameInGroup
            if srcGuid:
                srcObj = self.__observedObjectRepository.getByRemoteGuid(srcGuid)
            else:
                srcObj = self.__observedObjectRepository.get(srcId)
            if srcObj is not None:
                self.__connectObjects(srcObj, obj, nameInGroup)

        return obj, msg

    def editObject(self, cmd: EditObservedObjectCommand) -> Tuple[Optional[ObsObj], str]:
        """
        Изменить объект мониторинга
        :param cmd: Класс команды изменения объекта
        """
        reqData = cmd.reqData
        return self.__editObject(reqData)

    def __editObject(self, obsObjData: ObsObj) -> Tuple[Optional[ObsObj], str]:
        objId = obsObjData.id
        mapLayer = obsObjData.maplayer
        mapLayerId = mapLayer.id if mapLayer else None
        mapLayer_guid = mapLayer.remoteGuid if mapLayer else None

        remote_guid = obsObjData.remoteGuid

        msg = self.__checkObservedObjectParam(obsObjData)
        # если в параметрах ОМ выявилась ошибка, вернем ее и прекратим выполнение команды
        if msg:
            return None, msg

        if remote_guid:
            obj = self.__observedObjectRepository.getByRemoteGuid(remote_guid)
        else:
            obj = self.__observedObjectRepository.get(objId)
        if obj is None:
            return None, msg
        obj.name = obsObjData.name
        obj.latitude = obsObjData.latitude
        obj.longitude = obsObjData.longitude
        obj.altitude = obsObjData.altitude
        obj.additionaldata = obsObjData.additionaldata
        obj.veracity = obsObjData.veracity
        obj.remoteMonitoring = obsObjData.remoteMonitoring
        obj.description = obsObjData.description
        layer = None
        if mapLayer_guid:
            layer = self.__mapLayerGetter.getByRemoteGuid(mapLayer_guid)
        elif mapLayerId:
            layer = self.__mapLayerGetter.get(mapLayerId)
        obj.maplayer = layer

        self.__observedObjectRepository.save(obj)
        self.__notifyPusher.push([ObsObjEditedNotification(obj)])

        return obj, msg

    def deleteObject(self, cmd: DeleteObservedObjectCommand) -> bool:
        """
        Удалить объект мониторинга
        :param cmd: Класс команды удаления объекта
        """
        reqData = cmd.reqData
        objectId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            obj = self.__observedObjectRepository.getByRemoteGuid(remote_guid)
        else:
            obj = self.__observedObjectRepository.get(objectId)
        if obj is None:
            return False

        # Удалим все связи в которых участвовал данный объект
        links = copy.copy(obj.links)
        for lnk in links:
            self.__disconnectObjects(lnk.src, lnk.target, lnk.nameInGroup)
        backlinks = copy.copy(obj.backlinks)
        for lnk in backlinks:
            self.__disconnectObjects(lnk.src, lnk.target, lnk.nameInGroup)

        self.__observedObjectRepository.delete(obj.id)
        self.__notifyPusher.push([ObsObjDeletedNotification(obj)])

        return True

    def connectObjects(self, cmd: ConnectObservedObjectsCommand) -> bool:
        """
        Связывает два объекта мониторинга друг с другом
        :param cmd: Класс команды связывания объекта
        """
        linkInfo = cmd.reqData
        srcData = linkInfo.src
        targetData = linkInfo.target
        nameInGroup = linkInfo.nameInGroup
        srcId = srcData.id
        srcGuid = srcData.remoteGuid
        targetId = targetData.id
        targetGuid = targetData.remoteGuid
        if srcGuid:
            srcObj = self.__observedObjectRepository.getByRemoteGuid(srcGuid)
        else:
            srcObj = self.__observedObjectRepository.get(srcId)
        if targetGuid:
            targetObj = self.__observedObjectRepository.getByRemoteGuid(targetGuid)
        else:
            targetObj = self.__observedObjectRepository.get(targetId)
        if srcObj is None or targetObj is None:
            return False
        self.__connectObjects(srcObj, targetObj, nameInGroup)
        return True

    def __findLink(self, srcObj: ObsObj, targetObj: Optional[ObsObj], nameInGroup: str) ->\
            Union[Tuple[ObsObjLink, int], Tuple[None, None]]:
        """
        Ищет объект ссылки между srcObj и targetObj и ее индекс в списке ссылок srcObj
        Если targetObj = None то ищется ссылка с именем nameInGroup у srcObj
        :param srcObj: Исходный объект мониторинга
        :param targetObj: Целевой объект мониторинга
        :param nameInGroup: имя ссылки
        """
        links = srcObj.links
        i = 0
        for link in links:
            if link.src.id == srcObj.id and link.nameInGroup == nameInGroup:
                if targetObj:
                    if link.target.id == targetObj.id:
                        return link, i
                return link, i
            i += 1
        return None, None

    def __connectObjects(self, srcObj: ObsObj, targetObj: ObsObj, nameInGroup: str) -> None:
        """
        Связывает объекты мониторинга
        :param srcObj: Исходный объект
        :param targetObj: Целевой объект
        :param nameInGroup: Имя ссылки
        :return:
        """
        linkObj, i = self.__findLink(srcObj, targetObj, nameInGroup)
        if linkObj:
            logging.getLogger('console').info('objects (%d %d) already connected' % (srcObj.id, targetObj.id))
            raise ConnectionExistsException(srcObj.id, targetObj.id)

        groupDescr = srcObj.type.elements
        if nameInGroup not in groupDescr:
            logging.getLogger('console').info("group '%s' cannot has element with name '%s'" % (srcObj, nameInGroup))
            raise InvalidNameInGroupException(srcObj, nameInGroup)

        # Поищем была ли у srcObj заполена ссылка с именем nameInGroup и если была то отсоединим ее
        linkObj, i = self.__findLink(srcObj, None, nameInGroup)
        if linkObj:
            self.__disconnectObjects(srcObj, linkObj, nameInGroup)

        if groupDescr[nameInGroup]['type'] != 'place':
            if self.__checkConnectionLoop(targetObj, srcObj.id):
                logging.getLogger('console').info("loop detected %s %s" % (targetObj.id, srcObj.id))
                raise ConnectionLoopException(srcObj.id, targetObj.id)

        link = ObsObjLink(id=None, src=srcObj, target=targetObj, nameInGroup=nameInGroup)
        targetObj.backlinks.append(link)
        srcObj.links.append(link)

        self.__observedObjectRepository.save(srcObj)
        self.__notifyPusher.push([ObsObjConnectedNotification(link)])
        self.__insertStatesToParentGroupsCache(targetObj)
        self.calculateState(srcObj.id)

    def disconnectObjects(self, cmd: DisconnectObservedObjectsCommand) -> bool:
        """
        Удаляет связь между двумя объектами мониторинга
        :param cmd: Класс команды удаления связи
        :return:
        """
        linkInfo = cmd.reqData
        srcData = linkInfo.src
        targetData = linkInfo.target
        nameInGroup = linkInfo.nameInGroup
        srcId = srcData.id
        srcGuid = srcData.remoteGuid
        targetId = targetData.id
        targetGuid = targetData.remoteGuid
        if srcGuid:
            srcObj = self.__observedObjectRepository.getByRemoteGuid(srcGuid)
        else:
            srcObj = self.__observedObjectRepository.get(srcId)
        if targetGuid:
            targetObj = self.__observedObjectRepository.getByRemoteGuid(targetGuid)
        else:
            targetObj = self.__observedObjectRepository.get(targetId)
        if srcObj is None or targetObj is None:
            return False

        self.__disconnectObjects(srcObj, targetObj, nameInGroup)
        return True

    def setState(self, cmd: SetObservedObjectStateCommand) -> None:
        reqData = cmd.reqData
        obsObjId = reqData.id
        state = reqData.state
        # TODO: надо тестировать, очень вероятно что это могло сломаться
        self.calculateState(obsObjId, state)

    def __disconnectObjects(self, srcObj: ObsObj, targetObj: ObsObj, nameInGroup: str):
        """
        Удаляет связь между двумя объектами мониторинга
        :param srcObj: Гланый объект связи
        :param targetObj: Объект, который вложен в srcObj
        :param nameInGroup: Название ссылки с которой targetObj вложен в srcObj
        """
        linkObj, i = self.__findLink(srcObj, targetObj, nameInGroup)
        if linkObj is None:
            logging.getLogger('console').info('objects already disconnected')
            raise Exception('objects already disconnected')
        del srcObj.links[i]

        self.__delStatesFromParentGroupsCache(targetObj)

        backlinks = targetObj.backlinks
        i = 0
        for link in backlinks:
            if link.src.id == srcObj.id and link.target.id == targetObj.id and link.nameInGroup == nameInGroup:
                break
            i += 1
        del targetObj.backlinks[i]

        self.calculateState(srcObj.id)

        self.__observedObjectRepository.save(srcObj)
        self.__notifyPusher.push([ObsObjDisconnectedNotification(linkObj)])

    def __getObsObjChildStates(self, obj: ObsObj, devState: dict) -> dict:
        """
        Получает состояния всех вложенных в obj объектов
        :param obj: Объект мониторинга состояния детей которого надо собрать
        :param devState: Словарь состояний объекта оборудования связанного с obj
        """
        obsObjType = obj.type
        elements = obsObjType.elements

        if obsObjType.kind == 'group':
            return obj.childStates

        elementState = {}
        for nameInGroup in elements:
            if elements[nameInGroup]['type'] == 'dev':
                elementState[nameInGroup] = devState
            elif elements[nameInGroup]['type'] == 'state':
                targetLinkObj, _ = self.__findLink(obj, None, nameInGroup)
                if targetLinkObj:
                    elementState[nameInGroup] = targetLinkObj.target.state
        return elementState

    def __evaluateStateCalculationFunction(self, stateFunction: dict, obj: ObsObj, devState: dict) -> Optional[dict]:
        """
        Выполняет функцию рассчета состояния для объекта obj
        :param stateFunction: Функция рассчета состояния
        :param obj: Объект мониторинга состояние которого нужно сосчитать
        :param devState: Словарь состояний объекта оборудования связанного с obj
        """
        resFunctions = stateFunction.get('result_function')
        objects = stateFunction.get('objects')

        if not (resFunctions and objects):
            return None
        elementState = self.__getObsObjChildStates(obj, devState)
        newState = {}

        for flag in resFunctions:
            for obj in objects:
                if obj in elementState:
                    if not elementState[obj]:
                        continue
                    elif flag in objects[obj] and isinstance(elementState[obj], dict) and flag in elementState[obj]:
                        if flag not in newState:
                            if resFunctions[flag] == 'and':
                                newState[flag] = 1
                            else:
                                newState[flag] = 0

                        if resFunctions[flag] == 'and':
                            newState[flag] = newState[flag] and elementState[obj][flag]
                            if newState[flag] == 0:  # по функции И дальше не нужно умножать
                                break
                        elif resFunctions[flag] == 'or':
                            newState[flag] = newState[flag] or elementState[obj][flag]
                            if newState[flag] == 1:  # по функции ИЛИ дальше не нужно складывать
                                break
        return newState

    def __updateParentsState(self, obj: ObsObj) -> None:
        """
        Обновляет состояния всех объектов мониторинга в которые вложен obj.
        :param obj: Объект мониторинга
        :type obj: ObsObj
        :return:
        """
        for backLink in obj.backlinks:
            groupObj = backLink.src
            elements = groupObj.type.elements
            if backLink.nameInGroup in elements and elements[backLink.nameInGroup]['type'] != 'place':
                self.calculateState(groupObj.id, childGroupName=backLink.nameInGroup, childState=obj.state)

    def calculateState(self, obsObjId: int, devState: Optional[dict] = None, childGroupName: Optional[str] = None,
                       childState: Optional[dict] = None, code: int = 1000):
        """
        Рассчитывает новое состояние объекта мониторинга.
        :param obsObjId: идентификатор объекта мониторинга
        :param devState: Словарь состояний объекта оборудования связанного с obj
        :param childGroupName: Имя слота состояние которого поменялось если надо пересчитать состояние группового
        объекта
        :param childState: Словарь состояний вложенного объекта
        :param code: Код события изменения состояния (1000 иил 1021)
        :return:
        """
        obsObj = self.__observedObjectRepository.get(obsObjId)
        obsObjType = obsObj.type

        if childGroupName:
            states = obsObj.childStates if obsObj.childStates else {}
            states[childGroupName] = childState
            obsObj.childStates = states

        try:
            try:
                calcHandl = obsObjType.stateCalculation
                newState = self.__evaluateStateCalculationFunction(calcHandl, obsObj, devState)
            except:
                logger.exception(u"Error calc handlers: type %s, obj %s(%s)" % (obsObjType.id, obsObj.name, obsObjId))
                newState = None

            if devState and 'CONF' in devState:
                if not newState:
                    newState = {}
                newState['CONF'] = devState['CONF']

                if 'GPS' in newState['CONF']:
                    lat, lon = newState['CONF']['GPS'].split(';')
                    if len(lat) and len(lon):
                        obsObj.latitude = float(lat)
                        obsObj.longitude = float(lon)
                        self.__observedObjectRepository.save(obsObj)
                        self.__notifyPusher.push([ObsObjEditedNotification(obsObj)])
            if newState:
                oldState = obsObj.state
                # обновльение флагов нового состояния из старого на случай если в новом нет флагов старого состояния
                if oldState:
                    saved_state = oldState.copy()
                    saved_state.update(newState)
                    newState = saved_state
                obsObj.state = newState
                if newState != oldState:
                    self.__mutationReportChangeState(obsObj, newState, code)
                    self.__updateParentsState(obsObj)
            return newState
        except:
            logging.getLogger('console').exception('cannot calculate state of %d object' % obsObjId)
            oldState = obsObj.state
            obsObj.state = None
            if oldState is not None:
                self.__mutationReportChangeState(obsObj, None, code)
                self.__updateParentsState(obsObj)
            return None

    def __delStatesFromParentGroupsCache(self, obsObj: ObsObj) -> None:
        """
        Удаляет запись об объекте из кэша флагов состояний родительского группового объекта
        :param obsObj: объект мониторинга, записи о котором надо удалить
        """
        for lnk in obsObj.backlinks:
            groupObj = lnk.src
            elements = groupObj.type.elements
            if lnk.nameInGroup in elements and elements[lnk.nameInGroup]['type'] != 'place':
                states = groupObj.childStates if groupObj.childStates else {}
                if lnk.nameInGroup in states:
                    del states[lnk.nameInGroup]
                    groupObj.childStates = states
                return

    def __insertStatesToParentGroupsCache(self, obsObj: ObsObj) -> None:
        """
        Добавляет запись об объекте в кэш флагов состояний родительского группового объекта
        :param obsObj: объект мониторинга, запись о котором надо добавить
        """
        for lnk in obsObj.backlinks:
            groupObj = lnk.src
            elements = groupObj.type.elements
            if lnk.nameInGroup in elements and elements[lnk.nameInGroup]['type'] != 'place':
                states = groupObj.childStates if groupObj.childStates else {}
                states[lnk.nameInGroup] = obsObj.state
                groupObj.childStates = states
                return

    def __checkObsObjTypeMaxCountExceeded(self, typeObj: ObsObjType) -> Tuple[bool, int]:
        """
        Проверяет не привышено ли лицензионное ограничение на количество объектов с таким же kind как у typeObj
        :param typeObj: тип объекта мониторинга создаваемого объекта
        """
        kind = typeObj.kind
        kindCount = self.__license.getObservedObjectKindLimit(kind)
        if kindCount == -1:
            return True, kindCount
        objects = self.__observedObjectRepository.getObjects()
        count = 0
        for obj in objects:
            if obj.type.kind == kind:
                count += 1
        if count >= kindCount:
            return False, kindCount
        return True, kindCount

    def __checkConnectionLoop(self, targetObj: ObsObj, srcObjId: int):
        if int(targetObj.id) == int(srcObjId):
            return True

        elDescrAll = targetObj.type.elements
        for el in targetObj.links:
            elDescr = elDescrAll[el.nameInGroup]
            if elDescr['type'] != 'place':
                if self.__checkConnectionLoop(el.target, srcObjId):
                    return True

        return False

    def __mutationReportChangeState(self, obj: ObsObj, state: dict, code: Optional[int] = None):
        # TODO: сдеать класс для нотификации
        notifCode = 2000
        if code and code == 1021:
            notifCode = 2021
        notif = {
            'notification': {
                'code': notifCode,
                'clock': time.clock(),
                'module': 'sServer'
            },
            'statement': {
                'directObj': {
                    'obsObj': {
                        'id': obj.id,
                        'type': obj.type.id,
                        'state': state,
                        'remoteGuid': obj.remoteGuid
                    }
                }
            }
        }
        self.__eventPusher.push(notif)

    def deleteLayerFromObsObj(self, layer: MapLayer) -> bool:
        """
        Удаляет ссылки на удаляемый слой в объектах мониторинга
        :param layer: удаляемый слой
        """
        layerId = layer.id
        remote_guid = layer.remoteGuid
        if remote_guid:
            mapLayer = self.__mapLayerGetter.getByRemoteGuid(remote_guid)
        else:
            mapLayer = self.__mapLayerGetter.get(layerId)
        if mapLayer is None:
            return False
        obsObj = self.__observedObjectRepository.getObjects()
        for obsObjElement in obsObj:
            if obsObjElement.maplayer and obsObjElement.maplayer.id == mapLayer.id:
                obsObjElement.maplayer = None
                self.__observedObjectRepository.save(obsObjElement)
                self.__notifyPusher.push([ObsObjEditedNotification(obsObjElement)])

        return True

    def deleteLinkedObsObjWithEquip(self, equipName: str, typeName: str, objId: int, remote_guid: str):
        """
        Удаляет ОМ связанный с удаляемым объектом оборудования
        :param equipName: название оборудования
        :param typeName: тип оборудования
        :param objId: id оборудования
        :param remote_guid: remote_guid оборудования
        :return:
        """
        obsObjlist = self.getObjects()
        linkedObsObj = None
        for obsObj in obsObjlist:
            if not obsObj.dev:
                continue
            if obsObj.dev.type == typeName and obsObj.dev.equip == equipName and (
                    obsObj.dev.remoteGuid == remote_guid or obsObj.dev.id == objId):
                linkedObsObj = obsObj
                break
        if linkedObsObj:
            self.deleteObject(DeleteObservedObjectCommand(linkedObsObj))

    def __checkObservedObjectParam(self, obsObj) -> str:
        """
        Метод для проверки корректности параметров при создании/редактировании ОМ
        """
        if not obsObj.name:
            return _('Ошибка! Нельзя создавать ОМ без названия')
