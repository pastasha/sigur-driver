
from typing import Optional, ValuesView
import uuid

from esmapi.objects.maplayer import MapLayer
from esmapi.notifications.sServerNotifications import MapLayerCreatedNotification, MapLayerEditedNotification,\
    MapLayerDeletedNotification
from esmapi.commands.sServerCommands import AddMapLayerCommand, EditMapLayerCommand, DeleteMapLayerCommand

from repository.maplayerrepository import MapLayerRepository


class MapLayerManager(object):
    """
    Класс для работы со слоями на картах
    """
    def __init__(self, mapLayerRepository: MapLayerRepository, notifyPusher):
        """
        Создает объект класса
        :param mapLayerRepository: Репозиторий слоев
        :param notifyPusher: объект для посылки нотификаций
        """
        self.__mapLayerRepository = mapLayerRepository
        self.__notifyPusher = notifyPusher

    def getLayers(self) -> ValuesView[MapLayer]:
        """
        Возвращает список сериализованных слоев
        """
        return self.__mapLayerRepository.getObjects()

    def addLayer(self, cmd: AddMapLayerCommand) -> Optional[MapLayer]:
        """
        Добавить слой
        :param cmd: Класс команды добавления слоя
        """
        reqData = cmd.reqData
        layerData = reqData.mapLayer
        siteId = reqData.siteId
        remote_guid = layerData.remoteGuid

        if remote_guid:
            if self.__mapLayerRepository.getByRemoteGuid(remote_guid):
                return self.__editLayer(layerData)

        if remote_guid == '':
            remote_guid = str(uuid.uuid4())
            if siteId != '':
                remote_guid = '%s.%s' % (remote_guid, siteId)

        layer = MapLayer(id=None, name=layerData.name, icon=layerData.icon, remoteGuid=remote_guid)

        self.__mapLayerRepository.save(layer)
        self.__notifyPusher.push([MapLayerCreatedNotification(layer)])

        return layer

    def editLayer(self, cmd: EditMapLayerCommand) -> Optional[MapLayer]:
        """
        Изменить слой
        :param cmd: Класс команды изменения слоя
        """
        reqData = cmd.reqData
        return self.__editLayer(reqData)

    def __editLayer(self, layerData: MapLayer) -> Optional[MapLayer]:
        layerId = layerData.id
        remote_guid = layerData.remoteGuid

        if remote_guid:
            layer = self.__mapLayerRepository.getByRemoteGuid(remote_guid)
        else:
            layer = self.__mapLayerRepository.get(layerId)
        if layer is None:
            return None
        layer.name = layerData.name
        layer.icon = layerData.icon

        self.__mapLayerRepository.save(layer)
        self.__notifyPusher.push([MapLayerEditedNotification(layer)])

        return layer

    def deleteLayer(self, cmd: DeleteMapLayerCommand) -> bool:
        """
        Удалить слой
        :param cmd: Класс команды удаления слоя
        :type cmd: DeleteMapLayerCommand
        :return: bool
        """
        reqData = cmd.reqData
        layerId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            layer = self.__mapLayerRepository.getByRemoteGuid(remote_guid)
        else:
            layer = self.__mapLayerRepository.get(layerId)
        if layer is None:
            return False

        self.__mapLayerRepository.delete(layerId)
        self.__notifyPusher.push([MapLayerDeletedNotification(layer)])

        return True
