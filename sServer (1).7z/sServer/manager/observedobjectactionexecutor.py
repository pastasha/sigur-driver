
import logging

from esmapi.objects.obsobj import ObsObj
from esmapi.notifications.sServerNotifications import ObsObjExecActionNotification
from esmapi.commands.sServerCommands import ExecObservedObjectActionCommand

from repository.observedobjectrepository import ObservedObjectRepository

logger = logging.getLogger('sServer')

# TODO: сломалась отправка команд на REST для удаленного мониторинга


class ActionNotFoundException(Exception):
    def __init__(self, obsObj,  actName):
        super(ActionNotFoundException, self).__init__('%s hasnt\'t action %s' % (obsObj, actName))
        self.obsObj = obsObj
        self.actName = actName


class ObservedObjectActionExecutor(object):
    """
    Класс выполняющий команды над объектами мониторинга
    """
    def __init__(self, observedObjectGetter: ObservedObjectRepository, notifyPusher, equipments):
        """
        :param observedObjectGetter: Объект из которого можно получать объекты мониторинга
        :type observedObjectGetter: basicrepository.IGetObject
        :param notifyPusher: объект для посылки нотификаций
        :param equipments: Список оборудования
        """
        self.__observedObjectGetter = observedObjectGetter
        self.__notifyPusher = notifyPusher
        self.__equipments = equipments

    def execAction(self, cmd: ExecObservedObjectActionCommand) -> bool:
        """
        Выполняет команду
        :param cmd: Класс команды выполнения действия
        """
        reqData = cmd.reqData
        id = reqData.obsObj.id
        remote_guid = reqData.obsObj.remoteGuid
        actName = reqData.act
        actParams = reqData.params

        if cmd.author:
            actParams['hostName'] = cmd.author.apmid

        if remote_guid:
            obsObj = self.__observedObjectGetter.getByRemoteGuid(remote_guid)
        else:
            obsObj = self.__observedObjectGetter.get(id)

        if obsObj is None:
            return False

        remote_guid = obsObj.remoteGuid
        g = remote_guid.split('.')
        if len(g) > 1:
            # TODO: понять как пробросить в нотификацию автора команды
            self.__notifyPusher.push([ObsObjExecActionNotification(ObsObjExecActionNotification.Statement(obsObj, actName, actParams))])
            return True

        self.__execAction(obsObj, actName, actParams)
        return True

    def __execAction(self, obsObj: ObsObj, actName: str, params: dict):
        actions = obsObj.type.actions
        if actName not in actions:
            raise ActionNotFoundException(obsObj, actName)

        if 'params' in actions[actName]:
            for p in actions[actName]['params']:
                if p not in params:
                    param = actions[actName]['params'][p]
                    if 'defval' in param:
                        params[p] = param['defval']

        elements = obsObj.type.elements
        for index, instr in enumerate(actions[actName]['instr']):
            calculatedParams = {}
            for p in instr['params']:
                if isinstance(instr['params'][p], str) and instr['params'][p][0:1] == '&':
                    calculatedParams[p] = params[instr['params'][p][1:]]
                else:
                    if p in instr['params']:
                        calculatedParams[p] = instr['params'][p]
                    else:
                        logger.error('Invalid params act=%s, obj=%s, param=%s' % (instr['act'], obsObj.id, p))
                        logging.getLogger('console').info(
                            'Invalid params act=%s, obj=%s, param=%s' % (instr['act'], obsObj.id, p))

            if 'hostName' in params:
                calculatedParams['hostName'] = params['hostName']

            if elements[instr['obj']]['type'] == 'dev':
                try:
                    dev = obsObj.dev
                    if dev is None:
                        return None
                    if dev.equip in self.__equipments:
                        self.__equipments[dev.equip].execAction(dev.type, dev.id, '', instr['act'], calculatedParams)

                except Exception as e:
                    logging.getLogger('console').info(
                        u"instruction %d in action '%s' fail, because: %s" % (index, actName, repr(e)))
                    raise

            elif elements[instr['obj']]['type'] == 'state':
                element = None
                for link in obsObj.links:
                    if link.nameInGroup == instr['obj']:
                        element = link.target
                if element is None:
                    logging.getLogger('console').info("object '%s' not connected" % instr['obj'].encode('utf-8'))
                else:
                    self.__execAction(element, instr['act'], calculatedParams)
