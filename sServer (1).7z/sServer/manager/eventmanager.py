
from typing import Optional, ValuesView

import uuid

from esmapi.objects.event import Event
from esmapi.notifications.sServerNotifications import EventCreatedNotification, EventEditedNotification,\
    EventDeletedNotification
from esmapi.commands.sServerCommands import AddEventCommand, EditEventCommand, DeleteEventCommand

from repository.eventrepository import EventRepository


class EventManager(object):
    """
    Класс для работы с типами событий
    """
    def __init__(self, eventRepository: EventRepository, notifyPusher):
        """
        Создает объект класса
        :param eventRepository: Репозиторий типов событий
        :param notifyPusher: объект для посылки нотификаций
        """
        self.__eventRepository = eventRepository
        self.__notifyPusher = notifyPusher

    def getEvents(self) -> ValuesView[Event]:
        """
        Возвращает список сериализованных типов событий
        """
        return self.__eventRepository.getObjects()

    def addEvent(self, cmd: AddEventCommand) -> Optional[Event]:
        """
        Добавить тип события
        :param cmd: Класс команды создания события
        """
        reqData = cmd.reqData
        eventData = reqData.event
        siteId = reqData.siteId
        remote_guid = eventData.remoteGuid

        if remote_guid:
            if self.__eventRepository.getByRemoteGuid(remote_guid):
                return self.__editEvent(eventData)

        if remote_guid == '':
            remote_guid = str(uuid.uuid4())
            if siteId != '':
                remote_guid = '%s.%s' % (remote_guid, siteId)

        event = Event(id=None, code=eventData.code, description=eventData.description, equipment=eventData.equipment,
                      format=eventData.format, options=eventData.options, level=eventData.level,
                      channel=eventData.channel, color=eventData.color, remoteGuid=remote_guid)

        self.__eventRepository.save(event)
        self.__notifyPusher.push([EventCreatedNotification(event)])

        return event

    def editEvent(self, cmd: EditEventCommand) -> Optional[Event]:
        """
        Изменить тип события
        :param cmd: Класс команды редактирования события
        """
        reqData = cmd.reqData
        return self.__editEvent(reqData)

    def __editEvent(self, eventData: Event) -> Optional[Event]:
        eventId = eventData.id
        remote_guid = eventData.remoteGuid

        if remote_guid:
            event = self.__eventRepository.getByRemoteGuid(remote_guid)
        else:
            event = self.__eventRepository.get(eventId)
        if event is None:
            return None
        event.description = eventData.description
        event.equipment = eventData.equipment
        event.options = eventData.options
        event.level = eventData.level
        event.format = eventData.format
        event.color = eventData.color
        event.channel = eventData.channel

        self.__eventRepository.save(event)
        self.__notifyPusher.push([EventEditedNotification(event)])

        return event

    def deleteEvent(self, cmd: DeleteEventCommand) -> bool:
        """
        Удалить тип события
        :param cmd: Класс команды удаления события
        """
        reqData = cmd.reqData
        eventId = reqData.id
        remote_guid = reqData.remoteGuid
        if remote_guid:
            event = self.__eventRepository.getByRemoteGuid(remote_guid)
        else:
            event = self.__eventRepository.get(eventId)
        if event is None:
            return False

        self.__eventRepository.delete(eventId)
        self.__notifyPusher.push([EventDeletedNotification(event)])

        return True
