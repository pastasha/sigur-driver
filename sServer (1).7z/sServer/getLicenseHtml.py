# -*- coding: utf-8 -*-

from licensemanager import License

headerData = """
    <html>
        <head>
            <meta charset="UTF-8">
            <style>
       @font-face {
           font-family: ESM;
           src: url(Fonts/PFDinTextPro-Regular.ttf);
          }
       *
       {
       padding: 0 0;
       margin: 0 0;
       font-family: ESM;
       }
        body
        {
        width: 360px;
        overflow-x: hidden;
        font-size:9pt;
        background: #ECEFF1;
        }
        .header{
        color: #4A4A4A;
        width:350px;
        overflov-x: hidden;
        background: #DBE1E6;
        text-align: center;
        height: 20px;
        padding-top: 4px;
        float:left;
        }
        .license
        {
        color: #4A4A4A;
        width:350px;
        background: #ECEFF1;
        padding-top: 8px;
        text-align: center;
        overflov-x: hidden;
        float:left;
        }
        .colomn1{
        margin-top:10px;float:left; width:100px; font-weight: bold;
        }
        .colomn2{
        margin-top:10px;float:left; width:190px; overflow-x: hidden; text-align: left;
        }
        .colomn3{
        margin-top:10px;float:left; width:60px;
        }</style>
            <title>Title</title>
        </head>
        <body>
        <div class="header">
            <div style="float:left;width:100px">%s</div>
            <div style="float:left;width:180px;">%s</div>
            <div style="float:left;width:60px">%s</div>
        </div>
        <div class="license">
"""

ESMBasic = {
    'title': 'ESM-Basic',
    'ru': 'ПО "ESM" Базовый компонент ESM Basic.',
    'en': 'Software "ESM". Base component ESM Basic.'
}

ESMPro = {
    'title': 'ESM-Professional',
    'ru': 'ПО "ESM" Базовый компонент ESM Professional.',
    'en': 'Software "ESM". Base component ESM Professional.'
}

ESMEnt = {
    'title': 'ESM-Enterprise',
    'ru': 'Базовый компонент ESM Enterprise.',
    'en': 'Software "ESM". Base component ESM Professional.'
}

ESMDemo = {
    'title': 'ESM-Demo',
    'ru': 'DEMO версия ESM предназначенная для демонстраций',
    'en': 'DEMO version Electronika Security Manager'
}

ESMNet = {
    'title': 'ESM-NET-1',
    'ru': 'Лицензия на сетевой клиент ESM (desktop).',
    'en': 'Additional license for network client ESM (desktop)'
}

ESMWebUsers = {
    'title': 'ESM-WEB-USERS',
    'ru': 'Лицензия на учетную запись пользователя с доступом к WEB интерфейсу.',
    'en': 'Additional license for web-interface access'
}

ESMOMSensor = {
    'title': 'ESM-OM-Sensor',
    'ru': 'Дополнительные шлейфы/зоны сигнализации.'
          'Определяет количество техических средств охраны'
          'подключенного оборудования.',
    'en': 'Additional license for alarm sensors'
}

ESMOMCam = {
    'title': 'ESM-OM-CAM',
    'ru': 'Дополнительные лицензии на видеокамеры подключенной видеоподсистемы.',
    'en': 'Additional license for video cameras'
}

ESMOMReader = {
    'title': 'ESM-OM-R',
    'ru': 'Дополнительные лицензии на считыватели подключенной системы.',
    'en': 'Additional license for readers IDs Card'
}

ESMMONITORING = {
    'title': 'ESM-MONITORING',
    'ru': 'Лицензия на подключение удаленного сервера ESM',
    'en': 'Additional license on connecting of remote monitoring server.'
}

ESMCard = {
    'title': 'ESM-Card',
    'ru': 'Личенция на действующие (активные) пропуска (карты доступа, гос. номера автомобилей, штрих-коды и др.)',
    'en': 'Additional license for IDs'
}

ESMUpNumber = {
    'title': 'ESM-UpNumber',
    'ru': 'Лицензия на ПО терминала для корректировки распознанных номеров автомобилей',
    'en': 'The terminal software, designed for correcting the recognized license plate numbers.'
}

ESMOMKey = {
    'title': 'ESM-OM-KEY',
    'ru': 'Лицензия на колличество ячеек хранения ключей подключенной системы хранения ключей.',
    'en': 'Additional license for cells in Electronic Key Control'
}

ESMPassportRead = {
    'title': 'ESM-Passp-Ru-Cogn',
    'ru': 'Лицензия на использование распознавателя Cognitive для российских паспортов',
    'en': 'License to use cognitive Recognizer for Russian passports'
}

equipmentsLicense = {
    'pce': {
        'title': 'ESM-PCE',
        'ru': 'Лицензия на подклчение контроллеров РСЕ',
        'en': 'Connection of ESM server with PCE controllers and subordinate controllers'
    },
    'intellect': {
        'title': 'ESM-Intellect',
        'ru': 'Лицензия на подключение системы видеонаблюдения Интеллект (ITV)',
        'en': 'The license for connecting the “INTELLECT (ITV) CCTV”.'
    },
    'bis': {
        'title': 'ESM-BOSCH-BIS',
        'ru': 'Лицензия на подключение системы BOSCH BIS.',
        'en': 'Driver provides: Monitoring of events, export of users and IDs, assigning of rights to ACM users in '
              'BIS-system from ESM ACM.'
    },
    'bosch': {
        'title': 'ESM-BOSCH-ACE',
        'ru': 'Лицензия на подклучение СКУД BOSCH ACE',
        'en': 'Driver provides: Monitoring of events, export of users and IDs, assigning of rights to ACM users in '
              'ACE-system from ESM ACM.'
    },
    'centum': {
        'title': 'ESM-ACSTP',
        'ru': 'Лицензия на подключение серверов OPC DA, для мониторинга тегов (параметров) РСУ "Centum VP" '
              '(Yokogawa Electric)',
        'en': 'Monitoring of OPC tag values (parameters) of a distributed control system "Centum VP" (produced by the '
              'Company of YOKOGAWA ELECTRIC) by OPC DA protocol.'
    },
    'milestone': {
        'title': 'ESM-Milestone',
        'ru': 'Лицензия на подключение системы видеонаблюдения  XProtect Milestone',
        'en': 'Connection of ESM server with server of digital video surveillance XProtect Milestone'
    },
    'securos': {
        'title': 'ESM-SecurOS',
        'ru': 'Лицензия на подключение видеосерверов SecurOS.',
        'en': 'Connection of ESM server with server of digital video surveillance SecurOS (ISS Comp.)'
    },
    'mobotix': {
        'title': 'ESM-Mobotix',
        'ru': 'Лицензия на  подключение видеокамер Mobotix.',
        'en': 'Establishment of a decentralized surveillance system based on the MOBOTIX cameras and the ESM Software.'
    },
    'orioniso': {
        'title': 'ESM-Orion-ISO',
        'ru': 'Лицензия на подключение ИСО Орион (Болид).'
    },
    'orionintgrsrv': {
        'title': 'ESM-Orion-Pro',
        'ru': 'Лицензия на подключение системы АРМ Орион Про(Болид).'
    },
    'apollo': {
        'title': 'ESM-APOLLO',
        'ru': 'Лицензия на подключение контроллеров APOLLO AAN-100(32)',
        'en': 'Connection of ESM server with Apollo AAN-100(32) controllers.'
    },
    'rubej08': {
        'title': 'ESM-Rubeg08',
        'ru': 'Лицензия на подключение ППКОП Р-08 ("Рубеж-08").',
        'en': 'Connection of ESM server with receiving and controlling fire and security devices named R-08 (produced '
              'by the company of SIGMA-IS).'
    },
    'axxon': {
        'title': 'ESM-Axxon',
        'ru': 'Лицензия на подключение системы видеонаблюдения Axxon Next(ITV).',
        'en': 'Connection of ESM server with server of digital video surveillance Axxon Next(ITV).'
    },
    'zabbix': {
        'title': 'ESM-Zabbix',
        'ru': 'Лицензия на подключение открытой системы распределенного мониторинга Zabbix.',
        'en': 'The license for connecting an enterprise open source monitoring software for networks'
              'and applications “Zabbix”.'
    },
    'trassir': {
        'title': 'ESM-Trassir',
        'ru': 'Лицензия на драйвер интеграции системы видеонаблюдения Trassir (DSSL)',
        'en': 'The license for connecting the “Trassir” integration driver.'
    },
    'gsm': {
        'title': 'ESM-SMS',
        'ru': 'Лицензия подключение одного GSM модема к серверу ESM. Позволяет выполнять SMS оповещения.',
        'en': 'The license for connecting one GSM modem to the ESM Server. Allows to send SMS '
              'notifications.'
    },
    'hikvision': {
        'title': 'ESM-HIKVISION',
        'ru': 'Лицензия на драйвер интеграции видеокамеры Hikvision для распознавания автотранспортных '
              'регистрационных знаков.',
        'en': 'The license for connecting the “Hikvision” camera integration driver, which is used for '
              'license plate recognition.'
    },
    'housekeeper': {
        'title': 'ESM-SK',
        'ru': 'Лицензия на подключение систем хранения ключей СК-24/32 ("ЭВС").',
        'en': 'Connection of ESM server with system of Electronic Key Control. Model #CК24/32 (Company of "EVS").'
    },
    'rusguard': {
        'title': 'ESM-RusGuard',
        'ru': 'Лицензия на подключение СКУД RusGuard'
    },
    'orionro': {
        'title': 'ESM-Orion-UO',
        'ru': 'Лицензия на подключение удаленных объектов при помощи приборов передачи извещений ИСО Орион'
    },
    'bam': {
        'title': 'ESM-BAM-128',
        'ru': 'Лицензия на подключение контроллеров BAM-128'
    },
    'bvms': {
        'title': 'ESM-BVMS',
        'ru': 'Лицензия на подключение системы видеонаблюдения BVMS (Bosch)'
    },
    'rubezhglobal': {
        'title': 'ESM-Global',
        'ru': 'Лицензия на подключение ИСБ Global'
    },
    'vizir': {
        'title': 'ESM-Vizir',
        'ru': 'Лицензия на подключение системы идентификации лиц Визирь.'
    },
    'nts': {
        'title': 'ESM-SPI',
        'ru': 'Лицензия на подключение к ESM систем передачи извещений по протоколу ContactID.'
    },
    'tss': {
        'title': 'ESM-TSS2000',
        'ru': 'Лицензия на подключение СКУД TSS2000 ("Семь печатей").'
    },
    'orwell': {
        'title': 'ESM-Orwell-2k',
        'ru': 'Лицензия на подключение видеосерверов Orwell2K.'
    },
    'gollard': {
        'title': 'ESM-GV',
        'ru': 'Лицензия на подключение видеосерверов. Golard Vision.'
    },
    'navigation': {
        'title': 'ESM-Navigation',
        'ru': 'Лицензия на подключение к ESM систем мониторинга подвижных объектов'
    },
    'onvif': {
        'title': 'ESM-ONVIF',
        'ru': 'Лицензия на подкл.видеосерверов  и/или видеокамер по спецификации Onvif'
    },
    'winmag': {
        'title': 'ESM-Winmag-Plus',
        'ru': 'Лицензия на подключение ПО Winmag Plus (Honeywell).'
    },
    'boschbis': {
        'title': 'ESM-BOSCH-BIS-DA',
        'ru': 'Лицензия на подключение системы BOSCH BIS по протоколу OPC-DA.'
    },
    'biostar': {
        'title': 'ESM-BioStar',
        'ru': 'Лицензия на подключение ПО BioStar (BioStar).'
    },
    'volnaaplha': {
        'title': 'ESM-Volna-Alpha',
        'ru': 'Лицензия на подключение сисемы охраны периметра Волна Альфа (УВП).'
    },
    'apacsbio': {
        'title': 'ESM-Apacs-Bio',
        'ru': 'Лицензия на подключение системы контроля доступа APACS Bio (ААМ Системз)'
    },
    'jupiter': {
        'title': 'ESM-Jupiter8',
        'ru': 'Лицензия на подключение одной системы охраны удаленных объектов Юпитер 8 (производства Элеста)'
    },
    'ccure': {
        'title': 'ESM-CCURE-9000',
        'ru': 'Лицензия на драйвер интеграции системы C CURE 9000 (компания Tyco Software House)'
    },
    'goalcity': {
        'title': 'ESM-GOAL',
        'ru': 'Лицензия на интеграции системы видеонаблюдения GoalCity Cassandra'
    },
    'dsc': {
        'title': 'ESM-DCS-IT-100',
        'ru': 'Лицензия для подключения панелей охраны DSC PowerSeries (компания Digital Security Controls )'
    }
}

licenseBlock = {
    'ru': """
        <div style="float:left; width:100px; font-weight: bold;">%s</div>
        <div style="float:left; width:190px; overflow-x: hidden; text-align: left;">%s</div>
        <div style="float:left; width:60px;">&#9745;</div>
    """,
    'en': """
        <div style="float:left; width:100px; font-weight: bold;">%s</div>
        <div style="float:left; width:190px; overflow-x: hidden; text-align: left;">%s</div>
        <div style="float:left; width:60px;">&#9745;</div>
    """
}

rowBlock = {
    'ru': """
        <div class="colomn1">%s</div>
        <div class="colomn2">%s</div>
        <div class="colomn3">%s </div>
    """,
    'en': """
        <div class="colomn1">%s</div>
        <div class="colomn2">%s</div>
        <div class="colomn3">%s </div>
    """
}

rowBlockEquip = {
    'ru': """
        <div class="colomn1">%s</div>
        <div class="colomn2">%s</div>
        <div class="colomn3">&#9745;</div>
    """,
    'en': """
        <div class="colomn1">%s</div>
        <div class="colomn2">%s</div>
        <div class="colomn3">&#9745;</div>
    """
}


def getLicenseText(license: License, lang: str):
    if lang == 'ru':
        data = headerData % ('Артикул', 'Наименование', 'Право')
    else:
        data = headerData % ('Vendor code', 'Name', 'Right')
    if license.getPackage() == "bas":
        data += licenseBlock[lang] % (ESMBasic['title'], ESMBasic[lang])
        # Профессиональная версия
    elif license.getPackage() == "pro":
        data += licenseBlock[lang] % (ESMPro['title'], ESMPro[lang])
    # Ентерпрайз версия
    elif license.getPackage() == "ent":
        data += licenseBlock[lang] % (ESMEnt['title'], ESMEnt[lang])
    else:
        # Демо версия
        data += rowBlock[lang] % (ESMDemo['title'], ESMDemo[lang], 1)
        data += '''
                    </div>
                    </body>
                    </html>'''
        return data

    # Количество АРМ
    data += rowBlock[lang] % (ESMNet['title'], ESMNet[lang],
                              license.getEquipmentsLimit('system', 'workstation'))

    # Количество веб пользователей
    """
    data += rowBlock[lang] % (ESMWebUsers['title'], ESMWebUsers[lang],
                              license.getWebOperatorsCount())
    """

    # Количество сенсоров
    data += rowBlock[lang] % (ESMOMSensor['title'], ESMOMSensor[lang],
                              license.getObservedObjectKindLimit('input'))

    # Количество камер
    data += rowBlock[lang] % (ESMOMCam['title'], ESMOMCam[lang],
                              license.getObservedObjectKindLimit('cam'))

    # Количество считывателей
    data += rowBlock[lang] % (ESMOMReader['title'], ESMOMReader[lang],
                              license.getObservedObjectKindLimit('reader'))

    # Количество ключей
    data += rowBlock[lang] % (ESMOMKey['title'], ESMOMKey[lang],
                              license.getObservedObjectKindLimit('key'))
    # Количество идентификаторов
    data += rowBlock[lang] % (ESMCard['title'], ESMCard[lang],
                              license.getActivatePermitsCount())
    """TODO сделать поддкжку кол-ва терминалов корректировки номеров
    # Количество Терминалов корреткировки номеров
    data += rowBlock[lang] % (ESMUpNumber['title'], ESMUpNumber[lang],
                              license.getNumberCorrectingTerminals())
    """
    # Количество удаленных серверов
    data += rowBlock[lang] % (ESMMONITORING['title'], ESMMONITORING[lang],
                              license.getEquipmentsLimit('remote', 'site'))

    clientLimitations = license.getClientLimitations()
    # Есть ли лицензия на распознавание паспортов через ПО cognitive
    if clientLimitations['scan_api']:
        data += rowBlock[lang] % (ESMPassportRead['title'], ESMPassportRead[lang], '')

    availableEquipments = license.getAvailableEquipments()
    for equip in availableEquipments:
        if equip in equipmentsLicense and lang in equipmentsLicense[equip]:
            data += rowBlockEquip[lang] % (equipmentsLicense[equip]['title'], equipmentsLicense[equip][lang])
        else:
            print('LICENSE FOR EQUIP %s IS NOT AVAILABLE' % equip)
    data += '''
            </div>
            </body>
            </html>'''
    return data
