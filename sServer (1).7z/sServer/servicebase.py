# -*- coding: utf-8 -*-
from threading import Lock
import logging
import abc


class ServiceBase(object, metaclass=abc.ABCMeta):
    def __init__(self):
        self.servicename = ""
        self._logger = logging.getLogger("%s.%s" % (self.__module__, __name__))
        self.__runlock = Lock()
        self.__isRunning = False

    def start(self):
        if self.isRunning():
            return
        try:
            self._logger.info("Service '%s' starting..." % self.servicename)
            self.onStart()
            self._logger.info("Service '%s' started successfully." % self.servicename)
        except Exception as e:
            self._logger.exception(e)

    def stop(self):
        if not self.isRunning():
            return
        try:
            self._logger.info("Service '%s' stopping..." % self.servicename)
            self.onStop()
            self._logger.info("Service '%s' stopped successfully." % self.servicename)
        except Exception as e:
            self._logger.exception(e)

    def restart(self):
        self.stop()
        self.start()

    def isRunning(self):
        self.__runlock.acquire()
        value = self.__isRunning
        self.__runlock.release()
        return value

    def _setRunning(self, value):
        self.__runlock.acquire()
        self.__isRunning = value
        self.__runlock.release()

    @abc.abstractmethod
    def onStart(self):
        pass

    @abc.abstractmethod
    def onStop(self):
        pass
