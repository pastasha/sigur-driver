# -*- coding: utf-8 -*-


class NotifKeys(object):
    notification = 'notification'
    code = 'code'
    statement = 'statement'
    directObj = 'directObj'
    type = 'type'
    equip = 'equip'
    dev = 'dev'
    id = 'id'
    adverbialTime = 'adverbialTime'
    param = 'param'
    params = 'params'
    state = 'state'
    cmd = 'cmd'
    result = 'result'
    msg = 'msg'
    hostName = 'hostName'
    adverbialMode = 'adverbialMode'
    adverbialPlace = 'adverbialPlace'

    ASYNC_RESPONSE = 705
