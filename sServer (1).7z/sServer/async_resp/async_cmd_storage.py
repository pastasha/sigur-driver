# -*- coding: utf-8 -*-

from uuid import uuid4
from threading import Timer


class AsyncCMDStorage(object):
    """
    Container for storing async commands
    """

    def __init__(self):
        self.commands = {}

    def register_cmd(self, cmd, params, timeout=60 * 60):
        """
        Register async cmd at one hour await by default
        :param cmd: cmd name
        :param params: parameters of cmd with hostname PC that is sender of cmd
        :param timeout: timeout of life cmd in storage, one hour by default
        :return: uuid of registered cmd
        """
        cmd_uuid = str(uuid4())
        timer = Timer(timeout, self.unregister_cmd, [cmd_uuid])
        self.commands[cmd_uuid] = {
            'cmd': cmd,
            'hostName': params.get('hostName', None),
            'timer': timer,
        }

        timer.start()

        return cmd_uuid

    def unregister_cmd(self, cmdId):
        """
        Unregister async cmd
        :param cmdId: uuid of registered cmd
        :return: cmd information from storage {cmd, hostname} or None
        """
        return self.pop(cmdId)

    def __contains__(self, item):
        if item in self.commands:
            return True

        return False

    def __getitem__(self, item):
        if item in self:
            return self.commands[item]

        return None

    def __delitem__(self, key):
        if key in self:
            self.commands.pop(key)

    def pop(self, key):
        """
        Remove cmd from storage and stopping cmd live timer
        :param key: uuid of cmd in storage
        :return: cmd information from storage or None
        """
        if key in self:
            if self.commands[key]['timer'].isAlive():
                self.commands[key]['timer'].cancel()
            return self.commands.pop(key)
