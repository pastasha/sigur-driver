# -*- coding: utf-8 -*-

import time

from .notif_keys import NotifKeys


class AsyncMessageMaker(object):
    """
    Make async message (event with code 705) for ESM
    """

    def __init__(self):
        pass

    @classmethod
    def base_notif(cls):
        return {
            NotifKeys.notification: {
                NotifKeys.code: None
            },
            NotifKeys.statement: {
                NotifKeys.adverbialTime: {
                    NotifKeys.param: time.time()
                },
            }
        }

    @classmethod
    def make_async_event(cls, notif, cmd_info):
        notif[NotifKeys.notification].update({
            NotifKeys.code: NotifKeys.ASYNC_RESPONSE,
            NotifKeys.cmd: cmd_info.get('cmd'),
        })

        if cmd_info.get('hostName'):
            notif[NotifKeys.notification].update({
                NotifKeys.hostName: cmd_info.get('hostName')
            })

        return notif

    @classmethod
    def make_async_message(cls, cmd_info, msg, result):
        notif = cls.base_notif()
        notif = cls.make_async_event(notif, cmd_info)
        notif[NotifKeys.notification].update({
            NotifKeys.result: result,
            NotifKeys.msg: msg
        })

        return notif

    @classmethod
    def make_success_message(cls, cmd_info, msg=''):
        """
        Make a success async message
        :param cmd_info: information of registered cmd
        :param msg: text of message
        :return: notification
        """
        return cls.make_async_message(cmd_info, msg, 'ok')

    @classmethod
    def make_warning_message(cls, cmd_info, msg=''):
        """
        Make a warning async message
        :param cmd_info: information of registered cmd
        :param msg: text of message
        :return: notification
        """
        return cls.make_async_message(cmd_info, msg, 'warning')

    @classmethod
    def make_error_message(cls, cmd_info, error=''):
        """
        Make a error async message
        :param cmd_info: information of registered cmd
        :param error: text of message
        :return: notification
        """
        return cls.make_async_message(cmd_info, error, 'error')

    @classmethod
    def make_cmd_info(cls, cmd_name, hostname=None):
        """
        This method might be used for create a cmd_info structure for async messages, if command not in storage
        :param cmd_name: cmd name
        :param hostname: parameters of cmd with hostname PC that is sender of cmd, default None
        :return: cmd_info structure
        """
        return {
            'cmd': cmd_name,
            'hostname': hostname
        }
