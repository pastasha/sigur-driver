# -*- coding: utf-8 -*-

import logging
import logging.config
import inspect
import sys
# TODO need change to faulthandler in python 3.x?
import cgitb

from . import pymetalog_settings as settings

logging.config.dictConfig(settings.PYMETALOG_CONFIG)


class PyMetaLog(type):
    logger = logging.getLogger('pymetalog')

    @classmethod
    def __logobject(cls, target):
        result = []

        for attr in target.__dict__:
            try:
                result.append('#\t{}\t{}'.format(attr, target.__dict__[attr]))
            except:
                pass

        return 'Info of object << {} >> :\n\t\t{}'.format(target, '\n\t\t'.join(result))

    @classmethod
    def __logframe(cls, frame):
        f_locals = frame.f_locals
        result = []
        for key in f_locals:
            try:
                result.append('#\t{}\t{}'.format(key, f_locals[key]))
            except:
                pass

        return 'Local vars of frame:\n\t\t{}'.format('\n\t\t'.join(result))

    @classmethod
    def __wrap(cls, target_cls_name, func):
        def __call_wrapped(*args, **kwargs):
            target_cls = args[0] if len(args) else None

            if isinstance(func, classmethod):
                f = func.__func__
            elif isinstance(func, staticmethod):
                f = func.__func__
            else:
                f = func

            try:
                not_inited_thread = hasattr(target_cls, '_Thread__initialized') and not getattr(target_cls,
                                                                                                '_Thread__initialized')
                if not_inited_thread:
                    cls.logger.debug(
                        'Call << {}.{} >>'.format(target_cls_name, f.__name__))
                else:
                    cls.logger.debug(
                        'Call << {}.{} >> args: {}; kwargs: {}'.format(target_cls_name, f.__name__, args, kwargs))
            except:
                pass

            try:
                return f(*args, **kwargs)

            except Exception as ex:
                # make html dump
                sys.excepthook.handle()

                trace = inspect.trace()
                # last frame is frame that raised exception
                last_trace = trace[len(trace) - 1]
                frame = last_trace[0]

                # if we raise exception don't log it
                if last_trace[3] == '__call_wrapped':
                    raise

                try:
                    if not_inited_thread:
                        call_info = '<< {}.{}\n\t{}>>'.format(target_cls_name, f.__name__, cls.__logframe(frame))
                    else:
                        call_info = '<< {}.{} >> args: {}; kwargs: {}\n\t{}'.format(
                            target_cls_name, f.__name__, args,
                            kwargs, cls.__logframe(frame))

                    if target_cls:
                        obj_info = cls.__logobject(target_cls)
                        error_str = '<<< EXCEPTION at object {} in call {}\n\t{} >>>'.format(target_cls_name, call_info,
                                                                                              obj_info)
                    else:
                        error_str = '<<< EXCEPTION at call {}\n>>>'.format(call_info)

                    cls.logger.error(error_str)
                except:
                    pass

                cls.logger.exception(repr(ex))

                raise

        return __call_wrapped

    def __new__(cls, clsname, superclasses, attributedict):
        if sys.getdefaultencoding() != 'utf-8':
            reload(sys)
            sys.setdefaultencoding('utf-8')
        
        if settings.ENABLE:
            cls.static_methods = {}

            methods = []

            exclude = {'__metaclass__', '__module__'}

            for attr in attributedict:
                if attr in exclude:
                    continue

                value = attributedict[attr]
                value_type = type(value)

                # if value is a function wrap it
                if callable(value) or value_type == classmethod or value_type == staticmethod:
                    methods.append(attr)
                    if isinstance(value, staticmethod):
                        attributedict[attr] = staticmethod(cls.__wrap(clsname, value))
                    elif isinstance(value, classmethod):
                        attributedict[attr] = classmethod(cls.__wrap(clsname, value))
                    else:
                        attributedict[attr] = cls.__wrap(clsname, value)

            cls.logger.debug('PyMetaLog configured for {}. Modify: {}'.format(clsname, methods))

        return type(clsname, superclasses, attributedict)
