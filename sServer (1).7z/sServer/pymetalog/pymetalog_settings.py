# -*- coding: utf-8 -*-

import os

LOGS_PATH = 'logs'
ENABLE = True

# system logging levels
DEBUG_LEVEL = 'DEBUG'
INFO_LEVEL = 'INFO'
WARNING_LEVEL = 'WARNING'
ERROR_LEVEL = 'ERROR'
EXCEPTION_LEVEL = 'EXCEPTION'

# pymetalog use this levels for logging
CONSOLE_LOG_LEVEL = INFO_LEVEL
FILE_LOG_LEVEL = DEBUG_LEVEL
PYMETALOG_LEVEL = INFO_LEVEL

if not os.path.exists(LOGS_PATH):
    os.mkdir(LOGS_PATH)

PYMETALOG_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'pymetalog_Fmt': {
            'format': '%(levelname)-3s [%(asctime)s] %(message)s',
        },
    },
    'handlers': {
        'pymetalog_ConsoleHandler': {
            'level': CONSOLE_LOG_LEVEL,
            'class': 'logging.StreamHandler',
            'formatter': 'pymetalog_Fmt',
        },

        'pymetalog_FileHandler': {
            'level': FILE_LOG_LEVEL,
            'class': 'logging.handlers.TimedRotatingFileHandler',
            'formatter': 'pymetalog_Fmt',
            'filename': 'logs/pymetalog.log',
            'when': 'midnight',
            'backupCount': 5,
            'encoding': 'utf8'
        },
    },
    'loggers': {
        'pymetalog': {
            'handlers': ['pymetalog_ConsoleHandler', 'pymetalog_FileHandler'],
            'level': PYMETALOG_LEVEL,
        },
    },
}
