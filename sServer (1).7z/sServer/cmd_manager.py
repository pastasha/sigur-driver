# -*- coding: utf-8 -*-

import sys

import getLicenseHtml
import version
import json
import logging

from manager.observedobjectmanager import LicenseLimitException
from manager.observedobjectactionexecutor import ActionNotFoundException

from esmapi.serializer import Serializer, SerializerException
from esmapi.commands.baseCommandReply import Reply
from esmapi.notifications.sServerNotifications import StartCommandNotification, FinishCommandNotification
from esmapi.notifications.baseNotification import StartCommandExecutionNotification, FinishCommandExecutionNotification
from esmapi.commands.sServerCommandsReply import GetObservedObjectIdsCommandReply, GetObservedObjectInfoCommandReply,\
    AddObservedObjectCommandLicenseErrorReply, AddObservedObjectCommandSuccessReply,\
    EditObservedObjectCommandSuccessReply, EditObservedObjectCommandErrorReply,\
    DeleteObservedObjectCommandSuccessReply, DeleteObservedObjectCommandErrorReply,\
    ConnectObservedObjectsCommandSuccessReply, ConnectObservedObjectsCommandErrorReply,\
    DisconnectObservedObjectsCommandSuccessReply, DisconnectObservedObjectsCommandErrorReply,\
    ExecObservedObjectActionCommandSuccessReply, ExecObservedObjectActionCommandErrorReply,\
    ExecObservedObjectActionCommandErrorReplyWrongAction
from esmapi.commands.sServerCommandsReply import GetEventCatalogCommandReply, AddEventCommandReply,\
    EditEventCommandSuccessReply, EditEventCommandErrorReply, DeleteEventCommandSuccessReply,\
    DeleteEventCommandErrorReply, GetObservedObjectTypesCommandReply, AddObservedObjectTypeCommandReply,\
    EditObservedObjectTypeCommandSuccessReply, EditObservedObjectTypeCommandErrorReply,\
    DeleteObservedObjectTypeCommandSuccessReply, DeleteObservedObjectTypeCommandErrorReply,\
    GetMapLayerListCommandReply, AddMapLayerCommandReply, EditMapLayerCommandSuccessReply,\
    EditMapLayerCommandErrorReply, DeleteMapLayerCommandSuccessReply, DeleteMapLayerCommandErrorReply, \
    GetObjectsOnMapCommandReply, AddObjectToMapCommandReply, EditObjectOnMapCommandSuccessReply,\
    EditObjectOnMapCommandErrorReply, DeleteObjectFromMapCommandSuccessReply, DeleteObjectFromMapCommandErrorReply,\
    SaveObjectsOnMapCommandReply, GetObjectsOnGisMapCommandReply, AddObjectToGisMapCommandReply,\
    EditObjectOnGisMapCommandSuccessReply, EditObjectOnGisMapCommandErrorReply,\
    DeleteObjectFromGisMapCommandSuccessReply, DeleteObjectFromGisMapCommandErrorReply,\
    SaveObjectsOnGisMapCommandReply, SimulateAlarmCommandReply, GenerateEventCommandReply,\
    SetObservedObjectStateCommandReply, MarkEventAsFalseCommandReply

from esmapi.commands.sServerCommands import GetObservedObjectIdsCommand, GetObservedObjectInfoCommand,\
    AddObservedObjectCommand, EditObservedObjectCommand, DeleteObservedObjectCommand, ConnectObservedObjectsCommand,\
    DisconnectObservedObjectsCommand, ExecObservedObjectActionCommand, GetEventCatalogCommand, AddEventCommand,\
    EditEventCommand, DeleteEventCommand, GetObservedObjectTypesCommand, AddObservedObjectTypeCommand,\
    EditObservedObjectTypeCommand, DeleteObservedObjectTypeCommand, GetMapLayerListCommand, AddMapLayerCommand,\
    EditMapLayerCommand, DeleteMapLayerCommand, GetObjectsOnMapCommand, AddObjectToMapCommand, EditObjectOnMapCommand,\
    DeleteObjectFromMapCommand, SaveObjectsOnMapCommand, GetObjectsOnGisMapCommand, AddObjectToGisMapCommand,\
    EditObjectOnGisMapCommand, DeleteObjectFromGisMapCommand, SaveObjectsOnGisMapCommand, SimulateAlarmCommand,\
    GenerateEventCommand, SetObservedObjectStateCommand, MarkEventAsFalseCommand, GetEquipStructCommand,\
    GetEquipmentCommand, GetEquipListCommand, GetVersionInfoCommand

from esmapi.commands.sServerCommandsReply import GetEquipStructCommandReply, GetEquipListCommandReply,\
    GetEquipmentCommandReply, GetVersionInfoCommandReply, CreateEquipmentObjectSuccessCommandReply,\
    CreateEquipmentObjectCommandErrorReply, DeleteEquipmentObjectSuccessCommandReply,\
    DeleteEquipmentObjectCommandErrorReply, SetEquipmentObjectAttributeSuccessCommandReply,\
    SetEquipmentObjectAttributeCommandErrorReply, SetEquipmentObjectLinkSuccessCommandReply,\
    SetEquipmentObjectLinkCommandErrorReply, AddEquipmentObjectChildSuccessCommandReply,\
    AddEquipmentObjectChildCommandErrorReply, LeaveEquipmentObjectParentSuccessCommandReply,\
    LeaveEquipmentObjectParentCommandErrorReply, CreateEquipmentObjectBridgeSuccessCommandReply,\
    CreateEquipmentObjectBridgeCommandErrorReply, ExecEquipmentObjectActionCommandReply,\
    CreateSubjectSuccessCommandReply, CreateSubjectCommandErrorReply, CopyEquipmentObjectCommandReply,\
    CopyPceAlgorithmCommandReply, AddObservedObjectCommandErrorReply

from esmapi.commands.sServerCommands import CreateEquipmentObjectCommand, DeleteEquipmentObjectCommand,\
    SetEquipmentObjectAttributeCommand, SetEquipmentObjectLinkCommand, AddEquipmentObjectChildCommand,\
    LeaveEquipmentObjectParentCommand, CreateEquipmentObjectBridgeCommand, ExecEquipmentObjectActionCommand,\
    CreateSubjectCommand, CopyEquipmentObjectCommand, CopyPceAlgorithmCommand

from equipment import dev_except


settings = __import__('settings')
sys.path.append('locale')
locale = __import__('%s' % settings.language)

logger = logging.getLogger('sServer')


class CmdManager:
    """
    Класс, реализующий логику выполнения команд
    """

    def __init__(self, evMon, notifyPusher, license, mapLayerManager, eventManager, obsObjTypeManager,
                 observedObjectManager, observedObjectActionExecutor, observedObjectOnMapManager,
                 observedObjectOnGisMapManager, eventCommandsManager):
        """

        :param evMon:
        :param notifyPusher: Для отправки нотификаций о запуске и завершении выполнения команды
        """
        self.__evMon = evMon
        self.__notifyPusher = notifyPusher
        self.__mapLayerManager = mapLayerManager
        self.__eventManager = eventManager
        self.__obsObjTypeManager = obsObjTypeManager
        self.__observedObjectManager = observedObjectManager
        self.__observedObjectActionExecutor = observedObjectActionExecutor
        self.__observedObjectOnMapManager = observedObjectOnMapManager
        self.__observedObjectOnGisMapManager = observedObjectOnGisMapManager
        self.__eventCommandsManager = eventCommandsManager
        self.__license = license

        self.__reqTable = {
            GetObservedObjectIdsCommand.req: self.__getListOO,  # Получить идентификаторы объектов мониторинга
            GetObservedObjectInfoCommand.req: self.__getInfoOOList,  # Получить подробную информацию по объектам мониторинга
            AddObservedObjectCommand.req: self.__addObservedObject,  # Создать объект мониторинга
            EditObservedObjectCommand.req: self.__editObservedObject,  # Изменить объект мониторинга
            DeleteObservedObjectCommand.req	: self.__deleteObservedObject,  # Удалить объект мониторинга
            ConnectObservedObjectsCommand.req: self.__connectObservedObjects,  # Связать объекты мониторинга
            DisconnectObservedObjectsCommand.req: self.__disconnectObservedObjects,  # Отвязать объекты мониторинга
            ExecObservedObjectActionCommand.req: self.__execObservedObjectAction,  # Выполнить действие над объектом мониторинга

            GetEventCatalogCommand.req: self.__getEventCatalog,  # Получить каталог событий
            AddEventCommand.req: self.__addEvent,  # Создать тип события
            EditEventCommand.req: self.__editEvent,  # Изменить тип события
            DeleteEventCommand.req: self.__deleteEvent,  # Удалить тип события

            GetObservedObjectTypesCommand.req: self.__getTypeStructOO,  # Получить типы объектов мониторинга
            AddObservedObjectTypeCommand.req: self.__addOOType,  # Создать тип объекта мониторинга
            EditObservedObjectTypeCommand.req: self.__editOOType,  # Изменить тип объекта мониторинга
            DeleteObservedObjectTypeCommand.req: self.__delOOType,  # Удалить тип объекта мониторинга

            GetMapLayerListCommand.req: self.__getMapLayerList,  # Получить список слоев на картах
            AddMapLayerCommand.req: self.__addMapLayer,  # Создать слой на карте
            EditMapLayerCommand.req: self.__editMapLayer,  # Изменить слой на карте
            DeleteMapLayerCommand.req: self.__delMapLayer,  # Удалить слой на карте

            GetObjectsOnMapCommand.req: self.__getObjectsOnMap,  # Получить список объектов на векторной карте
            AddObjectToMapCommand.req: self.__addObjectToMap,  # Добавить объект на векторныую карту
            EditObjectOnMapCommand.req: self.__editObjectOnMap,  # Изменить объект на векторной карте
            DeleteObjectFromMapCommand.req: self.__deleteObjectFromMap,  # Удалить объект с векторной карты
            SaveObjectsOnMapCommand.req: self.__saveObjectsOnMap,  # Изменить конфигурацию объектов на векторной карте

            GetObjectsOnGisMapCommand.req: self.__getObjectsOnGisMap,  # Получить список объектов на ГИС карте
            AddObjectToGisMapCommand.req: self.__addObjectToGisMap,  # Добавить объект на ГИС карту
            EditObjectOnGisMapCommand.req: self.__editObjectOnGisMap,  # Изменить объект на ГИС карте
            DeleteObjectFromGisMapCommand.req: self.__deleteObjectFromGisMap,  # Удалить объект с ГИС карты
            SaveObjectsOnGisMapCommand.req: self.__saveObjectsOnGisMap,  # Изменить конфигурацию объектов на ГИС карте

            SimulateAlarmCommand.req: self.__simulateAlarm,  # Смоделировать тревогу
            GenerateEventCommand.req: self.__generateEvent,  # Сгенерировать событие
            SetObservedObjectStateCommand.req: self.__setObservedObjectState,  # Установить состояние объекта мониторинга
            MarkEventAsFalseCommand.req: self.__markEventAsFalse,  # Установить ложность события

            GetEquipStructCommand.req: self.__getEquipStruct,  # Получить структуру объектов оборудования
            GetEquipListCommand.req: self.__getEquipList,  # Получить список всех оборудований которые есть в системе
            GetEquipmentCommand.req: self.__getEquipment,  # Получить все объекты конкретного оборудования и типа
            GetVersionInfoCommand.req: self.__getVersionInfo,  # Получить информацию о версии и лицензии

            CreateEquipmentObjectCommand.req: self.__createEquipDev,  # Создать объект оборудования
            DeleteEquipmentObjectCommand.req: self.__delEquipDev,  # Удалить объект оборудования
            SetEquipmentObjectAttributeCommand.req: self.__setEquipAttr,  # Установить атриубт объекта оборудования
            SetEquipmentObjectLinkCommand.req: self.__setEquipLink,  # Установить ссылку объекта оборудования
            AddEquipmentObjectChildCommand.req: self.__addEquipChild,  # Добавить ребенка к объекту оборудования
            # 'removeEquipmentObjectChild': self.__removeEquipChild,  # ++ TODO: реализовать в будущем
            LeaveEquipmentObjectParentCommand.req: self.__leaveEquipParent,
            # Отсоединить объект оборудования от родителя
            CreateEquipmentObjectBridgeCommand.req: self.__createEquipLink,
            # Создать мостовую свзяь между объектами оборудования
            ExecEquipmentObjectActionCommand.req: self.__execAction,  # Выполнить действие у объекта оборудования

            CreateSubjectCommand.req: self.__createSubject,  # Создать субъект
            CopyEquipmentObjectCommand.req: self.__copyEquipObj,  # Скопировать объект оборудования
            CopyPceAlgorithmCommand.req: self.__copyPceAlg,  # Скопировать алгоритм pce
            # TODO: это надо оживлять отдельно
            'createPceAlg': self.__createPceAlg
        }

        self.__commandsNotSendProcessingNotifications = [GetObservedObjectIdsCommand.req,
                                                         GetObservedObjectInfoCommand.req,
                                                         GetObservedObjectTypesCommand.req, GetEventCatalogCommand.req,
                                                         GetMapLayerListCommand.req, GetObjectsOnMapCommand.req,
                                                         GetObjectsOnGisMapCommand.req, GetEquipStructCommand.req,
                                                         GetEquipmentCommand.req, GetEquipListCommand.req,
                                                         GetVersionInfoCommand.req]

    def runCommand(self, cmd):
        with self.__evMon:
            if isinstance(cmd, dict) and 'author' in cmd:
                self.__evMon.setCurrOperator(cmd['author'])

            reply = self.__runCommand(cmd)

            if isinstance(cmd, dict) and 'author' in cmd:
                reply['author'] = cmd['author']

            return reply

    def __runCommand(self, cmd):
        """
        Выполнить команду
        """
        try:
            command = Serializer.deserialize(cmd)
        except SerializerException as e:
            logging.error('error parsing request %s %s' % (cmd, repr(e)))
            res = Reply(status='error', msg=Reply.Msg('error in request %s' % repr(e), 'error'))
            return Serializer.serialize(res)
        if command:
            try:
                if command.req not in self.__commandsNotSendProcessingNotifications:
                    self.__notifyPusher.push(StartCommandNotification(StartCommandExecutionNotification.Statement(
                        command.req, command.executorSiteId)))
                if command.req in self.__reqTable:
                    res = self.__reqTable[command.req](command)
            except Exception as e:
                logging.exception("error processing request %s" % cmd)
                # TODO: надо бы подставить сюда req как-то
                res = Reply(status='error', author=command.author,
                            msg=Reply.Msg('error processing request %s' % e, 'error'))
            finally:
                if command.req not in self.__commandsNotSendProcessingNotifications:
                    self.__notifyPusher.push(FinishCommandNotification(FinishCommandExecutionNotification.Statement(
                        command.req, command.executorSiteId)))
        else:
            logging.error('undefRequest %s' % cmd)
            res = Reply(status='error', msg=Reply.Msg('undefRequest', 'error'))
        return Serializer.serialize(res)

    def __getEventCatalog(self, cmd):
        return GetEventCatalogCommandReply(GetEventCatalogCommandReply.RepData(self.__eventManager.getEvents()))

    def __addEvent(self, cmd):
        event = self.__eventManager.addEvent(cmd)
        return AddEventCommandReply(AddEventCommandReply.RepData(event.id))

    def __editEvent(self, cmd):
        res = self.__eventManager.editEvent(cmd)
        if res:
            return EditEventCommandSuccessReply()
        else:
            return EditEventCommandErrorReply()

    def __deleteEvent(self, cmd):
        self.__obsObjTypeManager.deleteEventsRedirection(cmd.reqData)
        res = self.__eventManager.deleteEvent(cmd)
        if res:
            return DeleteEventCommandSuccessReply()
        else:
            return DeleteEventCommandErrorReply()

    def __generateEvent(self, cmd):
        self.__eventCommandsManager.generateEvent(cmd)
        return GenerateEventCommandReply()

    def __simulateAlarm(self, cmd):
        self.__eventCommandsManager.simulateAlarm(cmd)
        return SimulateAlarmCommandReply()

    def __setObservedObjectState(self, cmd):
        self.__observedObjectManager.setState(cmd)
        return SetObservedObjectStateCommandReply()

    def __execObservedObjectAction(self, cmd):
        """
        Выполнение команды объекта мониторинга
        """
        try:
            res = self.__observedObjectActionExecutor.execAction(cmd)
            if res:
                return ExecObservedObjectActionCommandSuccessReply()
            else:
                return ExecObservedObjectActionCommandErrorReply()
        except ActionNotFoundException as e:
            return ExecObservedObjectActionCommandErrorReplyWrongAction(e.actName)

    def __getListOO(self, cmd):
        """
        Получение списка объектов мониторинга
        """
        return GetObservedObjectIdsCommandReply(
            GetObservedObjectIdsCommandReply.RepData([obj.id for obj in self.__observedObjectManager.getObjects()]))

    def __getInfoOOList(self, cmd):
        return GetObservedObjectInfoCommandReply(
            GetObservedObjectInfoCommandReply.RepData(self.__observedObjectManager.getInformation(cmd)))

    def __addObservedObject(self, cmd):
        """
        Добавление объектов мониторинга
        """
        try:
            obj, msg = self.__observedObjectManager.addObject(cmd)
            if obj:
                return AddObservedObjectCommandSuccessReply(AddObservedObjectCommandSuccessReply.RepData(obj.id))
            else:
                return AddObservedObjectCommandErrorReply(msg=msg)

        except LicenseLimitException as e:
            return AddObservedObjectCommandLicenseErrorReply(e.count, e.kind)

    def __deleteObservedObject(self, cmd):
        self.__observedObjectOnMapManager.deleteObjectFromAllMaps(cmd.reqData)
        self.__observedObjectOnGisMapManager.deleteObjectFromAllMaps(cmd.reqData)
        res = self.__observedObjectManager.deleteObject(cmd)
        if res:
            return DeleteObservedObjectCommandSuccessReply()
        else:
            return DeleteObservedObjectCommandErrorReply()

    def __editObservedObject(self, cmd):
        res, msg = self.__observedObjectManager.editObject(cmd)
        if res:
            return EditObservedObjectCommandSuccessReply()
        else:
            return EditObservedObjectCommandErrorReply(msg=msg)

    def __disconnectObservedObjects(self, cmd):
        res = self.__observedObjectManager.disconnectObjects(cmd)
        if res:
            return DisconnectObservedObjectsCommandSuccessReply()
        else:
            return DisconnectObservedObjectsCommandErrorReply()

    def __connectObservedObjects(self, cmd):
        res = self.__observedObjectManager.connectObjects(cmd)
        if res:
            return ConnectObservedObjectsCommandSuccessReply()
        else:
            return ConnectObservedObjectsCommandErrorReply()

    def __markEventAsFalse(self, cmd):
        self.__eventCommandsManager.markEventAsFalse(cmd)
        return MarkEventAsFalseCommandReply()

    def __getTypeStructOO(self, cmd):
        return GetObservedObjectTypesCommandReply(
            GetObservedObjectTypesCommandReply.RepData(self.__obsObjTypeManager.getTypes()))

    def __addOOType(self, cmd):
        objType = self.__obsObjTypeManager.addType(cmd)
        return AddObservedObjectTypeCommandReply(AddObservedObjectTypeCommandReply.RepData(objType.id))

    def __editOOType(self, cmd):
        res = self.__obsObjTypeManager.editType(cmd)
        if res:
            return EditObservedObjectTypeCommandSuccessReply()
        else:
            return EditObservedObjectTypeCommandErrorReply()

    def __delOOType(self, cmd):
        res = self.__obsObjTypeManager.deleteType(cmd)
        if res:
            return DeleteObservedObjectTypeCommandSuccessReply()
        else:
            return DeleteObservedObjectTypeCommandErrorReply()

    def __getMapLayerList(self, cmd):
        return GetMapLayerListCommandReply(GetMapLayerListCommandReply.RepData(self.__mapLayerManager.getLayers()))

    def __addMapLayer(self, cmd):
        layer = self.__mapLayerManager.addLayer(cmd)
        return AddMapLayerCommandReply(AddMapLayerCommandReply.RepData(layer.id))

    def __editMapLayer(self, cmd):
        res = self.__mapLayerManager.editLayer(cmd)
        if res:
            return EditMapLayerCommandSuccessReply()
        else:
            return EditMapLayerCommandErrorReply()

    def __delMapLayer(self, cmd):
        self.__observedObjectManager.deleteLayerFromObsObj(cmd.reqData)
        res = self.__mapLayerManager.deleteLayer(cmd)
        if res:
            return DeleteMapLayerCommandSuccessReply()
        else:
            return DeleteMapLayerCommandErrorReply()

    def __getObjectsOnMap(self, cmd):
        return GetObjectsOnMapCommandReply(
            GetObjectsOnMapCommandReply.RepData(self.__observedObjectOnMapManager.getObjectsOnMap(cmd)))

    def __addObjectToMap(self, cmd):
        obj = self.__observedObjectOnMapManager.addObjectToMap(cmd)
        return AddObjectToMapCommandReply(AddObjectToMapCommandReply.RepData(obj.id))

    def __editObjectOnMap(self, cmd):
        res = self.__observedObjectOnMapManager.editObjectOnMap(cmd)
        if res:
            return EditObjectOnMapCommandSuccessReply()
        else:
            return EditObjectOnMapCommandErrorReply()

    def __deleteObjectFromMap(self, cmd):
        res = self.__observedObjectOnMapManager.deleteObjectFromMap(cmd)
        if res:
            return DeleteObjectFromMapCommandSuccessReply()
        else:
            return DeleteObjectFromMapCommandErrorReply()

    def __saveObjectsOnMap(self, cmd):
        self.__observedObjectOnMapManager.saveObjectsOnMap(cmd)
        return SaveObjectsOnMapCommandReply()

    def __getObjectsOnGisMap(self, cmd):
        return GetObjectsOnGisMapCommandReply(
            GetObjectsOnGisMapCommandReply.RepData(self.__observedObjectOnGisMapManager.getObjectsOnMap(cmd)))

    def __addObjectToGisMap(self, cmd):
        obj = self.__observedObjectOnGisMapManager.addObjectToMap(cmd)
        return AddObjectToGisMapCommandReply(AddObjectToGisMapCommandReply.RepData(obj.id))

    def __editObjectOnGisMap(self, cmd):
        res = self.__observedObjectOnGisMapManager.editObjectOnMap(cmd)
        if res:
            return EditObjectOnGisMapCommandSuccessReply()
        else:
            return EditObjectOnGisMapCommandErrorReply()

    def __deleteObjectFromGisMap(self, cmd):
        res = self.__observedObjectOnGisMapManager.deleteObjectFromMap(cmd)
        if res:
            return DeleteObjectFromGisMapCommandSuccessReply()
        else:
            return DeleteObjectFromGisMapCommandErrorReply()

    def __saveObjectsOnGisMap(self, cmd):
        self.__observedObjectOnGisMapManager.saveObjectsOnMap(cmd)
        return SaveObjectsOnGisMapCommandReply()

    def __getEquipStruct(self, req):
        return GetEquipStructCommandReply(GetEquipStructCommandReply.RepData(self.__evMon.getEquipmentStruct()))

    def __getEquipList(self, req):
        struct = self.__evMon.getEquipmentStruct()
        equipments = []
        for equipment in struct:
            equipments.append({
                'name': equipment,
                'alias': struct[equipment]['alias']
            })
        return GetEquipListCommandReply(GetEquipListCommandReply.RepData(equipments))

    def __getEquipment(self, req):
        reqData = req.reqData
        equip = reqData.equip
        type = reqData.type
        index = reqData.index
        dump = self.__evMon.equipExport(equip, type, index if index else None)
        return GetEquipmentCommandReply(GetEquipmentCommandReply.RepData(equip, type, dump))

    def __getVersionInfo(self, req):
        lang = req.reqData.lang
        vers = version.getVersion()
        endTime = self.__license.getEndTime()
        license = getLicenseHtml.getLicenseText(self.__license, lang)
        return GetVersionInfoCommandReply(GetVersionInfoCommandReply.RepData(vers, endTime, license))

    def __createEquipDev(self, req):
        reqData = req.reqData
        equipName = reqData.equip
        typeName = reqData.type
        siteId = reqData.siteId
        attributes = reqData.attributes
        bridges = reqData.bridges
        parent = reqData.parent
        remoteGuid = reqData.remoteGuid
        ignoreCreateObjects = reqData.ignoreCreateObjects
        force = reqData.force

        try:
            info = {}
            newId = self.__evMon.createEquipmentObject(equipName, typeName, siteId, remoteGuid, attributes, bridges,
                                                       parent, ignoreCreateObjects, force, info)
            repData = CreateEquipmentObjectSuccessCommandReply.RepData(newId)
            reply = CreateEquipmentObjectSuccessCommandReply(repData)
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
                # TODO: обратить внимание на это
                reply.msg.level = info['msg']['type']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Create equipment object error')
            res = CreateEquipmentObjectCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __delEquipDev(self, req):
        reqData = req.reqData
        equipName = reqData.equip
        typeName = reqData.type
        id = reqData.id
        remoteGuid = reqData.remoteGuid

        try:
            info = {}
            res = self.__evMon.deleteEquipmentObject(equipName, typeName, id, remoteGuid, info)
            if res:
                # если оборудование удалилось, найдем и удалим ОМ связанный с удаленным объектом оборудования
                self.__observedObjectManager.deleteLinkedObsObjWithEquip(equipName, typeName, id, remoteGuid)
                reply = DeleteEquipmentObjectSuccessCommandReply()
                if 'msg' in info:
                    reply.msg.text = info['msg']['txt']
                return reply
            else:
                return DeleteEquipmentObjectCommandErrorReply()
        except dev_except.EquipmentException as e:
            logging.exception('Delete equipment object error')
            res = DeleteEquipmentObjectCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __setEquipAttr(self, req):
        reqData = req.reqData
        obj = reqData.obj
        equipName = obj.equip
        typeName = obj.type
        id = obj.id
        remoteGuid = obj.remoteGuid
        attrName = reqData.attrName
        attrValue = reqData.attrValue
        force = reqData.force
        try:
            info = {}
            self.__evMon.setEquipmentObjectsAttribute(equipName, typeName, id, remoteGuid, attrName, attrValue, force,
                                                      info)
            reply = SetEquipmentObjectAttributeSuccessCommandReply()
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Set equipment object attribute error')
            res = SetEquipmentObjectAttributeCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __setEquipLink(self, req):
        reqData = req.reqData
        obj = reqData.obj
        objEquipName = obj.equip
        objTypeName = obj.type
        objId = obj.id
        objRemoteGuid = obj.remoteGuid
        force = reqData.force

        lnEquipName = None
        lnTypeName = None
        lnId = None
        lnRemoteGuid = None
        linkName = reqData.linkName
        if reqData.linkedObj:
            linkedObj = reqData.linkedObj
            lnEquipName = linkedObj.equip
            lnTypeName = linkedObj.type
            lnId = linkedObj.id
            lnRemoteGuid = linkedObj.remoteGuid
        try:
            info = {}
            if lnTypeName:
                self.__evMon.setEquipmentObjectsLink(objEquipName, objTypeName, objId, objRemoteGuid, lnEquipName,
                                                     lnTypeName, lnId, lnRemoteGuid, linkName, force, info)
            else:
                self.__evMon.clrEquipmentObjectsLink(objEquipName, objTypeName, objId, objRemoteGuid,
                                                     linkName, info)
            reply = SetEquipmentObjectLinkSuccessCommandReply()
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Set equipment object link error')
            res = SetEquipmentObjectLinkCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __addEquipChild(self, req):
        reqData = req.reqData
        parentObj = reqData.parentObj
        childObj = reqData.childObj
        equipName = parentObj.equip
        parentTypeName = parentObj.type
        parentId = parentObj.id
        parentRemoteGuid = parentObj.remoteGuid
        childTypeName = childObj.type
        childId = childObj.id
        childRemoteGuid = childObj.remoteGuid
        addr = reqData.addr

        try:
            info = {}
            # TODO: какая-то дичь. Вроде может использоваться только при привешивании право к пропуску и как то связано
            #  с увровнем безопастности
            # if 'dlg' in req['reqData']:
            #    info['dlg'] = req['reqData']['dlg']
            self.__evMon.addEquipmentChild(equipName, parentTypeName, parentId, parentRemoteGuid, childTypeName,
                                           childId, childRemoteGuid, addr, info)
            reply = AddEquipmentObjectChildSuccessCommandReply()
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Add equipment object child error')
            res = AddEquipmentObjectChildCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __leaveEquipParent(self, req):
        reqData = req.reqData
        equipName = reqData.equip
        typeName = reqData.type
        id = reqData.id
        remoteGuid = reqData.remoteGuid
        try:
            info = {}
            self.__evMon.leaveEquipmentParent(equipName, typeName, id, remoteGuid, info)
            reply = LeaveEquipmentObjectParentSuccessCommandReply()
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Leave equipment object parent error')
            res = LeaveEquipmentObjectParentCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __createEquipLink(self, req):
        reqData = req.reqData
        obj = reqData.obj
        linkedObj = reqData.linkedObj
        objEquipName = obj.equip
        objTypeName = obj.type
        objId = obj.id
        lnEquipName = linkedObj.equip
        lnTypeName = linkedObj.type
        lnId = linkedObj.id
        linkName = reqData.linkName
        addr = reqData.addr
        bridgeAttrs = reqData.bridgeAttrs
        try:
            info = {}
            # TODO: какая-то дичь. Вроде может использоваться только при привешивании право к пропуску и как то связано
            #  с увровнем безопастности
            # if 'dlg' in req['reqData']:
            #    info['dlg'] = req['reqData']['dlg']
            self.__evMon.createEquipmentLink(objEquipName, objTypeName, objId, lnEquipName, lnTypeName, lnId, linkName,
                                             addr, bridgeAttrs, info)
            reply = CreateEquipmentObjectBridgeSuccessCommandReply()
            if 'msg' in info:
                reply.msg.text = info['msg']['txt']
            return reply
        except dev_except.EquipmentException as e:
            logging.exception('Create equipment bridge error')
            res = CreateEquipmentObjectBridgeCommandErrorReply()
            res.msg.text += ' %s' % str(e)
            return res

    def __execAction(self, req):
        reqData = req.reqData
        obj = reqData.obj
        actName = reqData.act
        params = reqData.params

        equipName = obj.equip
        typeName = obj.type
        id = obj.id
        remote_guid = obj.remoteGuid
        # TODO: подозрительно
        params['hostName'] = req.author.apmid

        reply = ExecEquipmentObjectActionCommandReply()
        try:
            res = self.__evMon.execEquipmentAction(equipName, typeName, id, remote_guid, actName, params)
            if res and isinstance(res, dict):
                # TODO: подозрительно
                reply.msg.text = res.get('txt', '')
                reply.msg.level = res.get('type', 'info')
            else:
                reply.repData.data = res
        except Exception as e:
            # TODO: подозрительно
            reply.status = 'error'
            reply.msg.text = str(e)
            reply.msg.level = 'error'
        return reply

    def __createSubject(self, req):
        """
        На самом деле это в чистом виде createEquipDev, нужный для создания человека, машины или вещи из бюро пропусков
        Добавляет в ответ еще и id cубъекта, а не только того кого мы создавали
        """
        reqData = req.reqData
        newReqData = CreateEquipmentObjectCommand.ReqData('common', reqData.type, attributes=reqData.attributes)
        newCmd = CreateEquipmentObjectCommand(newReqData)
        result = self.__createEquipDev(newCmd)
        if result.status == 'error':
            return CreateSubjectCommandErrorReply()
        else:
            # TODO: подозрительно
            subjectId = self.__evMon.getEquipObj({
                'equip': 'common',
                'type': reqData.type,
                'id': result.repData.newId
            }).getParent().getUniID()

            repData = CreateSubjectSuccessCommandReply.RepData(result.repData.newId, subjectId)
            reply = CreateSubjectSuccessCommandReply(repData)
            return reply

    def __copyEquipObj(self, req):
        """
        Копирование объектов оборудования.
        Кратко суть: возьмем из запроса айдишники объектов
        и сделаем список словарей, в которых по ключу 'obj'
        будут сами объекты, по ключу 'links' -- всякие
        ссылки, по ключу 'attrs' -- всякие атрибуты, и
        вызовем в цикле создание ссылок и мостовых связей.
        Если нужно крутое копирование вместе с детьми и их
        атрибутами, то для них рекурсивно вызываем копирование,
        после чего прикрепляем их к новому родителю.
        """
        reqData = req.reqData
        obj = reqData.obj
        equipName = obj.equip
        typeName = obj.type
        objId = obj.id
        deep = reqData.deep
        newId = self.__copyEquipObjInternal(equipName, typeName, objId, deep)
        return CopyEquipmentObjectCommandReply(CopyEquipmentObjectCommandReply.RepData(newId))

    def __copyEquipObjInternal(self, equipName, typeName, objId, deep):
        attrList = self.__evMon.getEquipmentObjectsAttributes(equipName, typeName, objId)
        obj = self.__evMon.getEquipObj({'equip': equipName, 'type': typeName, 'id': objId})
        newId = self.__copyObj(equipName, typeName, attrList, obj, deep)
        return newId

    def __copyObj(self, equipName, typeName, attrs, obj, deep):
        typeStruct = self.__evMon.getEquipmentStruct()

        newObjId = self.__evMon.createEquipmentObject(equipName, typeName, obj.getSiteId(), '', attrs)

        # прицепим к родителю
        if obj.hasParent():
            par = obj.getParent()
            # Попытаемся сосчитать адрес, иначе падает копирование алгоритмов pce
            addr = max(par.children[typeName].keys()) + 1
            try:
                self.__evMon.addEquipmentChild(equipName, par.getTypeName(), par.getUniID(), '', typeName, newObjId, '',
                                               addr)
            except dev_except.PostActionFail:
                # Это надо для подавления ошибки прогрузки в PCE если мы копируем алгоритм который не на шине
                pass

        for childType in obj.children:
            if typeStruct[equipName]['types'][childType]['brg']:
                for addr in obj.children[childType]:
                    linkname = list(typeStruct[equipName]['types'][childType]['links'].keys())[0]
                    linkedObj = obj.children[childType][addr]
                    realLinkedObj = linkedObj.getLinkedElement(linkname)
                    lnEquipName = realLinkedObj.equipment.getName()
                    try:
                        self.__evMon.createEquipmentLink(equipName, typeName, newObjId, lnEquipName, linkname,
                                                         realLinkedObj.getUniID(), childType, addr)
                    except dev_except.PostActionFail:
                        # Это надо для подавления ошибки прогрузки в PCE если мы копируем алгоритм который не на шине
                        pass
            else:
                if deep:
                    for addr in obj.children[childType].keys():
                        child = obj.children[childType][addr]
                        attrList = self.__evMon.getEquipmentObjectsAttributes(equipName, child.getTypeName(),
                                                                              child.getUniID())
                        childObj = self.__evMon.getEquipObj({
                            'equip': equipName,
                            'type': child.getTypeName(),
                            'id': child.getUniID()
                        })
                        childId = self.__copyObj(equipName, child.getTypeName(), attrList, childObj, deep)
                        try:
                            self.__evMon.addEquipmentChild(equipName, typeName, newObjId, '', childType, childId, '',
                                                           addr)
                        except BaseException:
                            pass
        return newObjId

    def __copyPceAlg(self, req):
        # Специальная функция для копирования алгоритма PCE
        reqData = req.reqData
        objId = reqData.algId
        # Часть baseNamePart из имен всех объектов копируемого алгоритма заменим на newNamePart
        baseNamePart = reqData.algBaseNamePart
        newNamePart = reqData.algNewNamePart
        obsObjBaseNamePart = reqData.obsObjBaseNamePart
        obsObjNewNamePart = reqData.obsObjNewNamePart
        # Список соответствий объектов из копируемого алгоритма к новому (для копирования объектов мониторинга)
        parentAlgObjToNewAlgObj = []
        # Объект копируемого алгоритма
        parentAlg = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'alg', 'id': objId})
        parentAlgDescr = parentAlg.getAttribute('description')  # Название копируемого алгоритма
        algClass = parentAlg.getLinkedElement('algclass')  # Класс этого алгоритма
        logging.info('Start copy pce alg \'%s\' having class \'%s\'' % (parentAlgDescr,
                                                                        algClass.getAttribute('description')))
        # Виртуальные объекты содержащиеся в классе алгоритма
        algClassConnectedObjects = algClass.getChildListByType('vobj')
        parentAlgConnectedObjectsBrg = parentAlg.getChildListByType('alg_object')
        parentAlgConnectedObjects = []  # Реальные объекты привязанные к алгоритму
        for brgObj in parentAlgConnectedObjectsBrg:
            parentAlgConnectedObjects.append(brgObj.getLinkedElement('object'))
        # Словарь соотношений между узлами к которым были привязаны объекты из исходного алгоритма и
        # скопированными узлами
        parentNodeIdToNewNodeIdBrg = {}
        # Словать соотношений между зонами старого и нового алгоритмов
        parentAreaIdToNewAreaIdBrg = {}
        # Словарь соотношение между командами старого и нового алгоритма
        parentCommandIdToNewCommandIdBrg = {}
        parentInputIdToNewInputIdBrg = {}
        # Создадим копию алгоритма
        newAlgDescription = parentAlgDescr.replace(baseNamePart, newNamePart) if baseNamePart in parentAlgDescr else\
            parentAlgDescr + '_copy'
        attrs = {
            'description'	: newAlgDescription,
            'algclass'		: {
                'type'		: 'algclass',
                'id'		: algClass.getUniID()
            }
        }
        siteId = parentAlg.getSiteId()
        newAlgId = self.__evMon.createEquipmentObject('pce', 'alg', siteId, '', attrs)
        # Объект нового алгоритма
        newAlg = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'alg', 'id': newAlgId})
        logging.getLogger('console').info('New alg has id %s and name %s' % (newAlgId, attrs['description']))
        # Сделаем несколько проходов
        # На первом проходе скопируем области, чтобы потом привязать их к копиям команд
        # На втором проходе скопируем команды, чтобы потом изменить ссылки на команды у считывателей
        # Потом скопируем входы чтобы потом изменить мостовые связи на них у раздела
        for objType in ('area', 'command', 'input', 'other'):
            # Пройдем по всем объектам привязанным к копируемому алгоритму
            for i in range(len(parentAlgConnectedObjects)):
                # Привязаный объект
                parentAlgObj = parentAlgConnectedObjects[i]
                # Мостовая связь соответствующая привязанному объекту
                parentAlgObjBrg = parentAlgConnectedObjectsBrg[i]
                # Адрес объекта с которым он привязан к алгоритму
                objAddr = parentAlgObjBrg.getAddr()
                algClassVObj = None
                for vobj in algClassConnectedObjects:
                    if vobj.getAddr() == objAddr:
                        algClassVObj = vobj  # Виртуальный объект соответствующий текущему реальному
                        break
                isglobal = False
                if algClassVObj:
                    isglobal = algClassVObj.getAttribute('isglobal')
                # Если в классе объект указан как глобальный значит реальный объект копировать не нужно, а к
                # новому алгоритму нужно привязать тот же объект
                # что и у родительского, если же объект не глобальный, то нужно скопировать реальный объект и
                # уже его привязать
                parentAlgObjTypeName = parentAlgObj.getTypeName()
                parentAlgObjId = parentAlgObj.getUniID()
                if objType == 'command' and parentAlgObjTypeName != 'command':
                    continue
                if objType == 'area' and parentAlgObjTypeName != 'area':
                    continue
                if objType == 'input' and parentAlgObjTypeName != 'input':
                    continue
                if objType == 'other' and parentAlgObjTypeName in ('area', 'command', 'input'):
                    continue
                if isglobal:
                    logging.info('Link global real object from parent algorithm pce %s id %s to new algorithm id '
                                 '%s on addr %s' % (parentAlgObjTypeName, parentAlgObjId, newAlgId, objAddr))
                    self.__evMon.createEquipmentLink('pce', 'alg', newAlgId, 'pce', parentAlgObjTypeName,
                                                     parentAlgObjId, 'alg_object', objAddr)
                else:
                    logging.info('Copy real object from parent algorithm pce %s id %s for addr %s' % (
                        parentAlgObjTypeName, parentAlgObjId, objAddr))
                    # Сначала скопируем объект со всеми его атрибутами, ссылки и дети привяжутся такие же какие
                    # были у исхоного объекта
                    copyReq = {
                        'reqData'	: {
                            'equip'	: 'pce',
                            'type'	: parentAlgObjTypeName,
                            'id'	: [parentAlgObjId],
                            'deep'	: False
                        }
                    }
                    newAlgObjId = self.__copyEquipObjInternal('pce', parentAlgObjTypeName, parentAlgObjId, False)
                    # Добавим в массив соответствий
                    parentAlgObjToNewAlgObj.append([{
                        'equip'	: 'pce',
                        'type'	: parentAlgObjTypeName,
                        'id'	: parentAlgObjId
                    }, {
                        'equip'	: 'pce',
                        'type'	: parentAlgObjTypeName,
                        'id'	: newAlgObjId
                    }
                    ])
                    logging.info('Copy of real object has id %s' % newAlgObjId)
                    # Изменим имя нового объекта и привяжем его к алгоритму
                    objDescr = parentAlgObj.getAttribute('description')
                    objDescr = objDescr.replace(baseNamePart, newNamePart) if baseNamePart in objDescr else\
                        objDescr + '_copy#%s' % newAlgId
                    info = {}
                    self.__evMon.setEquipmentObjectsAttribute('pce', parentAlgObjTypeName, newAlgObjId, '',
                                                              'description', objDescr, False, info)
                    # Привесим скопированный объект на новый алгоритм
                    self.__evMon.createEquipmentLink('pce', 'alg', newAlgId, 'pce', parentAlgObjTypeName, newAlgObjId,
                                                     'alg_object', objAddr)
                    # Для каждого типа реального объекта будем делать свои действия
                    if parentAlgObjTypeName == 'command':
                        # Для команды сделаем специальное действие, изменим ссылку на алгоритм на новый
                        # алгоритм вместо родительского (так получилось после копирования)
                        self.__evMon.setEquipmentObjectsLink('pce', 'command', newAlgObjId, '', 'pce', 'alg', newAlgId,
                                                             '', 'algorithm', False, info)
                        # Еще если у алгоритма были ссылки на области и для этих областей есть копии нужно
                        # сменить ссылки на копии областей
                        command = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'command', 'id': newAlgObjId})
                        if command.isLinkedElement('area'):
                            areaId = command.getLinkedElement('area').getUniID()
                            if areaId in parentAreaIdToNewAreaIdBrg:
                                self.__evMon.setEquipmentObjectsLink('pce', 'command', newAlgObjId, '', 'pce', 'area',
                                                                     parentAreaIdToNewAreaIdBrg[areaId], '', 'area',
                                                                     False, info)
                        if command.isLinkedElement('toArea'):
                            areaId = command.getLinkedElement('toArea').getUniID()
                            if areaId in parentAreaIdToNewAreaIdBrg:
                                self.__evMon.setEquipmentObjectsLink('pce', 'command', newAlgObjId, '', 'pce', 'area',
                                                                     parentAreaIdToNewAreaIdBrg[areaId], '', 'toArea',
                                                                     False, info)
                        # Занесем команду в словарь соответствий для подмены в считывателе
                        parentCommandIdToNewCommandIdBrg[parentAlgObjId] = newAlgObjId
                        # Для команды создадим еще и право и привесим эту команду к праву
                        rightAttrs = {
                            'description'	: objDescr,
                            'command'		: {
                                'type'	: 'command',
                                'id'	: newAlgObjId
                            }
                        }
                        self.__evMon.createEquipmentObject('pce', 'pceright', siteId, '', rightAttrs)
                        # Так как для прав не создаются объекты мониторинга то не будем добавлять их в список
                        # соответствий
                    elif parentAlgObjTypeName in ('input', 'output', 'display', 'reader'):
                        # Если это вход, выход, дисплей или считыватель найдем узел (dc) к которому был
                        # привязан исходный объект, дальше посмотрим не копировали мы еще это узел.
                        # Если этот узел уже скопирован то привяжем новый объект к новому узлу. Если узел еще
                        # не скопирован, то скопируем узел и привяжем объект к новому узлу
                        # и добавим соответствие между старым и новым узлом
                        if parentAlgObjTypeName == 'input':
                            parentInputIdToNewInputIdBrg[parentAlgObjId] = newAlgObjId
                        if parentAlgObj.hasParent():
                            # Узел к которому привязан объект из исходного алгоритма
                            parentAlgObjNode = parentAlgObj.getParent()
                            parentNodeId = parentAlgObjNode.getUniID()
                            if parentNodeId not in parentNodeIdToNewNodeIdBrg:
                                logging.info('Copy pce node %s' % parentNodeId)
                                # Если для узла из реального алгоритма еще была сделана копия сделаем ее
                                newNodeId = self.__copyEquipObjInternal('pce', 'node', parentNodeId, False)
                                parentAlgObjToNewAlgObj.append([{
                                    'equip'	: 'pce',
                                    'type'	: 'node',
                                    'id'	: parentNodeId
                                }, {
                                    'equip'	: 'pce',
                                    'type'	: 'node',
                                    'id'	: newNodeId
                                }
                                ])
                                logging.info('New node has id %s' % newNodeId)
                                # Изменим имя нового объекта и привяжем его к алгоритму
                                objDescr = parentAlgObjNode.getAttribute('description')
                                objDescr = objDescr.replace(baseNamePart, newNamePart) if baseNamePart in objDescr\
                                    else objDescr + '_copy#%s' % newAlgId
                                self.__evMon.setEquipmentObjectsAttribute('pce', 'node', newNodeId, '', 'description',
                                                                          objDescr, False, info)
                                parentNodeIdToNewNodeIdBrg[parentNodeId] = newNodeId
                            # Ид скопированного узла
                            newNodeId = parentNodeIdToNewNodeIdBrg[parentNodeId]
                            # Привесим к новому узлу новый объект с тем же адресом с каким был привешен объект
                            # из исходного алгоритма
                            try:
                                self.__evMon.addEquipmentChild('pce', 'node', newNodeId, '', parentAlgObjTypeName,
                                                               newAlgObjId, '', parentAlgObj.getAddr(), info)
                            except dev_except.PostActionFail:
                                # Это надо для подавления ошибки прогрузки в PCE если мы копируем алгоритм который не
                                # на шине
                                pass
                        # Для считывателя будем делать специальные действия, заменим ссылки на команды, если
                        # команды привязанные к считывателю были скопированы
                        if parentAlgObjTypeName == 'reader':
                            reader = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'reader', 'id': newAlgObjId})
                            # Заменим ссылки
                            if reader.isLinkedElement('defaultDisarm'):
                                defaultDisarm = reader.getLinkedElement('defaultDisarm').getUniID()
                                if defaultDisarm in parentCommandIdToNewCommandIdBrg:
                                    self.__evMon.setEquipmentObjectsLink('pce', 'reader', newAlgObjId, '', 'pce',
                                                                         'command',
                                                                         parentCommandIdToNewCommandIdBrg[defaultDisarm],
                                                                         '', 'defaultDisarm', False, info)
                            if reader.isLinkedElement('defaultArm'):
                                defaultArm = reader.getLinkedElement(
                                    'defaultArm').getUniID()
                                if defaultArm in parentCommandIdToNewCommandIdBrg:
                                    self.__evMon.setEquipmentObjectsLink('pce', 'reader', newAlgObjId, '', 'pce',
                                                                         'command',
                                                                         parentCommandIdToNewCommandIdBrg[defaultArm],
                                                                         '', 'defaultArm', False, info)
                            # Заменим детей в "Команды оператора"
                            readerCommands = reader.getChildListByType('reader_command')
                            for readerCommand in readerCommands:
                                childCommand = readerCommand.getLinkedElement('command')
                                childCommandId = childCommand.getUniID()
                                childCommandAddr = readerCommand.getAddr()
                                if childCommandId in parentCommandIdToNewCommandIdBrg:
                                    newCommandId = parentCommandIdToNewCommandIdBrg[childCommandId]
                                    self.__evMon.deleteEquipmentObject('pce', 'reader_command',
                                                                       readerCommand.getUniID(), '', info)
                                    self.__evMon.createEquipmentLink('pce', 'reader', newAlgObjId, 'pce', 'command',
                                                                     newCommandId, 'reader_command', childCommandAddr)
                    elif parentAlgObjTypeName == 'area':
                        parentAreaIdToNewAreaIdBrg[parentAlgObjId] = newAlgObjId
                    elif parentAlgObjTypeName == 'part':
                        # Для раздела нужно сделать специальное действие, заменить мостовые связи с входами и
                        # выходами на из копии
                        part = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'part', 'id': newAlgObjId})
                        partInputs = part.getChildListByType('part_input')
                        for partInput in partInputs:
                            input = partInput.getLinkedElement('input')
                            inputId = input.getUniID()
                            inputAddr = partInput.getAddr()
                            self.__evMon.deleteEquipmentObject('pce', 'part_input', partInput.getUniID(), '', info)
                            if inputId in parentInputIdToNewInputIdBrg:
                                newInputId = parentInputIdToNewInputIdBrg[inputId]
                                self.__evMon.createEquipmentLink('pce', 'part', newAlgObjId, 'pce', 'input', newInputId,
                                                                 'part_input', inputAddr)

        obsObjIds = self.__evMon.copyObservedObjectsForPceAlg(parentAlgObjToNewAlgObj, newAlgDescription,
                                                              obsObjBaseNamePart, obsObjNewNamePart)
        repData = CopyPceAlgorithmCommandReply.RepData(newAlgName=newAlgDescription, obsObjIds=obsObjIds)
        return CopyPceAlgorithmCommandReply(repData)

    def __createPceAlg(self, req):
        try:
            algName = str(req['reqData']['algName'])
            busClassUniid = int(req['reqData']['busClassUniid'])
            confFileData = json.loads(req['reqData']['confFileData'])
            objectsAddr = req['reqData']['objectsAddr']
            objectsName = req['reqData']['objectsName']
            observedObjects = req['reqData']['observedObjects']
        except Exception as e:
            return {
                'rep'	: 'createPceAlg',
                'repData'	: {
                    'status'	: 'error',
                    'error'		: 'wrongParamList'
                }
            }
        else:
            reply = {
                'rep'		: 'createPceAlg',
                'repData'	: req['reqData']
            }
            busClass = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'bus_class', 'id': busClassUniid})
            pceClass = busClass.getLinkedElement('algclass')  # объет класса для которого создается адгоритм
            pceBus = busClass.getParent()  # шина накоторой все это надо сделать

            newAlgId = self.__evMon.createEquipmentObject('pce', 'alg', '', '', {
                'description': algName,
                'algclass': {
                    'type': 'algclass',
                    'id': pceClass.getUniID()
                }
            })
            # Объект нового алгоритма
            newAlg = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'alg', 'id': newAlgId})
            realObjects = {}
            rightsIds = []
            commandsIds = []
            variablesIds = []
            stringsIds = []
            areasIds = []
            partsIds = []
            for addr in objectsAddr:
                vobj = pceClass.getChildByAddr('vobj', addr)
                vobjType = vobj.getAttribute('objType')
                realObj = None
                confAttrs = confFileData['objects'][str(addr)]
                objType = ''
                objAttrs = {}
                needCreateObject = True
                if vobjType == 1:  # reader
                    objType = 'reader'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 2:  # input
                    objType = 'input'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 3:  # output
                    objType = 'output'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 4:  # display
                    objType = 'display'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 5:  # collector
                    objType = 'collector'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 6:  # emitter
                    objType = 'emitter'
                    objAttrs = {'description': objectsName[str(addr)]}
                elif vobjType == 64:  # string
                    strings = self.__evMon.getEquipmentObjectsList('pce', 'string')
                    for sId in strings:
                        s = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'string', 'id': sId})
                        if s.getAttribute('description') == objectsName[str(addr)]:
                            realObj = s
                            realObjId = sId
                            needCreateObject = False
                            break
                    objType = 'string'
                    objAttrs = {'description' : objectsName[str(addr)]}
                elif vobjType == 76:  # command
                    objType = 'command'
                    objAttrs = {'description' : objectsName[str(addr)]}
                elif vobjType == 79:  # part
                    objType = 'part'
                    objAttrs = {'description' : objectsName[str(addr)]}
                elif vobjType == 84:  # area
                    objType = 'area'
                    objAttrs = {'description' : objectsName[str(addr)]}
                elif vobjType == 88:  # variable
                    objType = 'variable'
                    objAttrs = {'description' : objectsName[str(addr)]}
                if needCreateObject:
                    realObjId = self.__evMon.createEquipmentObject('pce', objType, '', '', objAttrs)
                    realObj = self.__evMon.getEquipObj({'equip': 'pce', 'type': objType, 'id': realObjId})
                # Привесим объект на алгоритм
                self.__evMon.createEquipmentLink('pce', 'alg', newAlgId,
                                                 'pce', realObj.getTypeName(), realObjId, 'alg_object', addr)
                realObjects[addr] = realObj
                for attrName in realObj.attrs:
                    if 'target' not in realObj.attrs[attrName]:
                        if attrName in confAttrs and attrName != 'description':
                            self.__evMon.setEquipmentObjectsAttribute('pce', realObj.getTypeName(), realObjId, '',
                                                                      attrName, confAttrs[attrName], False, {})
                # Если мы создали команду то для нее надо создать право и установить ссылку на алгоритм
                if vobjType == 76:  # command
                    commandsIds.append(realObjId)
                    attrs = {
                        'description'   : objectsName[str(addr)],
                        'command'       : {
                            'type'  : 'command',
                            'id'    : realObjId
                        }
                    }
                    rightsIds.append(self.__evMon.createEquipmentObject('pce', 'pceright', '', '', attrs))
                    self.__evMon.setEquipmentObjectsLink('pce', 'command', realObjId, '', 'pce', 'alg', newAlgId, '', 'algorithm')
                elif vobjType == 88:  # variable
                    variablesIds.append(realObjId)
                elif vobjType == 64 and needCreateObject:  # string
                    stringsIds.append(realObjId)
                elif vobjType == 84:  # area
                    areasIds.append(realObjId)
                elif vobjType == 79:  # part
                    partsIds.append(realObjId)

            # Пройдем вторым кругом для присвоения ссылок
            for addr in objectsAddr:
                realObj = realObjects[addr]
                if realObj:
                    confAttrs = confFileData['objects'][str(addr)]
                    for attrName in realObj.attrs:
                        if 'target' in realObj.attrs[attrName]:
                            if attrName in confAttrs:
                                if confAttrs[attrName] != 0:
                                    targetObj = realObjects[confAttrs[attrName]]
                                    self.__evMon.setEquipmentObjectsLink('pce', realObj.getTypeName(), realObj.getUniID(), '',
                                                                         'pce', targetObj.getTypeName(), targetObj.getUniID(), '', attrName)
                    # Для считывателей еще добавим команы
                    if realObj.getTypeName() == 'reader' and 'command' in confAttrs:
                        value = confAttrs['command']
                        if type(value) == list:  # На всякий случай
                            for id in value:
                                targetObj = realObjects[id]
                                self.__evMon.createEquipmentLink('pce', 'reader', realObj.getUniID(),
                                                                 'pce', 'command', targetObj.getUniID(), 'reader_command', None)

            # Теперь создадим для всех прав общее полномочие и добавим в него все права
            rlistId = -1
            if len(rightsIds) > 0:
                rlistId = self.__evMon.createEquipmentObject('pce', 'rlist', '', '', {'description' :algName})
                # Попробуем найти расписание "Всегда"
                scheduleId = -1
                schedules = self.__evMon.getEquipmentObjectsList('pce', 'schedule')
                for sId in schedules:
                    s = self.__evMon.getEquipObj({'equip': 'pce', 'type': 'schedule', 'id': sId})
                    if s.getAttribute('description') == 'Всегда':
                        scheduleId = sId
                        break
                attrs = None
                if scheduleId != -1:
                    attrs =  {
                        'schedule'  : {
                            'type'  : 'schedule',
                            'id'    : scheduleId
                        }
                    }
                for rightId in rightsIds:
                    self.__evMon.createEquipmentLink('pce', 'rlist', rlistId,
                                                     'pce', 'pceright', rightId, 'rlist_pceright', None, attrs)

            # Привесим на шину все команды, права и полномочие
            if len(commandsIds) > 0:
                busCommands = pceBus.getChildListByType('bus_command')
                commandAddr = 1
                if len(busCommands) > 0:
                    commandAddr = busCommands[-1].getAddr( ) +1
                for cId in commandsIds:
                    self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                     'pce', 'command', cId, 'bus_command', commandAddr)
                    commandAddr += 1

                for rId in rightsIds:
                    self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                     'pce', 'pceright', rId, 'bus_pceright', None)

                self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                 'pce', 'rlist', rlistId, 'bus_rlist', None)

            # Привесим на шину все переменные с адресом большим 1000
            if len(variablesIds) > 0:
                busVariables = pceBus.getChildListByType('bus_variable')
                variableAddr = 1001
                if len(busVariables) > 0:
                    variableAddr = max(variableAddr, busVariables[-1].getAddr( ) +1)
                for vId in variablesIds:
                    self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                     'pce', 'variable', vId, 'bus_variable', variableAddr)
                    variableAddr += 1

            # Привесим на шину все строки
            for sId in stringsIds:
                self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                 'pce', 'string', sId, 'bus_string', None)

            # Привесим на шину все области
            for aId in areasIds:
                self.__evMon.createEquipmentLink('pce', 'bus', pceBus.getUniID(),
                                                 'pce', 'area', aId, 'bus_area', None)

            # Привесим на шину все разделы
            for partId in partsIds:
                self.__evMon.addEquipmentChild('pce', 'bus', pceBus.getUniID(), '',
                                               'part', partId, '', None)

            # Привесим алгоритм на шину
            self.__evMon.addEquipmentChild('pce', 'bus', pceBus.getUniID(), '',
                                           'alg', newAlgId, '', None)

            # Создадим объекты мониторинга
            obsObjAddr = self.__evMon.createObservedObjectsForPCEAlg(algName, realObjects, observedObjects)

            reply['repData']['obsObjAddr'] = obsObjAddr
            reply['repData']['status'] = 'ok'
            reply['repData']['msg'] = locale.createPCEAlgResult
        return reply
