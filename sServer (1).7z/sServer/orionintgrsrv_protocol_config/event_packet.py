# -*- coding: utf-8 -*-

import json
import datetime
import uuid
import logging
import time
import base64
import traceback
from equipment import dev_except

from . import eventsdict

settings = __import__('settings')
photoDir = settings.photoPath
logger = logging.getLogger('sServer')


class EventPacketException (Exception):
    pass


def getBooleanType():
    return {
        'Нет': False,
        'Да': True
    }


def getAntipassbackValue():
    return {
        '0-Нет': 0,
        '1-Строгий': 1,
        '2-Временной': 2,
        '3-Мягкий': 3
    }


def copy_attribute_to_access_item(obj, sourceObj):
    for attrName in obj.attrs:
        if 'target' in obj.attrs[attrName] and attrName != sourceObj.getTypeName():
            if attrName in sourceObj.attrs:
                if sourceObj.isLinkedElement(attrName):
                    obj.bindElement(attrName, sourceObj.getLinkedElement(attrName))
        elif attrName in sourceObj.attrs and attrName != 'itemid':
            obj.setAttribute(attrName, sourceObj.getAttribute(attrName))


def updExt_id(core, ext_id, params):
    pers, subj = getPersonSubject(core, ext_id, 0, params)
    if pers and pers.getAttribute('external_id') != str(ext_id):
        pers.setAttr('external_id', str(ext_id))    


def findAP_uniid(core, deviceId):
    for ap in core.getElements('accessitempoint'):
        if int(ap.getAttribute('itemid')) == int(deviceId):
            return ap.getUniID()
    return 0

        
def eventParser(obj, core, event, portsEvent):
    if event:
        if 'Orion' in event and event['Orion'] == 'connect':
            pass
        else:
            evTypeId = event['EventTypeId']
            if evTypeId == 'data_to_server':
                if 'info_ext_id' in event:
                    data = json.loads(event['info_ext_id'])
                    updExt_id(core, str(data['ext_id']), str(data['params']))
                elif 'readAccessLevelsList' in event:
                    UpdateAccessLevelTable(core, json.loads(event['readAccessLevelsList']))
                elif 'infoPers' in event:
                    UpdatePersonTable(core, json.loads(event['infoPers']))
                elif 'infoKeys' in event:
                    UpdatePermitTable(core, json.loads(event['infoKeys']))
                elif 'infoTW' in event:
                    UpdateScheduleTable(core, json.loads(event['infoTW']))
                else:
                    print('uknown data from orion')
            elif evTypeId == 'async_result':
                asyncCommand = event['command']
                asyncResult = event['result']
                if asyncCommand == 'OISUpdateAccessLevel':
                    if asyncResult == 'ok':
                        print('%s = %s' % (asyncCommand, asyncResult))
                        UpdateAccessLevelTable(core, event['data']['res'])
                    else:
                        print('update access level error %s' % event['data'])
                else:
                    print('%s = %s: %s' % (asyncCommand, asyncResult, event['data']))
            else:
                if event['ItemType']:
                    if event['ItemType'] not in ('READER', 'ACCESSPOINT'):
                        return
                if str(evTypeId) in eventsdict.accepteventslist:
                    code = int(eventsdict.ESM_ORION_evBridge[str(evTypeId)]) + 8000
                    timeEvent = time.mktime(datetime.datetime.strptime(event['EventDate'],'%Y-%m-%d %H:%M:%S').timetuple())
                    AccessPointId = int(event['AccessPointId'])
                    apUniid = int(findAP_uniid(core, AccessPointId))
                    if apUniid > 0:
                        event = {
                            'notification': {
                                'code': code
                            },
                            'statement': {
                                'adverbialTime': {
                                    'param': timeEvent
                                },
                                'directObj': {
                                    'dev': {
                                        'equip': 'orionintgrsrv',
                                        'type': 'accessitempoint',
                                        'id': apUniid
                                    }
                                },
                                'subject': {
                                    'card': int(orionDecodeCard(event['CardNo'])) if event['CardNo'] else 0
                                }
                            }
                        }
                        obj.pushEvent(event)
                else:
                    logger.info('Orion Pro. uknown event: %s '% event)


def getSubjPhoto(photoName):
    if photoName == '':
        return ''
    fileContent = ''
    try:
        photoFile = '%s/%s.jpg' % (photoDir, photoName)
        with open(photoFile, mode='rb') as file:  # b is important -> binary
            fileContent = file.read()
    finally:
        return base64.b64encode(fileContent.encode()).decode()


def findAccessLevel(core, orion_id):
    if int(orion_id) > 0:
        for idE, objE in core.getElementsByIndex('schedule', 'orion_id', None, keyValue=int(orion_id)).items():
            return objE
    return None


def findItemByType(core, item_type, item_id):
    if item_type == 'ACCESSZONE':
        for idE, objE in core.getElementsByIndex('accessitemzone', 'item_id', None, keyValue=item_id).items():
            return objE
    else:
        for idE, objE in core.getElementsByIndex('accessitempoint', 'item_id', None, keyValue=item_id).items():
            return objE
    return None


def UpdateAccessLevel(al, id, name, comment, flags=0):
    al.setAttribute('description', name)
    al.setAttribute('code', id)
    al.setAttribute('orion_comment', comment)
    al.setAttribute('orion_flags', flags)


def addAccessLevel(core, id, name='', comment='', flags=0):
    print('++ AccessLevel %s,%s,%s' % (id, name, comment))
    newAL = core.createElement('schedule', createAction=(int(id) == 0), attrs={
        'description': name,
        'code': id,
        'orion_comment': comment,
        'orion_flags': flags
    })
    return newAL


def updateAccLvlItem (core,uid,item):
    if item['type'] == 'ACCESSZONE':
        itemCurr = core.getElementById('accessitemzone', uid)
        if itemCurr:
            itemCurr.setAttribute('itemid', item['item_id'])
            if 'name' in item and itemCurr.getAttribute('description') != item['name']:
                itemCurr.setAttribute('description', item['name'])
    elif item['type'] == 'ACCESSPOINT':
        itemCurr = core.getElementById('accessitempoint', uid)
        if itemCurr:
            itemCurr.setAttribute('itemid', item['item_id'])
            if 'name' in item and itemCurr.getAttribute('description') != item['name']:
                itemCurr.setAttribute('description', item['name'])


def addAccLvlItem(core, item):
    try:
        newItem = None
        if item['type'] == 'ACCESSZONE':
            newItem = core.createElement('accessitemzone', attrs={
                'itemid': item['item_id'],
                'description': item.get('name', '')
            })
        elif item['type'] == 'ACCESSPOINT':
            newItem = core.createElement('accessitempoint', attrs={
                'itemid': item['item_id'],
                'description': item.get('name', '')
            })
        return newItem
    except:
        logger.exception('Failed create acclvlitem %s' % repr(item))
        return False


def UpdateScheduleTable(core, twind_arr):
    for t_wind in twind_arr:
        cur = core['common'].sql(
            "select uniid  from common_schedule where  external_id = '%s' and flags = 0" %
            (t_wind['id']))
        if cur.rowcount > 0:
            schID = int(cur.fetchone()[0])
            print("Find schedule by ext_id %s updating"%schID)
            schObj = core['common'].getElementById('schedule', schID)
            schObj.setAttribute('description', t_wind['name'])
        else:
            cur = core['common'].sql(
                "select uniid from common_schedule where description = '%s' and flags = 0" %
                t_wind['name'])
            print('schName %s - %s' % (t_wind['name'], cur.rowcount))
            if cur.rowcount > 0:
                schID = int(cur.fetchone()[0])
                print("Find schedule by name %s updating" % schID)
                # TODO: переделать на subsystem_id
                schObj = core['common'].getElementById('schedule', schID)
                schObj.setAttribute('external_id', str(t_wind['id']))
            else:
                # TODO: переделать на subsystem_id
                core['common'].createElement('schedule', attrs={
                    'description': t_wind['name'],
                    'external_id': str(t_wind['id'])
                })


def UpdateLevelItemsInDataBase(core, items):
    for item in items:
        itemObj = findItemByType(core, item['type'], item['item_id'])
        if itemObj:
            if 'name' in item and itemObj.getAttribute('description') != item['name'] and item['name'] != '':
                itemObj.setAttribute('description', item['name'])
        else:
            addAccLvlItem(core, item)


def UpdateChildIteminAccessLevel(core, alObj, items):
    chieldItemsObj = alObj.getChildListByType('schedule_accessitempoint')+alObj.getChildListByType('schedule_accessitemzone')
    # Проход для удаления отсутствующих прав в полученных данных
    for childItem in chieldItemsObj:
        itemFinden = False
        try:
            linkedLvlItem = childItem.getLinkedElement(childItem.getTypeName().split('_')[1])
        except:
            linkedLvlItem = None
        if linkedLvlItem:
            for item in items:
                # поиск по идентификатору мостовой связи
                if int(item['id']) == int(childItem.getAttribute('itemid')):
                    if (childItem.getTypeName() == 'schedule_accessitempoint' and item['type'] == 'ACCESSPOINT')\
                            or (childItem.getTypeName() == 'schedule_accessitemzone' and item['type'] == 'ACCESSZONE'):
                        # тип права соответсвует
                        itemFinden = True
                # поиск по идентификатору точки или зоны доступа, для вновь добавленных идентификатор мостовой связи - 0
                if int(childItem.getAttribute('itemid')) == 0 and \
                        int(linkedLvlItem.getAttribute('itemid')) == int(item['item_id']):
                    if (childItem.getTypeName() == 'schedule_accessitempoint' and item['type'] == 'ACCESSPOINT')\
                            or (childItem.getTypeName() == 'schedule_accessitemzone' and item['type'] == 'ACCESSZONE'):
                        itemFinden = True
                        childItem.setAttribute('itemid',item['id'])
        if not itemFinden:
            print("delete accesslevel item %s" % childItem.getAttribute('itemid'))
            childItem.selfDelete()
    # проход на обновление и добавление
    chieldItemsObj = alObj.getChildListByType('schedule_accessitempoint')+alObj.getChildListByType('schedule_accessitemzone')
    for item in items:
        itemObj = findItemByType(core, item['type'], item['item_id'])
        itemFinden = False
        for childItem in chieldItemsObj:
            try:
                linkedLvlItem = childItem.getLinkedElement(childItem.getTypeName().split('_')[1])
            except:
                linkedLvlItem = None
            if linkedLvlItem and \
                    int(item['item_id']) == int(linkedLvlItem.getAttribute('itemid')) and \
                    int (item['id']) == int(childItem.getAttribute('itemid')):
                #нашли соответсвующее право доступа
                if (childItem.getTypeName() == 'schedule_accessitempoint' and item['type'] == 'ACCESSPOINT')\
                        or (childItem.getTypeName() == 'schedule_accessitemzone' and item['type'] == 'ACCESSZONE'):
                    # тип права соответсвует
                    itemFinden = True
                    childItem.setAttribute('itemid',item['id'])
                    childItem.setAttribute('ltime',item['lTime'])
                    childItem.setAttribute('apback',item['apback'])
                    childItem.setAttribute('zonalapback',bool(item['apbackZonal']))
                    childItem.setAttribute('isconf',item['isConf'])
                    childItem.setAttribute('isconfb',item['isConfB'])
                    childItem.setAttribute('rights',int(item['rights']))

                    schedule = findOrCreateSchedule(core, item['timeWID'], '')
                    if schedule:
                        childItem.bindElement('schedule', schedule)

                    dconfObj = None
                    if childItem.isLinkedElement('dconf'):
                        dconfObj = childItem.getLinkedElement('dconf')
                    if (dconfObj and int(dconfObj.getAttribute('code')) == int(item['dConf']) and int(item['dConf']) != 0):
                        pass
                    else:
                        if dconfObj:
                            childItem.unBindElement('dconf')
                        dconfObj = findAccessLevel(core, item['dConf'])
                        if dconfObj:
                            childItem.bindElement('dconf',dconfObj)

                    tconfObj = None
                    if childItem.isLinkedElement('tconf'):
                        tconfObj = childItem.getLinkedElement('tconf')
                    if (tconfObj and int(tconfObj.getAttribute('code')) == int(item['tConf']) and int(item['tConf']) != 0):
                        pass
                    else:
                        if tconfObj:
                            childItem.unBindElement('tconf')
                        tconfObj = findAccessLevel(core, item['tConf'])
                        if tconfObj:
                            childItem.bindElement('tconf',tconfObj)
                else:
                    print("delete2 accesslevel item %s" % childItem.getAttribute('itemid'))
                    childItem.selfDelete()
        if not itemFinden:
            createType = 'schedule_accessitempoint' if item['type'] == 'ACCESSPOINT' else 'schedule_accessitemzone'
            childItem = core.createElement(createType, attrs={
                'itemid': item['id'],
                'ltime': item['lTime'],
                'apback': item['apback'],
                'zonalapback': bool(item['apbackZonal']),
                'isconf': item['isConf'],
                'isconfb': item['isConfB'],
                'rights': item['rights']
            })
            print("add accesslevel item %s" % item['id'])
            alObj.addChild(childItem)
            childItem.bindElement(childItem.getTypeName().split('_')[1], itemObj)
            schedule = findOrCreateSchedule(core, item['timeWID'],'')
            if schedule:
                # проверка на случаей если postAction уже присваивает значения.
                if childItem.isLinkedElement('schedule'):
                    commonSchedule = childItem.getLinkedElement('schedule')
                    if commonSchedule.getUniID() != schedule.getUniID():
                        childItem.bindElement('schedule', schedule)
            dconfObj = findAccessLevel(core, item['dConf'])
            if dconfObj:
                childItem.bindElement('dconf', dconfObj)
            tconfObj = findAccessLevel(core, item['tConf'])
            if tconfObj:
                childItem.bindElement('tconf', tconfObj)


def UpdateAccessLevelTable(core, arrayAL):
    for elemAL in arrayAL:
        idAl = int(elemAL['id'])
        alObj = findAccessLevel(core, idAl)
        if alObj:
            print('Update Access Level №%s - %s' % (idAl, elemAL['name']))
            UpdateAccessLevel(alObj, idAl, elemAL['name'], elemAL['desc'])
        else:
            alObj = addAccessLevel(core, idAl, elemAL['name'], elemAL['desc'])
        # обновление точек доступа и зон доступа
        UpdateLevelItemsInDataBase(core, elemAL['items'])
        # обновление прав доступа уровня доступа
        UpdateChildIteminAccessLevel(core, alObj, elemAL['items'])

        if idAl > 0:
            findOrCreateCommonRight(core, idAl)
    print('Imported Access Level count - %s' % (len(arrayAL)))


def UpdateOrgTable(core, arrayOrg):
    for org in arrayOrg:
        try:
            print('process orgID %s' % (org['ID']))
            cur = core['common'].sql(
                "select uniid  from common_organization where external_id = '%s' and flags = 0" %
                (org['ID']))
            if cur.rowcount > 1:
                try:
                    print('Find too much organizations (%s) with description %s'%(cur.rowcount,org['Name']))
                except:
                    print('Bad org name id = %s '%org['ID'])
            elif cur.rowcount == 1:
                orgID = cur.fetchone()[0]
                oldOrg = core['common'].getElementById('organization', orgID)
                oldOrg.setAttribute('description', org['Name'])
                oldOrg.setAttribute('external_id', org['ID'])
            else:
                try:
                    print('orgName %s '%org['Name'])
                except:
                    print('type %s '%type(org['Name']))
                    print('withescapes %s' %org['Name'].encode('utf-8'))
                cur = core.sql(
                    "select uniid from common_organization where description = '%s' and flags = 0" %
                    (org['Name']))
                if cur.rowcount > 0:
                    orgID = int(cur.fetchone()[0])
                    print('orgID %s' % (orgID))
                    oldOrg = core['common'].getElementById('organization', orgID)
                    oldOrg.setAttribute('external_id', org['ID'])
                else:
                    # TODO: переделать на subsystem_id
                    core['common'].createElement('organization', attrs={
                        'description': org['Name'],
                        'external_id': org['ID']
                    })
        except Exception as e:
            print('failed add org %s'% (org['ID']))
            print(repr(e))


def orionDecodeCard(code):
    try:
        binstr = bytearray.fromhex(code)
        byte1 = binstr[-2]
        byte2 = binstr[-3]
        byte3 = binstr[-4]
        byte4 = binstr[-5]
        return (byte4 << 24) | (byte3 << 16) | (byte2 << 8) | byte1
    except Exception as e:
        print("ERROR in orionDecodeCard: %s %s" % (code, str(e)))
        raise
        return 0
                
                
def UpdatePostTable(core, arrayPost):
    for post in arrayPost:
        post['ID'] = str(post['ID'])
        cur = core['common'].sql(
            "select uniid  from common_post where external_id = '%s' and flags = 0" %
            (post['ID']))
        if cur.rowcount > 0:
            postID = cur.fetchone()[0]
            print('postID %s' % (postID))
            oldPost = core['common'].getElementById('post', postID)
            oldPost.setAttribute('description', post['Name'])
            oldPost.setAttribute('external_id', post['ID'])
        else:
            print('postName %s' % (post['Name']))
            cur = core.sql(
                "select uniid from common_post where description = '%s' and flags = 0" %
                (post['Name']))
            if cur.rowcount > 0:
                postID = int(cur.fetchone()[0])
                print('postID %s' % postID)
                # TODO: переделать на subsystem_id
                oldPost = core['common'].getElementById('post', postID)
                oldPost.setAttribute('external_id', post['ID'])
            else:
                # TODO: переделать на subsystem_id
                core['common'].createElement('post', attrs={
                    'description': post['Name'],
                    'external_id': post['ID']
                })


def UpdateAccessZones(core, arrayZones):
    for zone in arrayZones:
        cur = core['common'].sql(
            "select uniid  from orionintgrsrv_accessitemzone where itemid = '%s' and flags = 0" %
            (str(zone['ID'])))
        if cur.rowcount > 0:
            zoneID = cur.fetchone()[0]
            print('update zoneID %s' % zoneID)
            oldZone = core['orionintgrsrv'].getElementById('accessitemzone', zoneID)
            oldZone.setAttribute('description', zone['Name'])
        else:
            print('create zone %s' % (zone['Name']))
            core['orionintgrsrv'].createElement('accessitemzone', attrs={
                'description': zone['Name'],
                'itemid': zone['ID']
            })


def UpdateEntryPoints(core, arrayPoints):
    for point in arrayPoints:
        cur = core['common'].sql(
            "select uniid  from orionintgrsrv_accessitempoint where itemid = '%s' and flags = 0" %
            (str(point['ID'])))
        if cur.rowcount > 0:
            pointID = cur.fetchone()[0]
            print('update point with ID %s' % (pointID))
            oldPoint = core['orionintgrsrv'].getElementById('accessitempoint', pointID)
            oldPoint.setAttribute('description', point['Name'])
        else:
            print('create point %s' % point['Name'])
            core['orionintgrsrv'].createElement('accessitempoint', attrs={
                'description': point['Name'],
                'itemid': point['ID']
            })


def findOrCreateSchedule(core, orion_id, name):
    # Поиск расписаний в общих обектах у которых указан внешний идентификатор, карты идентификатору уровня доступа в
    # Орион
    if orion_id == 0:
        return None
    cur = core['common'].sql("select uniid from common_schedule where external_id = '%s' and flags = 0" % orion_id)
    if cur.rowcount > 0:
        schID = int(cur.fetchone()[0])
        schObj = core['common'].getElementById('schedule', schID)
        if schObj.getAttribute('description') != name and name != '':
            schObj.setAttribute('description', name)
        return schObj
    elif name != '':
        cur = core['common'].sql("select uniid from common_schedule where description = '%s' and flags = 0" % name)
        print('schName %s - %s' % (name, cur.rowcount))
        if cur.rowcount > 0:
            schID = int(cur.fetchone()[0])
            schObj = core['common'].getElementById('schedule', schID)
            schObj.setAttribute('external_id', str(orion_id))
            return schObj
    # TODO: переделать на subsystem_id
    schObj = core['common'].createElement('schedule', attrs={
        'description': name,
        'external_id': str(orion_id)
    })
    return schObj


def findOrCreateDepartment(core, orion_id, name, shedule):
    cur = core['common'].sql("select uniid from common_department where  external_id = '%s' and flags = 0" % orion_id)
    if cur.rowcount > 0:
        depID = int(cur.fetchone()[0])
        depObj = core['common'].getElementById('department', depID)
        depObj.setAttribute('description', name)
        if shedule:
            depObj.bindElement('schedule', shedule)
        return depObj
    else:
        cur = core['common'].sql("select uniid from common_department where description = '%s' and flags = 0" % name)
        # print 'depName %s - %s' % (name, cur.rowcount)
        if cur.rowcount > 0:
            depID = int(cur.fetchone()[0])
            depObj = core['common'].getElementById('department', depID)
            if shedule:
                depObj.bindElement('schedule', shedule)
            return depObj
        else:
            # TODO: переделать на subsystem_id
            depObj = core['common'].createElement('department', attrs={
                'description': name,
                'external_id': orion_id
            })
            if shedule:
                depObj.bindElement('schedule', shedule)
            return depObj


def UpdateDepartTable(core, arrayDep):
    for dep in arrayDep:
        aclvl_obj = alID = findAccessLevel(core, dep['GroupID'])
        if aclvl_obj:
            name_data = aclvl_obj.getAttribute('description')
            schedule = findOrCreateSchedule(core, str(dep['GroupID']), name_data)
            depUniID = findOrCreateDepartment(core, str(dep['ID']), dep['Name'], schedule)


def getPersonSubject(core, id_pList, tn, uniid_ext):
    if id_pList == '':
        return None, None
    if str(uniid_ext).isdigit():
        # uniid_ext - значение поля GUID_1C из БД Орион, в котором должно храниться uniid ESM
        subObj = core['common'].getElementById('subject', uniid_ext)
        if subObj:
            try:
                objList = subObj.getChildListByType('person')
                if objList and len(objList) == 0:
                    objList = subObj.getChildListByType('mobile')
                if objList and len(objList) == 0:
                    objList = subObj.getChildListByType('thing')
                if objList and len(objList) > 0:
                    print('Найден субъект по GUID  %s' % uniid_ext)
                    return objList[0], subObj
            except:
                pass
    if tn and tn != '' and tn.isdigit() and int(tn) != 0:
        sqlReq = "select uniid  from common_person where employeenumber = '%s' and flags = 0" % tn
        cur = core['common'].sql(sqlReq)
        if cur.rowcount > 0:
            persID = int(cur.fetchone()[0])
            persObj = core['common'].getElementById('person', persID)
            print('persID %s from id_pList %s -> person %s' % (persID, id_pList, persObj))
            if persObj:
                if persObj.getAttribute('external_id') != '' and int(persObj.getAttribute('external_id')) != int(id_pList):
                    persObj.setAttribute('external_id', id_pList)
                subjectCallBack(core, persObj, id_pList)
                print('Найден субъект по ТН  %s' % uniid_ext)
                return persObj, persObj.getParent()

    print('Субъект не найден. Создание нового.')
    # TODO: переделать на subsystem_id
    persObj = core['common'].createElement('person', attrs={
        'external_id': str(id_pList)
    })
    subj = persObj.getParent()
    subjectCallBack(core, persObj, id_pList)
    return persObj, subj


def subjectCallBack(core, pers, id_pList):
    orion_buses = core.getElements('master')
    if orion_buses and len(orion_buses) > 0:
        orion_buses[0].doAction('updateUser', {
            'extId': id_pList,
            'subjectId': pers.getUniID(),
            'forceUpdatePers': True,
        })


def findOrCreateCommonRight(core, accessLevel_extId):
    accessLevel = findAccessLevel(core, accessLevel_extId)
    if not accessLevel:
        return None
    # получение права доступа по найденному уровню доступа
    rights = core['common'].getElements('commonright')
    r_with_ext = None
    al_name = accessLevel.getAttribute('description')
    al_comment = accessLevel.getAttribute('orion_comment')
    for r in rights:
        if r.getAttribute('external_id') != '':
            if int(r.getAttribute('external_id')) == int(accessLevel_extId):
                r_with_ext = r
            al = r.getLinkedElement('schedule_srv')
            if al:
                if al.getUniID() == accessLevel.getUniID():
                    if r.getAttribute('description') != al_name and al_name != '':
                        r.setAttr('description', al_name)
                    if r.getAttribute('comment') != al_comment and al_comment != '':
                        r.setAttr('comment', al_comment)
                    # print 'return %s'%r.getAttribute('description')
                    return r
    # Не нашли, проверим по внешнему идентификатору
    if r_with_ext:
        # print 'found common pright %s'%r_with_ext.getAttribute('description')
        r_with_ext.bindElement('schedule_srv', accessLevel)
        if r_with_ext.getAttribute('description') != al_name:
            r_with_ext.setAttr('description',al_name)
        if r_with_ext.getAttribute('comment') != al_comment and al_comment != '':
            r_with_ext.setAttr('comment', al_comment)
        return r_with_ext

    '''Не нашли, нужно создавать  новый'''
    # TODO: переделать на subsystem_id
    r = core['common'].createElement('commonright', attrs={
        'external_id': str(accessLevel_extId),
        'schedule_srv': accessLevel,
        'description': al_name,
        'comment': al_comment
    })
    print('--------------------------------')
    print('create permit_commonright %s %s' % (r.getUniID(), accessLevel.getUniID()))
    print('--------------------------------')
    return r


def GetIDCodeObject(core, code):
    print('Поиск идентификатора %s' % code)
    for id, idObj in core['common'].getElementsByIndex('idcode', 'name', None, keyValue=str(code)).items():
        if not idObj:
            print("Создание нового идентификатора - %s" % code)
            print('---------------------------------------------')
            # TODO: переделать на subsystem_id
            idObj = core['common'].createElement('idcode', attrs={
                'name': str(code)
            })
        return idObj
    print("Создание нового идентификатора 2 - %s " % code)
    idObj = core['common'].createElement('idcode', attrs={
        'name': str(code)
    })
    return idObj


def UpdatePermitTable(core, arrayKey):
    for k in arrayKey:
        print('-------------------------------------------------------------------')
        #if k['GrStatus'] != 1:
        #   continue
        singKey = k['storeInDevice']
        lockKey = k['isBlock']
        print('Обновление пропуска для владельца %s , ТН %s, GUID %s' % (k['Owner'], k['TN'], k.get('GUID', 'нет')))
        id_card_code = orionDecodeCard(k['CodeP'])
        if int(id_card_code) == 0:
            print('Нет кода карты')
            continue
        pers, subj = getPersonSubject(core, k['Owner'], k['TN'], k.get('GUID', ''))
        codeObj = GetIDCodeObject(core, id_card_code)
        prightObj = findOrCreateCommonRight(core, k['GroupID'])
        try:
            print('Субъект %s (%s), Карта %s, Права %s ' % (
                subj.doAction('getDescription'), k['Owner'], codeObj.getAttribute('name'),
                prightObj.getAttribute('description') if prightObj else 'Не найдены'))
        except Exception as e:
            print('Импорт пропуска %s выполнен. Невалидное наименование частного лица \n %s' % (k['Owner'], str(e)))
        permits = core['common'].getElementsByIndex('permit', 'activeIdcode', None, keyValue=id_card_code)
        # print "permits %s" % (permits)
        if len(permits) == 0:
            # в активных пропусках не найден поиск в заблокированных
            permits = core['common'].getElementsByIndex('permit', 'blockedIdcode', None, keyValue=id_card_code)
            # print "permits 2 %s" % (permits)
            if len(permits) == 0:
                # TODO: переделать на subsystem_id
                permits = {0: core['common'].createElement('permit')}
                print("Создание нового пропуска %s" % (permits[0].getUniID()))
                if codeObj:
                    permits[0].bindElement('idcode', codeObj)
        # редактирование пропуска
        np = permits.copy()
        for idPerm, objPerm in np.items():
            permitSubj = None
            if objPerm.isLinkedElement('subject'):
                permitSubj = objPerm.getLinkedElement('subject')
            else:
                objPerm.bindElement('subject', subj)
                permitSubj = subj
            if permitSubj and permitSubj.getUniID() != subj.getUniID():
                # print "permitSubj %s <> subj %s" % (permitSubj.getUniID(), subj.getUniID())
                # выходит что пропуск с текущим ключем(картой) принадлежит другому субъекту, деактивируем его и создаем
                # новый
                objPerm.setAttribute('state', 2)
                objPerm.setAttribute('deactdt', time.time())
                # print "Create New permit 2 for  %s" % (codeObj)
                objPerm = core['common'].createElement('permit', attrs={
                    'idcode': codeObj,
                    'subject': subj
                })
            beginDT = time.mktime(
                datetime.datetime.strptime(
                    k['Start'], '%Y-%m-%d %H:%M:%S').timetuple())
            objPerm.setAttribute('beginDT', beginDT)
            endDT = time.mktime(
                datetime.datetime.strptime(
                    k['Finish'], '%Y-%m-%d %H:%M:%S').timetuple())
            objPerm.setAttribute('endDT', endDT)
            if lockKey:
                objPerm.setAttribute('state', 3)
                objPerm.setAttribute(
                    'blockcomment',
                    'Заблокирован автоматически при импорте из Орион Про')
                objPerm.setAttribute('blockdt', time.time())
            else:
                objPerm.setAttribute('state', 1)
                objPerm.setAttribute('actdt', time.time())
            if prightObj:
                alFound = False
                for pr in objPerm.getChildListByType('permit_commonright'):
                    right = pr.getLinkedElement('commonright')
                    #for r in right.getRightFarElements(
                    #        equipFilter='orionintgrsrv', typeFilter='schedule_srv', linkNameFilter='schedule_srv'):
                    #    if k['GroupID'] == r.getAttribute('code'):
                            # найдено право которое ссылает на искомый уровень доступа
                    if right.getUniID() ==  prightObj.getUniID():
                        alFound = True
                if not alFound:
                    # print "CREAT permit_commonright"
                    objPerm.createLink('commonright', prightObj)
            break


def UpdatePersonTable(core, arrayPers):
    for p in arrayPers:
        # print(p)
        p['ID'] = str(p['ID'])
        # time.sleep(30)
        print('-------------------------------------------------')
        pers, subj = getPersonSubject(core, p['ID'], p['TN'], p['GUID'])
        if pers.getTypeName() == 'person':
            # обновляем только частных лиц
            print(p['ID'], p['TN'], p['GUID'])
            if pers.getAttribute('employeeNumber') != p['TN']:
                try:
                    pers.setAttribute('employeeNumber', p['TN'])
                except BaseException:
                    print('у частного лица %s табельный номер %s не уникальный!' % (p['Name'], p['TN']))
            pers.setAttribute('description', p['Name'])
            pers.setAttribute('phoneNumber', p['WP'])
            pers.setAttribute('phone', p['HP'])
            if subj.getAttribute('photo') == '':
                photo_file_name = '{%s}' % str(uuid.uuid3(uuid.NAMESPACE_DNS, p['ID']))
                if p['Photo'] != None:
                    with open('%s/%s.jpg' % (photoDir, photo_file_name), 'wb') as photo_file:
                        photo_file.write(base64.b64decode(p['Photo']))
                        subj.setAttribute('photo', photo_file_name)
            if p['BD'] and pers.getAttribute("birthday_v2").strftime('%Y-%m-%d') != p['BD']:
                pers.setAttribute('birthday_v2', datetime.datetime.strptime(p['BD'], '%Y-%m-%d'))
            try:
                post = pers.getLinkedElement('postref')
            except BaseException:
                post = None
            if not post or post.getAttribute('external_id') != p['pID']:
                cur = core['common'].sql(
                    "select uniid  from common_post where external_id = '%s' and flags = 0" % (p['pID']))
                if cur.rowcount > 0:
                    postID = cur.fetchone()[0]
                    post = core['common'].getElementById('post', postID)
                    pers.bindElement('postref', post)
            try:
                org = subj.getLinkedElement('organization')
            except BaseException:
                org = None
            if not org or org.getAttribute('external_id') != p['cID']:
                cur = core['common'].sql(
                    "select uniid  from common_organization where external_id = '%s' and flags = 0" % (p['cID']))
                if cur.rowcount > 0:
                    orgID = cur.fetchone()[0]
                    org = core['common'].getElementById('organization', orgID)
                    try:
                        subj.bindElement('organization', org)
                    except BaseException:
                        print('у частного лица %s табельный номер %s не уникальный!' % (
                            pers.getAttribute('description'), p['TN']))
            try:
                dep = subj.getLinkedElement('department')
            except BaseException:
                dep = None
            if not dep or dep.getAttribute('external_id') != p['dID']:
                cur = core['common'].sql(
                    "select uniid  from common_department where external_id = '%s' and flags = 0" % (p['dID']))
                if cur.rowcount > 0:
                    depID = cur.fetchone()[0]
                    dep = core['common'].getElementById('department', depID)
                    subj.bindElement('department', dep)
            try:
                sch = subj.getLinkedElement('schedule_srv')
            except BaseException:
                sch = None
            if not sch or sch.getAttribute('external_id') != p['schID']:
                cur = core['common'].sql(
                    "select uniid  from common_schedule where external_id = '%s' and flags = 0" % (p['schID']))
                if cur.rowcount > 0:
                    schID = cur.fetchone()[0]
                    try:
                        sch = core['common'].getElementById('schedule_srv', schID)
                        subj.bindElement('schedule_srv', sch)
                    except:
                        pass
        try:
            print('Импорт субъекта %s (%s), ТН %s - выполнен' % (subj.doAction('getDescription'), p['ID'],
                                                                 pers.getAttribute('employeeNumber')))
        except Exception as e:
            print('Импорт субъекта %s выполнен. Невалидное наименование частного лица \n %s' % (p['ID'], str(e)))


def get_res_function(txt='Результат выполнения', timeout=3000, type='info'):
    return {
        'txt': txt,
        'timeout': timeout,
        'type': type
    }


def decodeCommandResult(core, rootElement, cmdRes, cmdName):
    try:
        if 'status' in cmdRes:
            if cmdRes['status'] == 'ok':
                return {
                    'txt': "Команда выполнена успешно : %s" % cmdRes['status'],
                    'res': cmdRes,
                    'timeout': 3000,
                    'type': 'info'
                }
            elif cmdRes['status'] == 'async_ok':
                return {
                    'txt': "Команда %s успешно отправлена на выполнение" % cmdRes['cmd'],
                    'res': cmdRes,
                    'timeout': 3000,
                    'type': 'info'
                }
            else:
                if cmdRes['res'] == 'tabnum':
                    return {
                        'txt': "Команда %s невыполнена: табельный номер уже принадлежит %s" % (cmdName, cmdRes['err_data']),
                        'res': cmdRes['res'] if 'res' in cmdRes else cmdRes,
                        'timeout': 20000,
                        'type': 'warning'
                    }
                return {
                    'txt': "Команда %s невыполнена: %s" % (cmdName, cmdRes['res'] if 'res' in cmdRes else ''),
                    'res': cmdRes['res'] if 'res' in cmdRes else cmdRes,
                    'timeout': 30000,
                    'type': 'warning'
                }
        else:
            return get_res_function('Команда выполнена c ошибкой : %s' % cmdRes, 30000, 'warning')
    except BaseException:
        return get_res_function('Ошибка в выполнении команды %s' % cmdName, 30000, 'error')
