# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, index_decorator

from . import event_packet
from .orionintgrsrv_schedule import orionintgrsrv_schedule

from common_protocol_config.common_schedule import common_schedule


class orionintgrsrv_accessitemzone(protocol_obj_base, alias='Зоны доступа'):

    OBSOBJTYPE = 'dev'

    @index_decorator('item_id')
    def item_idIndexBuilder(self):
        return self.itemid

    @classmethod
    def getBooleanType(cls):
        return event_packet.getBooleanType()

    @classmethod
    def getAntipassbackValue(cls):
        return event_packet.getAntipassbackValue()

    def __rightsChanged(self, oldValue, oldValues):
        if self.rights == 0:
            self.apback = 0
            self.zonalapback = 0
            self.ltime = 0
        self.attrUpdated('mask')

    def __apbackChanged(self, oldValue, oldValues):
        if self.apback == 0:
            self.zonalapback = 0
        if self.apback != 2:
            self.ltime = 0
        self.attrUpdated('mask')

    def __getFieldMask(self, field):
        result = 'description,itemid,timewind,dconf,tconf,schedule,isconf,isconfb,rights,obsobjtype'
        # для режима Проход (0), антипасбак не используется
        if self.rights > 0:
            result += ',apback'
        if self.apback > 0:
            result += ',zonalapback'
        # для всременного антипасбак включаем атрибут времени блокировки
        if self.apback == 2:
            result += ',ltime'
        return result

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Название зоны доступа', fieldType=str, defval='', index=1)
    rights = Attribute(alias='Режим', fieldType=int, defval=3, index=2, postAction=__rightsChanged,
                       editorType='enum(Проход, Вход, Выход, Вход/Выход)')
    apback = Attribute(alias='Antipassback', fieldType=int, defval=0, index=3, postAction=__apbackChanged,
                       editorType="treeSelect(getAntipassbackValue)")
    ltime = Attribute(alias='Время разблокировки antipassback', fieldType=int, defval=0, index=4)
    dconf = Link(alias='Подтвержденре по 2-м лицам', target=orionintgrsrv_schedule, index=5)
    tconf = Link(alias='Подтвержденре по 3-м лицам', target=orionintgrsrv_schedule, index=6)
    isconf = Attribute(alias='Подтверждающий', fieldType=bool, defval=False, index=7,
                       editorType='treeSelect(getBooleanType)')
    zonalapback = Attribute(alias='Зональный antipassback', fieldType=bool, defval=False, index=8,
                            editorType='treeSelect(getBooleanType)')
    isconfb = Attribute(alias='Подтверждение по кнопке', fieldType=bool, defval=False, index=9,
                        editorType='treeSelect(getBooleanType)')
    itemid = Attribute(alias='Идентификатор в Орион Про', fieldType=int, defval=0, index=10, editorType='int')
    schedule = Link(alias='Окно времени', target=common_schedule, index=11)

    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
    mask = Attribute(alias='', fget=__getFieldMask, readOnly=True, storeInDb=False)

    itemtype = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
    timewind = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
