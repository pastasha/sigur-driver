# -*- coding: utf-8 -*-

alias = 'Сторонние системы АРМ Орион Про'
rootDev = 'master'
