# -*- coding: utf-8 -*-

import json
import traceback

from equipment.protocol_obj_base import protocol_obj_base, Attribute, action_decorator

from . import event_packet


class orionintgrsrv_master(protocol_obj_base, alias='Драйвера интеграции Орион Про'):

    OBSOBJTYPE = 'dev'

    def readAccessLevels(self):
        return self.sendToPorts('OISReadAccessLevels', {
            'cmd': 'OISReadAccessLevels'
        })

    def importAccessLevel(self, level_id):
        return self.sendToPorts('OISImportAccessLevel', {
            'cmd': 'OISImportAccessLevel',
            'id': level_id
        })

    def createAccessLevel(self, name, comment, items):
        return self.sendToPorts('OISCreateAccessLevel', {
            'cmd': 'OISCreateAccessLevel',
            'name': name,
            'comment': comment,
            'items': items
        })

    def updateAccessLevel(self, level_id, name, comment, items, asynchronously=False):
        return self.sendToPorts('OISUpdateAccessLevel', {
            'cmd': 'OISUpdateAccessLevel',
            'id': level_id,
            'name': name,
            'comment': comment,
            'items': items,
            'async': asynchronously
        })

    def deleteAccessLevel(self, level_id):
        return self.sendToPorts('OISDeleteAccessLevel', {
            'cmd': 'OISDeleteAccessLevel',
            'id': level_id
        })

    def __get_access_points_and_access_zones_data(self, itemsids):
        result = []
        item_index = 0
        for i in itemsids.split(','):
            if i == '':
                continue
            orion_id = int(i[1:])

            item_obj = event_packet.findItemByType(self._core, 'ACCESSPOINT' if i[0] == 'p' else 'ACCESSZONE', orion_id)
            if not item_obj:
                continue
            item_index += 1
            item = {
                'Id': item_index,
                'ItemId': item_obj.getAttribute('itemid'),
                'ItemType': 1 if i[0] == 'p' else 0,  # для точек доступа 1, для зон 0
                'TimeWindowId': 0,
                'Rights': 0,
                'Antipassback': item_obj.getAttribute('apback'),
                'LockTime': item_obj.getAttribute('ltime'),
                'IsZonalAntipassback': item_obj.getAttribute('zonalapback'),
                'DoubleConfirmationId': 0,
                'TripleConfirmationId': 0,
                'IsConfirming': item_obj.getAttribute('isconf'),
                'IsConfirmationButton': item_obj.getAttribute('isconfb')
            }
            if item_obj.isLinkedElement('schedule'):
                # TODO: переделать на subsystem_id
                item['TimeWindowId'] = int(item_obj.getLinkedElement('schedule').getAttribute('external_id'))
            right = item_obj.getAttribute('rights')
            item['Rights'] = int(right if right else 0)
            if item_obj.isLinkedElement('dconf'):
                item['DoubleConfirmationId'] = item_obj.getLinkedElement('dconf').getAttribute('code')

            if item_obj.isLinkedElement('tconf'):
                item['TripleConfirmationId'] = item_obj.getLinkedElement('tconf').getAttribute('code')

            result.append(item)

        return result

    def init(self):
        if self.siteId == '':
            self['cmdDriver'] = self.buildPlugin('portsClient2', connStr=self.portsaddr, methodTimeout=30)
        else:
            self['cmdDriver'] = None

    def finit(self):
        if 'cmdDriver' in self:
            self['cmdDriver'].release()
        print('finit orionintrsrv')

    def __reinit(self, oldValue, oldValues):
        try:
            self.finit()
        except:
            pass
        self.init()

    def onEvent(self, event=None, portsEvent=None):
        # print 'new OrionIntgSrv event: %.300s %s'%(params,'...' if len(str(params))> 300 else '')
        event_packet.eventParser(self, self._core, event, portsEvent)
        if self['cmdDriver'].isValid():
            self['cmdDriver'].sendOk()

    def createUserAsync(self, permitParams, permit):
        # TODO: REFACTORING. это вообще ужасно.
        try:
            print("try createUserAsync orion intgrsrv...")
            if 'Photo' in permitParams:
                permitParams['Photo'] = event_packet.getSubjPhoto(['Photo'])
            res = self.sendToPorts('userRegisterAsync', {
                'cmd': 'userRegisterAsync',
                'permit': permitParams,
                'async': False,
                'dbconnection': 'useconfig'  # obj.getAttribute('dbconnection')
            })
            if res:
                if 'type' in res and res['type'] != 'info':
                    # TODO: смысл raise не очень ясен так как он перехватится 3 строчками ниже
                    raise Exception(res['txt'])
            return res
        except Exception as e:
            # TODO: заменить на логгер
            print("Orion  userRegister - fail: %s" % repr(e))
            raise

    def updateUser(self, extId, subjectId, forceUpdatePers):
        try:
            self.sendToPorts('updateUser', {
                'cmd': 'updateUser',
                'ExtID': extId,
                'SubjectID': subjectId,
                'async': True,
                'forceupdatePers': forceUpdatePers
            })
        except Exception as e:
            print("updateUser Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()

    @action_decorator(alias='Импортировать Уровни доступа')
    def OISReadAccessLevels(self):
        try:
            ret = self.readAccessLevels()
            if ret.get('res', {}).get('status') == 'ok':
                return event_packet.get_res_function('Импорт уровней доступа Орион Про запущен успешно', 5000, 'info')
            else:
                return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadAccessLevels Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % (repr(e)), 5000, 'error')

    @action_decorator(alias='Импортировать Карты доступа')
    def OISReadKeyList(self):
        try:
            ret = self.sendToPorts('OISReadKeyList', {
                'cmd': 'OISReadKeyList'
            })
            print(u"OISReadKeyList = %s" % (ret['txt']))
            print('read %.300s' % (ret['res']))
            if 'arrayKey' in ret['res']:
                event_packet.UpdatePermitTable(self._core, json.loads(ret['res']['arrayKey']))
                return event_packet.get_res_function('Импорт списка Ключей Орион Про выполнен успешно', 5000, 'info')
            return event_packet.get_res_function('Команда импорта Ключей Орион Про не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadKeyList Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать Частные лица')
    def OISReadPersonList(self):
        try:
            ret = self.sendToPorts('OISReadPersonList', {
                'cmd': 'OISReadPersonList'
            })
            # TODO: тут все очень странно. buildCommand через decodeCommandResult не может вернуть None поэтому проверка
            #  не имеет смысла. Но если выполнение команды завернится ошибкой то в ret не будет параметра res и эта
            #  функция упадет 3 строчками ниже
            if ret:
                print(u"OISReadPersonList = %s" % (ret['txt'] if ret and 'txt' in ret else "Error"))
                # print 'read %.300s'%(ret['res'])
                if 'arrayPers' in ret['res']:
                    event_packet.UpdatePersonTable(self._core, json.loads(ret['res']['arrayPers']))
                return event_packet.get_res_function('Импорт списка Частных Лиц Орион Про выполнен успешно', 5000,
                                                     'info')
            else:
                return event_packet.get_res_function('Команда импорта Частных лиц не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadPersonList Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать Организации')
    def OISReadOrgList(self):
        try:
            ret = self.sendToPorts('OISReadOrgList', {
                'cmd': 'OISReadOrgList'
            })
            print(u"OISReadOrgList = %s" % (ret['txt']))
            if 'arrayOrg' in ret['res']:
                event_packet.UpdateOrgTable(self._core, json.loads(ret['res']['arrayOrg']))
                return event_packet.get_res_function('Импорт списка Организаций Орион Про выполнен успешно', 5000,
                                                     'info')
            return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadOrgList Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать Должности')
    def OISReadPostList(self):
        try:
            ret = self.sendToPorts('OISReadPostList', {
                'cmd': 'OISReadPostList'
            })
            print(u"OISReadPostList = %s" % (ret['txt']))
            if 'arrayPost' in ret['res']:
                event_packet.UpdatePostTable(self._core, json.loads(ret['res']['arrayPost']))
                return event_packet.get_res_function('Импорт списка Должностей Орион Про выполнен успешно', 5000,
                                                     'info')
            return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadPostList Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать Подразделения')
    def OISReadDepList(self):
        try:
            ret = self.sendToPorts('OISReadDepList', {
                'cmd': 'OISReadDepList'
            })
            print(u"OISReadDepList = %s" % (ret['txt']))
            if 'arrayDep' in ret['res']:
                event_packet.UpdateDepartTable(self._core, json.loads(ret['res']['arrayDep']))
                return event_packet.get_res_function('Импорт списка Подразделений Орион Про выполнен успешно', 5000,
                                                     'info')
            return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISReadDepList Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать все')
    def OISReadALL(self):
        result = self.OISReadPostList()
        result['txt'] = '\n' + self.OISReadOrgList()['txt']
        result['txt'] = '\n' + self.OISReadDepList()['txt']
        result['txt'] = '\n' + self.OISReadPersonList()['txt']
        result['txt'] = '\n' + self.OISReadKeyList()['txt']
        result['txt'] = '\n' + self.OISGetTimeWindows()['txt']
        result['txt'] = '\n' + self.OISGetAccessZones()['txt']
        result['txt'] = '\n' + self.OISGetEntryPoints()['txt']
        result['txt'] = '\n' + self.OISReadAccessLevels()['txt']
        return result

    @action_decorator(alias='Импортировать окна времени')
    def OISGetTimeWindows(self):
        try:
            ret = self.sendToPorts('OISGetTimeWindows', {
                'cmd': 'OISGetTimeWindows'
            })
            print(u"OISGetTimeWindows = %s" % (ret['txt']))
            return event_packet.get_res_function('Импорт окон времени Орион Про выполнен успешно', 5000, 'info')
        except Exception as e:
            print("OISGetTimeWindows Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать зоны доступа')
    def OISGetAccessZones(self):
        try:
            ret = self.sendToPorts('OISGetAccessZones', {
                'cmd': 'OISGetAccessZones'
            })
            print(u"OISGetAccessZones = %s" % (ret['txt']))
            if 'arrayZones' in ret['res']:
                event_packet.UpdateAccessZones(self._core, json.loads(ret['res']['arrayZones']))
                return event_packet.get_res_function('Импорт зон доступа Орион Про выполнен успешно', 5000, 'info')
            return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISGetAccessZones Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Импортировать точки доступа')
    def OISGetEntryPoints(self):
        try:
            ret = self.sendToPorts('OISGetEntryPoints', {
                'cmd': 'OISGetEntryPoints'
            })
            print(u"OISGetEntryPoints = %s" % (ret['txt']))
            if 'arrayPoints' in ret['res']:
                event_packet.UpdateEntryPoints(self._core, json.loads(ret['res']['arrayPoints']))
                return event_packet.get_res_function('Импорт точек доступа Орион Про выполнен успешно', 5000, 'info')
            return event_packet.get_res_function('Команда не выполнена', 5000, 'warning')
        except Exception as e:
            print("OISGetEntryPoints Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка выполнения команды: %s' % repr(e), 5000, 'error')

    @action_decorator(alias='Создание уровня доступа', name='', itemsid='', comment='')
    def OISCreateAccessLevel(self, name: str = '', itemsid: str = '', comment: str = ''):
        try:
            itemsid = self.__get_access_points_and_access_zones_data(itemsid)
            result = self.createAccessLevel(name, comment, itemsid)
            if 'res' in result and 'acclvl' in result['res']:
                event_packet.UpdateAccessLevelTable(self._core, json.loads(result['res']['acclvl']))
                return event_packet.get_res_function('Создание УД "%s" Орион Про прошло успешно' % name, 5000, 'info')
            else:
                print('-----------------')
                print('Error result %s' % result)
                print('-----------------')
                return event_packet.get_res_function('Ошибка создания УД "%s" в Орион Про. ' % name, -1, 'warning')
        except Exception as e:
            print("OISCreateAccessLevel Error %s" % (repr(e)))
            # TODO: заменить на логгер
            traceback.print_exc()
            return event_packet.get_res_function('Ошибка создания уровня доступа: %s' % repr(e), 5000, 'error')

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    portsaddr = Attribute(alias='Адрес модуля Ports', fieldType=str, defval='', index=2, postAction=__reinit)
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)

    # TODO: перенести в эти параметры настройки подключения из ports
    # hostname = Attribute(alias='', fieldType=str, defval='', showInClient=False)
    # port = Attribute(alias='', fieldType=int, defval=0, showInClient=False)
    # TODO: похоже что это параметр вообще не нужен
    # dbconnection = Attribute(alias='', fieldType=str, defval='', showInClient=False)
