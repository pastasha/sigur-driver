<?xml version='1.0' encoding='UTF-8'?>
<equipment name="orionintgrsrv">
  <alias>
    <source>Сторонние системы АРМ Орион Про</source>
    <translation>undefined</translation>
  </alias>
  <devTypes>
    <devType name="accessitempoint">
      <alias>
        <source>Точка доступа</source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Профили</source>
        <translation>undefined</translation>
      </parent>
      <field name="apback">
        <source>Antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="description">
        <source>Название точки доступа</source>
        <translation>undefined</translation>
      </field>
      <field name="isconf">
        <source>Подтверждающий</source>
        <translation>undefined</translation>
      </field>
      <field name="isconfb">
        <source>Подтверждение по кнопке</source>
        <translation>undefined</translation>
      </field>
      <field name="itemid">
        <source>Идентификатор в Орион Про</source>
        <translation>undefined</translation>
      </field>
      <field name="ltime">
        <source>Время разблокировки antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="mask">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>undefined</translation>
      </field>
      <field name="rights">
        <source>Режим</source>
        <translation>undefined</translation>
      </field>
      <field name="zonalapback">
        <source>Зональный antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="dconf">
        <source>Подтвержденре по 2-м лицам</source>
        <translation>undefined</translation>
      </field>
      <field name="schedule">
        <source>Окно времени</source>
        <translation>undefined</translation>
      </field>
      <field name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="accessitemzone">
      <alias>
        <source>Зоны доступа</source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Профили</source>
        <translation>undefined</translation>
      </parent>
      <field name="apback">
        <source>Antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="description">
        <source>Название зоны доступа</source>
        <translation>undefined</translation>
      </field>
      <field name="isconf">
        <source>Подтверждающий</source>
        <translation>undefined</translation>
      </field>
      <field name="isconfb">
        <source>Подтверждение по кнопке</source>
        <translation>undefined</translation>
      </field>
      <field name="itemid">
        <source>Идентификатор в Орион Про</source>
        <translation>undefined</translation>
      </field>
      <field name="ltime">
        <source>Время разблокировки antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="mask">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>undefined</translation>
      </field>
      <field name="rights">
        <source>Режим</source>
        <translation>undefined</translation>
      </field>
      <field name="zonalapback">
        <source>Зональный antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="dconf">
        <source>Подтвержденре по 2-м лицам</source>
        <translation>undefined</translation>
      </field>
      <field name="schedule">
        <source>Окно времени</source>
        <translation>undefined</translation>
      </field>
      <field name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="master">
      <alias>
        <source>Драйвера интеграции Орион Про</source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Профили</source>
        <translation>undefined</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>undefined</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>undefined</translation>
      </field>
      <field name="portsaddr">
        <source>Адрес модуля Ports</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
      <action name="OISCreateAccessLevel">
        <source>Создание уровня доступа</source>
        <translation>undefined</translation>
        <params>
          <param name="name">
            <source></source>
            <translation>undefined</translation>
          </param>
          <param name="itemsid">
            <source></source>
            <translation>undefined</translation>
          </param>
          <param name="comment">
            <source></source>
            <translation>undefined</translation>
          </param>
        </params>
      </action>
      <action name="OISGetAccessZones">
        <source>Импортировать зоны доступа</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISGetEntryPoints">
        <source>Импортировать точки доступа</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISGetTimeWindows">
        <source>Импортировать окна времени</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadALL">
        <source>Импортировать все</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadAccessLevels">
        <source>Импортировать Уровни доступа</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadDepList">
        <source>Импортировать Подразделения</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadKeyList">
        <source>Импортировать Карты доступа</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadOrgList">
        <source>Импортировать Организации</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadPersonList">
        <source>Импортировать Частные лица</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISReadPostList">
        <source>Импортировать Должности</source>
        <translation>undefined</translation>
        <params/>
      </action>
    </devType>
    <devType name="schedule">
      <alias>
        <source>Уровень доступа</source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Профили</source>
        <translation>undefined</translation>
      </parent>
      <field name="code">
        <source>Идентификатор в Орион Про</source>
        <translation>undefined</translation>
      </field>
      <field name="description">
        <source>Название уровня доступа</source>
        <translation>undefined</translation>
      </field>
      <field name="orion_comment">
        <source>Комментарий</source>
        <translation>undefined</translation>
      </field>
      <field name="orion_flags">
        <source>Тип уровня доступа</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
      <action name="OISImportAcLvl">
        <source>Прочитать из Орион Про</source>
        <translation>undefined</translation>
        <params/>
      </action>
      <action name="OISUpdateAccessLevel">
        <source>Записать в Орион Про</source>
        <translation>undefined</translation>
        <params/>
      </action>
    </devType>
    <devType name="schedule_accessitempoint">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Точки доступа</source>
        <translation>undefined</translation>
      </parent>
      <field name="apback">
        <source>Antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="isconf">
        <source>Подтверждающий</source>
        <translation>undefined</translation>
      </field>
      <field name="isconfb">
        <source>Подтверждение по кнопке</source>
        <translation>undefined</translation>
      </field>
      <field name="itemid">
        <source>Идентификатор в Орион Про</source>
        <translation>undefined</translation>
      </field>
      <field name="ltime">
        <source>Время разблокировки antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="mask">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="rights">
        <source>Режим</source>
        <translation>undefined</translation>
      </field>
      <field name="zonalapback">
        <source>Зональный antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="accessitempoint">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="dconf">
        <source>Подтвержденре по 2-м лицам</source>
        <translation>undefined</translation>
      </field>
      <field name="schedule">
        <source>Окно времени</source>
        <translation>undefined</translation>
      </field>
      <field name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="schedule_accessitemzone">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Зоны доступа</source>
        <translation>undefined</translation>
      </parent>
      <field name="apback">
        <source>Antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="isconf">
        <source>Подтверждающий</source>
        <translation>undefined</translation>
      </field>
      <field name="isconfb">
        <source>Подтверждение по кнопке</source>
        <translation>undefined</translation>
      </field>
      <field name="itemid">
        <source>Идентификатор в Орион Про</source>
        <translation>undefined</translation>
      </field>
      <field name="ltime">
        <source>Время разблокировки antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="mask">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="rights">
        <source>Режим</source>
        <translation>undefined</translation>
      </field>
      <field name="zonalapback">
        <source>Зональный antipassback</source>
        <translation>undefined</translation>
      </field>
      <field name="accessitemzone">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <field name="dconf">
        <source>Подтвержденре по 2-м лицам</source>
        <translation>undefined</translation>
      </field>
      <field name="schedule">
        <source>Окно времени</source>
        <translation>undefined</translation>
      </field>
      <field name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </field>
      <link name="tconf">
        <source>Подтвержденре по 3-м лицам</source>
        <translation>undefined</translation>
      </link>
    </devType>
  </devTypes>
  <strings/>
</equipment>
