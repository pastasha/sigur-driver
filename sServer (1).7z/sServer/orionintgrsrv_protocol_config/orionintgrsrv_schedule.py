# -*- coding: utf-8 -*-

import json

from equipment.protocol_obj_base import protocol_obj_base, Attribute, index_decorator, action_decorator
from equipment import dev_except

from . import event_packet


class orionintgrsrv_schedule(protocol_obj_base, alias='Уровень доступа'):

    def __get_linked_items_data(self):
        def getObjData(obj):
            item = {
                'Id': int(obj.getAttribute('itemid')),
                'ItemId': int(obj.getLinkedElement('accessitempoint').getAttribute('itemid')),
                'ItemType': 'ACCESSPOINT',  # для точек доступа
                'TimeWindowId': 0,
                'Rights': int(obj.getAttribute('rights')),
                'Antipassback': int(obj.getAttribute('apback')),
                'LockTime': int(obj.getAttribute('ltime')),
                'IsZonalAntipassback': bool(obj.getAttribute('zonalapback')),
                'DoubleConfirmationId': 0,
                'TripleConfirmationId': 0,
                'IsConfirming': bool(obj.getAttribute('isconf')),
                'IsConfirmationButton': bool(obj.getAttribute('isconfb'))
            }
            if obj.isLinkedElement('schedule'):
                item['TimeWindowId'] = int(obj.getLinkedElement('schedule').getAttribute('external_id'))
            if obj.isLinkedElement('dconf'):
                item['DoubleConfirmationId'] = int(obj.getLinkedElement('dconf').getAttribute('code'))
            if obj.isLinkedElement('tconf'):
                item['TripleConfirmationId'] = int(obj.getLinkedElement('tconf').getAttribute('code'))
            return item

        result = []
        try:
            points_d = self.getChildListByType('schedule_accessitempoint')
            zones_d = self.getChildListByType('schedule_accessitemzone')
            for point in points_d:
                result.append(getObjData(point))

            for zone in zones_d:
                result.append(getObjData(zone))
            return result
        except Exception as e:
            import traceback
            traceback.print_exc()
            return None

    def __read_access_level_from_orion(self):
        if self.code == 0:
            result = event_packet.get_res_function('"Идентификатор УД Орион не задан"', 5000, 'warning')
        else:
            ret = self._core.getFirst('master').doAction('importAccessLevel', {'level_id': self.code})
            if ret and 'res' in ret and 'status' in ret['res'] and ret['res']['status'] == 'ok':
                event_packet.UpdateAccessLevelTable(self._core, ret['res']['res'])
                result = event_packet.get_res_function('"Чтение УД %s выполнен успешно"' %
                                                       self.description, 5000, 'info')
            elif ret:
                result = ret
            else:
                result = event_packet.get_res_function('Ошибка выполнения чтения УД: %s' % repr(ret), 5000, 'warning')
        return result

    def __add_access_level_to_orion(self):
        if self.code > 0:
            # Если идентификатор Орион назначен, то УД уже создан.
            # Это может быть при импорте УД и при Создаении УД из БП
            return event_packet.get_res_function('Создание  уровня доступа завершено успешно', 5000, 'info')
        params = {
            'items': self.__get_linked_items_data(),
            'name': self.description,
            'comment': self.orion_comment
        }
        ret = self._core.getFirst('master').doAction('createAccessLevel', params)
        if ret and 'res' in ret and 'acclvl' in ret['res']:
            self.code = json.loads(ret['res']['acclvl'])[0]['id']
            # UpdateAccessLevelTable(core, json.loads(ret['res']['acclvl']))
            result = event_packet.get_res_function('Создание  уровня доступа завершено успешно', 5000, 'info')
        else:
            raise dev_except.CommandExecError(ret['txt'])
        return result

    def __update_access_level_to_orion(self, asynchronously=False):
        if self.code == 0:
            result = self.__add_access_level_to_orion()
        else:
            params = {
                'items': self.__get_linked_items_data(),
                'level_id': self.code,
                'asynchronously': asynchronously,
                'name': self.description,
                'comment': self.orion_comment
            }
            ret = self._core.getFirst('master').doAction('updateAccessLevel', params)
            if ret and 'res' in ret and 'status' in ret['res'] and ret['res']['status'] == 'ok':
                event_packet.UpdateAccessLevelTable(self._core, ret['res']['res'])
                result = event_packet.get_res_function('"Запись УД %s выполнена успешно"' %
                                                       self.description, 5000, 'info')
            elif ret:
                result = ret
            else:
                result = event_packet.get_res_function('Ошибка выполнения экспорта УД: %s' % repr(ret), 5000, 'warning')
        return result

    def __delete_access_level_from_orion(self):
        result = None
        ret = None
        # Вообще code не может быть <= 0. Это специально чтобы расписание можно было удалить если нет связи и орион
        # или его там уже нет
        if self.code > 0:
            if self._core.getFirst('master'):
                ret = self._core.getFirst('master').doAction('deleteAccessLevel', {'level_id': self.code})
                if ret and 'res' in ret and 'status' in ret['res'] and ret['res']['status'] == 'ok':
                    result = event_packet.get_res_function('Удаление  уровня доступа завершено успешно', 5000, 'info')
                else:
                    raise dev_except.CommandExecError(ret['txt'])
        childItemsObj = self.getChildListByType('schedule_accessitempoint') + self.getChildListByType(
            'schedule_accessitemzone')
        for item in childItemsObj:
            self.removeChild(item, dbCorrect=True, skipTrig=True)
            item.selfDelete()
        rightObjs = self.getBackLinkElements('commonright', 'schedule_srv', 'common')
        for r in rightObjs:
            if r.getAttribute('description') == self.getAttribute('description'):
                r.unBindElement('schedule_srv')  # добавлено чтобы event_monitor не падал
                r.selfDelete()
        return result

    @index_decorator('orion_id')
    def orion_idIndexBuilder(self):
        return self.code

    @classmethod
    @action_decorator(alias='Прочитать все из БД Орион Про', actionClass='static')
    def importAll(cls):
        return cls._core.getFirst('master').doAction('readAccessLevels')

    @classmethod
    @action_decorator(alias='Записать все в БД Орион Про', actionClass='static')
    def exportAll(cls):
        res = u''
        for o in cls._core.getElements(cls.typeName):
            ret = o.doAction('OISUpdateAccessLevel')
            if ret['type'] == 'info':
                res = u"""%s&lt;div style="color: green;"&gt;'%s' %s &lt;/div&gt;""" % (res, o.getDescription(), ret['txt'])
            else:
                res = u"""%s&lt;div style="color: red;"&gt;'%s': %s&lt;/div&gt;""" % (res, o.getDescription(), ret['txt'])
        return {
            'txt'	:	res,
            'timeout'	:	30000,
            'type'		:	'info'
        }

    @action_decorator(alias='Записать в Орион Про')
    def OISUpdateAccessLevel(self):
        return self.__update_access_level_to_orion(asynchronously=True)

    @action_decorator(alias='Прочитать из Орион Про')
    def OISImportAcLvl(self):
        return self.__read_access_level_from_orion()

    def postCreate(self, ignore_create_objects=False):
        return self.__add_access_level_to_orion()

    def preDelete(self, deleteAsLink=False):
        self.__delete_access_level_from_orion()

    description = Attribute(alias='Название уровня доступа', fieldType=str, defval='', index=1)
    code = Attribute(alias='Идентификатор в Орион Про', fieldType=int, defval=0, index=2, editorType='int')
    orion_comment = Attribute(alias='Комментарий', fieldType=str, defval='', index=3)
    orion_flags = Attribute(alias='Тип уровня доступа', fieldType=int, defval=0, index=4,
                            editorType='enum(Обычный уровень доступа, Оперативный уровень доступа)')
