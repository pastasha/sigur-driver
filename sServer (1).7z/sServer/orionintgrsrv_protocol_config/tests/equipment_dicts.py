# -*- coding: utf-8 -*-

list_equipment = [
    {
        'name': 'accessitempoint',
        'attributes': {
            'description': 'accessitempoint',
            'rights': 0,
            'apback': 1,
            'ltime': 1,
            'isconf': True,
            'zonalapback': True,
            'isconfb': True,
            'itemid': 1
        }

    },
    {
        'name': 'accessitemzone',
        'attributes': {
            'description': 'accessitemzone',
            'rights': 0,
            'apback': 1,
            'ltime': 1,
            'isconfb': True,
            'zonalapback': True,
            'itemid': 1,
            'isconf': True
        }

    },
    {
        'name': 'master',
        'attributes': {
            'description': 'master',
            'portsaddr': '127.0.0.1,8002'
        }

    },
    {
        'name': 'schedule',
        'attributes': {
            'description': 'schedule',
            'code': 123,
            'orion_comment': 'orion_comment',
            'orion_flags': 1
        }

    },
    {
        'name': 'schedule_accessitempoint',
        'attributes': {
            'description': 'schedule_accessitempoint',
            'rights': 0,
            'apback': 1,
            'ltime': 1,
            'isconfb': True,
            'zonalapback': True,
            'itemid': 1,
            'isconf': True
        }

    },
    {
        'name': 'schedule_accessitemzone',
        'attributes': {
            'description': 'schedule_accessitemzone',
            'rights': 0,
            'apback': 1,
            'ltime': 1,
            'isconfb': True,
            'zonalapback': True,
            'itemid': 1,
            'isconf': True
        }

    }
]