# -*- coding: utf-8 -*-

from equipment.methods_for_testing import *
from orionintgrsrv_protocol_config.tests.equipment_dicts import *


def main():
    class_methods = MethodsForTesting()
    class_methods.list_equipment = list_equipment
    class_methods.equipment_name = 'orionintgrsrv'
    class_methods.create_and_delete_equipments()

    accessitempoint = class_methods.get_reqData('accessitempoint')
    accessitemzone = class_methods.get_reqData('accessitemzone')
    master = class_methods.get_reqData('master')
    schedule = class_methods.get_reqData('schedule')
    schedule_accessitempoint = class_methods.get_reqData('schedule_accessitempoint')
    schedule_accessitemzone = class_methods.get_reqData('schedule_accessitemzone')

    class_methods.add_childr_equipments(schedule, schedule_accessitempoint)
    class_methods.add_childr_equipments(schedule, schedule_accessitemzone)

    class_methods.set_link(accessitempoint, schedule, 'dconf')
    class_methods.set_link(accessitempoint, schedule, 'tconf')
    class_methods.set_link(accessitempoint, schedule, 'schedule')

    class_methods.set_link(accessitemzone, schedule, 'dconf')
    class_methods.set_link(accessitemzone, schedule, 'tconf')
    class_methods.set_link(accessitemzone, schedule, 'schedule')

    class_methods.set_link(schedule_accessitempoint, schedule, 'dconf')
    class_methods.set_link(schedule_accessitempoint, schedule, 'tconf')
    class_methods.set_link(schedule_accessitempoint, schedule, 'schedule')

    class_methods.set_link(schedule_accessitemzone, schedule, 'dconf')
    class_methods.set_link(schedule_accessitemzone, schedule, 'tconf')
    class_methods.set_link(schedule_accessitemzone, schedule, 'schedule')

    input("Press Enter to continue...")

    class_methods.delete_childr__equipments(schedule_accessitempoint)
    class_methods.delete_childr__equipments(schedule_accessitemzone)

    class_methods.delete_equipments(accessitempoint)
    class_methods.delete_equipments(accessitemzone)
    class_methods.delete_equipments(master)
    class_methods.delete_equipments(schedule)
    class_methods.delete_equipments(schedule_accessitempoint)
    class_methods.delete_equipments(schedule_accessitemzone)

if __name__ == '__main__':
    main()
