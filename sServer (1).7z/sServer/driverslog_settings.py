# -*- coding: utf-8 -*-

# configure logging for drivers
settings = __import__('settings')
#для собранных модулей идентификатор БД постоянный
import sys
if getattr(sys, 'frozen', False):
    settings.Redis_db = 1

def driverLogConfig(equip, loglevel):
    return {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'driver_Fmt': {
                'format': '%(name)-3s %(levelname)-3s [%(asctime)s] %(message)s',
            }
        },
        'handlers': {
            'driver_ConsoleHandler': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'driver_Fmt',
            },

            'driver_FileHandler': {
                'level': 'DEBUG',
                'class': 'logging.handlers.TimedRotatingFileHandler',
                'formatter': 'driver_Fmt',
                'filename': 'logs/' + equip,
                'when': 'midnight',
                'backupCount': 5,
                'encoding': 'utf8'
            },
            'driver_Redis': {
                'level': 'DEBUG',
                'class': 'rlog.RedisListHandler',
                'host': settings.Redis_host,
                'password': settings.Redis_password,
                'port': settings.Redis_port,
                'db': settings.Redis_db,
                'key': equip,
                'max_messages': settings.Redis_messages_per_logger
            }
        },
        'loggers': {
            equip: {
                'handlers': ['driver_Redis', 'driver_ConsoleHandler', 'driver_FileHandler'],
                'level': loglevel,
            },
        },
    }
