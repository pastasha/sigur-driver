# -*- coding: utf-8 -*-

"""
    Оповещение
    Формат:
    {
        "notification"		:	{
            "code"				:	<code>,
            "time"				:	<time>
        },
        "statement"			:	{
            "<role_1>"			:	{
                "dev"				:	{
                    "equip"				:	<equip>,
                    "type"				:	<type>,
                    "id"				:	<id>,
                    "state"				:	<state>
                },
                "obsObj"			:	{
                    "id"				:	<id>,
                    "state"				:	<state>
                },
                "card"				:	<card>
            },
            ...
            "<role_n>"			:	{
                "dev"				:	{
                    "equip"				:	<equip>,
                    "type"				:	<type>,
                    "id"				:	<id>,
                    "state"				:	<state>
                },
                "obsObj"			:	{
                    "id"				:	<id>,
                    "state"				:	<state>
                },
                "card"				:	<card>,
                "param"				:	<param>
            }
        }
    }
    Пакет оповещений
    Формат:
    {
        "notifPack"		:	[
            <notification 1>,
            <notification 2>,
                ...
            <notification n>,
        ]
    }


    Пояснения:
        При каких-либо изменениях конфигурации объектов оборудования или
    объектов мониторинга сервер их состояния и прочих событиях сервер высылает
    оповещение.
        В некоторых случаях сервер может выслать пакет оповещений. Это
    означает, что оповещения из пакета логически связаны, являются следствиями
    общих причин. Пакет оповещений содержит json-массив, элементами которого
    являются собственно оповещения
        Оповещение можно понимать как предложение в изъявительном наклонении,
    повествующее о некотором событии и его участниках.
        Оповещение всегда содержит два сложных поля:
        1. notification - содержит кодовое обозначение события и
            время(опционально)
        2. statement - набор участников события
        Набор участников события представляет собой массив пар ключ-значение,
    где ключ указывает роль участника в событии, а значение описавает участника.
        В описание участника могут входить следующие поля:
        1. dev - если учаснику соответствует некоторый объект оборудования.
        В описание объекта оборудование входит:
            equip - название оборудования (например pce)
            type - тип объекта оборудования
            id - идентификатор объекта оборудования. Может быть равен
            None(null), если объект неизвестен серверу
            state - состояние объекта оборудования (опционально)
        2. card - код считанной карты
        3. param - численная или строковая величина, имевшая место в событии
        4. obsObj - если учаснику соответствует некоторый объект мониторинга.
        5. obsObjType - если учаснику соответствует некоторый тип объекта
            мониторинга.
        В описание объекта мониторинга входит:
            id - идентификатор
            state - состояние (опционально)
    Роль участника является произвольной строкой
"""

import datetime
import traceback
import sys
import http.client
from functools import reduce

import collections
import threading
import time

from esmapi.serializer import Serializer
from esmapi.notifications.sServerNotifications import EquipmentObjectExecActionNotification
from esmapi.objects.equipmentobject import EquipmentObject
from esmapi.commands.sServerCommands import AddObservedObjectCommand
from esmapi.objects.obsobj import ObsObj, DevInfo, ObsObjLink
from esmapi.objects.obsobjtype import ObsObjType

from .event_number_generator import EventNumberGenerator
from .common_processor import CommonProcessor

from equipment.equipment_interface import EquipmentInterface
from equipment.equipment_module import EquipmentModule

from interface_n_tools.speedmeter import SpeedMeter

import json
import string
import logging
import os
from os.path import normpath

import equipment.dev_except as dev_except
from manager.observedobjectmanager import ObservedObjectManager
import uuid
import base64

import some_funcs

from pymetalog.pymetalog import PyMetaLog


settings = __import__('settings')
sys.path.append('locale')
locale = __import__('%s' % settings.language)

logger = logging.getLogger('sServer')


class EventMonitor(threading.Thread, metaclass=PyMetaLog):

    def __init__(self, conn, license, observedObjectTypeGetter, observedObjectGetter, eventsGetter,
                 observedObjectManager: ObservedObjectManager, allEvents=False):
        super(EventMonitor, self).__init__()

        self.setName("EventMonitor")

        self.__observedObjectTypeGetter = observedObjectTypeGetter
        self.__observedObjectGetter = observedObjectGetter
        self.__eventsGetter = eventsGetter
        self.__observedObjectManager = observedObjectManager

        self.__license = license
        self.__allEvents = allEvents
        self.__pluginMsgQueue = collections.deque()

        self.__lock = threading.RLock()

        self.__runFlag = threading.Event()
        self.__runFlag.clear()

        self.__equipments = {}

        self.__mainConn = conn

        self.__mutationReportQueue = collections.deque()

        self.__notifyServer = None

        self.__lastTime = time.time()
        self.__eventCount = 0

        self.__commonProcessor = None

        self.__eventNumGenerator = EventNumberGenerator(conn)

    def getEquipments(self):
        return self.__equipments

    def __enter__(self):
        self.__lock.acquire()

    def setCurrOperator(self, author):
        EquipmentModule.setCurrOperator(author)

    def __exit__(self, type, value, traceback):
        EquipmentModule.setCurrOperator(None)
        self.__lock.release()

    def __mutationReportExecEquipmentAction(self, equipName, typeName, id, remote_guid, actName, params):
        currentOperatorSubject = None
        if 'common' in self.__equipments:
            subj = self.__equipments['common'].getCurrOperatorSubject()
            # Через удаленный мониторинг команды выполняются не авторизованно, поэтому там нет автора
            # TODO: убрать проверку когда поддержка удаленного мониторинга прекратится
            if subj:
                currentOperatorSubject = {
                    'equip': 'common',
                    'type': 'subject',
                    'id': subj.getUniID(),
                    'remote_guid': subj.getRemoteGUID()
                }
        # TODO: подумать как пробросить туда автора
        obj = EquipmentObject(equipName, typeName, id, remote_guid)
        statement = EquipmentObjectExecActionNotification.Statement(obj, actName, params)
        noitf = EquipmentObjectExecActionNotification(statement)
        self.__mutationReportQueue.append(noitf)

    def equipExport(self, equipName, typeName, index):
        return self.__equipments[equipName].export(typeName, index)

    def equipInit(self):
        for equip in self.__equipments.values():
            equip.initAllDev()

    def equipFinit(self):
        for equip in self.__equipments.values():
            equip.finitAllDev()

    def getEquipmentStruct(self):
        struct = EquipmentInterface.getStruct()
        resultStruct = {}
        for equipment in struct:
            resultStruct[equipment] = {
                'alias': struct[equipment]['alias'],
                'types': {}
            }
            for type in struct[equipment]['types']:
                if not struct[equipment]['types'][type]['hidden']:
                    resultStruct[equipment]['types'][type] = struct[equipment]['types'][type]
        return resultStruct

    def getEquipmentObjectsList(self, equipName, typeName):
        if equipName not in self.__equipments:
            raise Exception("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].getDeviceIdListOfType(typeName)

    def getEquipmentObjectsAttributes(self, equipName, typeName, objId):
        if equipName not in self.__equipments:
            raise Exception("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].getDeviceAttributes(
            typeName, objId
        )

    def createEquipmentObject(self, equipName, typeName, siteId='', remote_guid='', attributes=None, bridges=None,
                              parent=None, ignore_create_objects=False, force=False, info=None):
        # TODO: эти проверки наверное в будущем можно убрать
        attributes = attributes or {}
        bridges = bridges or {}
        parent = parent or {}
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        if remote_guid:
            # Подпорка
            guid = remote_guid
            if siteId:
                guid = '%s.%s' % (remote_guid, siteId) if equipName != 'common' else remote_guid
            obj = self.__equipments[equipName].getElementByRemoteGUID(typeName, guid)
            if obj:
                for attr in attributes:
                    self.setEquipmentObjectsAttribute(equipName, typeName, -1, guid, attr, attributes[attr], True, {})
                return obj.getUniID()
        id = self.__equipments[equipName].newElement(typeName, siteId, remote_guid, attributes, bridges, parent,
                                                     ignore_create_objects, force, info).getUniID()
        return id

    def deleteEquipmentObject(self, equipName, typeName, objId, remote_guid, info):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].delElement(typeName, objId, remote_guid, info)

    def setEquipmentObjectsAttribute(self, equipName, typeName, objId, remote_guid, attrName, attrValue, force, info):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].setAttr(typeName, objId, remote_guid, attrName, attrValue, force, info)

    def setEquipmentObjectsLink(self, objEquip, objType, objId, objRemoteGuid, linkedObjEquip, linkedObjType,
                                linkedObjId, linkedObjRemoteGuid, linkName, force=False, info=None):
        if objEquip not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % objEquip)
        if linkedObjEquip not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % linkedObjEquip)

        self.__equipments[objEquip].bind(objType, objId, objRemoteGuid, linkedObjEquip, linkedObjType,
                                         linkedObjId, linkedObjRemoteGuid, linkName, force, info)
        if objEquip != linkedObjEquip:
            if isinstance(info, dict):
                typeStruct = EquipmentInterface.getStruct()
                objDescr = self.__equipments[objEquip].getDescription(objType, objId, objRemoteGuid)
                lnObjDescr = self.__equipments[linkedObjEquip].getDescription(linkedObjType, linkedObjId,
                                                                              linkedObjRemoteGuid)
                # TODO: не круто
                info['msg'] = {
                    'txt': locale.setEquipmentObjectLinkSuccess % (
                        objDescr, lnObjDescr,
                        typeStruct[objEquip]['types'][objType]['links'][linkName]['alias']
                    ),
                    'timeout': 4000,
                    'type': 'info'
                }

    def clrEquipmentObjectsLink(self, equipName, objType, objId, objRemoteGuid, linkName, info=None):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].unBind(objType, objId, objRemoteGuid, linkName, info)

    def addEquipmentChild(self, equipName, parentObjType, parentObjId, parentObjRemoteGuid, childObjType, childObjId,
                          childObjRemoteGuid, addr, info=None):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].addChild(parentObjType, parentObjId, parentObjRemoteGuid, childObjType,
                                                     childObjId, childObjRemoteGuid, addr, info)

    def leaveEquipmentParent(self, equipName, typeName, objId, remote_guid, info=None):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        return self.__equipments[equipName].leaveParent(typeName, objId, remote_guid, info)

    def createEquipmentLink(self, objEquipName, objType, objId, linkedEquipName, linkedObjType, linkedObjId, linkName,
                            addr, bridgeAttrs=None, info=None):
        u"Вызывается клиентом при создании мостового объекта"
        if objEquipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % objEquipName)

        return self.__equipments[objEquipName].createLink(objType, objId, linkedEquipName, linkedObjType, linkedObjId,
            linkName, bridgeAttrs, addr, info)

    def execEquipmentAction(self, equipName, typeName, id, remote_guid, actName, params):
        if equipName not in self.__equipments:
            raise dev_except.EquipmentException("undefined equipment '%s'" % equipName)

        def func():
            return self.__equipments[equipName].execAction(
                typeName, id, remote_guid, actName, params
            )

        # Если id None то значит что действие статическое и его нужно выполнить на всех серверах
        if id and not remote_guid:
            # Если id указан значит выполняется действие над конкретным объектом и можно получить его guid
            data = self.__mainConn.directRequest("""
                select remote_guid from %s_%s where uniid = %s
            """ % (equipName, typeName, id), extract=True)
            remote_guid = data[0][0]
        g = remote_guid.split('.')
        # Нотификации по выполнению команд по общим объектам и статические действия должны разойтись на все сервера
        if len(g) > 1 or equipName == 'common' or not id:
            # Действие "Клонировать" у пропуска делать не надо, иначе буду получатся лишние дубли пропусков
            if not (equipName == 'common' and typeName == 'permit' and actName == 'clone'):
                self.__mutationReportExecEquipmentAction(equipName, typeName, id, remote_guid, actName, params)
                if self.__notifyServer:
                    self.__notifyServer.push([self.__mutationReportQueue[0]])
                    self.__mutationReportQueue.clear()
                # И выполнится на локальном
                if equipName != 'common' and id:
                    return {
                        'txt': locale.equipmentCommandForRemoteSite,
                        'timeout': 5000,
                        'type': 'info'
                    }

        info = {}
        res = self.__processEquipRequest(func, locale.execEquipmentActionError, info)
        if 'msg' in info:
            return info['msg']

        return res

    @staticmethod
    def __processEquipRequest(func, errMsg, info):
        try:
            return func()
        except dev_except.PostActionFail as e:
            if isinstance(info, dict):
                info['msg'] = {
                    'txt': str(e),
                    'timeout': 8000,
                    'type': 'warning'
                }
            logger.exception('__processEquipRequest 1: %s' % repr(e))
        except dev_except.NeedAnswers as e:
            # TODO: похоже что не используется
            if isinstance(info, dict):
                info['msg'] = {
                    'form': e.getForm(),
                    'type': 'dlg'
                }
        except dev_except.CommandExecError2 as e:
            # TODO: похоже что не используется
            if isinstance(info, dict):
                try:
                    errMsg = str(e)
                except BaseException:
                    pass
                info['msg'] = {
                    'txt': errMsg,
                    'timeout': 8000,
                    'type': 'info'
                }
            logger.exception('__processEquipRequest 2: %s' % repr(e))
        except dev_except.EquipmentException as e:
            if isinstance(info, dict):
                try:
                    errMsg = str(e)
                except BaseException:
                    pass
                info['msg'] = {
                    'txt': errMsg,
                    'timeout': 30000,
                    'type': 'error'
                }
            logger.exception('__processEquipRequest 3: %s' % repr(e))
        except Exception as e:
            logger.exception('__processEquipRequest 4: %s' % repr(e))
            if isinstance(info, dict):
                info['msg'] = {
                    'txt': "%s [%s]" % (errMsg, str(repr(e))),
                    'type': 'error'
                }

    def setNotifyServer(self, notifyServer):
        with self.__lock:
            self.__notifyServer = notifyServer

    def addEquipment(self, equipment):
        with self.__lock:
            self.__equipments[equipment.getName()] = equipment

    def setCommon(self, commonProcessor):
        with self.__lock:
            self.__commonProcessor = commonProcessor

    def start(self):
        super(EventMonitor, self).start()

    def stop(self):
        self.__runFlag.set()
        self.join(2)

    def pushPluginMsg(self, equipName, typeName, id, actName, params):
        self.__pluginMsgQueue.append({
            'equip': equipName,
            'type': typeName,
            'id': id,
            'actName': actName,
            'params': params
        })

    def run(self):
        try:
            lastMsg = None
            while not self.__runFlag.isSet():
                lastMsg = None
                try:
                    msg = self.__pluginMsgQueue.popleft()
                    lastMsg = msg
                except IndexError:
                    time.sleep(0.001)
                else:
                    if msg['equip'] not in self.__equipments:
                        logging.getLogger('console').info("undefined equipment '%s'" % msg['equip'])
                    else:
                        self.__equipments[msg['equip']].execSysAction(
                            msg['type'], msg['id'], msg['actName'], msg['params']
                        )

                self.__processEventQueue()
                self.__processEquipNotificationQueue()

        except Exception as e:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            formatted_exception = repr(traceback.format_exception(exc_type, exc_value, exc_traceback))
            logger.exception('event_monitor run() fail: %s\r\nLast msg: %s' % (formatted_exception, repr(lastMsg) if lastMsg else ''))
            os._exit(-1) # WTF: почему завершается весь процесс???
        else:
            logger.info('event_monitor run() finalized')

    def __showSpeed(self):
        currTime = time.time()
        if currTime - self.__lastTime > 5:
            self.__lastTime = currTime
            logging.getLogger('console').info(str(float(self.__eventCount) / 5) + ' ev/s')
            self.__eventCount = 0

    def __processEventQueue(self):
        for ev in EquipmentModule.eventsIterator():
            self.__process(ev)

    def __processEquipNotificationQueue(self):
        for ev in EquipmentModule.equipNotificationsIterator():
            # TODO: дичь полнейшая
            # Думаю что нотификации надо посылать прямо так
            # mutations = collections.deque()
            # mutations.append(ev)
            # self.__sendNotification(mutations)
            if self.__notifyServer:
                self.__notifyServer.push([ev])

    def __processOneEvent(self, event):
        self.__eventCount += 1

        if 'statement' not in event:
            logging.getLogger('console').info('DEBUG __process: %s' % str(event))
            raise Exception('ERROR: Wrong event format')
        statement = event['statement']

        devObjects = {}

        isConfigNotif = True
        isEquipChangeNotif = False
        code = event['notification']['code']
        if not self.__allEvents:
            if 1000 > code or code > 3000:
                isConfigNotif = False
            if 1002 < code < 1008:
                isEquipChangeNotif = True

        # первый этап
        # собираем цепочки ассоциированных объектов мониторинга
        roleToDelete = []  # список пустых ролей события для удаления из итоговой нотификации
        if not isEquipChangeNotif:
            for partyRoleName in statement:
                # Определяем тип участника
                party = statement[partyRoleName]
                if party is None:
                    roleToDelete.append(partyRoleName)
                    continue
                if 'dev' in party:
                    # участник - объект оборудования
                    if party['dev']['id'] is not None:
                        try:
                            # если включен AllEvents то пишем в событие информаю об объекте оборудования
                            if party['dev']['equip'] in self.__equipments or self.__allEvents:
                                dev = self.__equipments[party['dev']['equip']] \
                                    .getElementById(party['dev']['type'], party['dev']['id'])
                                if dev:
                                    devObjects[partyRoleName] = dev
                                    if 'description' in party['dev']:
                                        party['dev']['description'] = dev.getDescription()
                                    if 'name' in party['dev']:
                                        party['dev']['name'] = dev.getDescription()
                        except Exception as e:
                            logging.getLogger('console').info('__process party %s except %s'%(party, e))

                        # Найдем объект мониторинга связанный с объектом оборудования и добавим информацию о нем в
                        # нотификацию
                        obsObj = self.__observedObjectGetter.getByDevObject(party['dev'])
                        if obsObj is not None:
                            party['obsObj'] = {
                                'id': obsObj.id,
                                'type': obsObj.type.id,
                                'name': obsObj.name,
                                'remoteGuid': obsObj.remoteGuid
                            }
                            party['name'] = obsObj.name
                        else:
                            if party['dev']['equip'] != 'common' and not isConfigNotif:
                                return devObjects, event, False
                elif 'card' in party:
                    # участник - карта доступа
                    # пытаемся узнать владельца
                    # если рядом с кодом карты есть параметр codeformat значит возможно в контроллер был прогружен не
                    # полный код карты
                    # по коду пришедшему из контроллера найдем первый уникальный по указанному формату код совпадающий
                    # с кодом из контроллера по этому же формату
                    # будем это делать только для кодов, которые представимы в виде чисел
                    if 'codeformat' in party:
                        try:
                            formatAttr = 'format%s'%party['codeformat']
                            cardCode = int(party['card'])
                            mask = 2**int(party['codeformat'])-1
                            for idcode in self.__equipments['common'].getElements('idcode'):
                                if idcode.getAttribute('codeType') == 0:
                                    if int(idcode.getAttribute(formatAttr)) == 1:
                                        if cardCode == int(idcode.getAttribute('name')) & mask:
                                            party['card'] = int(idcode.getAttribute('name'))
                                            break
                        except: pass
                        del party['codeformat']
                    permitInfo = None
                    extend = self.__get_extend_option(code)
                    if self.__commonProcessor:
                        permitInfo = self.__commonProcessor.getActivePermitInfo(party['card'], extend)
                    if permitInfo:
                        party['dev'] = permitInfo
                elif 'pin' in party:
                    extend = self.__get_extend_option(code)
                    pin = str(party['pin'])
                    permitId = None
                    permit = None
                    for _permitId, _permit in self.__equipments['common'].getElementsByIndex(
                            'permit', 'permitsWithoutIdCodeFromPIN', None, keyValue='pin#%s' % pin).items():
                        permitId = _permitId
                        permit = _permit
                        break
                    if permitId is not None:
                        subj = permit.getLinkedElement('subject')
                        rightsIds = []
                        for pr in permit.getChildListByType('permit_commonright'):
                            rightsIds.append(pr.getLinkedElement('commonright').getUniID())
                        party['dev'] = {
                            'description'	: subj.getDescription(),
                            'name'			: subj.getDescription(),
                            'photo'			: subj.getAttribute('photo'),
                            'equip'			: 'common',
                            'type'			: 'subject',
                            'id'			: subj.getUniID(),
                            'permit'		: permitId,
                            'rightsIds'     : rightsIds
                        }
                    if extend:
                        party['dev'].update(self.__commonProcessor.getExtendedPermitInfo(permitId, subj.getUniID()))

                elif 'subj' in party:
                    # Добавим основую информацию о субъекте
                    subject = self.__equipments['common'].getElementById('subject', party['subj'])
                    party['dev'] = {
                        'description': subject.getDescription(),
                        'name': subject.getDescription(),
                        'photo': subject.getAttribute('photo'),
                        'equip': 'common',
                        'type': 'subject',
                        'id': subject.getUniID()
                    }
                    # Поищем активированный пропуск, и если он есть, добавим информацию о нем
                    permitId = None
                    permit = None
                    for _permitId, _permit in self.__equipments['common'].getElementsByIndex(
                            'permit', 'owner', None, keyValue='%s#%s' % (subject.getUniID(), 1)).items():
                        permitId = _permitId
                        permit = _permit
                        break
                    if permitId is not None and permit is not None:
                        rightsIds = []
                        for pr in permit.getChildListByType('permit_commonright'):
                            rightsIds.append(pr.getLinkedElement('commonright').getUniID())
                        party['dev']['permit'] = permitId
                        party['dev']['rightsIds'] = rightsIds
                    extend = self.__get_extend_option(code)
                    if extend:
                        party['dev'].update(self.__commonProcessor.getExtendedPermitInfo(permitId, subj.getUniID()))

                elif 'wantedface' in party:
                    wantedface = self.__equipments['common'].getElementById('wantedface', party['wantedface'])
                    party['dev'] = {
                        'description': wantedface.getAttribute('description'),
                        'name'		: wantedface.getAttribute('description'),
                        'photo'			: wantedface.getAttribute('photos'),
                        'equip'			: 'common',
                        'type'			: 'wantedface',
                        'id'			: wantedface.getUniID()
                    }

                elif 'wantedface_by_person' in party:
                    subject = self.__equipments['common'].getElementById('subject', party['wantedface_by_person'])
                    party['dev'] = {
                        'description': subject.getDescription(),
                        'name'		: subject.getDescription(),
                        'photo'			: subject.getAttribute('photo'),
                        'equip'			: 'common',
                        'type'			: 'subject',
                        'id'			: subject.getUniID()
                    }

            # добавим информацию о нарушении
            if 'statement' in event:
                if 'subject' in event['statement']:
                    if event['statement']['subject'] and 'card' in event['statement']['subject']:
                        breach_info = self.__find_in_black_list(event['statement']['subject']['card'])

                        if breach_info:
                            self.__set_warning_info(event, breach_info)

        for partyRoleName in roleToDelete:
            del statement[partyRoleName]

        # второй этап
        # вычисляем состояние

        place = None
        if not isEquipChangeNotif:
            for partyRoleName in statement:
                party = statement[partyRoleName]
                # определяем, есть ли объект мониторинга
                if party is None or 'obsObj' not in party:
                    continue

                devState = party.get('dev', {}).get('state')
                party['obsObj']['state'] = self.__observedObjectManager.calculateState(party['obsObj']['id'], devState,
                                                                                       code=code)
                if partyRoleName == 'directObj':
                    # Найдем место главного объекта события
                    obsObj = self.__observedObjectGetter.get(party['obsObj']['id'])
                    elements = obsObj.type.elements
                    for lnk in obsObj.links:
                        if elements[lnk.nameInGroup]['type'] == 'place':
                            place = lnk.target
        if place:
            # Если в событии есть место, и у directObj тоже есть место то скопируем место из события в adverbialCond
            # Условие было заменено потому что оказывается в событии может быть роль adverbialPlace но она будет None
            if 'adverbialPlace' in statement and statement['adverbialPlace'] and 'obsObj' in statement['adverbialPlace']:
                statement['adverbialCond'] = statement['adverbialPlace']
            statement['adverbialPlace'] = {
                'obsObj': {
                    'id': place.id,
                    'type': place.type.id,
                    'name': place.name,
                    'remoteGuid': place.remoteGuid
                },
                'name': place.name
            }

        return devObjects, event, True

    def __get_extend_option(self, code):
        evt = self.__eventsGetter.getByCode(code)
        if not evt:
            logger.exception('event_monitor __process() fail. Cant find Event by code %s' % code)
            return False
        return evt.options & 1 << 4

    def __find_in_black_list(self, code):
        """
        Выполняет поиск распознанного номера или номера карты в черном списке
        """
        try:
            blackItems = self.__equipments['common'].getDeviceListOfType('blacklist')

            for item in blackItems:
                try:
                    if item.getAttribute('state') != 1:
                        continue

                    subj = item.getLinkedElement('subject')
                    mobiles = subj.getChildListByType('mobile')
                    permits = iter(self.__equipments['common'].getElementsByIndex(
                        'permit', 'owner', None, keyValue='%s#1' % subj.getUniID()).items())

                    for mobile in mobiles:
                        # на случай ошибки распознавания
                        if mobile.getAttribute('description').lower().find(code.lower()) != -1:
                            return {
                                'mobile': mobile,
                                'subject': subj,
                                'black_item': item
                            }

                    for permitID, permit in permits:
                        idcode = permit.getLinkedElement('idcode')
                        if str(idcode.getAttribute('name')).lower() == str(code).lower():
                            return {
                                'permit': permit,
                                'subject': subj,
                                'black_item': item
                            }

                except dev_except.LinkedElementNotFound as ex:
                    logger.exception(ex)
        except Exception as ex:
            logger.exception(ex)
            logging.getLogger('console').info(repr(ex))

        return None

    def __set_warning_info(self, notif, breach_item):
        black_item = breach_item['black_item']

        try:
            breachtype = black_item.getLinkedElement('breachtype')
            notif['notification']['level'] = breachtype.getAttribute('level')
        except dev_except.LinkedElementNotFound as ex:
            logger.exception(ex)

        notif['statement']['adverbialWhy'] = {
            'dev': {
                'equip': 'common',
                'type': 'blacklist',
                'id': black_item.getUniID(),
                'state': black_item.getAttribute('state'),
                'value': black_item.getAttribute('timeopen')
            }
        }

    def __process(self, notifPack):
        res = []
        self.__mutationReportQueue.clear()
        mutations = collections.deque()
        if 'notifPack' in notifPack:
            for notif in notifPack['notifPack']:
                ev = self.__processOneEvent(notif)
                res.append((ev[0], ev[1]))
                # 1021 код он как 1000 но немного другой (обрабатывать его нужно в целом так же но вместо 2000
                # пошлется 2021)
                notifcode = notif['notification']['code']
                if notifcode not in (1000, 1021) and ev[2]:
                    mutations.append(notif)
        else:
            ev = self.__processOneEvent(notifPack)
            res.append((ev[0], ev[1]))
            notif_code = notifPack['notification']['code']
            # 1021 код он как 1000 но немного другой (обрабатывать его нужно в целом так же но вместо 2000 пошлется
            # 2021)
            if notif_code not in (1000, 1021) and ev[2]:
                mutations.append(notifPack)

        if len(mutations) > 0:
            self.__sendNotification(mutations)
        if len(self.__mutationReportQueue) > 0:
            self.__sendNotification(self.__mutationReportQueue)
        return res

    def __processEvent(self, event):
        ev = self.__eventsGetter.getByCode(event['notification']['code'])
        if not ev:
            if event['notification']['code'] < 1000 or event['notification']['code'] > 4000:
                # Если мы не нашли событие в каталоге и это не событие конфигурирования возвращаем False
                logger.exception('event_monitor __processEvent fail. Cant find Event by code %s\r\nnotif: %s' % (
                    event['notification']['code'], repr(event)
                ))
                return False
            # Если мы не нашли событие в каталоге и это событие конфигурирования то вернем True чтобы оно ушло в клиент
            return True
        obj = None
        statement = event.get('statement', {})
        directObj = statement.get('directObj', {})
        obsObj = directObj.get('obsObj', {})
        if obsObj:
            obj = self.__observedObjectGetter.get(obsObj['id'])
            event['notification']['veracity'] = obj.veracity
            # Попробуем найти у тебя переопределение данного события
            objType = obj.type
            for eventBrg in objType.events:
                if eventBrg.event.code == ev.code:
                    ev = eventBrg.newEvent
                    break
            event['notification']['userCode'] = ev.code

        format = ev.format
        level = ev.level
        options = ev.options
        color = ev.color
        channel = ev.channel

        if obj and (options & (1 << 2)):
            obj.alertCount = obj.alertCount + 1

        # если нет gui, то дописываем его
        if 'gui' not in event['notification']:
            event['notification']['gui'] = {}

        event['notification']['gui'].update({
            'text': format,
            'color': color
        })

        # если явно задан уровень тревожности события, то не изменяем его
        if 'level' not in event['notification']:
            event['notification']['level'] = level

        if 'pic' in event:
            event['notification']['gui']['picID'] = self.saveImage(event['pic'])
            del event['pic']
        if 'miniPic' in event:
            event['notification']['gui']['minID'] = self.saveImage(event['miniPic'])
            del event['miniPic']
        event['notification']['options'] = options
        event['channel'] = channel
        return True

    def saveImage(self, data):
        if data:
            guid = str(uuid.uuid4())
            img_data = base64.b64decode(data)
            with open(normpath(settings.EVENT_PHOTO_PATH) + '\\' + guid + '.mms', 'wb') as f:
                f.write(img_data)
            return guid

    def __ComplementNotif(self, notif):
        if 'time' in notif['notification']:
            del notif['notification']['time']
        evNum, evRegTime = self.__eventNumGenerator.getNumber()
        notif['notification']['num'] = evNum
        notif['notification']['regTime'] = evRegTime
        res = self.__processEvent(notif)
        if not res:
            return False

        if 'common' in self.__equipments:
            for rootObj in self.__equipments['common'].getElements('root'):
                try:
                    notif['notification']['securLevel'] = rootObj.getLinkedElement('securLevel').getAddr()
                except:
                    notif['notification']['securLevel'] = 0
        return True

    def push(self, event):
        queue = collections.deque()
        queue.append(event)
        return self.__sendNotification(queue)

    def __sendNotification(self, notifs):
        notifPack = []
        while len(notifs) > 0:
            oneNotif = notifs.popleft()
            res = self.__ComplementNotif(oneNotif)
            if not res:
                continue
            notifPack.append(oneNotif)

        if self.__notifyServer and len(notifPack) > 0:
            self.__notifyServer.push(notifPack)

    def getEquipObj(self, equipId):
        if 'equip' not in equipId or \
                        'type' not in equipId or \
                        'id' not in equipId:
            return None
        if not equipId['equip'] in self.__equipments:
            return None
        try:
            return self.__equipments[equipId['equip']].getElementById(
                equipId['type'], equipId['id']
            )
        except dev_except.UndefinedType:
            return None

    def copyObservedObjectsForPceAlg(self, objects, algName, baseNamePart, newNamePart):
        # Метод для копирования объектов мониторинга привязанных к скопированному алгоритму pce
        # Словарь соответствий ид объектов мониторинга из копируемого алгоритма к новому (нужно чтобы потом скопировать
        # обработчики)
        oldObsObjToNewObsObj = {}
        # Найдем ид типа объекта мониторинга "Контейнер объектов"
        containerObjType = 0
        containerElementsLen = 0
        for objType in self.__observedObjectTypeGetter.getObjects():
            if objType.name == 'Контейнер объектов' and len(objType.remoteGuid.split('.')) == 1:
                containerObjType = objType.id
                el = objType.elements
                containerElementsLen = len(el.keys())
        # Создадим контейнер на 64 элемента
        cmd = AddObservedObjectCommand(AddObservedObjectCommand.ReqData(
            obsObj=ObsObj(name='Контейнер для алгоритма %s' % algName, type=ObsObjType(id=containerObjType))))
        containerId = self.__observedObjectManager.addObject(cmd).id
        # По объектам оборудования алгоритма найдем связанные объекты мониторинга
        for obj in self.__observedObjectGetter.getObjects():
            if obj.dev:
                devId = obj.dev.id
                devEquip = obj.dev.equip
                devType = obj.dev.type
                for pceObj in objects:
                    if pceObj[0]['equip'] == devEquip and pceObj[0]['type'] == devType and pceObj[0]['id'] == devId:
                        pceObj[0]['obsObj'] = obj
        i = 1
        for pceObj in objects:
            if 'obsObj' in pceObj[0]:
                obj = pceObj[0]['obsObj']
                newName = obj.name.replace(
                    baseNamePart, newNamePart) if baseNamePart in obj.name else obj.name + '_copy'
                backlinks = []
                if i <= containerElementsLen:
                    backlinks = [ObsObjLink(src=ObsObj(id=containerId), nameInGroup='%03d' % i)]
                cmd = AddObservedObjectCommand(AddObservedObjectCommand.ReqData(
                    obsObj=ObsObj(name=newName, type=ObsObjType(id=obj.type.id),
                                  dev=DevInfo(equip=pceObj[0]['equip'], type=pceObj[0]['type'], id=pceObj[1]['id']),
                                  backlinks=backlinks)))
                newObsObjId = self.__observedObjectManager.addObject(cmd).id
                oldObsObjToNewObsObj[obj.id] = newObsObjId
                logging.getLogger('console').info('Copy obsObj %s id %s connected with %s %s %s' % (
                    obj.name, obj.id, pceObj[0]['equip'], pceObj[0]['type'], pceObj[0]['id']))
                i += 1
        return oldObsObjToNewObsObj

    def createObservedObjectsForPCEAlg(self, algName, equipObjects, observedObjects):
        # Найдем ид типа объекта мониторинга "Контейнер объектов"
        containerObjType = 0
        containerElementsLen = 0
        for objType in self.__observedObjectTypeGetter.getObjects():
            if objType.name == 'Контейнер объектов':
                containerObjType = objType.id
                el = objType.elements
                containerElementsLen = len(list(el.keys()))
        # TODO: это сломано
        containerId = self.createObservedObject(u'Контейнер для алгоритма %s' % algName, containerObjType)

        realObsObj = {}
        i = 1
        for addr in observedObjects:
            name = observedObjects[addr]['name']
            type = observedObjects[addr]['type']
            group = {
                'id': containerId,
                'withName': '%03d' % i
            } if containerObjType != 0 else None
            # TODO: это сломано
            newObsObjId = self.createObservedObject(name, type, group)
            addr = int(addr)
            realObsObj[addr] = newObsObjId
            self.associate(newObsObjId, 'pce', equipObjects[addr].getTypeName(), equipObjects[addr].getUniID())
            i += 1
            if i > containerElementsLen:
                containerId = self.createObservedObject('Контейнер для алгоритма %s' % algName, containerObjType)
                i = 1
        return realObsObj
