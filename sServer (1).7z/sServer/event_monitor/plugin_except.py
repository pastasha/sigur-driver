# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$03.02.2012 16:07:34$"


class PluginSupportError(Exception):
    pass


class UnsupportedPlugin(PluginSupportError):
    def __init__(self, name):
        PluginSupportError.__init__(self,
                                    "UnsupportedPlugin '%s'" % name
                                    )


class PluginNotFound(PluginSupportError):
    def __init__(self, name):
        PluginSupportError.__init__(self,
                                    "PluginSupportError: plugin '%s' not found" % name
                                    )


class PluginError(PluginSupportError):
    def __init__(self, pluginName, equipName, typeName, id, txt):
        self.pluginName = pluginName
        self.obj = (equipName, typeName, id)
        self.txt = txt

    def __str__(self):
        return 'Failed to send command in the equipment'
        # return u'Не удалось отправить команду в оборудование'
        # return u"PluginError [plu=%s, obj=%s:%s#%d]: %s" % (
        #	self.pluginName, self.obj[0], self.obj[1], self.obj[2], unicode(self.txt)
        #)


class UndefinedPluginAttribute(PluginError):
    def __init__(self, pluginName, equipName, typeName, id, attrName):
        PluginError.__init__(
            self, pluginName, equipName, typeName, id, "undefined attr '%s'" % attrName
        )


class WrongEventParameter(PluginSupportError):
    def __init__(self, txt=None):
        PluginSupportError.__init__(self,
                                    "wrong event parameter format%s" % (
                                        ': %s' % txt) if txt else ''
                                    )


class InvalidPlugin(PluginSupportError):
    pass
