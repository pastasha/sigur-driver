# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$02.02.2012 13:37:21$"

from .plugin_except import *
import logging

class PluginObject(object):
    @classmethod
    def init(cls, evMon):
        cls.__evMon = evMon

    def eventProcess(self, eventParams):
        if not isinstance(eventParams, dict):
            raise WrongEventParameter('type %s' % type(eventParams))
        self.__evMon.pushPluginMsg(
            self.__equipName, self.__typeName, self.__id, 'onEvent', eventParams
        )

    def __init__(self, equipName, typeName, id):
        self.__equipName = equipName
        self.__typeName = typeName
        self.__id = id

    def getPluginInfo(self):
        return (self.__equipName, self.__typeName, self.__id)


class PluginSupport(object):
    __instances = {}

    class PluginAgent(object):
        __prohibitedMethod = ('init', 'eventProcess', 'getPluginInfo')

        def __init__(self, name, plgnObj):
            self.__name = name
            self.__plgnObj = plgnObj

        def isValid(self):
            return self.__plgnObj is not None

        '''def __str__(self):
			if not self.__plgnObj:
				return "<Plugin '%s' (invalid)>" % self.__name

			info = self.__plgnObj.getPluginInfo()
			return "<Plugin '%s' (obj=%s:%s#%s)>" % (
				self.__name, info[0], info[1], info[2]
			)'''

        def __getattr__(self, attrName):
            if not self.__plgnObj:
                raise InvalidPlugin()

            if attrName in self.__prohibitedMethod:
                raise AttributeError()

            if not hasattr(self.__plgnObj, attrName):
                info = self.__plgnObj.getPluginInfo()
                raise UndefinedPluginAttribute(
                    self.__name, info[0], info[1], info[2], attrName
                )

            def method(*args, **kwargs):
                if not self.__plgnObj:
                    raise InvalidPlugin()

                try:
                    return getattr(self.__plgnObj, attrName)(*args, **kwargs)
                except Exception as e:
                    info = self.__plgnObj.getPluginInfo()
                    raise PluginError(self.__name, info[0], info[1], info[2],
                                      "method '%s' error: %s" % (
                                          attrName, repr(e))
                                      )

            return method

        def release(self):
            if not self.__plgnObj:
                return

            try:
                self.__plgnObj.release()
            except Exception as e:
                info = self.__plgnObj.getPluginInfo()
                raise PluginError(self.__name, info[0], info[1], info[2],
                                  "release error: %s" % str(e)
                                  )

            self.__plgnObj = None

    @classmethod
    def install(cls, name, pluginCls):
        cls.__instances[name] = pluginCls

    @classmethod
    def buildPlugin(cls, name, equipName, typeName, id, **kwargs):
        logging.getLogger('console').info('Build plugin: %s %s %s[%s] %s' % (name, equipName, typeName, id, kwargs))
        if name not in cls.__instances:
            raise UnsupportedPlugin(name)

        try:
            plgnObj = cls.__instances[name](equipName, typeName, id, **kwargs)
        except Exception as e:
            raise PluginError(name, equipName, typeName, id,
                              "constructor error: %s" % str(e)
                              )
        else:
            return cls.PluginAgent(name, plgnObj)
