# -*- coding: utf-8 -*-

# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$11.07.2011 14:31:27$"


class CommonProcessor(object):
    def __init__(self, conn):
        self._conn = conn

    def getActivePermitInfo(self, cardNum, extend):
        if isinstance(cardNum, int) or isinstance(cardNum, int):
            cardNum = str(cardNum)
        cur = self._conn.cursor()
        cur.execute("""
            select description, photo, subject, permit, rights from get_active_permit_info(%s) where subject is not null
        """, (cardNum,))
        row = cur.fetchone()
        if row:
            permitInfo = {
                'description'	: row[0],
                'name'			: row[0],
                'photo'			: row[1],
                'equip'			: 'common',
                'type'			: 'subject',
                'id'			: row[2],
                'permit'		: row[3],
                'rightsIds'     : row[4]
            }
            if extend:
                permitInfo.update(self.getExtendedPermitInfo(row[3], row[2]))
            return permitInfo

        return None

    def getExtendedPermitInfo(self, permitId, subjId):
        cur = self._conn.cursor()
        permitInfo = dict()
        if permitId:
            cur.execute("""
                select cp.begindt, cp.enddt, cp.equipment_import, cp.equipment_export, cp.note_mobile, cp.note_thing,
                cp.attrflags, cpt.description
                from common_permit cp, common_permittype cpt
                where cp.permittype = cpt.uniid and cp.uniid = %s
            """ % permitId)
            commonPermitInformation = cur.fetchone()
            if commonPermitInformation:
                permitInfo['begindt'] = commonPermitInformation[0]
                permitInfo['enddt'] = commonPermitInformation[1]
                permitInfo['equipmentImport'] = commonPermitInformation[2]
                permitInfo['equipmentExport'] = commonPermitInformation[3]
                permitInfo['noteMobile'] = commonPermitInformation[4]
                permitInfo['noteThing'] = commonPermitInformation[5]
                permitInfo['search'] = (
                                               commonPermitInformation[6] & 1) == 1
                permitInfo['lost'] = (commonPermitInformation[6] & 2) == 2
                permitInfo['permitType'] = commonPermitInformation[7]
            cur.execute("""
                select ccr.description, ccr.icon
                from common_commonright ccr, common_permit_commonright cpcr
                where ccr.uniid = cpcr.commonright and cpcr.devparent = %s
            """ % permitId)
            commonRightInformation = cur.fetchall()
            if commonRightInformation:
                permitInfo['rights'] = []
                for right in commonRightInformation:
                    permitInfo['rights'].append({
                        'descr': right[0],
                        'icon': right[1]
                    })
        cur.execute("""
            select co.description, cd.description, csc.description
            from common_subject cs left outer join common_organization co on cs.organization = co.uniid
            left outer join common_department cd on cs.department = cd.uniid
            left outer join common_schedule csc on cs.schedule = csc.uniid
            where cs.uniid = %s
        """ % subjId)
        subjectInformation = cur.fetchone()
        if subjectInformation:
            permitInfo['organization'] = subjectInformation[0] if subjectInformation[0] else ''
            permitInfo['department'] = subjectInformation[1] if subjectInformation[1] else ''
            permitInfo['schedule'] = subjectInformation[2] if subjectInformation[2] else ''
        cur.execute('select uniid from common_person where devparent = %s' % subjId)
        if cur.fetchone():
            cur.execute("""
                select cpp.description
                from common_post cpp, common_person cp
                where cpp.uniid = cp.postref and cp.devparent = %s
            """ % subjId)
            postInformation = cur.fetchone()
            if postInformation:
                permitInfo['post'] = postInformation[0] if postInformation[0] else ''
            else:
                permitInfo['post'] = ''
        else:
            cur.execute("""
                select brand, mode, color, trailer, trailernumber, owner_type, owner_id
                from common_mobile
                where devparent = %s
            """ % subjId)
            mobileInformation = cur.fetchone()
            if mobileInformation:
                permitInfo['brand'] = mobileInformation[0]
                permitInfo['mode'] = mobileInformation[1]
                permitInfo['color'] = mobileInformation[2]
                permitInfo['trailer'] = mobileInformation[3]
                permitInfo['trailernumber'] = mobileInformation[4]
                if mobileInformation[5] and mobileInformation[6]:
                    cur.execute('select description from common_%s where uniid = %s' % (
                        mobileInformation[5], mobileInformation[6])
                    )
                    ownerInformation = cur.fetchone()
                    if ownerInformation:
                        permitInfo['owner'] = ownerInformation[0]
        return permitInfo
