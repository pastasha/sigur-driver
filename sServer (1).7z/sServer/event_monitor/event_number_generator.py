# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$15.09.2011 17:11:56$"

import time


class EventNumberGenerator(object):
    def __init__(self, conn):
        self.__conn = conn

    def install(self):
        self.__conn.directRequest("""
			DROP SEQUENCE IF EXISTS event_register_seq
		""", extract=False)

        self.__conn.directRequest("""
			CREATE SEQUENCE event_register_seq START 1
		""", extract=False)

    def getNumber(self):
        res = self.__conn.directRequest("""
			select nextval('event_register_seq'), now()
		""")[0]
        return res[0], time.time()
