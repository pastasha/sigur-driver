# -*- coding: utf-8 -*-

import sys
import os
dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(dir_path)

print('===================')
print('working dir %s' % dir_path)
print('===================')
