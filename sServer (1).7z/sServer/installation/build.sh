#!/bin/bash

res=$(../../InstallPacket/unix/getbuildnum.sh)
ESMVERS="$(cut -d '#' -f1 <<<$res)"
REVIS="$(cut -d '#' -f2 <<<$res)"
suffLiter="$(cut -d '#' -f3 <<<$res)"
export ESMVERS
export REVIS
export suffLiter

pyinstaller -F sServer.spec --clean --log-level WARN
mkdir -p ../../InstallPacket/unix/modules
mv dist/sServer ../../InstallPacket/unix/modules/sServer

rm -rf __pycache__
rm -rf build
rm -rf dist
rm  sServer_ver_temp.txt
