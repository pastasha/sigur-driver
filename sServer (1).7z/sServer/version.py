 # -*- coding: utf-8 -*-
def getVersion():
    a = r"""['# UTF-8\n', '#\n', 'VSVersionInfo(\n', '  ffi=FixedFileInfo(\n', '    filevers=(2018, 1, 3, 90),\n', '    prodvers=(2018, 1, 3, 90),\n', '    mask=0x3f,\n', '    flags=0x0,\n', '    OS=0x40004,\n', '    fileType=0x1,\n', '    subtype=0x0,\n', '    date=(0, 0)\n', '    ),\n', '  kids=[\n', '    StringFileInfo(\n', '      [\n', '      StringTable(\n', "         u'040904e4',\n", "        [StringStruct(u'Comments', u'Ltd PSC Electronika: http://electronika.ru'),\n", "        StringStruct(u'CompanyName', u'Ltd PSC Electronika'),\n", "        StringStruct(u'FileDescription', u'ESM Equipment Manager'),\n", "        StringStruct(u'FileVersion', u'2018.1.3.90'),\n", "        StringStruct(u'InternalName', u'sServer.exe'),\n", "        StringStruct(u'LegalCopyright', u'Copyright (C) 2000-2018 PSC Electronika'),\n", "        StringStruct(u'OriginalFilename', u'sServer.exe'),\n", "        StringStruct(u'ProductName', u'Electronika Security Manager'),\n", "        StringStruct(u'ProductVersion', u'2018.1.3.90')])\n", '      ]),\n', "    VarFileInfo([VarStruct(u'Translation', [0, 1200])])\n", '  ]\n', ')\n']"""
    b = a.find("filevers=(", 0, len(a))
    a = a[b:]
    b = a.find('(', 0, len(a))
    c = a.find(')', 0, len(a))
    a = a[b + 1:c].replace(" ", "")
    a = a.replace(",", ".")
    return a