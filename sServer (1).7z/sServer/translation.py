
import gettext


def mygettext(message: str) -> str:
    return gettext.dgettext('sserver', message)
