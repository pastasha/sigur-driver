# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from . import event_packet
from .system_videowallsegment import system_videowallsegment


class system_videowallsegmenttemplate(protocol_obj_base, alias='Макет сегмента видеостены',
                               parent=ParentStruct(typeName='videowalltemplate', alias='Макеты сегментов')):

    def preDelete(self, deleteAsLink=False):
        event_packet.deleteWallSegmentTemplate(self, self._core)

    segment = Link(alias='Сегмент видеостены', target=system_videowallsegment, index=1)
