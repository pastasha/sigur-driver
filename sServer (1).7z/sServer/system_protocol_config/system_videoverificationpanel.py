# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link

from common_protocol_config.common_permittemplate import common_permittemplate


class system_videoverificationpanel(protocol_obj_base, alias='Панель верификации'):

    @classmethod
    def __getObjIdByRemoteGuid(cls, guid):
        cur = cls._core.sql("select id from observed_objects where remote_guid = '%s'" % guid)
        row = cur.fetchone()
        if row:
            id = row[0]
        else:
            id = 0
        return id

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        if 'videoserver' in createAttrs:
            value = createAttrs['videoserver']
            if isinstance(value, list): # Так может быть если мы просто скопировали объект
                createAttrs['videoserver'] = value[0]['id']
            else: # А так от dedicated
                try:
                    int(value)
                except:
                    # Если у нас не привелось к числу значит тут не id а remote_guid объекта
                    createAttrs['videoserver'] = cls.__getObjIdByRemoteGuid(value)

    def __getVideoserverAttr(self, field):
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        objid = system_videoverificationpanel.videoserver.defaultGet(self)
        cur = self._core.sql('select remote_guid from observed_objects where id = %s' % objid)
        row = cur.fetchone()
        remote_guid = ''
        if row:
            remote_guid = row[0]
        return [{
            'id': objid,
            'remote_guid': remote_guid
        }]

    def __setVideoserver(self, value, field):
        try:
            id = int(value)
        except:
            # Если у нас не привелось к числу значит тут не id а remote_guid объекта
            id = self.__getObjIdByRemoteGuid(value)
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        system_videoverificationpanel.videoserver.defaultSet(self, id)

    def __photoTemplateChanged(self, targetObj):
        if targetObj is None:
            self.photo_template_name = ''
        else:
            self.photo_template_name = targetObj.getAttribute('src')

    def __videoTemplateChanged(self, targetObj):
        if targetObj is None:
            self.video_template_name = ''
        else:
            self.video_template_name = targetObj.getAttribute('src')

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    photo_template_name = Attribute(alias='Файл шаблона фотоверификации', fieldType=str, defval='', index=2,
                                    readOnly=True)
    video_template_name = Attribute(alias='Файл шаблона видеоверификации', fieldType=str, defval='', index=3,
                                    readOnly=True)
    videoserver = Attribute(alias='Камера по умолчанию (объект мониторинга)', fieldType=int, defval=0,
                            editorType='obsObjSelect(cam,mobile)', fget=__getVideoserverAttr, index=4,
                            fset=__setVideoserver)
    cam = Attribute(alias='Камера по умолчанию (RTSP)', fieldType=str, defval='', index=7)
    show_without_place = Attribute(alias='Показывать нотификации без места', fieldType=bool, defval=False, index=8,
                                   editorType='checkBox')
    reset_timeout = Attribute(alias='Таймаут сброса (в секундах)', fieldType=int, defval=0, index=9, editorType='int')
    use_default_cam = Attribute(alias='Использовать только камеру по умолчанию', fieldType=bool, defval=False, index=10,
                                editorType='checkBox')

    photo_template = Link(alias='Шаблон фотоверификации', target=common_permittemplate, index=11,
                          postAction=__photoTemplateChanged)
    video_template = Link(alias='Шаблон видеоверификации', target=common_permittemplate, index=12,
                          postAction=__videoTemplateChanged)
