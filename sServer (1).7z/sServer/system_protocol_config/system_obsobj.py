# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_obsobj(protocol_obj_base, alias='Объекты мониторинга для панелей верификации'):

    @classmethod
    def __getObjIdByRemoteGuid(cls, guid):
        cur = cls._core.sql("select id from observed_objects where remote_guid = '%s'" % guid)
        row = cur.fetchone()
        if row:
            id = row[0]
        else:
            id = 0
        return id

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        if createAttrs and 'objid' in createAttrs:
            value = createAttrs['objid']
            if isinstance(value, list): # Так может быть если мы просто скопировали объект
                createAttrs['objid'] = value[0]['id']
            else: # А так от dedicated
                try:
                    int(value)
                except:
                    # Если у нас не привелось к числу значит тут не id а remote_guid объекта
                    createAttrs['objid'] = cls.__getObjIdByRemoteGuid(value)

    def __getDescription(self, field):
        cur = self._core.sql("SELECT name FROM observed_objects WHERE id=%s" % self.objid[0]['id'])
        row = cur.fetchone()
        if row:
            return row[0]
        else:
            return ''

    def __objChanged(self, oldValue, oldValues):
        self.attrUpdated('description')

    def __getObjIdAttr(self, field):
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        objid = system_obsobj.objid.defaultGet(self)
        cur = self._core.sql('select remote_guid from observed_objects where id = %s' % objid)
        row = cur.fetchone()
        remote_guid = ''
        if row:
            remote_guid = row[0]
        return [{
            'id': objid,
            'remote_guid': remote_guid
        }]

    def __setObjId(self, value, field):
        try:
            id = int(value)
        except:
            # Если у нас не привелось к числу значит тут не id а remote_guid объекта
            id = self.__getObjIdByRemoteGuid(value)
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        system_obsobj.objid.defaultSet(self, id)

    description = Attribute(alias='Описание', fget=__getDescription, index=1, storeInDb=False, readOnly=True)
    objid = Attribute(alias='Объект', fieldType=int, defval=0, index=2, editorType='obsObjSelect()',
                      fget=__getObjIdAttr, fset=__setObjId, postAction=__objChanged)
