# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_gismap(protocol_obj_base, alias='Гис карта'):

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    map_file_name = Attribute(alias='Имя map файла', fieldType=str, defval='', index=2)
    min_scale = Attribute(alias='Минимальный масштаб', fieldType=int, defval=0, index=3, editorType='int')
    max_scale = Attribute(alias='Максимальный масштаб', fieldType=int, defval=19, index=4, editorType='int')
    north_latitude = Attribute(alias='Граница северной широты', fieldType=float, defval=85, index=5)
    south_latitude = Attribute(alias='Граница южной широты', fieldType=float, defval=-85, index=6)
    west_longitude = Attribute(alias='Граница западной долготы', fieldType=float, defval=-180, index=7)
    east_longitude = Attribute(alias='Граница восточной долготы', fieldType=float, defval=180, index=8)
    r1 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.75(r1)', fieldType=int, defval=0, index=9,
                   editorType='int')
    r2 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.50(r2)', fieldType=int, defval=0, index=10,
                   editorType='int')
    r3 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.25(r3)', fieldType=int, defval=0, index=11,
                   editorType='int')
    showlimit = Attribute(alias='Минимальный размер видимой иконки (pix)', fieldType=int, defval=0, index=12,
                          editorType='int')
    hierarchy_level = Attribute(alias='Уровень иерархии', fieldType=int, defval=0, index=13, editorType='int')
    enable_opacity = Attribute(alias='Включить непрозрачность объектов связанных с объектами плана', fieldType=bool,
                               defval=False, index=14, editorType='treeSelect(getBooleanType)')
