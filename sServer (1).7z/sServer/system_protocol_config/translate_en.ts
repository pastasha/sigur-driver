<?xml version='1.0' encoding='UTF-8'?>
<equipment name="system">
  <alias>
    <source>Конфигурация клиентов ESM</source>
    <translation>ESM Client configuration</translation>
  </alias>
  <devTypes>
    <devType name="channel">
      <alias>
        <source>Каналы рассылки</source>
        <translation>Notification channels</translation>
      </alias>
      <parent>
        <source>Серверы</source>
        <translation>Servers</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="value">
        <source>Значение</source>
        <translation>Value</translation>
      </field>
      <link name="cam">
        <source>Привязанная камера</source>
        <translation>Attached camera</translation>
      </link>
    </devType>
    <devType name="fullscreensettings">
      <alias>
        <source>Параметры полноэкранного режима</source>
        <translation>Fullscreen settings</translation>
      </alias>
      <parent>
        <source>Параметры полноэкранного режима</source>
        <translation>Fullscreen settings</translation>
      </parent>
      <field name="enable">
        <source>Используется</source>
        <translation>Enabled</translation>
      </field>
      <field name="height">
        <source>Высота</source>
        <translation>Height</translation>
      </field>
      <field name="width">
        <source>Ширина</source>
        <translation>Width</translation>
      </field>
      <field name="x">
        <source>X левого верхнего угла</source>
        <translation>X coordinate of top-left corner</translation>
      </field>
      <field name="y">
        <source>Y левого верхнего угла</source>
        <translation>Y coordinate of top-left corner</translation>
      </field>
      <link name="cam">
        <source>Привязанная камера</source>
        <translation>Attached camera</translation>
      </link>
    </devType>
    <devType name="geozone">
      <alias>
        <source>Геозона</source>
        <translation>Geozone</translation>
      </alias>
      <parent>
        <source>Геозоны</source>
        <translation>Geozones</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>Monitored object type</translation>
      </field>
      <link name="cam">
        <source>Привязанная камера</source>
        <translation>Attached camera</translation>
      </link>
    </devType>
    <devType name="gismap">
      <alias>
        <source>Гис карта</source>
        <translation>GIS map</translation>
      </alias>
      <parent>
        <source>Геозоны</source>
        <translation>Geozones</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="east_longitude">
        <source>Граница восточной долготы</source>
        <translation>Eastern longitude border</translation>
      </field>
      <field name="enable_opacity">
        <source>Включить непрозрачность объектов связанных с объектами плана</source>
        <translation>Enable the opacity of objects associated with objects of the plan</translation>
      </field>
      <field name="hierarchy_level">
        <source>Уровень иерархии</source>
        <translation>Hierarchy level</translation>
      </field>
      <field name="map_file_name">
        <source>Имя map файла</source>
        <translation>.map file name</translation>
      </field>
      <field name="max_scale">
        <source>Максимальный масштаб</source>
        <translation>Maximum scale</translation>
      </field>
      <field name="min_scale">
        <source>Минимальный масштаб</source>
        <translation>Minimum scale</translation>
      </field>
      <field name="north_latitude">
        <source>Граница северной широты</source>
        <translation>Northern latitude border</translation>
      </field>
      <field name="r1">
        <source>Коэффициент маcштаба, для размера иконки 0.75(r1)</source>
        <translation>Scale coefficient, for 0.75(r1) icon size</translation>
      </field>
      <field name="r2">
        <source>Коэффициент маcштаба, для размера иконки 0.50(r2)</source>
        <translation>Scale coefficient, for 0.50(r2) icon size</translation>
      </field>
      <field name="r3">
        <source>Коэффициент маcштаба, для размера иконки 0.25(r3)</source>
        <translation>Scale coefficient, for 0.25(r3) icon size</translation>
      </field>
      <field name="showlimit">
        <source>Минимальный размер видимой иконки (pix)</source>
        <translation>Minimum size of visible icon (pix)</translation>
      </field>
      <field name="south_latitude">
        <source>Граница южной широты</source>
        <translation>Southern longitude border</translation>
      </field>
      <field name="west_longitude">
        <source>Граница западной долготы</source>
        <translation>Western longitude border</translation>
      </field>
      <link name="cam">
        <source>Привязанная камера</source>
        <translation>Attached camera</translation>
      </link>
    </devType>
    <devType name="gismap_gismap">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Иерархические точки ГИС</source>
        <translation>GIS hierarchical points</translation>
      </parent>
      <field name="latitude">
        <source>Широта</source>
        <translation>Latitude</translation>
      </field>
      <field name="longitude">
        <source>Долгота</source>
        <translation>Longtitude</translation>
      </field>
      <field name="gismap">
        <source>ГИС карта</source>
        <translation>GIS map</translation>
      </field>
      <field name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="gismap_map">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Иерархические точки</source>
        <translation>Hierarchical points</translation>
      </parent>
      <field name="latitude">
        <source>Широта</source>
        <translation>Latitude</translation>
      </field>
      <field name="longitude">
        <source>Долгота</source>
        <translation>Longitude</translation>
      </field>
      <field name="map">
        <source>Карта</source>
        <translation>Map</translation>
      </field>
      <field name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="incidentsettings">
      <alias>
        <source>Параметры инцидентов</source>
        <translation>Incident settings</translation>
      </alias>
      <parent>
        <source>Параметры инцидентов</source>
        <translation>Incident settings</translation>
      </parent>
      <field name="disablemapchange">
        <source>Выключить переключение карт в режиме инцидентов</source>
        <translation>Disable map switching in incident mode</translation>
      </field>
      <field name="display_video_selected_incident">
        <source>Отображать онлайн видео при выборе инцидента</source>
        <translation>Display online video after incident selecting</translation>
      </field>
      <field name="incident_video_policy">
        <source>Отображение видео при выборе инцидента</source>
        <translation>Display video after incident selecting</translation>
      </field>
      <field name="management_cammodule_selected_incident">
        <source>Управлять онлайн/архив видеомонитора из инцидента</source>
        <translation>Control online/archive video monitor from incident</translation>
      </field>
      <field name="worktool">
        <source>Отображать панель команд инцидента</source>
        <translation>Display incident command bar</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="layout">
      <alias>
        <source>Раскладка рабочего стола</source>
        <translation>Layout</translation>
      </alias>
      <parent>
        <source>Параметры инцидентов</source>
        <translation>Incident parameters</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="layout_type">
        <source>Тип раскладки рабочего стола</source>
        <translation>Layout type</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="logpanelsettings">
      <alias>
        <source>Параметры журнала событий</source>
        <translation>Event log settings</translation>
      </alias>
      <parent>
        <source>Параметры журнала событий</source>
        <translation>Event log settings</translation>
      </parent>
      <field name="enablefiltermode">
        <source>Разрешать фильтрацию</source>
        <translation>Allow filtering</translation>
      </field>
      <field name="fontsize">
        <source>Размер шрифта</source>
        <translation>Font size</translation>
      </field>
      <field name="linecount">
        <source>Количество строк</source>
        <translation>Number of lines</translation>
      </field>
      <field name="newEventsAtBottom">
        <source>Показывать новые события внизу</source>
        <translation>Display new events at the bottom</translation>
      </field>
      <field name="pointsize">
        <source>Толщина шрифта</source>
        <translation>Font thickness</translation>
      </field>
      <field name="stopscrolldelay">
        <source>Время прекращения автопрокрутки (с)</source>
        <translation>Auto-scroll stop timer (s)</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="map">
      <alias>
        <source>Карта</source>
        <translation>Map</translation>
      </alias>
      <parent>
        <source>Параметры журнала событий</source>
        <translation>Event log parameters</translation>
      </parent>
      <field name="antialoasing">
        <source>АнтиАлиасинг</source>
        <translation>Antialiasing</translation>
      </field>
      <field name="config">
        <source>Конфигурация</source>
        <translation>Configuration</translation>
      </field>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="enable_opacity">
        <source>Включить непрозрачность объектов связанных с объектами плана</source>
        <translation>Enable the opacity of objects associated with the objects on the plan</translation>
      </field>
      <field name="filename">
        <source>Имя файла</source>
        <translation>File name</translation>
      </field>
      <field name="guid">
        <source>GUID</source>
        <translation>GUID</translation>
      </field>
      <field name="hierarchy_level">
        <source>Уровень иерархии</source>
        <translation>Hierarchy level</translation>
      </field>
      <field name="latitude">
        <source>Широта нахождения карты</source>
        <translation>Map location latitude</translation>
      </field>
      <field name="length">
        <source>Длина (м)</source>
        <translation>Length (m)</translation>
      </field>
      <field name="longitude">
        <source>Долгота нахождения карты</source>
        <translation>Map location longitude</translation>
      </field>
      <field name="max_scale">
        <source>Максимальный масштаб</source>
        <translation>Maximum scale</translation>
      </field>
      <field name="min_scale">
        <source>Минимальный масштаб</source>
        <translation>Minimum scale</translation>
      </field>
      <field name="r1">
        <source>Коэффициент маcштаба, для размера иконки 0.75(r1)</source>
        <translation>Scale coefficient, for 0.75(r1) icon size</translation>
      </field>
      <field name="r2">
        <source>Коэффициент маcштаба, для размера иконки 0.50(r2)</source>
        <translation>Scale coefficient, for 0.50(r2) icon size</translation>
      </field>
      <field name="r3">
        <source>Коэффициент маcштаба, для размера иконки 0.25(r3)</source>
        <translation>Scale coefficient, for 0.25(r3) icon size</translation>
      </field>
      <field name="show">
        <source>Показывать</source>
        <translation>Show</translation>
      </field>
      <field name="showlimit">
        <source>Минимальный размер видимой иконки (pix)</source>
        <translation>Minimum size of a visible icon (pix)</translation>
      </field>
      <field name="width">
        <source>Ширина (м)</source>
        <translation>Width (m)</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="mapshierarchy">
      <alias>
        <source>Иерархии карт</source>
        <translation>Map hierarchies</translation>
      </alias>
      <parent>
        <source>Параметры журнала событий</source>
        <translation>Event log parameters</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="index">
        <source>Порядковый номер</source>
        <translation>Ordinal number</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="mapshierarchy_gismap">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Корневые ГИС карты</source>
        <translation>Root GIS maps</translation>
      </parent>
      <field name="index">
        <source>Порядковый номер</source>
        <translation>Ordinal number</translation>
      </field>
      <field name="gismap">
        <source>Корневая ГИС карта</source>
        <translation>Root GIS map</translation>
      </field>
      <link name="gismap">
        <source>Корневая ГИС карта</source>
        <translation>Root GIS map</translation>
      </link>
    </devType>
    <devType name="mapshierarchy_map">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Корневые векторные карты</source>
        <translation>Root vector maps</translation>
      </parent>
      <field name="index">
        <source>Порядковый номер</source>
        <translation>Ordinal number</translation>
      </field>
      <field name="map">
        <source>Корневая векторная карта</source>
        <translation>Root vector map</translation>
      </field>
      <link name="map">
        <source>Корневая векторная карта</source>
        <translation>Root vector map</translation>
      </link>
    </devType>
    <devType name="map_gismap">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Иерархические точки ГИС</source>
        <translation>GIS hierarchical points</translation>
      </parent>
      <field name="posx">
        <source>Координата x</source>
        <translation>X coordinate</translation>
      </field>
      <field name="posy">
        <source>Координата y</source>
        <translation>Y coordinate</translation>
      </field>
      <field name="gismap">
        <source>Карта</source>
        <translation>Map</translation>
      </field>
      <field name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="map_map">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Иерархические точки</source>
        <translation>Hierarchical points</translation>
      </parent>
      <field name="posx">
        <source>Координата x</source>
        <translation>X coordinate</translation>
      </field>
      <field name="posy">
        <source>Координата y</source>
        <translation>Y coordinate</translation>
      </field>
      <field name="map">
        <source>Карта</source>
        <translation>Map</translation>
      </field>
      <field name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </field>
      <link name="mapshierarchy">
        <source>Отображать в иерархии</source>
        <translation>Display in hierarchy</translation>
      </link>
    </devType>
    <devType name="mobiledevice">
      <alias>
        <source>Мобильное устройство</source>
        <translation>Mobile device</translation>
      </alias>
      <parent>
        <source>Иерархические точки</source>
        <translation>Hierarchical points</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="imei">
        <source>IMEI устройства</source>
        <translation>Device IMEI</translation>
      </field>
      <field name="obsobjtype">
        <source>Тип объекта мониторинга</source>
        <translation>Monitored object type</translation>
      </field>
      <field name="phone_number">
        <source>Номер телефона</source>
        <translation>Phone number</translation>
      </field>
      <field name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
      <action name="finishVideoTranslation">
        <source>Завершение видеотрансляции</source>
        <translation>Finish video broadcast</translation>
        <params/>
      </action>
      <action name="getVideoTranslation">
        <source>Запросить видеотрансляцию</source>
        <translation>Request video broadcast</translation>
        <params/>
      </action>
      <action name="mobileDeviceConnect">
        <source>Восстановилась связь</source>
        <translation>Connection restored</translation>
        <params/>
      </action>
      <action name="mobileDeviceLogIn">
        <source>Телефон залогинился</source>
        <translation>Phone logged in</translation>
        <params/>
      </action>
      <action name="mobileDeviceLogOut">
        <source>Телефон разлогинился</source>
        <translation>Phone logged out</translation>
        <params/>
      </action>
      <action name="mobileDeviceLostConnect">
        <source>Пропала связь</source>
        <translation>Connection lost</translation>
        <params/>
      </action>
      <action name="refuseToVideoTranslation">
        <source>Отказ от видеотрансляции</source>
        <translation>Refuse video broadcast</translation>
        <params/>
      </action>
      <action name="startVideoTranslation">
        <source>Начало видеотрансляции</source>
        <translation>Start video broadcast</translation>
        <params/>
      </action>
    </devType>
    <devType name="obsobj">
      <alias>
        <source>Объекты мониторинга для панелей верификации</source>
        <translation>Logical objects for verification panels</translation>
      </alias>
      <parent>
        <source>Иерархические точки</source>
        <translation>Hierarchical points</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="objid">
        <source>Объект</source>
        <translation>Object</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
    </devType>
    <devType name="permitofficesettings">
      <alias>
        <source>Параметры бюро пропусков</source>
        <translation>Permit office settings</translation>
      </alias>
      <parent>
        <source>Параметры бюро пропусков</source>
        <translation>Permit office settings</translation>
      </parent>
      <field name="createdepartment">
        <source>Разрешать создавать новые организации и подразделения</source>
        <translation>Allow the creation of new new organizations and departments</translation>
      </field>
      <field name="filterinputdelayms">
        <source>Пауза после ввода последнего символа в строке поиска списка пропусков перед началом фильтрации</source>
        <translation>Pause after entering the last character in the search field of the list of permits before the filter starts</translation>
      </field>
      <field name="human">
        <source>Отображать список частных лиц в диалоге создания пропуска по заявке</source>
        <translation>Display the list of individuals while creating a new permit by a requisition</translation>
      </field>
      <field name="maypermitprintsettings">
        <source>Включены настройки принтера при печати пропуска</source>
        <translation>Printer settings are enabled when printing a permit</translation>
      </field>
      <field name="minqualitybiosmart">
        <source>Минимальное качество отпечатка пальца</source>
        <translation>Minimum fingerprint quality</translation>
      </field>
      <field name="mobile">
        <source>Отображать список транспортных средств в диалоге создания пропуска по заявке</source>
        <translation>Display the list of vehicles while creating a new permit by a requisition</translation>
      </field>
      <field name="needminutesindate">
        <source>Необходимо ли вводить и выводить дату/время с учетом минут или без</source>
        <translation>Is it necessary to enter and display the date/time with or without minutes</translation>
      </field>
      <field name="oriondlgforals">
        <source>Отображать кнопку создать уровень доступа Орион</source>
        <translation>Enable «Create Orion accees level» button</translation>
      </field>
      <field name="permitddditionalcommands">
        <source>Отображать в контекстном меню и в кнопке действия дополнительные команды пропуска</source>
        <translation>Display additional permit commands in the context menu and action button</translation>
      </field>
      <field name="saveprintsonserver">
        <source>Сохранять распечатанные шаблоны пропусков на сервере</source>
        <translation>Save printed permits on server</translation>
      </field>
      <field name="showdailypassreport">
        <source>Отображать кнопку построения отчет по разовым пропускам</source>
        <translation>Display the button for building a report on one-time permits</translation>
      </field>
      <field name="showdocscan">
        <source>Добавляет в контекстном меню пропуска пункт «Просмотра скана документа».</source>
        <translation>Adds the "Scan document view" item to the context menu.</translation>
      </field>
      <field name="tabbiomini">
        <source>Отображать вкладку БиоМини</source>
        <translation>Enable «BioMini» tab</translation>
      </field>
      <field name="tabbiosmart">
        <source>Отображать вкладку Биометрия</source>
        <translation>Enable «Biometry» tab</translation>
      </field>
      <field name="tabidcode">
        <source>Отображать вкладку Идентификатор</source>
        <translation>Enable «Identifier» tab</translation>
      </field>
      <field name="tabpermit">
        <source>Отображать вкладку Информация</source>
        <translation>Enable «Information» tab</translation>
      </field>
      <field name="tabpermitpermits">
        <source>Отображать вкладку Связанные пропуска</source>
        <translation>Enable «Related permits» tab</translation>
      </field>
      <field name="tabrights">
        <source>Отображать вкладку Права доступа</source>
        <translation>Enable «Access rights» tab</translation>
      </field>
      <field name="tabschedule">
        <source>Отображать вкладку Расписание</source>
        <translation>Enable «Schedules» tab</translation>
      </field>
      <field name="thing">
        <source>Отображать список материальных ценностей в диалоге создания пропуска по заявке</source>
        <translation>Display the list of things while creating a new permit by a requisition</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
    </devType>
    <devType name="sensorsettings">
      <alias>
        <source>Параметры для сенсорных мониторов</source>
        <translation>Sensor monitor settings</translation>
      </alias>
      <parent>
        <source>Параметры для сенсорных мониторов</source>
        <translation>Sensor monitor settings</translation>
      </parent>
      <field name="kioskmode">
        <source>Использовать режим «kioskMode»</source>
        <translation>Use "kioskMode"</translation>
      </field>
      <field name="sensor">
        <source>Использовать режим для «для сенсорных мониторов»</source>
        <translation>Use "sensor monitor" mode</translation>
      </field>
      <field name="vk">
        <source>Использовать сенсорную клавиатуру VK</source>
        <translation>Use sensor keyboard VK</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
    </devType>
    <devType name="toastsettings">
      <alias>
        <source>Параметры всплывающих сообщений</source>
        <translation>Toast message settings</translation>
      </alias>
      <parent>
        <source>Параметры всплывающих сообщений</source>
        <translation>Toast message settings</translation>
      </parent>
      <field name="close_old_mess_if_display_is_filled">
        <source>Закрывать старые сообщения</source>
        <translation>Hide old messages</translation>
      </field>
      <field name="minimize_previous_messages">
        <source>Открывать только новое</source>
        <translation>Display only new messages</translation>
      </field>
      <field name="number_of_displayed_messages">
        <source>Число отображаемых сообщений</source>
        <translation>Number of displayed messages</translation>
      </field>
      <field name="priority_of_messages">
        <source>Приоритет вывода сообщений</source>
        <translation>Message priority</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
    </devType>
    <devType name="usersettings">
      <alias>
        <source>Общие параметры</source>
        <translation>General settings</translation>
      </alias>
      <parent>
        <source>Общие параметры</source>
        <translation>General settings</translation>
      </parent>
      <field name="adddevconfigpanel">
        <source>Отображать третью панель объектов оборудования</source>
        <translation>Enable additional Object configuration panel</translation>
      </field>
      <field name="alarmonmappolicy">
        <source>Политика поведения планов при тревоге</source>
        <translation>Map alarm policy</translation>
      </field>
      <field name="alertlevel">
        <source>Минимальная тревожность события для мигания на плане</source>
        <translation>Minimum event alarm level for flashing on the plan</translation>
      </field>
      <field name="allowchangedesktop">
        <source>Разрешать переключение между рабочими столами</source>
        <translation>Allow layout switching</translation>
      </field>
      <field name="alloweditdesktop">
        <source>Разрешать редактирование рабочих столов</source>
        <translation>Allow layout editing</translation>
      </field>
      <field name="fontsize">
        <source>Размер шрифта текста (для отображения имени объекта и системы)</source>
        <translation>Font size (to display the facility and system names)</translation>
      </field>
      <field name="modeledalarm">
        <source>Отображать команду запуска смоделированной тревоги</source>
        <translation>Enable alarm simulation</translation>
      </field>
      <field name="object">
        <source>Имя объекта</source>
        <translation>Facility name</translation>
      </field>
      <field name="previewmonitorhidetimeout">
        <source>Время отображения незафиксированного окна превью монитора на плане (мс)</source>
        <translation>Time of displaying the videomonitor preview on the plan (ms)</translation>
      </field>
      <field name="previewmonitorshowtimeout">
        <source>Время через которое появляется окно превью монитора на плане (мс)</source>
        <translation>Interval after which the videomonitor preview appears on plan (ms)</translation>
      </field>
      <field name="showcamondutymonitor">
        <source>Отображать камеру на дежурном мониторе по клику левой кнопкой</source>
        <translation>Display camera on the standby monitor by left-click</translation>
      </field>
      <field name="showcontrollerrequisitionsbutton">
        <source>Отображать в клиенте кнопку «Заявки на вход/выход»</source>
        <translation>Enable «entry/exit requests» button</translation>
      </field>
      <field name="system">
        <source>Имя системы</source>
        <translation>System name</translation>
      </field>
      <field name="timebeforeshowvideoarchive">
        <source>Сместить поиск видеоархива раньше на (с)</source>
        <translation>Shift video archive search earlier by (s)</translation>
      </field>
      <field name="twinkletime">
        <source>Время по умолчанию для мигания объектов на плане (с)</source>
        <translation>Default time for objects to blink on plan (s)</translation>
      </field>
      <field name="videomunitorbutton">
        <source>Отображать панель с видеомониторами</source>
        <translation>Enable «Videomonitors» bar</translation>
      </field>
      <field name="webpanelbutton">
        <source>Отображать панель с внешними компонентами</source>
        <translation>Enable «External components» button</translation>
      </field>
      <link name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </link>
    </devType>
    <devType name="videomonitor">
      <alias>
        <source>Видеомонитор</source>
        <translation>Videomonitor</translation>
      </alias>
      <parent>
        <source>Видеомониторы</source>
        <translation>Videomonitors</translation>
      </parent>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="axxonlayout">
        <source>Раскладка Axxon Next</source>
        <translation>Axxon Next layout</translation>
      </field>
      <field name="intellectmonitor">
        <source>Видеомонитор Интеллект</source>
        <translation>Intellect vieomonitor</translation>
      </field>
      <field name="milestonematrix">
        <source>Тревожный монитор Milestone</source>
        <translation>Milestone alarm monitor</translation>
      </field>
      <field name="securosmonitor">
        <source>Медиа Клиент SecurOS</source>
        <translation>SecurOS media client</translation>
      </field>
      <link name="securosmonitor">
        <source>Медиа Клиент SecurOS</source>
        <translation>SecurOS media client</translation>
      </link>
      <action name="activate">
        <source>Активировать</source>
        <translation>Activate</translation>
        <params/>
      </action>
      <action name="addShow">
        <source>Добавить камеру на монитор</source>
        <translation>Add camera to the display</translation>
        <params>
          <param name="cam">
            <source>ID камеры</source>
            <translation>Camera ID</translation>
          </param>
          <param name="timeout">
            <source>Таймаут</source>
            <translation>Timeout</translation>
          </param>
        </params>
      </action>
      <action name="archFrameTime">
        <source>Включить архив камеры</source>
        <translation>Enable camera archive</translation>
        <params>
          <param name="cam">
            <source>ID камеры</source>
            <translation>Camera Id</translation>
          </param>
          <param name="date">
            <source>Дата (dd-mm-yy)</source>
            <translation>Date (dd-mm-yy)</translation>
          </param>
          <param name="time">
            <source>Время (hh:mm:ss)</source>
            <translation>Time (hh:mm:ss)</translation>
          </param>
          <param name="play">
            <source>Воспроизвести архив (0-нет 1-да)</source>
            <translation>Play archive (0-no 1-yes)</translation>
          </param>
        </params>
      </action>
      <action name="deactivate">
        <source>Дезактивировать</source>
        <translation>Deactivate</translation>
        <params/>
      </action>
      <action name="pause">
        <source>Пауза</source>
        <translation>Pause</translation>
        <params/>
      </action>
      <action name="play">
        <source>Начать воспроизмедение</source>
        <translation>Play</translation>
        <params/>
      </action>
      <action name="removeAll">
        <source>Очистить</source>
        <translation>Clear all</translation>
        <params/>
      </action>
      <action name="showCams">
        <source>Вывести список видеокамер оборудования</source>
        <translation>Show the list of equipment cameras</translation>
        <params>
          <param name="camIds">
            <source>ID камер</source>
            <translation>Camera Id</translation>
          </param>
        </params>
      </action>
      <action name="showCamsArch">
        <source>Добавить камеры для просмотра архива</source>
        <translation>Add cameras for archive viewing</translation>
        <params>
          <param name="cam">
            <source>ID камер</source>
            <translation>Camera ID</translation>
          </param>
          <param name="date">
            <source>Дата (dd-mm-yy)</source>
            <translation>Date (dd-mm-yy)</translation>
          </param>
          <param name="time">
            <source>Время (hh:mm:ss)</source>
            <translation>Time (hh:mm:ss)</translation>
          </param>
          <param name="play">
            <source>Воспроизвести архив (0-нет 1-да)</source>
            <translation>Play archive (0-no 1-yes)</translation>
          </param>
        </params>
      </action>
      <action name="showCamsOO">
        <source>Вывести список видеокамер объектов мониторинга</source>
        <translation>Show the list of logical object cameras</translation>
        <params>
          <param name="OOCam">
            <source>ID камер</source>
            <translation>Cam id</translation>
          </param>
        </params>
      </action>
    </devType>
    <devType name="videopanel">
      <alias>
        <source>Видеопанель</source>
        <translation>Video panel</translation>
      </alias>
      <parent>
        <source>Видеомониторы</source>
        <translation>Videomonitors</translation>
      </parent>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="oo_cam1">
        <source>Камера №1 (объект мониторинга)</source>
        <translation>Camera No. 1 (logical object)</translation>
      </field>
      <field name="oo_cam10">
        <source>Камера №10 (объект мониторинга)</source>
        <translation>Camera No. 10 (logical object)</translation>
      </field>
      <field name="oo_cam11">
        <source>Камера №11 (объект мониторинга)</source>
        <translation>Camera No. 11 (logical object)</translation>
      </field>
      <field name="oo_cam12">
        <source>Камера №12 (объект мониторинга)</source>
        <translation>Camera No. 12 (logical object)</translation>
      </field>
      <field name="oo_cam13">
        <source>Камера №13 (объект мониторинга)</source>
        <translation>Camera No. 13 (logical object)</translation>
      </field>
      <field name="oo_cam14">
        <source>Камера №14 (объект мониторинга)</source>
        <translation>Camera No. 14 (logical object)</translation>
      </field>
      <field name="oo_cam15">
        <source>Камера №15 (объект мониторинга)</source>
        <translation>Camera No. 15 (logical object)</translation>
      </field>
      <field name="oo_cam16">
        <source>Камера №16 (объект мониторинга)</source>
        <translation>Camera No. 16 (logical object)</translation>
      </field>
      <field name="oo_cam2">
        <source>Камера №2 (объект мониторинга)</source>
        <translation>Camera No. 2 (logical object)</translation>
      </field>
      <field name="oo_cam3">
        <source>Камера №3 (объект мониторинга)</source>
        <translation>Camera No. 3 (logical object)</translation>
      </field>
      <field name="oo_cam4">
        <source>Камера №4 (объект мониторинга)</source>
        <translation>Camera No. 4 (logical object)</translation>
      </field>
      <field name="oo_cam5">
        <source>Камера №5 (объект мониторинга)</source>
        <translation>Camera No. 5 (logical object)</translation>
      </field>
      <field name="oo_cam6">
        <source>Камера №6 (объект мониторинга)</source>
        <translation>Camera No. 6 (logical object)</translation>
      </field>
      <field name="oo_cam7">
        <source>Камера №7 (объект мониторинга)</source>
        <translation>Camera No. 7 (logical object)</translation>
      </field>
      <field name="oo_cam8">
        <source>Камера №8 (объект мониторинга)</source>
        <translation>Camera No. 8 (logical object)</translation>
      </field>
      <field name="oo_cam9">
        <source>Камера №9 (объект мониторинга)</source>
        <translation>Camera No. 9 (logical object)</translation>
      </field>
      <field name="rtsp_cam1">
        <source>Камера №1 (RTSP)</source>
        <translation>Camera No. 1 (RTSP)</translation>
      </field>
      <field name="rtsp_cam10">
        <source>Камера №10 (RTSP)</source>
        <translation>Camera No. 10 (RTSP)</translation>
      </field>
      <field name="rtsp_cam11">
        <source>Камера №11 (RTSP)</source>
        <translation>Camera No. 11 (RTSP)</translation>
      </field>
      <field name="rtsp_cam12">
        <source>Камера №12 (RTSP)</source>
        <translation>Camera No. 12 (RTSP)</translation>
      </field>
      <field name="rtsp_cam13">
        <source>Камера №13 (RTSP)</source>
        <translation>Camera No. 13 (RTSP)</translation>
      </field>
      <field name="rtsp_cam14">
        <source>Камера №14 (RTSP)</source>
        <translation>Camera No. 14 (RTSP)</translation>
      </field>
      <field name="rtsp_cam15">
        <source>Камера №15 (RTSP)</source>
        <translation>Camera No. 15 (RTSP)</translation>
      </field>
      <field name="rtsp_cam16">
        <source>Камера №16 (RTSP)</source>
        <translation>Camera No. 16 (RTSP)</translation>
      </field>
      <field name="rtsp_cam2">
        <source>Камера №2 (RTSP)</source>
        <translation>Camera No. 2 (RTSP)</translation>
      </field>
      <field name="rtsp_cam3">
        <source>Камера №3 (RTSP)</source>
        <translation>Camera No. 3 (RTSP)</translation>
      </field>
      <field name="rtsp_cam4">
        <source>Камера №4 (RTSP)</source>
        <translation>Camera No. 4 (RTSP)</translation>
      </field>
      <field name="rtsp_cam5">
        <source>Камера №5 (RTSP)</source>
        <translation>Camera No. 5 (RTSP)</translation>
      </field>
      <field name="rtsp_cam6">
        <source>Камера №6 (RTSP)</source>
        <translation>Camera No. 6 (RTSP)</translation>
      </field>
      <field name="rtsp_cam7">
        <source>Камера №7 (RTSP)</source>
        <translation>Camera No. 7 (RTSP)</translation>
      </field>
      <field name="rtsp_cam8">
        <source>Камера №8 (RTSP)</source>
        <translation>Camera No. 8 (RTSP)</translation>
      </field>
      <field name="rtsp_cam9">
        <source>Камера №9 (RTSP)</source>
        <translation>Camera No. 9 (RTSP)</translation>
      </field>
      <link name="securosmonitor">
        <source>Медиа Клиент SecurOS</source>
        <translation>SecurOS media client</translation>
      </link>
    </devType>
    <devType name="videoserver">
      <alias>
        <source>Видеосервер</source>
        <translation>Videoserver</translation>
      </alias>
      <parent>
        <source>Видеомониторы</source>
        <translation>Videomonitors</translation>
      </parent>
      <field name="description">
        <source>Описание</source>
        <translation>Description</translation>
      </field>
      <field name="ip_addr">
        <source>Ip адрес сервера</source>
        <translation>Serve Ip</translation>
      </field>
      <field name="login">
        <source>Логин</source>
        <translation>Login</translation>
      </field>
      <field name="password">
        <source>Пароль</source>
        <translation>Password</translation>
      </field>
      <field name="port">
        <source>Порт сервера</source>
        <translation>Server port</translation>
      </field>
      <field name="rtsp_ports">
        <source>Порт rtsp</source>
        <translation>RTSP port</translation>
      </field>
      <link name="securosmonitor">
        <source>Медиа Клиент SecurOS</source>
        <translation>SecurOS media client</translation>
      </link>
    </devType>
    <devType name="videoverificationpanel">
      <alias>
        <source>Панель верификации</source>
        <translation>Verification panel</translation>
      </alias>
      <parent>
        <source>Видеомониторы</source>
        <translation>Videomonitors</translation>
      </parent>
      <field name="cam">
        <source>Камера по умолчанию (RTSP)</source>
        <translation>Default camera (RTSP)</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="photo_template_name">
        <source>Файл шаблона фотоверификации</source>
        <translation>Photo verification template</translation>
      </field>
      <field name="reset_timeout">
        <source>Таймаут сброса (в секундах)</source>
        <translation>Reset timeout (seconds)</translation>
      </field>
      <field name="show_without_place">
        <source>Показывать нотификации без места</source>
        <translation>Do not show place in notifications</translation>
      </field>
      <field name="use_default_cam">
        <source>Использовать только камеру по умолчанию</source>
        <translation>Use only default camera</translation>
      </field>
      <field name="video_template_name">
        <source>Файл шаблона видеоверификации</source>
        <translation>Video verification template</translation>
      </field>
      <field name="videoserver">
        <source>Камера по умолчанию (объект мониторинга)</source>
        <translation>Defaul camera (logical object)</translation>
      </field>
      <field name="photo_template">
        <source>Шаблон фотоверификации</source>
        <translation>Photoverification template</translation>
      </field>
      <field name="video_template">
        <source>Шаблон видеоверификации</source>
        <translation>Videoverification template</translation>
      </field>
      <link name="video_template">
        <source>Шаблон видеоверификации</source>
        <translation>Videoverification template</translation>
      </link>
    </devType>
    <devType name="videoverificationpanel_obsobj">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Объекты мониторинга</source>
        <translation>Logical objects</translation>
      </parent>
      <field name="obsobj">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="obsobj">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="videowall">
      <alias>
        <source>Видеостена</source>
        <translation>Videowall</translation>
      </alias>
      <parent>
        <source>Объекты мониторинга</source>
        <translation>Monitored objects</translation>
      </parent>
      <field name="changed">
        <source>Изменен</source>
        <translation>Edited at</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name/Description</translation>
      </field>
      <field name="currentlayout">
        <source>Текущая раскладка</source>
        <translation>Current layout</translation>
      </field>
      <link name="currentlayout">
        <source>Текущая раскладка</source>
        <translation>Current layout</translation>
      </link>
    </devType>
    <devType name="videowallsegment">
      <alias>
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </alias>
      <parent>
        <source>Сегменты</source>
        <translation>Segments</translation>
      </parent>
      <field name="columns">
        <source>Количество столбцов</source>
        <translation>Number of columns</translation>
      </field>
      <field name="description">
        <source>Имя сегмента</source>
        <translation>Segment name</translation>
      </field>
      <field name="rows">
        <source>Количество строк</source>
        <translation>Number of rows</translation>
      </field>
      <field name="serviceurl">
        <source>URL для обращения к сегменту</source>
        <translation>Segment URL</translation>
      </field>
      <field name="x">
        <source>Позиция по-горизонтали</source>
        <translation>Hotizontal position</translation>
      </field>
      <field name="y">
        <source>Позиция по-вертикали</source>
        <translation>Vertical position</translation>
      </field>
      <link name="currentlayout">
        <source>Текущая раскладка</source>
        <translation>Current layout</translation>
      </link>
    </devType>
    <devType name="videowallsegmentlayout">
      <alias>
        <source>Раскладка макета сегмента</source>
        <translation>Segment layout</translation>
      </alias>
      <parent>
        <source>Раскладки макетов сегментов</source>
        <translation>Segment layout</translation>
      </parent>
      <field name="segmenttemplate">
        <source>Макет сегмента</source>
        <translation>Segment template</translation>
      </field>
      <link name="segmenttemplate">
        <source>Макет сегмента</source>
        <translation>Segment template</translation>
      </link>
    </devType>
    <devType name="videowallsegmenttemplate">
      <alias>
        <source>Макет сегмента видеостены</source>
        <translation>Videowall segment template</translation>
      </alias>
      <parent>
        <source>Макеты сегментов</source>
        <translation>Segment templates</translation>
      </parent>
      <field name="segment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </field>
      <link name="segment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </link>
    </devType>
    <devType name="videowalltemplate">
      <alias>
        <source>Макет видеостены</source>
        <translation>Videowall template</translation>
      </alias>
      <parent>
        <source>Макеты</source>
        <translation>Templates</translation>
      </parent>
      <field name="description">
        <source>Имя макета</source>
        <translation>Template name</translation>
      </field>
      <link name="segment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </link>
    </devType>
    <devType name="videowalltemplatelayout">
      <alias>
        <source>Раскладка макета видеостены</source>
        <translation>Videowall template layout</translation>
      </alias>
      <parent>
        <source>Раскладки макета</source>
        <translation>Template layouts</translation>
      </parent>
      <field name="description">
        <source>Имя раскладки</source>
        <translation>Layout name</translation>
      </field>
      <link name="segment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </link>
    </devType>
    <devType name="videowalltemplatewindow">
      <alias>
        <source>Окно макета</source>
        <translation>Template window</translation>
      </alias>
      <parent>
        <source>Окно макета</source>
        <translation>Template window</translation>
      </parent>
      <field name="columns">
        <source>Ширина</source>
        <translation>Number of columns</translation>
      </field>
      <field name="number">
        <source>Порядковый номер</source>
        <translation>Ordinal number</translation>
      </field>
      <field name="rows">
        <source>Высота</source>
        <translation>Number of rows</translation>
      </field>
      <field name="x">
        <source>Номер столбца</source>
        <translation>Column number</translation>
      </field>
      <field name="y">
        <source>Номер строки</source>
        <translation>Row number</translation>
      </field>
      <link name="segment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </link>
    </devType>
    <devType name="videowallwindowlayout">
      <alias>
        <source>Представление окон в раскладке</source>
        <translation>Window content</translation>
      </alias>
      <parent>
        <source>Представление окон в раскладке</source>
        <translation>Window content</translation>
      </parent>
      <field name="content">
        <source>Содержимое</source>
        <translation>Content</translation>
      </field>
      <field name="contentobject">
        <source>Id связанного объекта</source>
        <translation>ID of content object</translation>
      </field>
      <field name="contenttype">
        <source>Тип содержимого</source>
        <translation>Content type</translation>
      </field>
      <field name="windowid">
        <source>Окно макета</source>
        <translation>Template window</translation>
      </field>
      <link name="windowid">
        <source>Окно макета</source>
        <translation>Template window</translation>
      </link>
    </devType>
    <devType name="webview">
      <alias>
        <source>Внешние компоненты</source>
        <translation>External components</translation>
      </alias>
      <parent>
        <source>Представление окон в раскладке</source>
        <translation>View of windows in a layout</translation>
      </parent>
      <field name="button_name">
        <source>Текст кнопки</source>
        <translation>Button text</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="show_button">
        <source>Отображать кнопку открытия</source>
        <translation>Display «Open» button</translation>
      </field>
      <field name="update_on_show">
        <source>Обновлять при открытии панели</source>
        <translation>Update when opening the panel</translation>
      </field>
      <field name="url">
        <source>URL внешнего компонента</source>
        <translation>External component URL</translation>
      </field>
      <link name="windowid">
        <source>Окно макета</source>
        <translation>Template window</translation>
      </link>
    </devType>
    <devType name="workstation">
      <alias>
        <source>Рабочая станция</source>
        <translation>Workstation</translation>
      </alias>
      <parent>
        <source>Представление окон в раскладке</source>
        <translation>View of windows in a layout</translation>
      </parent>
      <field name="call_context">
        <source>Контекст вызова</source>
        <translation>Context</translation>
      </field>
      <field name="cln_licence">
        <source>Лицензионные ограничения</source>
        <translation>License restrictions</translation>
      </field>
      <field name="deactivatealarmmon">
        <source>Скрывать тревожный монитор</source>
        <translation>Hide alarm display</translation>
      </field>
      <field name="description">
        <source>Имя/Название</source>
        <translation>Name</translation>
      </field>
      <field name="duty_timeout">
        <source>Время вывода на дежурный монитор</source>
        <translation>Period of showing on a standby display</translation>
      </field>
      <field name="name_guardinstruction">
        <source>Название оперативной инструкции</source>
        <translation>Operational instruction name</translation>
      </field>
      <field name="network_name">
        <source>Сетевое имя</source>
        <translation>Network name</translation>
      </field>
      <field name="phone">
        <source>Номер телефона</source>
        <translation>Phone number</translation>
      </field>
      <field name="show_guardinstruction">
        <source>Отображать оперативную инструкцию</source>
        <translation>Show operational instruction</translation>
      </field>
      <field name="alarm_videomonitor">
        <source>Тревожный монитор</source>
        <translation>Alarm monitor</translation>
      </field>
      <field name="authenticatedSubject">
        <source>Текущий оператор</source>
        <translation>Current operator</translation>
      </field>
      <field name="duty_videomonitor">
        <source>Дежурный монитор</source>
        <translation>Standby monitor</translation>
      </field>
      <field name="videowallsegment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </field>
      <link name="videowallsegment">
        <source>Сегмент видеостены</source>
        <translation>Videowall segment</translation>
      </link>
    </devType>
    <devType name="workstation_channel">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Дополнительные каналы рассылки</source>
        <translation>Additional notification channels</translation>
      </parent>
      <field name="channel">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="channel">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_gismap">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>ГИС Карты</source>
        <translation>GIS maps</translation>
      </parent>
      <field name="gismap">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="gismap">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_layout">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Раскладки рабочих столов</source>
        <translation>Layouts</translation>
      </parent>
      <field name="shortcut">
        <source>Комбинация клавиш</source>
        <translation>Shortcut key combinations</translation>
      </field>
      <field name="layout">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="layout">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_map">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Карты</source>
        <translation>Maps</translation>
      </parent>
      <field name="map">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="map">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_mapshierarchy">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Иерархии карт</source>
        <translation>Map hierarchies</translation>
      </parent>
      <field name="mapshierarchy">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="mapshierarchy">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_videopanel">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Видеопанели</source>
        <translation>Video panels</translation>
      </parent>
      <field name="videopanel">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="videopanel">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_videoverificationpanel">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Панели верификации</source>
        <translation>Verification panel</translation>
      </parent>
      <field name="videoverificationpanel">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="videoverificationpanel">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
    <devType name="workstation_webview">
      <alias>
        <source></source>
        <translation>undefined</translation>
      </alias>
      <parent>
        <source>Внешние компоненты</source>
        <translation>External components</translation>
      </parent>
      <field name="webview">
        <source>undefined</source>
        <translation>undefined</translation>
      </field>
      <link name="webview">
        <source></source>
        <translation>undefined</translation>
      </link>
    </devType>
  </devTypes>
  <strings>
    <string name="systemArchive">
      <source>Отображать архив</source>
      <translation>Display archive</translation>
    </string>
    <string name="systemOnline">
      <source>Отображать онлайн</source>
      <translation>Display online</translation>
    </string>
    <string name="yes">
      <source>Да</source>
      <translation>Yes</translation>
    </string>
    <string name="no">
      <source>Нет</source>
      <translation>No</translation>
    </string>
    <string name="settingsAlreadyExists">
      <source>У рабочей станции уже есть настройки такого типа</source>
      <translation>Workstation already has settings of this type</translation>
    </string>
    <string name="byTime">
      <source>По времени возникновения</source>
      <translation>By ocurence time</translation>
    </string>
    <string name="byImportance">
      <source>По степени важности</source>
      <translation>By importance</translation>
    </string>
    <string name="fullscreeWidthInvalidValue">
      <source>Значение ширины не может быть менее 300 пикселей</source>
      <translation>Width can not be less than 300 pixels</translation>
    </string>
    <string name="fullscreeHeightInvalidValue">
      <source>Значение высоты не может быть менее 300 пикселей</source>
      <translation>Height can not be less than 300 pixels</translation>
    </string>
    <string name="custom">
      <source>Произвольная раскладка</source>
      <translation>Custom layout</translation>
    </string>
    <string name="duty">
      <source>Дежурный рабочий стол</source>
      <translation>Standby layout</translation>
    </string>
    <string name="incident">
      <source>Рабочий стол инцидентов</source>
      <translation>Incident layout</translation>
    </string>
    <string name="logPanelLinecountMustBeNatural">
      <source>Количество строк должно быть положительным числом</source>
      <translation>Number of lines must be a positive number</translation>
    </string>
    <string name="notAlarmingAlertLevel">
      <source>0 - Не тревожный</source>
      <translation>0 - Normal</translation>
    </string>
    <string name="lowAlertLevel">
      <source>1 - Низкий</source>
      <translation>1 - Low</translation>
    </string>
    <string name="mediumAlertLevel">
      <source>2 - Средний</source>
      <translation>2 - Medium</translation>
    </string>
    <string name="highAlertLevel">
      <source>3 - Высокий</source>
      <translation>3 - High</translation>
    </string>
    <string name="criticalAlertLevel">
      <source>4 - Критический</source>
      <translation>4 - Critical</translation>
    </string>
    <string name="doNotBlink">
      <source>5 - Не мигать</source>
      <translation>5 - Don't blink</translation>
    </string>
    <string name="workstationNetworkNameNotUnique">
      <source>Сетевая станция с таким именем уже существует (%s)</source>
      <translation>A workstation with the same name already exists (%s)</translation>
    </string>
    <string name="numberOfDisplayedMessagesMustBePositive">
      <source>Число отображаемых сообщений должно быть больше или равно 0</source>
      <translation>The number of displayed messages must be greater than or equal to 0</translation>
    </string>
    <string name="preCreateVideoserverError">
      <source>Объект видеосервер может быть только один</source>
      <translation>There can be only one video server object</translation>
    </string>
    <string name="getVideoTranslationOk">
      <source>Запрос видеотрансляции отправлен в мобильное приложение</source>
      <translation>Video broadcast request sent to mobile application</translation>
    </string>
    <string name="getVideoTranslationError">
      <source>Запрос не может быть удовлетворен</source>
      <translation>Request could not be completed.</translation>
    </string>
    <string name="centerOnObject">
      <source>Позиционироваться на объекте</source>
      <translation>Position on object</translation>
    </string>
    <string name="showSavedArea">
      <source>Показывать настроенную область</source>
      <translation>Display configured area</translation>
    </string>
  </strings>
</equipment>
