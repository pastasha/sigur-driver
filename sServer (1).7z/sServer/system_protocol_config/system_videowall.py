# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link
from .system_videowalltemplatelayout import system_videowalltemplatelayout
from . import event_packet


class system_videowall(protocol_obj_base, alias='Видеостена'):

    def preDelete(self, deleteAsLink=False):
        event_packet.deleteWall(self, self._core)

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    currentlayout = Link(alias='Текущая раскладка', target=system_videowalltemplatelayout, index=2)
    changed = Attribute(alias='Изменен', fieldType=int, defval=0, index=3)
