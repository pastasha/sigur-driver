# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_gismap import system_gismap
from .system_mapshierarchy import system_mapshierarchy


class system_map_gismap(protocol_obj_base, alias='',
                        parent=ParentStruct(typeName='map', alias='Иерархические точки ГИС',
                                            addr=(1, constants.MAX_UINT8))):

    posx = Attribute(alias='Координата x', fieldType=int, defval=0, index=1, editorType='int')
    posy = Attribute(alias='Координата y', fieldType=int, defval=0, index=2, editorType='int')
    gismap = Link(alias='Карта', target=system_gismap, index=3)
    mapshierarchy = Link(alias='Отображать в иерархии', target=system_mapshierarchy, index=4)
