# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_map import system_map
from .system_mapshierarchy import system_mapshierarchy


class system_gismap_map(protocol_obj_base, alias='',
                        parent=ParentStruct(typeName='gismap', alias='Иерархические точки',
                                            addr=(1, constants.MAX_UINT8))):

    latitude = Attribute(alias='Широта', fieldType=float, defval=0, index=1)
    longitude = Attribute(alias='Долгота', fieldType=float, defval=0, index=2)
    map = Link(alias='Карта', target=system_map, index=3)
    mapshierarchy = Link(alias='Отображать в иерархии', target=system_mapshierarchy, index=4)
