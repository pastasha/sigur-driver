# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_sensorsettings(protocol_obj_base, alias='Параметры для сенсорных мониторов',
                            parent=ParentStruct(typeName='workstation', alias='Параметры для сенсорных мониторов',
                                                addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('sensorsettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    sensor = Attribute(alias='Использовать режим для «для сенсорных мониторов»', fieldType=bool, defval=False, index=1,
                       editorType='treeSelect(getBooleanType)')
    kioskmode = Attribute(alias='Использовать режим «kioskMode»', fieldType=bool, defval=False, index=2,
                          editorType='treeSelect(getBooleanType)')
    vk = Attribute(alias='Использовать сенсорную клавиатуру VK', fieldType=bool, defval=False, index=3,
                   editorType='treeSelect(getBooleanType)')
