# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_webview(protocol_obj_base, alias='Внешние компоненты'):
    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    url = Attribute(alias='URL внешнего компонента', fieldType=str, defval='', index=2)
    show_button = Attribute(alias='Отображать кнопку открытия', fieldType=bool, defval=False, index=3,
                            editorType='checkBox')
    button_name = Attribute(alias='Текст кнопки', fieldType=str, defval='', index=4)
    update_on_show = Attribute(alias='Обновлять при открытии панели', fieldType=bool, defval=False, index=5,
                               editorType='checkBox')
