# -*- coding: utf-8 -*-
import copy

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link, action_decorator
from equipment import constants
from milestone_protocol_config.milestone_matrix import milestone_matrix
from securos_protocol_config.securos_monitor import securos_monitor
from axxon_protocol_config.axxon_layout import axxon_layout
from intellect_protocol_config.intellect_monitor import intellect_monitor


# TODO: Наверное надо чтобы во всех действиях использовались объекты всех видеосистем


class system_videomonitor(protocol_obj_base, alias='Видеомонитор',
                          parent=ParentStruct(typeName='workstation', alias='Видеомониторы',
                                              addr=(1, constants.MAX_UINT32))):

    @action_decorator(alias='Активировать')
    def activate(self):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('activate')
        except:
            print('Intellect monitor activating error')
        try:
            if self.securosmonitor:
                self.securosmonitor.doAction('activate')
        except:
            print('SecurOS monitor activating error')
        try:
            if self.axxonlayout:
                self.axxonlayout.doAction('activate')
        except:
            print('Axxon Next layout activating error')

    @action_decorator(alias='Дезактивировать')
    def deactivate(self):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('deactivate')
        except:
            print('Intellect monitor deactivating error')
        try:
            if self.securosmonitor:
                self.securosmonitor.doAction('deactivate')
        except:
            print('SecurOS monitor deactivating error')

    @action_decorator(alias='Очистить')
    def removeAll(self):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('removeAll')
        except:
            print('Intellect monitor remove all error')
        try:
            if self.securosmonitor:
                self.securosmonitor.doAction('removeAll')
        except:
            print('Intellect monitor remove all error')
        try:
            if self.axxonlayout:
                self.axxonlayout.doAction('removeAll')
        except:
            print('Axxon Next layout remove all error')

    @action_decorator(alias='Добавить камеру на монитор', cam='ID камеры', timeout='Таймаут')
    def addShow(self, cam: str = '', timeout: int = 0):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('addShow', {
                    'cam': cam,
                    'control': 1,
                    'timeout': timeout
                })
        except:
            print('Intellect monitor addShow error')

        try:
            if self.securosmonitor:
                self.securosmonitor.doAction('activateCAM', {
                    'cam': cam
                })
        except:
            print('Intellect monitor addShow error')

        try:
            if self.axxonlayout:
                self.axxonlayout.doAction('addShow', {
                    'cam': cam,
                    'control': 1,
                    'timeout': timeout
                })
        except:
            print('Axxon Next layout addShow error')

    @action_decorator(alias='Вывести список видеокамер оборудования', camIds='ID камер')
    def showCams(self, camIds: str = ''):
        self.removeAll()
        if camIds != '':
            camIds = camIds.split(',')
            for camId in camIds:
                self.addShow(camId, 0)

    @staticmethod
    def __counting_securos_cameras(list_cam):
        i = 0
        for devequipment, devtype, devid, name in list_cam:
            if devequipment == 'securos':
                i += 1
        return i

    @action_decorator(alias='Вывести список видеокамер объектов мониторинга', OOCam='ID камер')
    def showCamsOO(self, OOCam: str = '', show_archive: bool = False, date: str = '', time: str = ''):
        self.removeAll()
        if OOCam == '':
            return

        cur = self._core.sql("""
            select devequipment, devtype, devid, name
            from observed_objects  
            where devequipment != '' and type in (select id from observed_objects_types  where kind = 'cam') 
            and deletemark = 0 and id in (%s)
        """ % OOCam)

        rows = cur.fetchall()
        securos_cams = []
        securos_cams_count = self.__counting_securos_cameras(rows)
        for devequipment, devtype, devid, name in rows:
            if devequipment == 'intellect':
                try:
                    if self.intellectmonitor:
                        # TODO: не круто что control и timeout передаются как строки, но иначе не работает
                        self.intellectmonitor.doAction('addShow', {
                            'cam': self._core['intellect'].getElementById('cam', devid).getAttribute('id'),
                            'control': '1',
                            'timeout': '0'
                        })
                except:
                    pass
            if devequipment == 'securos':
                # В команду activateCAM для securos нужно посылать все камеры разом иначе каждая новая перетрет
                # предыдущую.
                securos_cams.append(self._core['securos'].getElementById('cam', devid).getAttribute('id_obj'))
                if len(securos_cams) == securos_cams_count:
                    try:
                        if self.securosmonitor:
                            self.securosmonitor.doAction('activateCAM', {
                                'cam': ','.join(map(str, securos_cams))
                            })
                    except:
                        pass
                if show_archive:
                    self.showCamsArch(','.join(map(str, securos_cams)), date, time)
            if devequipment == 'axxon':
                try:
                    if self.axxonlayout:
                        self.axxonlayout.doAction('addShow', {
                            'cam': self._core['axxon'].getElementById('cam', devid).getAttribute('origin'),
                            'control': 1,
                            'timeout': 0
                        })
                except:
                    pass
            if devequipment == 'milestone':
                # вызов команды камеры для самовывода на монитор Milestone
                try:
                    if 'milestone' in self._core['...']:
                        # TODO: херь какая-то
                        msCam = self._core['milestone'].getElementById('cam', devid)
                        if msCam:
                            if self.milestonematrix:
                                msCam.doAction('sendToMatrix', {'matrix': self.milestonematrix})
                except:
                    print('Milestone matrix remove all error')
        self.activate()

    @action_decorator(alias='Включить архив камеры', cam='ID камеры', date='Дата (dd-mm-yy)', time='Время (hh:mm:ss)',
                      play='Воспроизвести архив (0-нет 1-да)')
    def archFrameTime(self, cam: int = 0, date: str = '', time: str = '', play: int = 1):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('archFrameTime', {
                    'cam': cam,
                    'date': date,
                    'time': time,
                    'play': play
                })
            if self.securosmonitor:
                self.securosmonitor.doAction('seekCAM', {
                    'cam': cam,
                    'date': date,
                    'time': time
                })
        except:
            print('Intellect monitor archFrameTime error')

    @action_decorator(alias='Добавить камеры для просмотра архива', cam='ID камер', date='Дата (dd-mm-yy)',
                      time='Время (hh:mm:ss)', play='Воспроизвести архив (0-нет 1-да)')
    def showCamsArch(self, cam: str = '', date: str = '', time: str = '', play: int = 1):
        try:
            if self.intellectmonitor:
                self.showCams(cam)
                self.intellectmonitor.doAction('archFrameTime', {
                    'cam': cam,
                    'date': date,
                    'time': time,
                    'play': play
                })
        except:
            print('Intellect monitor archFrameTime error')
        try:
            for camId in cam.split(','):
                self.archFrameTime(int(camId), date, time)
            if self.securosmonitor:
                self.securosmonitor.doAction('addSequence', {
                    'seq': cam,
                    'arch': cam.replace(',', '|')
                })
        except:
            print('Intellect monitor archFrameTime error')

    @action_decorator(alias='Начать воспроизмедение')
    def play(self):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('play')
        except:
            print('Intellect monitor play error')

    @action_decorator(alias='Пауза')
    def pause(self):
        try:
            if self.intellectmonitor:
                self.intellectmonitor.doAction('pause')
        except:
            print('Intellect monitor pause error')

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)

    intellectmonitor = Link(alias='Видеомонитор Интеллект', target=intellect_monitor, index=2)
    securosmonitor = Link(alias='Медиа Клиент SecurOS', target=securos_monitor, index=3)
    axxonlayout = Link(alias='Раскладка Axxon Next', target=axxon_layout, index=4)
    milestonematrix = Link(alias='Тревожный монитор Milestone', target=milestone_matrix, index=5)
