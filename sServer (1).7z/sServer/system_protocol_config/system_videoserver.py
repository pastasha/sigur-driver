
from equipment.protocol_obj_base import protocol_obj_base, Attribute
from equipment import dev_except


class system_videoserver(protocol_obj_base, alias='Видеосервер'):

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        try:
            obj = cls._core.getFirst('videoserver')
        except dev_except.ElementNotFound:
            pass
        else:
            if obj:
                raise dev_except.TerminateAction(cls._core.getString('preCreateVideoserverError'))

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    ip_addr = Attribute(alias='Ip адрес сервера', fieldType=str, defval='', index=2)
    port = Attribute(alias='Порт сервера', fieldType=int, defval=0, index=3, editorType='int')
    rtsp_ports = Attribute(alias='Порт rtsp', fieldType=int, defval=0, index=4, editorType='int')
    login = Attribute(alias='Логин', fieldType=str, defval='', index=5)
    password = Attribute(alias='Пароль', fieldType=str, defval='', index=6)
