# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_mapshierarchy(protocol_obj_base, alias='Иерархии карт'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    index = Attribute(alias='Порядковый номер', fieldType=int, defval=1, index=2, editorType='int')
