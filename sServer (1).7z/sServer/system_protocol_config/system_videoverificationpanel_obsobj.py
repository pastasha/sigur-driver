# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_obsobj import system_obsobj


class system_videoverificationpanel_obsobj(protocol_obj_base, alias='',
                                           parent=ParentStruct(typeName='videoverificationpanel',
                                                               alias='Объекты мониторинга',
                                                               addr=(1, constants.MAX_UINT32))):
    obsobj = Link(alias='', target=system_obsobj, index=1)
