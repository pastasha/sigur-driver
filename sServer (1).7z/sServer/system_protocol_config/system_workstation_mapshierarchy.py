# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_mapshierarchy import system_mapshierarchy


class system_workstation_mapshierarchy(protocol_obj_base, alias='',
                                       parent=ParentStruct(typeName='workstation', alias='Иерархии карт',
                                                           addr=(1, constants.MAX_UINT32))):
    mapshierarchy = Link(alias='', target=system_mapshierarchy, index=1)
