# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_gismap import system_gismap


class system_workstation_gismap(protocol_obj_base, alias='',
                                parent=ParentStruct(typeName='workstation', alias='ГИС Карты',
                                                    addr=(1, constants.MAX_UINT32))):
    gismap = Link(alias='', target=system_gismap, index=1)
