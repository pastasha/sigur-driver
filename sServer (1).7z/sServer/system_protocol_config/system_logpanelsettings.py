# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_logpanelsettings(protocol_obj_base, alias='Параметры журнала событий',
                              parent=ParentStruct(typeName='workstation', alias='Параметры журнала событий',
                                                  addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('logpanelsettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    def __checkLineCountValue(self, value, field):
        if value <= 0:
            raise dev_except.TerminateAction(self._core.getString('logPanelLinecountMustBeNatural'))

    fontsize = Attribute(alias='Размер шрифта', fieldType=int, defval=18, index=1, editorType='int')
    pointsize = Attribute(alias='Толщина шрифта', fieldType=int, defval=22, index=2, editorType='int')
    linecount = Attribute(alias='Количество строк', fieldType=int, defval=100, index=3, preAction=__checkLineCountValue,
                          editorType='int')
    enablefiltermode = Attribute(alias='Разрешать фильтрацию', fieldType=bool, defval=True, index=4,
                                 editorType='treeSelect(getBooleanType)')
    stopscrolldelay = Attribute(alias='Время прекращения автопрокрутки (с)', fieldType=int, defval=20, index=5,
                                editorType='int')
    newEventsAtBottom = Attribute(alias='Показывать новые события внизу', fieldType=bool, defval=True, index=6,
                                  editorType='treeSelect(getBooleanType)')
