# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from .system_videopanel import system_videopanel


class system_workstation_videopanel(protocol_obj_base, alias='',
                                    parent=ParentStruct(typeName='workstation', alias='Видеопанели', addr=(1, 100))):
    videopanel = Link(alias='', target=system_videopanel, index=1)
