list_equipment = [
    {
        'name': 'channel',
        'attributes': {
            'description': 'channel',
            'value': ''
        }
    },

    {
        'name': 'fullscreensettings',
        'attributes': {
            'x': 9,
            'y': 3,
            'width': 300,
            'height': 300
        }
    },

    {
        'name': 'geozone',
        'attributes': {
            'description': 'geozone'
        }
    },

    {
        'name': 'gismap',
        'attributes': {
            'description': 'gismap',
            'map_file_name': 'name',
            'min_scale': 1,
            'max_scale': 20,
            'north_latitude': 85,
            'south_latitude': -85,
            'west_longitude': -180,
            'east_longitude': 180,
            'r1': 1,
            'r2': 1,
            'r3': 1,
            'showlimit': 12,
            'hierarchy_level': 1
        }
    },

    {
        'name': 'incidentsettings',
        'attributes': {
            'incident_video_policy': 2,
            'worktool': True,
            'disablemapchange': True
        }
    },

    {
        'name': 'layout',
        'attributes': {
            'description': 'layout',
            'layout_type': 0
        }
    },

    {
        'name': 'logpanelsettings',
        'attributes': {
            'fontsize': 18,
            'pointsize': 22,
            'linecount': 100,
            'enablefiltermode': True,
            'stopscrolldelay': 20,
            'newEventsAtBottom': True
        }
    },

    {
        'name': 'map',
        'attributes': {
            'description': 'map',
            'filename': '',
            'antialoasing': 0,
            'show': 0,
            'min_scale': 0,
            'max_scale': 0,
            'r1': 0,
            'r2': 1,
            'r3': 1,
            'showlimit': 1,
            'latitude': 5,
            'longitude': 5,
            'hierarchy_level': 0,
            'guid': 'guid9545945',
            'enable_opacity': True,
            'length': 0,
            'width': 1,
            'config': ''
        }
    },

    {
        'name': 'mapshierarchy',
        'attributes': {
            'description': 'mapshierarchy',
            'index': 1
        }
    },

    {
        'name': 'mobiledevice',
        'attributes': {
            'description': 'mobiledevice',
            'imei': '445454554',
            'phone_number': '5454545'
        }
    },

    {
        'name': 'obsobj',
        'attributes': {
            'description': 'obsobj',
            'objid': '30'
        }
    },

    {
        'name': 'permitofficesettings',
        'attributes': {
            'tabpermit': True,
            'tabrights': True,
            'tabpermitpermits': True,
            'tabbiosmart': True,
            'tabidcode': True,
            'tabbiomini': True,
            'tabschedule': True,
            'human': True,
            'mobile': True,
            'thing': True,
            'createdepartment': True,
            'showdailypassreport': True,
            'permitddditionalcommands': True,
            'defval': True,
            'maypermitprintsettings': True,
            'needminutesindate': True,
            'saveprintsonserver': True,
            'showdocscan': True,
            'minqualitybiosmart': 80,
            'filterinputdelayms': 15,
            'oriondlgforals': True
        }
    },

    {
        'name': 'sensorsettings',
        'attributes': {
            'sensor': True,
            'kioskmode': True,
            'vk': True
        }
    },

    {
        'name': 'toastsettings',
        'attributes': {
            'minimize_previous_messages': True,
            'priority_of_messages': True,
            'number_of_displayed_messages': True,
            'close_old_mess_if_display_is_filled': True
        }
    },

    {
        'name': 'usersettings',
        'attributes': {
            'modeledalarm': True,
            'alertlevel': True,
            'twinkletime': 20,
            'showcontrollerrequisitionsbutton': True,
            'adddevconfigpanel': True,
            'previewmonitorshowtimeout': 1000,
            'previewmonitorhidetimeout': 8000,
            'object': '',
            'system': '',
            'fontsize': 16,
            'alloweditdesktop': True,
            'allowchangedesktop': True,
            'videomunitorbutton': True,
            'webpanelbutton': True,
            'timebeforeshowvideoarchive': 0
        }
    },

    {
        'name': 'videomonitor',
        'attributes': {
            'description': 'videomonitor',
        }
    },

    {
        'name': 'videopanel',
        'attributes': {
            'description': 'videopanel',
            'oo_cam1': -1,
            'rtsp_cam1': '',
            'oo_cam2': -1,
            'rtsp_cam2': '',
            'oo_cam3': -1,
            'rtsp_cam3': '',
            'oo_cam4': -1,
            'rtsp_cam4': '',
            'oo_cam5': -1,
            'rtsp_cam5': '',
            'oo_cam6': -1,
            'rtsp_cam6': '',
            'oo_cam7': -1,
            'rtsp_cam7': '',
            'oo_cam8': -1,
            'rtsp_cam8': '',
            'oo_cam9': -1,
            'rtsp_cam9': '',
            'oo_cam10': -1,
            'rtsp_cam10': '',
            'oo_cam11': -1,
            'rtsp_cam11': '',
            'oo_cam12': -1,
            'rtsp_cam12': '',
            'oo_cam13': -1,
            'rtsp_cam13': '',
            'oo_cam14': -1,
            'rtsp_cam14': '',
            'oo_cam15': -1,
            'rtsp_cam15': '',
            'oo_cam16': -1,
            'rtsp_cam16': ''
        }
    },

    {
        'name': 'videoserver',
        'attributes': {
            'description': 'videoserver',
            'ip_addr': '127.0.0.1',
            'port': 9000,
            'rtsp_ports': 3333,
            'login': 'login',
            'password': 'pass'
        }
    },

    {
        'name': 'videoverificationpanel',
        'attributes': {
            'description': 'videoverificationpanel',
            'photo_template_name': '',
            'video_template_name': '',
            'videoserver': 0,
            'cam': '',
            'show_without_place': True,
            'reset_timeout': 4,
            'use_default_cam': True
        }
    },

    {
        'name': 'videowall',
        'attributes': {
            'description': 'videowall',
            'changed': 1
        }
    },

    {
        'name': 'videowallsegment',
        'attributes': {
            'description': 'videowallsegment',
            'rows': 5,
            'columns': 5,
            'x': 1,
            'y': 1,
            'serviceurl': '/some/url'
        }
    },

    {
        'name': 'videowallsegmentlayout',
        'attributes': {
        }
    },

    {
        'name': 'videowallsegmenttemplate',
        'attributes': {
        }
    },

    {
        'name': 'videowalltemplate',
        'attributes': {
            'description': 'videowalltemplate'
        }
    },

    {
        'name': 'videowalltemplatelayout',
        'attributes': {
            'description': 'videowalltemplatelayout'
        }
    },

    {
        'name': 'videowalltemplatewindow',
        'attributes': {
            'number': 1,
            'y': 1,
            'x': 2,
            'columns': 3,
            'rows': 4
        }
    },

    {
        'name': 'videowallwindowlayout',
        'attributes': {
            'contentobject': 1,
            'contenttype': 2,
            'content': ''
        }
    },

    {
        'name': 'webview',
        'attributes': {
            'description': 'webview',
            'url': '/url/template',
            'show_button': True,
            'button_name': 'text',
            'update_on_show': True
        }
    },

    {
        'name': 'workstation',
        'attributes': {
            'description': 'workstation',
            'network_name': 'name_host',
            'deactivatealarmmon': True,
            'duty_timeout': 4,
            'phone': '55555',
            'name_guardinstruction': '',
            'show_guardinstruction': False,
            'call_context': ''
        }
    }
]
