import sys
from equipment.methods_for_testing import *
from system_protocol_config.tests.equipment_dicts import *


def main():
    class_methods = MethodsForTesting()
    class_methods.list_equipment = list_equipment
    class_methods.equipment_name = 'system'
    class_methods.create_and_delete_equipments()

    channel = class_methods.get_reqData('channel')
    fullscreensettings = class_methods.get_reqData('fullscreensettings')
    geozone = class_methods.get_reqData('geozone')
    gismap = class_methods.get_reqData('gismap')
    incidentsettings = class_methods.get_reqData('incidentsettings')
    layout = class_methods.get_reqData('layout')
    logpanelsettings = class_methods.get_reqData('logpanelsettings')
    map = class_methods.get_reqData('map')
    mapshierarchy = class_methods.get_reqData('mapshierarchy')
    obsobj = class_methods.get_reqData('obsobj')
    permitofficesettings = class_methods.get_reqData('permitofficesettings')
    sensorsettings = class_methods.get_reqData('sensorsettings')
    toastsettings = class_methods.get_reqData('toastsettings')
    usersettings = class_methods.get_reqData('usersettings')
    videomonitor = class_methods.get_reqData('videomonitor')
    videopanel = class_methods.get_reqData('videopanel')
    videoserver = None
    try:
        videoserver = class_methods.get_reqData('videoserver')
    except KeyError:
        print('Check exists videoserver in configuration clients ESM.'
              ' Delete videoserver before start this test if you want to test creation it', file=sys.stderr)
    videoverificationpanel = class_methods.get_reqData('videoverificationpanel')
    videowall =class_methods.get_reqData('videowall')
    videowallsegment = class_methods.get_reqData('videowallsegment')
    videowallsegmentlayout = class_methods.get_reqData('videowallsegmentlayout')
    videowallsegmenttemplate = class_methods.get_reqData('videowallsegmenttemplate')
    videowalltemplate = class_methods.get_reqData('videowalltemplate')
    videowalltemplatelayout = class_methods.get_reqData('videowalltemplatelayout')
    videowalltemplatewindow = class_methods.get_reqData('videowalltemplatewindow')
    videowallwindowlayout = class_methods.get_reqData('videowallwindowlayout')
    webview = class_methods.get_reqData('webview')
    workstation = class_methods.get_reqData('workstation')

    class_methods.add_childr_equipments(workstation, fullscreensettings)

    class_methods.set_bribge(gismap, gismap, 'gismap_gismap')
    class_methods.set_bribge(gismap, map, 'gismap_map')

    class_methods.add_childr_equipments(workstation, incidentsettings)

    class_methods.add_childr_equipments(workstation, logpanelsettings)

    class_methods.set_bribge(map, gismap, 'map_gismap')
    class_methods.set_bribge(map, map, 'map_map')

    class_methods.set_bribge(mapshierarchy, gismap, 'mapshierarchy_gismap')
    class_methods.set_bribge(mapshierarchy, map, 'mapshierarchy_map')

    class_methods.add_childr_equipments(workstation, permitofficesettings)
    class_methods.add_childr_equipments(workstation, sensorsettings)
    class_methods.add_childr_equipments(workstation, toastsettings)
    class_methods.add_childr_equipments(workstation, usersettings)
    class_methods.add_childr_equipments(workstation, videomonitor)

    class_methods.set_bribge(videoverificationpanel, obsobj, 'videoverificationpanel_obsobj')

    class_methods.set_link(videowall, videowalltemplatelayout, 'currentlayout')

    class_methods.add_childr_equipments(videowall, videowallsegment)

    class_methods.add_childr_equipments(videowalltemplatelayout, videowallsegmentlayout)
    class_methods.set_link(videowallsegmentlayout, videowallsegmenttemplate, 'segmenttemplate')

    class_methods.add_childr_equipments(videowalltemplate, videowallsegmenttemplate)
    class_methods.set_link(videowallsegmenttemplate, videowallsegment, 'segment')

    class_methods.add_childr_equipments(videowall, videowalltemplate)

    class_methods.add_childr_equipments(videowalltemplate, videowalltemplatelayout)

    class_methods.add_childr_equipments(videowallsegmenttemplate, videowalltemplatewindow)

    class_methods.add_childr_equipments(videowallsegmentlayout, videowallwindowlayout)
    class_methods.set_link(videowallwindowlayout, videowalltemplatewindow, 'windowid')

    class_methods.set_link(workstation, videomonitor, 'alarm_videomonitor')
    class_methods.set_link(workstation, videomonitor, 'duty_videomonitor')
    class_methods.set_link(workstation, videowallsegment, 'videowallsegment')
    class_methods.set_bribge(workstation, channel, 'workstation_channel')
    class_methods.set_bribge(workstation, gismap, 'workstation_gismap')
    class_methods.set_bribge(workstation, layout, 'workstation_layout')
    class_methods.set_bribge(workstation, map, 'workstation_map')
    class_methods.set_bribge(workstation, mapshierarchy, 'workstation_mapshierarchy')
    class_methods.set_bribge(workstation, videopanel, 'workstation_videopanel')
    class_methods.set_bribge(workstation, videoverificationpanel, 'workstation_videoverificationpanel')
    class_methods.set_bribge(workstation, webview, 'workstation_webview')

    input('Press any key...')

    class_methods.delete_childr__equipments(fullscreensettings)
    class_methods.delete_childr__equipments(incidentsettings)
    class_methods.delete_childr__equipments(logpanelsettings)
    class_methods.delete_childr__equipments(permitofficesettings)
    class_methods.delete_childr__equipments(sensorsettings)
    class_methods.delete_childr__equipments(toastsettings)
    class_methods.delete_childr__equipments(usersettings)
    class_methods.delete_childr__equipments(videomonitor)
    class_methods.delete_childr__equipments(videowallsegment)
    class_methods.delete_childr__equipments(videowallsegmentlayout)
    class_methods.delete_childr__equipments(videowallsegmenttemplate)
    class_methods.delete_childr__equipments(videowalltemplate)
    class_methods.delete_childr__equipments(videowalltemplatelayout)
    class_methods.delete_childr__equipments(videowalltemplatewindow)
    class_methods.delete_childr__equipments(videowallwindowlayout)

    class_methods.delete_equipments(channel)
    class_methods.delete_equipments(fullscreensettings)
    class_methods.delete_equipments(geozone)
    class_methods.delete_equipments(gismap)
    class_methods.delete_equipments(incidentsettings)
    class_methods.delete_equipments(layout)
    class_methods.delete_equipments(logpanelsettings)
    class_methods.delete_equipments(map)
    class_methods.delete_equipments(mapshierarchy)
    class_methods.delete_equipments(obsobj)
    class_methods.delete_equipments(permitofficesettings)
    class_methods.delete_equipments(sensorsettings)
    class_methods.delete_equipments(toastsettings)
    class_methods.delete_equipments(usersettings)
    class_methods.delete_equipments(videomonitor)
    class_methods.delete_equipments(videopanel)
    if videoserver:
        class_methods.delete_equipments(videoserver)
    class_methods.delete_equipments(videoverificationpanel)
    class_methods.delete_equipments(videowall)
    class_methods.delete_equipments(videowallsegment)
    class_methods.delete_equipments(videowallsegmentlayout)
    class_methods.delete_equipments(videowallsegmenttemplate)
    class_methods.delete_equipments(videowalltemplate)
    class_methods.delete_equipments(videowalltemplatelayout)
    class_methods.delete_equipments(videowalltemplatewindow)
    class_methods.delete_equipments(videowallwindowlayout)
    class_methods.delete_equipments(webview)
    class_methods.delete_equipments(workstation)


if __name__ == '__main__':
    main()
