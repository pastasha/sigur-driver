# -*- coding: utf-8 -*-

from equipment import dev_except
from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link
from .system_videomonitor import system_videomonitor
from .system_videowallsegment import system_videowallsegment
from common_protocol_config.common_subject import common_subject


class system_workstation(protocol_obj_base, alias='Рабочая станция'):

    def postCreate(self, ignore_create_objects=False):
        if not ignore_create_objects:
            self.addChild(self._core.createElement('fullscreensettings', siteId=self.siteId))
            self.addChild(self._core.createElement('incidentsettings', siteId=self.siteId))
            self.addChild(self._core.createElement('logpanelsettings', siteId=self.siteId))
            self.addChild(self._core.createElement('permitofficesettings', siteId=self.siteId))
            self.addChild(self._core.createElement('sensorsettings', siteId=self.siteId))
            self.addChild(self._core.createElement('toastsettings', siteId=self.siteId))
            self.addChild(self._core.createElement('usersettings', siteId=self.siteId))
            for layout in self._core.getElements('layout'):
                if int(layout.getAttribute('layout_type')) == 1:
                    self.createLink('workstation_layout', layout)

    def preDelete(self, deleteAsLink=False):
        childs = self.getChildListByType('fullscreensettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('incidentsettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('logpanelsettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('permitofficesettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('sensorsettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('toastsettings')
        for c in childs:
            c.selfDelete()
        childs = self.getChildListByType('usersettings')
        for c in childs:
            c.selfDelete()

    def __onChangeWallSegment(self, targetObj):
        """После изменения ссылки на сегмент видеостены"""
        if not self.videowallsegment:
            return
        objWallSegment = self.videowallsegment
        workstations = self._core.getElements("workstation")
        for workstation in workstations:
            if workstation.getUniID() == self.getUniID() or not workstation.isLinkedElement('videowallsegment'):
                continue
            wallsegment = workstation.getAttribute('videowallsegment')
            if wallsegment == objWallSegment:
                workstation.unBindElement("videowallsegment", skipActions=True)
                
    def __checkUniqueNetworkName(self, field, value):
        # У каждой рабочей станции в пределах одного слейва должно быть уникальное сетевое имя
        for workstation in self._core.getElements('workstation'):
            if workstation.getUniID() == self.getUniID() or workstation.getSiteId() != self.getSiteId():
                # Сетевое имя надо проверять у всех рабочих станций с такого же слейва что у той у которой меняем
                continue
            if workstation.getAttribute('network_name') == value:
                raise dev_except.TerminateAction(self._core.getString('workstationNetworkNameNotUnique') %
                                                 workstation.getAttribute('description'))

    def __getClnLicence(self, field):
        return self.equipment.getClientLicenceLimitations()

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    network_name = Attribute(alias='Сетевое имя', fieldType=str, defval='', index=2, preAction=__checkUniqueNetworkName)
    deactivatealarmmon = Attribute(alias='Скрывать тревожный монитор', fieldType=bool, defval=True, index=4,
                                   editorType='checkBox')
    duty_timeout = Attribute(alias='Время вывода на дежурный монитор', fieldType=int, defval=0, index=6,
                             editorType='int')
    alarm_videomonitor = Link(alias='Тревожный монитор', target=system_videomonitor, index=3)
    duty_videomonitor = Link(alias='Дежурный монитор', target=system_videomonitor, index=5)
    phone = Attribute(alias='Номер телефона', fieldType=str, defval='', index=7)
    name_guardinstruction = Attribute(alias='Название оперативной инструкции', fieldType=str, defval='', index=8)
    show_guardinstruction = Attribute(alias='Отображать оперативную инструкцию', fieldType=bool, defval=False, index=9,
                                      editorType='checkBox')
    videowallsegment = Link(alias='Сегмент видеостены', target=system_videowallsegment, index=10,
                            postAction=__onChangeWallSegment)
    call_context = Attribute(alias='Контекст вызова', fieldType=str, defval='', index=11)
    cln_licence = Attribute(alias='Лицензионные ограничения', fget=__getClnLicence, index=12, storeInDb=False,
                            readOnly=True)

    authenticatedSubject = Link(alias='Текущий оператор', target=common_subject, index=13)
