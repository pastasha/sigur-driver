# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_channel import system_channel


class system_workstation_channel(protocol_obj_base, alias='',
                                 parent=ParentStruct(typeName='workstation', alias='Дополнительные каналы рассылки',
                                                     addr=(1, constants.MAX_UINT32))):
    channel = Link(alias='', target=system_channel, index=1)
