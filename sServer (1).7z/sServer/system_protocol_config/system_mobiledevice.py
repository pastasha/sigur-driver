# -*- coding: utf-8 -*-

import time

from equipment.protocol_obj_base import protocol_obj_base, Attribute, Link, action_decorator
from common_protocol_config.common_subject import common_subject


class system_mobiledevice(protocol_obj_base, alias='Мобильное устройство'):

    OBSOBJTYPE = 'mobile'

    def __init__(self):
        super().__init__()
        self.state = {
            'CON': 0,
            'SGN': 0,
            'ATTN': 0,
            'ACT': 0,
            'CONF': {}
        }

    @action_decorator(alias='Запросить видеотрансляцию')
    def getVideoTranslation(self):
        if self.state['CON'] == 0 or self.state['SGN'] == 0:
            txt = self._core.getString('getVideoTranslationError')
            tp = 'error'
            self.__makeNotiff()
            return {
                'txt': txt,
                'type': tp
            }
        else:
            self.state['ATTN'] = 1
            self.__makeNotiff()
            txt = self._core.getString('getVideoTranslationOk')
            tp = 'info'
            self.__makeNotiff()
        return {
            'txt': txt,
            'type': tp
        }

    @action_decorator(alias='Телефон залогинился')
    def mobileDeviceLogIn(self):
        self.state['SGN'] = 1
        self.__makeNotiff()
        return

    @action_decorator(alias='Телефон разлогинился')
    def mobileDeviceLogOut(self):
        self.state['SGN'] = 0
        self.__makeNotiff()
        return

    @action_decorator(alias='Пропала связь')
    def mobileDeviceLostConnect(self):
        self.state['CON'] = 0
        self.__makeNotiff()
        return

    @action_decorator(alias='Восстановилась связь')
    def mobileDeviceConnect(self):
        self.state['CON'] = 1
        self.__makeNotiff()
        return

    @action_decorator(alias='Начало видеотрансляции')
    def startVideoTranslation(self):
        self.state['ACT'] = 1
        self.state['ATTN'] = 0
        self.__makeNotiff()
        return

    @action_decorator(alias='Завершение видеотрансляции')
    def finishVideoTranslation(self):
        self.state['ACT'] = 0
        self.state['ATTN'] = 0
        self.__makeNotiff()
        return

    @action_decorator(alias='Отказ от видеотрансляции')
    def refuseToVideoTranslation(self):
        self.state['ACT'] = 0
        self.state['ATTN'] = 0
        self.__makeNotiff()
        return

    def init(self):
        self.__makeNotiff()

    def __eventTemplate(self, state):
        event = {
            'notification': {
                'code': 1000
            },
            'statement': {
                'adverbialTime': {
                    'param': time.time()
                },
                'directObj': {
                    'dev': {
                        'equip': 'system',
                        'type': self.getTypeName(),
                        'id': self.getUniID(),
                        'state': state
                    }
                }
            }
        }
        return event

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    def postCreate(self, ignore_create_objects=False):
        self.__makeNotiff()

    def __makeNotiff(self, **kwargs):
        """
        Метод генерирует 1000 нотификацию и передает состояния флагов: CON, SGN, ATTN, CONF при инициализации сервера,
        при создани устройства, при выполнении экшенов, и при изменении каких-либо данных.
        """
        # пока подразумевается, что видеосервер может быть один
        try:
            videoServerList = self._core.getElements('videoserver')
            videoServer = videoServerList[0]
        except Exception:
            return None
        else:
            if not videoServer:
                return

            self.state['CONF'] = {
                'name': self.description,
                'ip': "%s:%s" % (videoServer.getAttribute('ip_addr'), videoServer.getAttribute('rtsp_ports')),
                'port': "/mobile.%s" % self.imei,
                'login': videoServer.getAttribute('login'),
                'pass': videoServer.getAttribute('password'),
                'type': 'Viinex',
                'storage': "%s:%s" % (videoServer.getAttribute('ip_addr'), videoServer.getAttribute('port')),
            }

            event = self.__eventTemplate(self.state)
            self._obj.pushEvent(event)
            return

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1, postAction=__makeNotiff)
    imei = Attribute(alias='IMEI устройства', fieldType=str, defval='', index=2, postAction=__makeNotiff)
    phone_number = Attribute(alias='Номер телефона', fieldType=str, defval='', index=3)
    authenticatedSubject = Link(alias='Текущий оператор', target=common_subject, index=13)

    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
