# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_layout(protocol_obj_base, alias='Раскладка рабочего стола'):
    @classmethod
    def getLayoutType(cls):
        return {
            cls._core.getString('custom'): 0,
            cls._core.getString('duty'): 1,
            cls._core.getString('incident'): 2,
        }

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    layout_type = Attribute(alias='Тип раскладки рабочего стола', fieldType=int, defval=0, index=2,
                            editorType='treeSelect(getLayoutType)')
