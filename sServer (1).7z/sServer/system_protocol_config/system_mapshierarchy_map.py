# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_map import system_map


class system_mapshierarchy_map(protocol_obj_base, alias='', uniqueBridge=True,
                               parent=ParentStruct(typeName='mapshierarchy', alias='Корневые векторные карты',
                                                   addr=(1, constants.MAX_UINT32))):

    map = Link(alias='Корневая векторная карта', target=system_map, index=1)
    index = Attribute(alias='Порядковый номер', fieldType=int, defval=1, index=2, editorType='int')
