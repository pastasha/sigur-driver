# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import constants
from equipment import dev_except


class system_fullscreensettings(protocol_obj_base, alias='Параметры полноэкранного режима',
                                parent=ParentStruct(typeName='workstation', alias='Параметры полноэкранного режима',
                                                    addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('fullscreensettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    def preChangeWidth(self, value, field):
        if value < 300:
            raise dev_except.TerminateAction(self._core.getString('fullscreeWidthInvalidValue'))

    def preChangeHeight(self, value, field):
        if value < 300:
            raise dev_except.TerminateAction(self._core.getString('fullscreeHeightInvalidValue'))

    enable = Attribute(alias='Используется', fieldType=bool, defval=False, index=1,
                       editorType='treeSelect(getBooleanType)')
    x = Attribute(alias='X левого верхнего угла', fieldType=int, defval=0, index=2, editorType='int')
    y = Attribute(alias='Y левого верхнего угла', fieldType=int, defval=0, index=3, editorType='int')
    width = Attribute(alias='Ширина', fieldType=int, defval=300, index=4, editorType='int',
                      preAction=preChangeWidth)
    height = Attribute(alias='Высота', fieldType=int, defval=300, index=5, editorType='int',
                       preAction=preChangeHeight)
