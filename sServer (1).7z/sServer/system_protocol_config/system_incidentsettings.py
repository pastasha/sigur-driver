# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_incidentsettings(protocol_obj_base, alias='Параметры инцидентов',
                              parent=ParentStruct(typeName='workstation', alias='Параметры инцидентов',
                                                  addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('incidentsettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    @classmethod
    def getVideoPolicy(cls):
        return {
            cls._core.getString('systemArchive'): 1,
            cls._core.getString('systemOnline'): 2
        }

    incident_video_policy = Attribute(alias='Отображение видео при выборе инцидента', fieldType=int, defval=2, index=1,
                                      editorType='treeSelect(getVideoPolicy)')
    worktool = Attribute(alias='Отображать панель команд инцидента', fieldType=bool, defval=True, index=2,
                         editorType='treeSelect(getBooleanType)')
    disablemapchange = Attribute(alias='Выключить переключение карт в режиме инцидентов', fieldType=bool, defval=True,
                                 index=3, editorType='treeSelect(getBooleanType)')
