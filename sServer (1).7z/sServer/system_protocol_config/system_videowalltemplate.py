# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from . import event_packet


class system_videowalltemplate(protocol_obj_base, alias='Макет видеостены',
                               parent=ParentStruct(typeName='videowall', alias='Макеты')):

    def preDelete(self, deleteAsLink=False):
        event_packet.deleteWallTemplate(self, self._core)

    description = Attribute(alias='Имя макета', fieldType=str, defval='', index=1)
