# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_channel(protocol_obj_base, alias='Каналы рассылки'):

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    value = Attribute(alias='Значение', fieldType=str, defval='', index=2)
