# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_videoverificationpanel import system_videoverificationpanel


class system_workstation_videoverificationpanel(protocol_obj_base, alias='',
                                                parent=ParentStruct(typeName='workstation', alias='Панели верификации',
                                                                    addr=(1, constants.MAX_UINT32))):
    videoverificationpanel = Link(alias='', target=system_videoverificationpanel, index=1)
