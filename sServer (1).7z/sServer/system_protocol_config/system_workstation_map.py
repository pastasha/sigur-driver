# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from equipment import constants
from .system_map import system_map


class system_workstation_map(protocol_obj_base, alias='', parent=ParentStruct(typeName='workstation', alias='Карты',
                                                                              addr=(1, constants.MAX_UINT32))):
    map = Link(alias='', target=system_map, index=1)
