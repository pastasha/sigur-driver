# -*- coding: utf-8 -*-

def deleteWallSegmentLayout(obj, core):
    """Удаление раскладки сегмента видеостены"""
    windowLayouts = obj.getChildListByType("videowallwindowlayout")
    for windowLayout in windowLayouts:
        windowLayout.selfDelete()

def deleteWallSegmentTemplate(obj, core):
    """Удаление макета сегмента видеостены"""
    windows = obj.getChildListByType("videowalltemplatewindow")
    for window in windows:
        window.selfDelete()

def deleteWallTemplateLayout(obj, core):
    """Удаление раскладки видеостены"""
    segmentLayouts = obj.getChildListByType("videowallsegmentlayout")
    for segmentLayout in segmentLayouts:
        deleteWallSegmentLayout(segmentLayout, core)
        segmentLayout.selfDelete()

def deleteWallTemplate(obj, core):
    """Удаление макета видеостены"""
    templateLayouts = obj.getChildListByType("videowalltemplatelayout")
    for templateLayout in templateLayouts:
        deleteWallTemplateLayout(templateLayout, core)
        templateLayout.selfDelete()

    segmentTemplates = obj.getChildListByType("videowallsegmenttemplate")
    for segmentTemplate in segmentTemplates:
        deleteWallSegmentTemplate(segmentTemplate, core)
        segmentTemplate.selfDelete()

def deleteWall(obj, core):
    """Удаление объекта видеостены"""
    templates = obj.getChildListByType("videowalltemplate")
    for template in templates:
        deleteWallTemplate(template, core)
        template.selfDelete()
    segments = obj.getChildListByType("videowallsegment")
    for segment in segments:
        segment.selfDelete()
