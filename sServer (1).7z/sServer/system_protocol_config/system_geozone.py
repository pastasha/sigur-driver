# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import constants


class system_geozone(protocol_obj_base, alias='Геозона',
                     parent=ParentStruct(typeName='geozone', alias='Геозоны', addr=(1, constants.MAX_UINT32))):

    OBSOBJTYPE = 'dev'

    def __getObsObjType(self, field):
        return self.OBSOBJTYPE

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    obsobjtype = Attribute(alias='Тип объекта мониторинга', index=100, fget=__getObsObjType, readOnly=True,
                           storeInDb=False)
