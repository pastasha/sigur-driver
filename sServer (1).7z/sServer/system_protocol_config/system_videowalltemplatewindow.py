# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute


class system_videowalltemplatewindow(protocol_obj_base, alias='Окно макета',
                                   parent=ParentStruct(typeName='videowallsegmenttemplate', alias='Окно макета')):
    number = Attribute(alias='Порядковый номер', fieldType=int, defval=1, index=1)
    y = Attribute(alias='Номер строки', fieldType=int, defval=0, index=2)
    x = Attribute(alias='Номер столбца', fieldType=int, defval=0, index=3)
    columns = Attribute(alias='Ширина', fieldType=int, defval=1, index=4)
    rows = Attribute(alias='Высота', fieldType=int, defval=1, index=5)
