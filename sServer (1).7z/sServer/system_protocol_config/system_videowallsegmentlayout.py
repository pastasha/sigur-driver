# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Link
from . import event_packet
from .system_videowallsegmenttemplate import system_videowallsegmenttemplate


class system_videowallsegmentlayout(protocol_obj_base, alias='Раскладка макета сегмента',
                                    parent=ParentStruct(typeName='videowalltemplatelayout',
                                                        alias='Раскладки макетов сегментов')):

    def preDelete(self, deleteAsLink=False):
        event_packet.deleteWallSegmentLayout(self, self._core)

    segmenttemplate = Link(alias='Макет сегмента', target=system_videowallsegmenttemplate, index=1)
