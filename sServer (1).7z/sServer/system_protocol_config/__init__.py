# -*- coding: utf-8 -*-

alias = 'Конфигурация клиентов ESM'
