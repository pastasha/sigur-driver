# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_layout import system_layout


class system_workstation_layout(protocol_obj_base, alias='',
                                parent=ParentStruct(typeName='workstation', alias='Раскладки рабочих столов',
                                                    addr=(1, constants.MAX_UINT8))):
    shortcut = Attribute(alias='Комбинация клавиш', fieldType=str, defval='', index=1)
    layout = Link(alias='', target=system_layout, index=2)
