# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_map(protocol_obj_base, alias='Карта'):

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    description = Attribute(alias='Описание', fieldType=str, defval='', index=1)
    filename = Attribute(alias='Имя файла', fieldType=str, defval='', index=2, editorType='fileMapdxf')
    antialoasing = Attribute(alias='АнтиАлиасинг', fieldType=float, defval=0, index=3)
    show = Attribute(alias='Показывать', fieldType=int, defval=0, index=4)  # TODO: вроде не используется
    min_scale = Attribute(alias='Минимальный масштаб', fieldType=float, defval=0, index=5)
    max_scale = Attribute(alias='Максимальный масштаб', fieldType=float, defval=0, index=6)
    r1 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.75(r1)', fieldType=float, defval=0, index=7)
    r2 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.50(r2)', fieldType=float, defval=0, index=8)
    r3 = Attribute(alias='Коэффициент маcштаба, для размера иконки 0.25(r3)', fieldType=float, defval=0, index=9)
    showlimit = Attribute(alias='Минимальный размер видимой иконки (pix)', fieldType=int, defval=0, index=10,
                          editorType='int')
    latitude = Attribute(alias='Широта нахождения карты', fieldType=float, defval=0, index=11)
    longitude = Attribute(alias='Долгота нахождения карты', fieldType=float, defval=0, index=12)
    hierarchy_level = Attribute(alias='Уровень иерархии', fieldType=int, defval=0, index=13, editorType='int')
    guid = Attribute(alias='GUID', fieldType=str, defval='', index=14)
    enable_opacity = Attribute(alias='Включить непрозрачность объектов связанных с объектами плана', fieldType=bool,
                               defval=False, index=15, editorType='treeSelect(getBooleanType)')
    length = Attribute(alias='Длина (м)', fieldType=float, defval=0, index=16)
    width = Attribute(alias='Ширина (м)', fieldType=float, defval=0, index=17)
    config = Attribute(alias='Конфигурация', fieldType=str, defval='', index=18)
