# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_usersettings(protocol_obj_base, alias='Общие параметры',
                          parent=ParentStruct(typeName='workstation', alias='Общие параметры',
                                              addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('usersettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    @classmethod
    def getAlertLevels(cls):
        return {
            cls._core.getString('notAlarmingAlertLevel'): 0,
            cls._core.getString('lowAlertLevel'): 1,
            cls._core.getString('mediumAlertLevel'): 2,
            cls._core.getString('highAlertLevel'): 3,
            cls._core.getString('criticalAlertLevel'): 4,
            cls._core.getString('doNotBlink'): 5
        }

    @classmethod
    def getAlarmOnMapPolicy(cls):
        return {
            cls._core.getString('centerOnObject'): 0,
            cls._core.getString('showSavedArea'): 1
        }

    modeledalarm = Attribute(alias='Отображать команду запуска смоделированной тревоги', fieldType=bool, defval=False,
                             index=1, editorType='treeSelect(getBooleanType)')
    alertlevel = Attribute(alias='Минимальная тревожность события для мигания на плане', fieldType=int, defval=1,
                           index=2, editorType="treeSelect(getAlertLevels)")
    twinkletime = Attribute(alias='Время по умолчанию для мигания объектов на плане (с)', fieldType=int, defval=20,
                            index=3, editorType='int')
    showcontrollerrequisitionsbutton = Attribute(alias='Отображать в клиенте кнопку «Заявки на вход/выход»',
                                                 fieldType=bool, defval=False, index=4,
                                                 editorType='treeSelect(getBooleanType)')
    adddevconfigpanel = Attribute(alias='Отображать третью панель объектов оборудования', fieldType=bool, defval=False,
                                  index=5, editorType='treeSelect(getBooleanType)')
    previewmonitorshowtimeout = Attribute(alias='Время через которое появляется окно превью монитора на плане (мс)',
                                          fieldType=int, defval=1000, index=6, editorType='int')
    previewmonitorhidetimeout = Attribute(
        alias='Время отображения незафиксированного окна превью монитора на плане (мс)', fieldType=int, defval=8000,
        index=7, editorType='int')
    object = Attribute(alias='Имя объекта', fieldType=str, defval='', index=8)
    system = Attribute(alias='Имя системы', fieldType=str, defval='', index=9)
    fontsize = Attribute(alias='Размер шрифта текста (для отображения имени объекта и системы)', fieldType=int,
                         defval=16, index=10, editorType='int')
    alloweditdesktop = Attribute(alias='Разрешать редактирование рабочих столов', fieldType=bool, defval=False,
                                 index=12, editorType='treeSelect(getBooleanType)')
    allowchangedesktop = Attribute(alias='Разрешать переключение между рабочими столами', fieldType=bool, defval=False,
                                   index=13, editorType='treeSelect(getBooleanType)')
    videomunitorbutton = Attribute(alias='Отображать панель с видеомониторами', fieldType=bool, defval=False, index=14,
                                   editorType='treeSelect(getBooleanType)')
    webpanelbutton = Attribute(alias='Отображать панель с внешними компонентами', fieldType=bool, defval=False,
                               index=15, editorType='treeSelect(getBooleanType)')
    timebeforeshowvideoarchive = Attribute(alias='Сместить поиск видеоархива раньше на (с)', fieldType=int, defval=0,
                                           index=16, editorType='int')
    showcamondutymonitor = Attribute(alias='Отображать камеру на дежурном мониторе по клику левой кнопкой',
                                     fieldType=bool, defval=False, index=17, editorType='treeSelect(getBooleanType)')
    alarmonmappolicy = Attribute(alias='Политика поведения планов при тревоге',
                                 fieldType=int, defval=0, index=18, editorType='treeSelect(getAlarmOnMapPolicy)')
