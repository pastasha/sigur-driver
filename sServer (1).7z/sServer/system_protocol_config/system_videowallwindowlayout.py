# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link

from .system_videowalltemplatewindow import system_videowalltemplatewindow


class system_videowallwindowlayout(protocol_obj_base, alias='Представление окон в раскладке',
                                   parent=ParentStruct(typeName='videowallsegmentlayout',
                                                       alias='Представление окон в раскладке')):
    windowid = Link(alias='Окно макета', target=system_videowalltemplatewindow, index=1)
    contentobject = Attribute(alias='Id связанного объекта', fieldType=int, defval=0, index=2)
    contenttype = Attribute(alias='Тип содержимого', fieldType=int, defval=0, index=3)
    content = Attribute(alias='Содержимое', fieldType=str, defval='', index=4)
