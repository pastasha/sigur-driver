# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_toastsettings(protocol_obj_base, alias='Параметры всплывающих сообщений',
                           parent=ParentStruct(typeName='workstation', alias='Параметры всплывающих сообщений',
                                               addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('toastsettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    @classmethod
    def getPriority(cls):
        return {
            cls._core.getString('byTime'): 0,
            cls._core.getString('byImportance'): 1
        }
        
    def checkMessagesValue(self, field, value):
        if int(value) < 0:
            raise dev_except.TerminateAction(self._core.getString('numberOfDisplayedMessagesMustBePositive'))

    minimize_previous_messages = Attribute(alias='Открывать только новое', fieldType=bool, defval=True, index=1,
                                           editorType='treeSelect(getBooleanType)')
    priority_of_messages = Attribute(alias='Приоритет вывода сообщений', fieldType=int, defval=0, index=2,
                                     editorType='treeSelect(getPriority)')
    number_of_displayed_messages = Attribute(alias='Число отображаемых сообщений', fieldType=int, defval=10, index=3,
                                             editorType='int', preAction=checkMessagesValue)
    close_old_mess_if_display_is_filled = Attribute(alias='Закрывать старые сообщения', fieldType=bool, defval=True,
                                                    index=4, editorType='treeSelect(getBooleanType)')
