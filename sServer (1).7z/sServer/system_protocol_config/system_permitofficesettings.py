# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute
from equipment import dev_except, constants


class system_permitofficesettings(protocol_obj_base, alias='Параметры бюро пропусков',
                                  parent=ParentStruct(typeName='workstation', alias='Параметры бюро пропусков',
                                                      addr=(1, constants.MAX_UINT32))):
    def preChangeParent(self, newParent=None, addr=None, info=None):
        if newParent:
            childs = newParent.getChildListByType('permitofficesettings')
            if len(childs) > 0:
                raise dev_except.TerminateAction(self._core.getString('settingsAlreadyExists'))

    @classmethod
    def getBooleanType(cls):
        return {
            cls._core.getString('yes'): True,
            cls._core.getString('no'): False
        }

    tabpermit = Attribute(alias='Отображать вкладку Информация', fieldType=bool, defval=True, index=1,
                          editorType='treeSelect(getBooleanType)')
    tabrights = Attribute(alias='Отображать вкладку Права доступа', fieldType=bool, defval=True, index=2,
                          editorType='treeSelect(getBooleanType)')
    tabpermitpermits = Attribute(alias='Отображать вкладку Связанные пропуска', fieldType=bool, defval=True, index=3,
                                 editorType='treeSelect(getBooleanType)')
    tabbiosmart = Attribute(alias='Отображать вкладку Биометрия', fieldType=bool, defval=True, index=4,
                            editorType='treeSelect(getBooleanType)')
    tabidcode = Attribute(alias='Отображать вкладку Идентификатор', fieldType=bool, defval=True, index=5,
                          editorType='treeSelect(getBooleanType)')
    tabbiomini = Attribute(alias='Отображать вкладку БиоМини', fieldType=bool, defval=False, index=6,
                           editorType='treeSelect(getBooleanType)')
    tabschedule = Attribute(alias='Отображать вкладку Расписание', fieldType=bool, defval=True, index=7,
                            editorType='treeSelect(getBooleanType)')
    human = Attribute(alias='Отображать список частных лиц в диалоге создания пропуска по заявке', fieldType=bool,
                      defval=True, index=8, editorType='treeSelect(getBooleanType)')
    mobile = Attribute(alias='Отображать список транспортных средств в диалоге создания пропуска по заявке',
                       fieldType=bool, defval=True, index=9, editorType='treeSelect(getBooleanType)')
    thing = Attribute(alias='Отображать список материальных ценностей в диалоге создания пропуска по заявке',
                      fieldType=bool, defval=False, index=10, editorType='treeSelect(getBooleanType)')
    createdepartment = Attribute(alias='Разрешать создавать новые организации и подразделения', fieldType=bool,
                                 defval=True, index=11, editorType='treeSelect(getBooleanType)')
    showdailypassreport = Attribute(alias='Отображать кнопку построения отчет по разовым пропускам', fieldType=bool,
                                    defval=False, index=12, editorType='treeSelect(getBooleanType)')
    permitddditionalcommands = Attribute(
        alias='Отображать в контекстном меню и в кнопке действия дополнительные команды пропуска', fieldType=bool,
        defval=True, index=13, editorType='treeSelect(getBooleanType)')
    maypermitprintsettings = Attribute(alias='Включены настройки принтера при печати пропуска', fieldType=bool,
                                       defval=True, index=14, editorType='treeSelect(getBooleanType)')
    needminutesindate = Attribute(alias='Необходимо ли вводить и выводить дату/время с учетом минут или без',
                                  fieldType=bool, defval=True, index=15, editorType='treeSelect(getBooleanType)')
    saveprintsonserver = Attribute(alias='Сохранять распечатанные шаблоны пропусков на сервере', fieldType=bool,
                                   defval=True, index=16, editorType='treeSelect(getBooleanType)')
    showdocscan = Attribute(alias='Добавляет в контекстном меню пропуска пункт «Просмотра скана документа».',
                            fieldType=bool, defval=False, index=17, editorType='treeSelect(getBooleanType)')
    minqualitybiosmart = Attribute(alias='Минимальное качество отпечатка пальца', fieldType=int, defval=75, index=18,
                                   editorType='int')
    filterinputdelayms = Attribute(
        alias='Пауза после ввода последнего символа в строке поиска списка пропусков перед началом фильтрации',
        fieldType=int, defval=15, index=19, editorType='int')
    oriondlgforals = Attribute(alias='Отображать кнопку создать уровень доступа Орион',
                               editorType='treeSelect(getBooleanType)', fieldType=bool, defval=False, index=20)
