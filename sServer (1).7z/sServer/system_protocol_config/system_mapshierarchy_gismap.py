# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_gismap import system_gismap


class system_mapshierarchy_gismap(protocol_obj_base, alias='', uniqueBridge=True,
                                  parent=ParentStruct(typeName='mapshierarchy', alias='Корневые ГИС карты',
                                                      addr=(1, constants.MAX_UINT32))):

    gismap = Link(alias='Корневая ГИС карта', target=system_gismap, index=1)
    index = Attribute(alias='Порядковый номер', fieldType=int, defval=1, index=2, editorType='int')
