# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute, Link
from equipment import constants
from .system_gismap import system_gismap
from .system_mapshierarchy import system_mapshierarchy


class system_gismap_gismap(protocol_obj_base, alias='',
                           parent=ParentStruct(typeName='gismap', alias='Иерархические точки ГИС',
                                               addr=(1, constants.MAX_UINT8))):

    latitude = Attribute(alias='Широта', fieldType=float, defval=0, index=1)
    longitude = Attribute(alias='Долгота', fieldType=float, defval=0, index=2)
    gismap = Link(alias='ГИС карта', target=system_gismap, index=3)
    mapshierarchy = Link(alias='Отображать в иерархии', target=system_mapshierarchy, index=4)
