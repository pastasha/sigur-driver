# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, ParentStruct, Attribute


class system_videowallsegment(protocol_obj_base, alias='Сегмент видеостены',
                              parent=ParentStruct(typeName='videowall', alias='Сегменты')):

    description = Attribute(alias='Имя сегмента', fieldType=str, defval='', index=1)
    rows = Attribute(alias='Количество строк', fieldType=int, defval=5, index=2)
    columns = Attribute(alias='Количество столбцов', fieldType=int, defval=5, index=3)
    x = Attribute(alias='Позиция по-горизонтали', fieldType=int, defval=0, index=4)
    y = Attribute(alias='Позиция по-вертикали', fieldType=int, defval=0, index=5)
    serviceurl = Attribute(alias='URL для обращения к сегменту', fieldType=str, defval='', index=6)
