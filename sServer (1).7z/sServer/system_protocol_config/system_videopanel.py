# -*- coding: utf-8 -*-

from equipment.protocol_obj_base import protocol_obj_base, Attribute


class system_videopanel(protocol_obj_base, alias='Видеопанель'):

    @classmethod
    def __getObjIdByRemoteGuid(cls, guid):
        cur = cls._core.sql("select id from observed_objects where remote_guid = '%s'" % guid)
        row = cur.fetchone()
        if row:
            id = row[0]
        else:
            id = -1
        return id

    @classmethod
    def preCreate(cls, createAttrs=None, targetObj=None, mainObj=None, info=None):
        for i in range(1, 17):
            attr = 'oo_cam%s' % i
            if attr in createAttrs:
                value = createAttrs[attr]
                if isinstance(value, list): # Так может быть если мы просто скопировали объект
                    createAttrs[attr] = value[0]['id']
                else: # А так от dedicated
                    try:
                        int(value)
                    except:
                        # Если у нас не привелось к числу значит тут не id а remote_guid объекта
                        createAttrs[attr] = cls.__getObjIdByRemoteGuid(value)

    def getOOCam(self, field):
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        objid = getattr(system_videopanel, field).defaultGet(self)
        cur = self._core.sql('select remote_guid from observed_objects where id = %s' % objid)
        row = cur.fetchone()
        remote_guid = ''
        if row:
            remote_guid = row[0]
        return [{
            'id': objid,
            'remote_guid': remote_guid
        }]

    def __setOOCam(self, value, field):
        try:
            id = int(value)
        except:
            # Если у нас не привелось к числу значит тут не id а remote_guid объекта
            id = self.__getObjIdByRemoteGuid(value)
        # Тут это действие не вызовется еще раз так как setAttribute не вызывает никаких действий
        # TODO: выглядит подозрительно но как исправить я пока не знаю
        getattr(system_videopanel, field).defaultSet(self, id)

    description = Attribute(alias='Имя/Название', fieldType=str, defval='', index=1)
    oo_cam1 = Attribute(alias='Камера №1 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=2, fset=__setOOCam)
    rtsp_cam1 = Attribute(alias='Камера №1 (RTSP)', fieldType=str, defval='', index=3)
    oo_cam2 = Attribute(alias='Камера №2 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=4, fset=__setOOCam)
    rtsp_cam2 = Attribute(alias='Камера №2 (RTSP)', fieldType=str, defval='', index=5)
    oo_cam3 = Attribute(alias='Камера №3 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=6, fset=__setOOCam)
    rtsp_cam3 = Attribute(alias='Камера №3 (RTSP)', fieldType=str, defval='', index=7)
    oo_cam4 = Attribute(alias='Камера №4 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=7, fset=__setOOCam)
    rtsp_cam4 = Attribute(alias='Камера №4 (RTSP)', fieldType=str, defval='', index=8)
    oo_cam5 = Attribute(alias='Камера №5 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=9, fset=__setOOCam)
    rtsp_cam5 = Attribute(alias='Камера №5 (RTSP)', fieldType=str, defval='', index=10)
    oo_cam6 = Attribute(alias='Камера №6 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=11, fset=__setOOCam)
    rtsp_cam6 = Attribute(alias='Камера №6 (RTSP)', fieldType=str, defval='', index=12)
    oo_cam7 = Attribute(alias='Камера №7 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=13, fset=__setOOCam)
    rtsp_cam7 = Attribute(alias='Камера №7 (RTSP)', fieldType=str, defval='', index=14)
    oo_cam8 = Attribute(alias='Камера №8 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=15, fset=__setOOCam)
    rtsp_cam8 = Attribute(alias='Камера №8 (RTSP)', fieldType=str, defval='', index=16)
    oo_cam9 = Attribute(alias='Камера №9 (объект мониторинга)', fieldType=int, defval=-1,
                        editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=17, fset=__setOOCam)
    rtsp_cam9 = Attribute(alias='Камера №9 (RTSP)', fieldType=str, defval='', index=18)
    oo_cam10 = Attribute(alias='Камера №10 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=19, fset=__setOOCam)
    rtsp_cam10 = Attribute(alias='Камера №10 (RTSP)', fieldType=str, defval='', index=20)
    oo_cam11 = Attribute(alias='Камера №11 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=21, fset=__setOOCam)
    rtsp_cam11 = Attribute(alias='Камера №11 (RTSP)', fieldType=str, defval='', index=22)
    oo_cam12 = Attribute(alias='Камера №12 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=23, fset=__setOOCam)
    rtsp_cam12 = Attribute(alias='Камера №12 (RTSP)', fieldType=str, defval='', index=24)
    oo_cam13 = Attribute(alias='Камера №13 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=25, fset=__setOOCam)
    rtsp_cam13 = Attribute(alias='Камера №13 (RTSP)', fieldType=str, defval='', index=26)
    oo_cam14 = Attribute(alias='Камера №14 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=27, fset=__setOOCam)
    rtsp_cam14 = Attribute(alias='Камера №14 (RTSP)', fieldType=str, defval='', index=28)
    oo_cam15 = Attribute(alias='Камера №15 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=29, fset=__setOOCam)
    rtsp_cam15 = Attribute(alias='Камера №15 (RTSP)', fieldType=str, defval='', index=30)
    oo_cam16 = Attribute(alias='Камера №16 (объект мониторинга)', fieldType=int, defval=-1,
                         editorType='obsObjSelect(cam,mobile)', fget=getOOCam, index=31, fset=__setOOCam)
    rtsp_cam16 = Attribute(alias='Камера №16 (RTSP)', fieldType=str, defval='', index=32)
