# -*- coding: utf-8 -*-

copyPCEAlgResult = 'Копирование алгоритма завершено'
createPCEAlgResult = 'Создание алгоритма завершено'

# dev_except.py
undefinedActionExceptionText = 'Неизвестное действие'
bridgeElementNotFoundExceptionText = 'Объекты %s и %s не связаны'
terminateActionExceptionText = 'Действие отменено'
portNotFoundExceptionText = 'Порт не найден'
commandExecErrorExceptionText = 'Ошибка выполнения команды'
noEditableFieldExceptionText = 'Нередактируемое поле'
bridgeMustBeUniqueExceptionText = 'Связь должна быть уникальна. Уже существует ссылка на %s'
handlerCompileErrorExceptionText = 'Ошибка компиляции'

# dev_obj_model_element.py
setAttrReadOnlyError = 'Поле "%s" только для чтения'

# event_monitor.py
execEquipmentActionError = 'Ошибка при выполнении действия'
createEquipmentObjectError = 'Ошибка при создании объекта'
createEquipmentLinkError = 'Ошибка при связывании объектов'
deleteEquipmentObjectError = 'Ошибка при удалении объекта'
addEquipmentChildError = 'Ошибка при добавлении дочернего объекта'
setEquipmentHandlersError = 'Ошибка при сохранении обработчиков'
removeEquipmentChildError = 'Ошибка при удалении дочернего объекта'
clrEquipmentObjectLinkError = 'Ошибка при сбросе ссылки'
setEquipmentObjectAttributeError = 'Ошибка при изменении атрибута'
setEquipmentObjectLinkSuccess = 'Объект "%s" ссылается на "%s" через "%s"'
setEquipmentObjectsLinkError = 'Ошибка при назначении ссылки'
checkMaxCountError = 'Вы не можете создать больше чем %d объектов вида %s'
equipmentCommandForRemoteSite = 'Действие будет выполнено на удаленном сервере'

# equipment_interface.py
setHandlersSuccess = 'Обработчики объекта "%s" установлены'
newElementSuccess = 'Создан объект типа "%s"'
newElementSetAttrError = 'Ошибка при установке'
newElementAddBridgeError = 'Ошибка при добавлении элемента в'
newElementAddParentError = 'Ошибка при добавлении родительской связи'
newElementUnknownType = 'Неизвестный тип'
delElementSuccess = 'Объект "%s" удален'
addChildSuccess = 'Объекту "%s" добавлен дочерний объект "%s" (%s)'
bindSuccess = 'Объект "%s" ссылается на "%s" через "%s"'
unBindSuccess = 'Ссылка "%s" на объекте "%s" сброшена'
createLinkSuccess = 'Объект "%s" связан с объектом "%s" через "%s"'
setAttrSuccess = 'Атрибут "%s" на объекте "%s" установлен'
removeChildSuccess = 'Объект "%s" исключен из потомков "%s" объекта "%s"'
