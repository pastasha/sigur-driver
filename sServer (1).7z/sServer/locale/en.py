# -*- coding: utf-8 -*-

copyPCEAlgResult = 'PCE Algorithm copying is completed'
createPCEAlgResult = 'PCE Algorithm creation is completed'

# dev_except.py
undefinedActionExceptionText = 'Undefined action'
bridgeElementNotFoundExceptionText = 'Objects %s and %s are not associated'
terminateActionExceptionText = 'Action cancelled'
portNotFoundExceptionText = 'Port not found'
commandExecErrorExceptionText = 'Error of command execution'
noEditableFieldExceptionText = 'Readonly field'
bridgeMustBeUniqueExceptionText = 'Bridge must be unique. Link №%s already exists'
handlerCompileErrorExceptionText = 'Compile error'

# dev_obj_model_element.py
setAttrReadOnlyError = 'Attribute "%s" is readonly'

# event_monitor.py
execEquipmentActionError = 'Error of action execution'
createEquipmentObjectError = 'Error of object creation'
createEquipmentLinkError = 'Error of objects linking'
deleteEquipmentObjectError = 'Error of object deletion'
addEquipmentChildError = 'Error of adding child object'
setEquipmentHandlersError = 'Error of handlers saving'
removeEquipmentChildError = 'Error of child object deletion'
clrEquipmentObjectLinkError = 'Error of link clearing'
setEquipmentObjectAttributeError = 'Error of attribute changing'
setEquipmentObjectLinkSuccess = 'Object "%s" refers to "%s" using "%s"'
setEquipmentObjectsLinkError = 'Error of link creation'
checkMaxCountError = 'You can\'t create more than %d %s objects'
equipmentCommandForRemoteSite = 'Action will be executed at remote server'

# equipment_interface.py
setHandlersSuccess = 'Handlers for object "%s" set'
newElementSuccess = 'Object of type "%s" created'
newElementSetAttrError = 'Error while setting'
newElementAddBridgeError = 'Error of adding an object to'
newElementAddParentError = 'Error of adding a parent relation'
newElementUnknownType = 'Unknown type'
delElementSuccess = 'Object "%s" deleted'
addChildSuccess = 'Child object "%s" (%s) added for object "%s"'
bindSuccess = 'Object "%s" references to "%s" using "%s"'
unBindSuccess = 'Link "%s" to object "%s" cleared'
createLinkSuccess = 'Object "%s" associated with object "%s" using "%s"'
setAttrSuccess = 'Attribute "%s" for object "%s" set'
removeChildSuccess = 'Object "%s" excluded from child objects "%s" of object "%s"'
