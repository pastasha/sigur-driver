# -*- coding: utf-8 -*-

import event_monitor.plugin_support as plgn
import threading
import socket
import json
import time
import logging


class PortsClientError(Exception):
    def __init__(self, msg=''):
        self.__msg = msg

    def __str__(self):
        return 'PortsClientError'


class PortsClient(plgn.PluginObject, threading.Thread):
    def __init__(self, equipName, typeName, id, connStr=''):
        plgn.PluginObject.__init__(self, equipName, typeName, id)
        threading.Thread.__init__(self)

        connStr = connStr.split(',')

        self.__device = connStr[0]
        self.__ip = connStr[1]
        self.__portRPC = int(connStr[2])
        self.__portSocket = int(connStr[3])

        self.__flag = threading.Event()
        self.__flag.clear()
        self.__runFlag = False

        self.__sock = None
        self.__rpcConn = None

        self.start()
        logging.getLogger('console').info('run. connStr =%s'%connStr)

    def sendCommand(self, cmd):
        # возвращается (код возврата, строка ответа)
        try:
            return self.__rpcConn.sendCommand(cmd)
        except Exception as e:
            self.__sock = None
            raise PortsClientError()

    def sendOk(self):
        if self.__sock:
            # Посылка серверу сообщения о доставке сообщения
            self.__sock.send('ok')

    def run(self):
        timeout = 5
        buff = ''
        self.__runFlag = True
        while self.__runFlag:
            if not self.__sock:
                self.__sock = socket.socket(
                    socket.AF_INET, socket.SOCK_STREAM
                )
                try:
                    logging.getLogger('console').info("try to connect to ports_server %s:%s(%s)" % (
                        self.__ip, self.__portSocket, self.__portRPC
                    ))
                    self.__sock.connect((self.__ip, self.__portSocket))
                except BaseException:
                    self.__sock = None
                    self.__flag.wait(timeout)
                else:
                    self.__sock.settimeout(timeout)

                    # Переподключение RPC
                    self.__rpcConn = jsonrpctcp.connect(
                        self.__ip, self.__portRPC
                    )

                    # Говорим, что соединение восстановлено
                    logging.getLogger('console').info("connected to ports server %s:%s(%s)" % (
                        self.__ip, self.__portSocket, self.__portRPC
                    ))

                    try:
                        self.__rpcConn.connect()
                    except Exception as e:
                        self.__sock = None
                        self.__flag.wait(timeout)

            else:
                try:
                    # Получаем сообщение от сервера
                    data = self.__sock.recv(4096).decode("utf-8")
                except Exception as e:
                    logging.getLogger('console').info(str(e))
                    self.__sock = None

                    # Если время ожидания исчерпано
                    # Говорим, что соединение потеряно
                    logging.getLogger('console').info("disconnected from ports server %s:%s(%s)" % (
                        self.__ip, self.__portSocket, self.__portRPC
                    ))
                else:
                    buff = '%s%s' % (buff, data)
                    first = buff.find("\r\n")
                    if first != -1:
                        # В буфере лежит комманда целиком

                        # Обрезаем "\r\n" - получаем текст комманды
                        evt = buff[:first]
                        if evt != "ping":
                            # Если комманда не пинг - добавляем событие в буффер
                            try:
                                evt = json.loads(evt)
                            except BaseException:
                                logging.getLogger('console').info('portClient: invalid json: %s' % evt[:150])
                            else:
                                self.eventProcess({'event': evt})
                        else:
                            self.__sock.send("ok")
                        # Очищаем буфер
                        buff = buff[first + 2:]

    def release(self):
        logging.getLogger('console').info('stopping...')
        self.__runFlag = False
        self.__flag.set()
        self.join(15)
        if self.isAlive():
            logging.getLogger('console').info('WARNING: PortsClient %s thread is steal alive' % (
                '%s,%s,%s,%s' % (
                    self.__device,
                    self.__ip,
                    self.__portRPC,
                    self.__portSocket)
            ))

        logging.getLogger('console').info('stopped')


plgn.PluginSupport.install('portsClient', PortsClient)
