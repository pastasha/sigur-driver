﻿# -*- coding: utf-8 -*-
# Модуль поддержки протокола UUS3
# Версия 1.05

from ctypes import *
import threading
import struct
import collections
import time
from datetime import date
import logging
import traceback

POLL_TIMEOUT = 0.1
EVENT_BASE = 40000

ERR_CODE_UNKNOWN_CMD = 1
ERR_CODE_COMMUNICATION = 2
ERR_CODE_IO = 3
ERR_CODE_NOT_SUPPORTED = 4

ERR_CODE_OPERATION_BASE = 10


class TRequestHdr(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("Command", c_ubyte),
                ("Reserved", c_ubyte),
                ("Reserved1", c_ubyte),
                ("BlockCount", c_ubyte)]


class TReplayHdr(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("Command", c_ubyte),
                ("ReturnCode", c_ubyte),
                ("State", c_ubyte),
                ("BlockCount", c_ubyte)]


class TPacketHdr(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("Transact", c_ubyte),
                ("Size", c_ulong)]


class TRecvHdr(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("ReplayHdr", TReplayHdr)]


class TGetVersion(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("CRC", c_ubyte)]

    def __init__(self):
        self.RequestHdr.Command = 1


class TGetDeviceInfo(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("HaspID_id", c_ubyte),
                ("HaspID_type", c_ubyte),
                ("HaspID", c_ulong),
                ("CRC", c_ubyte)]

    def __init__(self, HaspId):
        self.RequestHdr.Command = 2
        self.RequestHdr.BlockCount = 1
        self.HaspID_id = 1
        self.HaspID_type = 4
        self.HaspID = HaspId


class TGetNewRawState(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("Index_id", c_ubyte),
                ("Index_type", c_ubyte),
                ("Index", c_ulong),
                ("CRC", c_ubyte)]

    def __init__(self, Index):
        self.RequestHdr.Command = 0x24
        self.RequestHdr.BlockCount = 1
        self.Index_id = 0xF0
        self.Index_type = 4
        self.Index = Index


class TGetEvent(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("Index_id", c_ubyte),
                ("Index_type", c_ubyte),
                ("Index", c_ulong),
                ("CRC", c_ubyte)]

    def __init__(self, Index):
        self.RequestHdr.Command = 0x23
        self.RequestHdr.BlockCount = 1
        self.Index_id = 0xF0
        self.Index_type = 4
        self.Index = Index


class TCommMode(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("Flags_id", c_ubyte),
                ("Flags_type", c_ubyte),
                ("Flags", c_ushort),
                ("SendCount_id", c_ubyte),
                ("SendCount_type", c_ubyte),
                ("SendCount", c_ubyte),
                ("RepCount_id", c_ubyte),
                ("RepCount_type", c_ubyte),
                ("RepCount", c_ubyte),
                ("CRC", c_ubyte)]

    def __init__(self, Flags, BufSz):
        self.RequestHdr.Command = 3
        self.RequestHdr.BlockCount = 1
        self.Flags_id = 1
        self.Flags_type = 2
        self.Flags = Flags
        self.SendCount_id = 2
        self.SendCount_type = 1
        self.SendCount = BufSz
        self.RepCount_id = 2
        self.RepCount_type = 1
        self.RepCount = BufSz


class TAsk(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("CRC", c_ubyte)]

    def __init__(self):
        self.RequestHdr.BlockCount = 0
        self.RequestHdr.Command = 0xF1


class TGetAsyncResult(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("PacketHdr", TPacketHdr),
                ("RequestHdr", TRequestHdr),
                ("CRC", c_ubyte)]

    def __init__(self):
        self.RequestHdr.BlockCount = 0
        self.RequestHdr.Command = 0x25


class TDateTime(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("Date", c_ulong),
                ("Time", c_ulong)]

    def __init__(self, DateTime):
        if(DateTime > 978307200):
            l_time = DateTime - 978307200
        else:
            l_time = 0
        self.Date = int(l_time) / (24 * 60 * 60)
        l_date = self.Date * (24 * 60 * 60)
        self.Time = int((l_time - l_date) * 1000.0)


class TDate(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [("Date", c_ulong)]

    def __init__(self, DateTime):
        if(DateTime > 978307200):
            l_time = DateTime - 978307200
        else:
            l_time = 0
        self.Date = int(l_time) / (24 * 60 * 60)


class UluModule:
    def __init__(self, PipeName, HaspId):
        self.OBjTypes = ["root", "controller", "node", "zone", "part", "reader", "input",
                         "output", "collector", "emitter", "group", "display", "camera"]
        self.OBjTypesToIdx = {}
        idx = 0
        for type in self.OBjTypes:
            self.OBjTypesToIdx[type] = idx
            idx += 1
        self.FlagOptions = 0x7F00
        self.StateTypes = ["CON", "DEF", "TRB", "ACC", "ALRM", "DRS", "AJR", "TPR", "ATTN",
                           "ARM", "BPSD", "ACT", "ACT2", "ACT3", "BLCK", "WAIT", "SM", "LD", "LA"]
        self.LastControlAddr = None
        self.HaspId = HaspId
        self.CmdQueue = collections.deque()
        self.ConnectionEstablished = False
        self.lock = threading.Lock()
        self.CmdEvent = threading.Event()
        self.CmdEndEvent = threading.Event()
        self.CWRAPPER1 = CFUNCTYPE(c_void_p)
        self.CWRAPPER2 = CFUNCTYPE(c_void_p)
        self.PipeNameCPtr = c_char_p(PipeName.encode())
        self.OnConnectPtr = self.CWRAPPER1(self.__OnConnect)
        self.OnDisconnectPtr = self.CWRAPPER2(self.__OnDisconnect)
        self.PipeDll = cdll.LoadLibrary("pipe.dll")
        self.ThreadObject = None
        self.PipeDll.InitCRC()
        self.PipeDll.SetConnectionHandler(self.OnConnectPtr)
        self.PipeDll.SetDisconnectionHandler(self.OnDisconnectPtr)
        logging.getLogger('console').info('OpenPipe %s' % PipeName)
        self.PipeDll.OpenPipe(self.PipeNameCPtr)
        logging.getLogger('console').info('IsConnect %s' % self.PipeDll.IsConnect())
        logging.getLogger('console').info('PipeName: %s' % PipeName)
        logging.getLogger('console').info('HaspId: %s' % HaspId)

    # def __del__(self):
    #	self.PipeDll.ClosePipe();

    def __OnConnect(self):
        # print "__OnConnect"
        if(self.__InitConnection()):
            self.ConnectionEstablished = True
            self.eventProcess({'portsEvent': 'connect'});

    def __OnDisconnect(self):
        # logging.getLogger('console').info("__OnDisconnect");
        if(self.ConnectionEstablished == True):
            self.eventProcess({'portsEvent': 'disconnect'})
            self.ConnectionEstablished = False
        if(self.ThreadObject is not None):
            self.CmdQueue.clear()
            self.__SendThreadCmd({"code": 0});

    def __InitConnection(self):
        # print "__InitConnection"
        self.TransactCnt = 1
        self.LastCmdState = 0
        self.NewRawStateIndex = -1
        self.NewEventIndex = -1
        protocol_v = self.__CmdGetVersion()
        #logging.getLogger('console').info("protocol_v = " + str(protocol_v));
        if(protocol_v < 2):
            return False
        dev_info = self.__CmdGetDeviceInfo()
        if(dev_info is None):
            return False
        # logging.getLogger('console').info(dev_info);
        mode = self.__CmdCommModes(0x7F00, 100)
        if(mode is None):
            return False
        self.FlagOptions = mode["Flags"]
        self.MaxOutPacketBlock = mode["SendCount"]
        self.MaxInPacketBlock = mode["RepCount"]
        if((self.ThreadObject is not None) and (self.ThreadObject.is_alive())):
            self.CmdQueue.clear()
            self.__SendThreadCmd({"code": 0});
            self.ThreadObject.join()
        self.CmdQueue.clear()

        self.ThreadObject = threading.Thread(target=self.__WorkThread)
        self.ThreadObject.start()
        return True
        # self.CmdGetNewRawState();

    def __OnIOError(self):
        return
        # if(self.PipeDll.IsConnect() != 0):
        #	logging.getLogger('console').info("__OnIOError");

    def __OnCommunicationError(self):
        return
        # logging.getLogger('console').info("__OnCommunicationError")

    def __SendCmd(self, Cmd):
        self.LastCmdReturnCode = 0
        Cmd.PacketHdr.Transact = self.TransactCnt
        Cmd.PacketHdr.Size = sizeof(Cmd) - sizeof(Cmd.PacketHdr) - 1
        Cmd.CRC = self.PipeDll.CalcCheckSum(pointer(Cmd), sizeof(Cmd) - 1)
        result = self.PipeDll.WriteDataToPipe(pointer(Cmd), sizeof(Cmd))
        if(result != sizeof(Cmd)):
            self.__OnIOError()
            return None
        recv_hdr = TRecvHdr()
        result = self.PipeDll.ReadDataFromPipe(pointer(recv_hdr.PacketHdr),
                                               sizeof(recv_hdr.PacketHdr))
        if(result != sizeof(recv_hdr.PacketHdr)):
            self.__OnIOError()
            return None
        if(recv_hdr.PacketHdr.Size >= sizeof(recv_hdr.ReplayHdr)):
            sz = sizeof(recv_hdr.ReplayHdr)
        else:
            recv_hdr.ReplayHdr.BlockCount = 0
            sz = recv_hdr.PacketHdr.Size
        result = self.PipeDll.ReadDataFromPipe(pointer(recv_hdr.ReplayHdr), sz)
        if(result != sz):
            self.__OnIOError()
            return None
        recv_size = recv_hdr.PacketHdr.Size - sz + 1
        if((recv_hdr.PacketHdr.Transact != self.TransactCnt) or
                (recv_size > 0x10000) or
                (recv_hdr.ReplayHdr.Command != Cmd.RequestHdr.Command) or
                (recv_hdr.ReplayHdr.BlockCount > recv_size)
           ):
            self.__FlushPipe()
            self.__OnIOError()
            return None
        if((recv_hdr.ReplayHdr.ReturnCode != 0x00) and
                (recv_hdr.ReplayHdr.ReturnCode != 0x0C)):
            self.LastCmdReturnCode = recv_hdr.ReplayHdr.ReturnCode
            self.__FlushPipe()
            # self.__OnIOError();
            return None

        raw_params = create_string_buffer(recv_size)
        result = self.PipeDll.ReadDataFromPipe(pointer(raw_params), recv_size)
        if(result != recv_size):
            self.__OnIOError()
            return None
        self.LastCmdState = recv_hdr.ReplayHdr.State
        self.LastCmdTime = time.clock()
        self.LastCmdReturnCode = recv_hdr.ReplayHdr.ReturnCode
        self.TransactCnt += 1
        if(self.TransactCnt >= 256):
            self.TransactCnt = 1
        return self.__ParsePacket(raw_params, recv_hdr.ReplayHdr.BlockCount)

    def __ParsePacket(self, RawParams, BlockCnt):
        res = []
        idx = 0
        sz = sizeof(RawParams) - 1  # - CRC
        for b_idx in range(BlockCnt):
            block = {}
            while(idx < sz):
                id = ord(RawParams[idx])
                idx += 1
                if(id == 0xFF):
                    break
                type = ord(RawParams[idx])
                idx += 1
                if((type >= 1) and (type <= 0x10)):
                    val = 0
                    inv_idx = idx + type - 1
                    while(inv_idx >= idx):
                        val <<= 8
                        val |= ord(RawParams[inv_idx])
                        inv_idx -= 1
                    idx += type
                    block[id] = val

                elif(type == 0x14):
                    raw_timedate = struct.unpack_from("<LL", RawParams, idx)
                    block[id] = raw_timedate[0] * 24 * 60 * 60 + 978307200 + \
                        (float(raw_timedate[1]) / 1000) + time.timezone
                    idx += 8

                elif(type == 0x20):
                    len = ord(RawParams[idx])
                    idx += 1
                    block[id] = str(RawParams[idx: (idx + len)]);
                    idx += len
            res.append(block)
        return res

    def __ParamToStr(self, param, id):
        if(isinstance(param, int) or isinstance(param, int)):
            for i_sz in range(1, 9):
                if(param < (1 << (i_sz * 8))):
                    result = chr(id) + chr(i_sz)
                    if(param == 0):
                        result += chr(0)
                    else:
                        while(param > 0):
                            result += chr(param & 0xFF)
                            param >>= 8
                    return result
        elif(isinstance(param, str)):
            bytes = param.decode('utf-8').encode('cp1251')
            result = chr(id) + chr(0x20) + chr(len(bytes)) + bytes
            return result
        elif(isinstance(param, str)):
            bytes = param.encode('utf-16le')
            result = chr(id) + chr(0x28) + chr(len(param) &
                                               0xFF) + chr(len(param) >> 8) + bytes
            return result
        elif(isinstance(param, TDate)):
            result = chr(id) + chr(0x12) + \
                string_at(pointer(param), sizeof(param))
            return result
        elif(isinstance(param, TDateTime)):
            result = chr(id) + chr(0x14) + \
                string_at(pointer(param), sizeof(param))
            return result
        elif(isinstance(param, bytearray)):
            result = chr(id) + chr(0x40) + \
                struct.pack('l', len(param)) + str(param)
            return result

    def __FlushPipe(self):
        buf = create_string_buffer(1024)
        while(self.PipeDll.ReadDataFromPipe(pointer(buf), len(buf)) == len(buf)):
            continue
        #raw_timedate = struct.unpack_from("<LL", RawParams, idx);
        # logging.getLogger('console').info("__FlushPipe");
        # self.PipeDll.FlushPipe();

    def __CmdGetVersion(self):
        cmd = TGetVersion()
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return -1
            return result[0][1]
        except BaseException:
            return -1

    def __CmdGetDeviceInfo(self):
        cmd = TGetDeviceInfo(self.HaspId)
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return None
            dev_info = {}
            dev_info["DevName"] = result[0][1]
            dev_info["Version"] = result[0][2]
            dev_info["ID"] = result[0][3]
            dev_info["BuldNum"] = result[0][4]
            dev_info["Vendor"] = result[0][5]
            return dev_info
        except BaseException:
            return None

    def __CmdCommModes(self, Flags, BufSz):
        cmd = TCommMode(Flags, BufSz)
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return None
            mode = {}
            mode["Flags"] = result[0][1]
            mode["SendCount"] = result[0][2]
            mode["RepCount"] = result[0][3]
            return mode
        except BaseException:
            return None

    def __CmdAsk(self):
        cmd = TAsk()
        try:
            self.__SendCmd(cmd)
        except BaseException:
            self.__OnCommunicationError()

    def __SendEvent(self, State, IsEvent):
        if(IsEvent):
            if 0x01 in State:
                event_time = State[0x01]
            else:
                event_time = time.time()
            if 0x02 in State:
                event_code = EVENT_BASE + State[0x02]
            else:
                return None
        else:
            event_time = time.time()
            event_code = 1000
        event = {}
        event["event"] = {
            "notification"	: {
                "code"			: event_code
            },
            "statement"			: {
                "adverbialTime"		: {
                    "param"				: event_time
                }
            }
        };
        addr = []
        for idx in range(0x10, 0x15):
            if idx in State:
                addr.append(State[idx])
            else:
                break
        if(len(addr) > 0):
            directObj = {
                "dev"			: {
                    "equip": "uld",
                    "hwaddr": addr
                }
            };
            if(0x03 in State):
                directObj["dev"]["type"] = self.OBjTypes[State[0x03]]
            if(0x04 in State):
                bin_state = State[0x04]
                state = {}
                for idx in range(len(self.StateTypes)):
                    state[self.StateTypes[idx]] = (bin_state >> idx) & 1
                directObj["dev"]["state"] = state
            event["event"]["statement"]["directObj"] = directObj

        if(IsEvent):
            if(0x20 in State):
                event["event"]["statement"]["subject"] = {
                    "card": State[0x20]
                };
            if(0x40 in State):
                event["event"]["statement"]["subject"] = {
                    "type": State[0x40]
                };
            if(0x21 in State):
                event["event"]["statement"]["indirectObj"] = {
                    "card": State[0x21]
                };
            if(0x41 in State):
                event["event"]["statement"]["indirectObj"] = {
                    "type": State[0x41]
                };

        self.eventProcess(event)

    def __CmdGetNewRawState(self):
        cmd = TGetNewRawState(self.NewRawStateIndex)
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return None
            for state in result:
                s_idx = state[0xF0]
                self.__SendEvent(state, False)
                if(s_idx > self.NewRawStateIndex):
                    self.NewRawStateIndex = s_idx
            if(self.LastCmdReturnCode == 0x0C):
                self.NewRawStateIndex = -1
        except BaseException:
            self.__OnCommunicationError()

    def __CmdGetEvent(self):
        cmd = TGetEvent(self.NewEventIndex)
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return None
            for event in result:
                s_idx = event[0xF0]
                self.__SendEvent(event, True)
                if(s_idx > self.NewEventIndex):
                    self.NewEventIndex = s_idx
            if(self.LastCmdReturnCode == 0x0C):
                self.NewEventIndex = -1
        except BaseException:
            self.__OnCommunicationError()

    def __CmdGetAsyncResult(self):
        cmd = TGetAsyncResult()
        try:
            result = self.__SendCmd(cmd)
            if(result is None):
                return None
            if(self.LastCmdReturnCode == 0x00):
                errorCode = 0
                status = "ok"
            else:
                errorCode = self.LastCmdReturnCode + ERR_CODE_OPERATION_BASE
                status = "error"
            event = {}
            event["event"] = {
                "notification"	: {
                    "code"	: 9999
                },
                "reply"	: {
                    "rep": "CC_CONTROL",
                    "repData": {
                        "status": status,
                        "addr": self.LastControlAddr,
                        "errorCode": errorCode
                    }
                }
            };
            #self.eventProcess(event)
        except BaseException:
            self.__OnCommunicationError()

    def __CmdControl(self, Params):
        try:
            if((self.FlagOptions & (1 << 11)) == 0):
                return {"result": 0, "errorCode": ERR_CODE_NOT_SUPPORTED};
            fields = [("PacketHdr", TPacketHdr),
                      ("RequestHdr", TRequestHdr)]
            #s = str();
            s = self.__ParamToStr(Params["action"], 0xF1)
            if("type" in Params):
                s += self.__ParamToStr(
                    self.OBjTypesToIdx[Params["type"]], 0x03)
            if("hwaddr" in Params):
                addr = Params["hwaddr"]
                self.LastControlAddr = addr
                idx = 0x10
                for ai in addr:
                    if(idx >= 0x15):
                        break
                    s += self.__ParamToStr(ai, idx)
                    idx += 1
            else:
                self.LastControlAddr = None
            if("card" in Params):
                s += self.__ParamToStr(Params["card"], 0x20)
            if("subCard" in Params):
                s += self.__ParamToStr(Params["subCard"], 0x21)
            if("params" in Params):
                params = Params["params"]
                idx = 0x30
                for pi in params:
                    if(idx >= 0x34):
                        break
                    s += self.__ParamToStr(pi, idx)
                    idx += 1
            for idx in range(len(s)):
                fields.append(("field" + str(idx), c_ubyte))
            fields.append(("CRC", c_ubyte))

            class TControl(LittleEndianStructure):
                _pack_ = 1
                _fields_ = fields

                def __init__(self):
                    self.RequestHdr.Command = 0x09
                    self.RequestHdr.BlockCount = 1
            cmd = TControl()
            for idx in range(len(s)):
                cmd.__setattr__("field" + str(idx), ord(s[idx]))
            result = self.__SendCmd(cmd)
        except Exception as e:
            # logging.getLogger('console').info('xxx');
            # traceback.print_exc()
            self.__OnCommunicationError()
            return {"result": 0, "errorCode": ERR_CODE_COMMUNICATION};
        if(result is not None):
            return {"result": 1};
        if(self.LastCmdReturnCode != 0):
            return {"result": 0, "errorCode": self.LastCmdReturnCode +
                    ERR_CODE_OPERATION_BASE};
        else:
            return {"result": 0, "errorCode": ERR_CODE_IO};

    def __CmdGetState(self, Params):
        try:
            if((self.FlagOptions & (1 << 8)) == 0):
                return {"result": 0, "errorCode": ERR_CODE_NOT_SUPPORTED};
            fields = [("PacketHdr", TPacketHdr),
                      ("RequestHdr", TRequestHdr)]
            s = self.__ParamToStr(self.OBjTypesToIdx[Params["type"]], 0x03)
            addr = Params["hwaddr"]
            idx = 0x10
            for ai in addr:
                if(idx >= 0x15):
                    break
                s += self.__ParamToStr(ai, idx)
                idx += 1
            for idx in range(len(s)):
                fields.append(("field" + str(idx), c_ubyte))
            fields.append(("CRC", c_ubyte))

            class TGetState(LittleEndianStructure):
                _pack_ = 1
                _fields_ = fields

                def __init__(self):
                    self.RequestHdr.Command = 0x08
                    self.RequestHdr.BlockCount = 1
            cmd = TGetState()
            for idx in range(len(s)):
                cmd.__setattr__("field" + str(idx), ord(s[idx]))
            result = self.__SendCmd(cmd)
            if(result is not None):
                result = result[0]
            addr = []
            for idx in range(0x10, 0x15):
                if idx in result:
                    addr.append(result[idx])
                else:
                    break
            bin_state = result[0x04]
            state = {}
            for idx in range(len(self.StateTypes)):
                state[self.StateTypes[idx]] = (bin_state >> idx) & 1
            type = self.OBjTypes[result[0x03]]
        except BaseException:
            self.__OnCommunicationError()
            return {"result": 0, "errorCode": ERR_CODE_COMMUNICATION};
        if(result is not None):
            return {"result": 1, "type": type, "hwaddr": addr, "state": state};
        if(self.LastCmdReturnCode != 0):
            return {"result": 0, "errorCode": self.LastCmdReturnCode +
                    ERR_CODE_OPERATION_BASE};
        else:
            return {"result": 0, "errorCode": ERR_CODE_IO};

    def __CmdSetUser(self, Params):
        try:
            if((self.FlagOptions & (1 << 12)) == 0):
                return {"result": 0, "errorCode": ERR_CODE_NOT_SUPPORTED};
            fields = [("PacketHdr", TPacketHdr),
                      ("RequestHdr", TRequestHdr)]
            s = self.__ParamToStr(Params["UserID"], 0x40)
            s += self.__ParamToStr(Params["UserRight"], 0x41)
            if("UserPIN" in Params):
                s += self.__ParamToStr(Params["UserPIN"], 0x42)
            if("Flags" in Params):
                s += self.__ParamToStr(Params["Flags"], 0x43)
            if("StartTime" in Params):
                s += self.__ParamToStr(TDateTime(Params["StartTime"]), 0x44)
            if("EndTime" in Params):
                s += self.__ParamToStr(TDateTime(Params["EndTime"]), 0x45)
            if("Name" in Params):
                s += self.__ParamToStr(Params["Name"], 0x51)
            if("Photo" in Params):
                # if( (self.FlagOptions & (1 << 14)) == 0):
                    # return {"result" : 0, "errorCode" :
                    # ERR_CODE_NOT_SUPPORTED};
                s += self.__ParamToStr(Params["Photo"], 0x70)
            if("SubjectType" in Params):
                s += self.__ParamToStr(Params["SubjectType"], 0x50)
            if("BirthDay" in Params):
                s += self.__ParamToStr(TDate(Params["BirthDay"]), 0x52)
            if("Handle" in Params):
                s += self.__ParamToStr(Params["Handle"], 0x53)
            if("Comments" in Params):
                s += self.__ParamToStr(Params["Comments"], 0x54)
            if("Firm" in Params):
                s += self.__ParamToStr(Params["Firm"], 0x55)
            if("Department" in Params):
                s += self.__ParamToStr(Params["Department"], 0x56)
            if("Number" in Params):
                s += self.__ParamToStr(Params["Number"], 0x57)
            if("Post" in Params):
                s += self.__ParamToStr(Params["Post"], 0x58)
            if("BirthPlace" in Params):
                s += self.__ParamToStr(Params["BirthPlace"], 0x59)
            if("DocType" in Params):
                s += self.__ParamToStr(Params["DocType"], 0x5A)
            if("DocSeries" in Params):
                s += self.__ParamToStr(Params["DocSeries"], 0x5B)
            if("DocNumber" in Params):
                s += self.__ParamToStr(Params["DocNumber"], 0x5C)
            if("Issuer" in Params):
                s += self.__ParamToStr(Params["Issuer"], 0x5D)
            if("IssueDate" in Params):
                issue_date = date.fromtimestamp(Params["IssueDate"])
                s += self.__ParamToStr(issue_date.strftime('''%d/%m/%Y'''), 0x5E)
            if("Model" in Params):
                s += self.__ParamToStr(Params["Model"], 0x5F)
            if("Colour" in Params):
                s += self.__ParamToStr(Params["Colour"], 0x60)
            if("TrailerNumber" in Params):
                s += self.__ParamToStr(Params["TrailerNumber"], 0x61)
            if("PackageSort" in Params):
                s += self.__ParamToStr(Params["PackageSort"], 0x62)
            if("Amount" in Params):
                s += self.__ParamToStr(Params["Amount"], 0x63)
            fields.append(("fields", c_ubyte * len(s)))
            fields.append(("CRC", c_ubyte))

            class TSetUser(LittleEndianStructure):
                _pack_ = 1
                _fields_ = fields

                def __init__(self):
                    self.RequestHdr.Command = 0x31
                    self.RequestHdr.BlockCount = 1
            cmd = TSetUser()
            cmd.__setattr__("fields", (c_ubyte * len(s))
                            (*[c_ubyte(ord(c)) for c in s[:len(s)]]));
            result = self.__SendCmd(cmd)
        except Exception as e:
            # logging.getLogger('console').info("xxx");
            # traceback.print_exc();
            self.__OnCommunicationError()
            return {"result": 0, "errorCode": ERR_CODE_COMMUNICATION};
        if(result is not None):
            return {"result": 1};
        if(self.LastCmdReturnCode != 0):
            return {"result": 0, "errorCode": self.LastCmdReturnCode +
                    ERR_CODE_OPERATION_BASE};
        else:
            return {"result": 0, "errorCode": ERR_CODE_IO};

    def __CmdGetUser(self, Params):
        try:
            if((self.FlagOptions & (1 << 12)) == 0):
                return {"result": 0, "errorCode": ERR_CODE_NOT_SUPPORTED};
            fields = [("PacketHdr", TPacketHdr),
                      ("RequestHdr", TRequestHdr)]
            s = self.__ParamToStr(Params["UserID"], 0x20)
            fields.append(("fields", c_ubyte * len(s)))
            fields.append(("CRC", c_ubyte))

            class TGetUser(LittleEndianStructure):
                _pack_ = 1
                _fields_ = fields

                def __init__(self):
                    self.RequestHdr.Command = 0x32
                    self.RequestHdr.BlockCount = 1
            cmd = TGetUser()
            cmd.__setattr__("fields", (c_ubyte * len(s))
                            (*[c_ubyte(ord(c)) for c in s[:len(s)]]));
            result = self.__SendCmd(cmd)
            if(result is not None):
                result = result[0]
                result_xtbl = {
                    "result": 1,
                    "UserID": result[0x40],
                    "UserRight": result[0x41]};
                if("UserPIN" in Params):
                    result_xtbl["UserPIN"] = result[0x42]
                if("Flags" in Params):
                    result_xtbl["Flags"] = result[0x43]
                if("StartTime" in Params):
                    result_xtbl["StartTime"] = result[0x44]
                if("EndTime" in Params):
                    result_xtbl["EndTime"] = result[0x45]
                return result_xtbl

        except Exception as e:
            self.__OnCommunicationError()
            return {"result": 0, "errorCode": ERR_CODE_COMMUNICATION};
        if(self.LastCmdReturnCode != 0):
            return {"result": 0, "errorCode": self.LastCmdReturnCode +
                    ERR_CODE_OPERATION_BASE};
        else:
            return {"result": 0, "errorCode": ERR_CODE_IO};

    def __WorkThread(self):
        while(True):
            try:
                cmd = self.CmdQueue.pop()
                self.CmdEvent.clear()
                id = cmd["code"]
                if(id == 0):
                    break
                elif(id == 1):
                    self.LastCmdResult = self.__CmdControl(cmd)
                    self.CmdEndEvent.set()
                elif(id == 2):
                    self.LastCmdResult = self.__CmdGetState(cmd)
                    self.CmdEndEvent.set()
                elif(id == 3):
                    self.LastCmdResult = self.__CmdSetUser(cmd)
                    self.CmdEndEvent.set()
                elif(id == 4):
                    self.LastCmdResult = self.__CmdGetUser(cmd)
                    self.CmdEndEvent.set()
            except BaseException:
                evf = True
                # print self.LastCmdState;
                if((self.LastCmdState & 0x20) != 0):
                    evf = False
                    self.__CmdGetAsyncResult()
                if((self.LastCmdState & 0x10) != 0):
                    evf = False
                    self.__CmdGetNewRawState()
                if((self.LastCmdState & 0x08) != 0):
                    evf = False
                    self.__CmdGetEvent()
                if(evf):
                    cur_time = time.clock()
                    if(cur_time > (self.LastCmdTime + POLL_TIMEOUT)):
                        self.__CmdAsk()
                    self.CmdEvent.wait(POLL_TIMEOUT)
        #logging.getLogger('console').info("Thread stop");

    def __SendThreadCmd(self, cmd):
        self.CmdEvent.set()
        self.CmdQueue.append(cmd)

    def close(self):
        self.PipeDll.ClosePipe()
        if(self.ThreadObject is not None):
            self.ThreadObject.join()

        logging.getLogger('console').info('UUS CLosed')

    def eventProcess(self, event):
        logging.getLogger('console').info("***eventProcess***")
        logging.getLogger('console').info(event)

    def command(self, cmd):
        code = cmd["code"]
        if((code < 1) or (code > 4)):
            return {"result": 0, "errorCode": ERR_CODE_UNKNOWN_CMD};
        self.lock.acquire()
        self.CmdEndEvent.clear()
        self.__SendThreadCmd(cmd)
        if(self.CmdEndEvent.wait(3)):
            self.lock.release()
            return self.LastCmdResult
        else:
            self.lock.release()
            return {"result": 0, "errorCode": ERR_CODE_COMMUNICATION};
