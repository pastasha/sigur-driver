# -*- coding: utf-8 -*-

import event_monitor.plugin_support as plgn
import threading
import socket
import json
import time
import collections
import interface_n_tools.my_rpc.rpc_client as rpc_cln
import logging
import logging.config
from driverslog_settings import driverLogConfig

class PortsClientError(Exception):
    def __init__(self, msg=''):
        self.__msg = msg

    def __str__(self):
        return 'PortsClientError'

class PortsClient(plgn.PluginObject, rpc_cln.RpcClient):
    def __init__(self, equipName, typeName, id, connStr='',
                 methodTimeout=rpc_cln.MethodTimeout):
        plgn.PluginObject.__init__(self, equipName, typeName, id)
        connStrL = connStr.split(',')
        rpc_cln.RpcClient.__init__(
            self, connStrL[0], int(connStrL[1]), methodTimeout=methodTimeout
        )

        log_name = 'PC_%s_%s' % (equipName,connStr)

        logging.config.dictConfig(driverLogConfig(log_name, 'INFO'))

        self.logger = logging.getLogger(log_name)
       
        self.start()
        self.logger.info('start')

    def onTryConnectFail(self):
        self.logger.info('try connect')

    '''def onEvent(self, evt):
		try:
			evt = json.loads(evt)
		except Exception as e:
			print 'onEvent error: json.loads', str(e), evt
			self.sendOk()
		else:
			self.eventProcess({'event': evt})'''

    def onEvent(self, evt):
        self.eventProcess({'event': evt})

    def onConnect(self):
        self.logger.info('connected')
        thConnect = threading.Thread (target=self.__onConnectUnBlock)
        thConnect.start()

    def __onConnectUnBlock(self):
        self.connect()
        self.eventProcess(
            {'portsEvent': {'type': 'connect', 'time': time.time()}})

    def onDisconnect(self):
        self.logger.info('disconnected from ports')
        self.eventProcess(
            {'portsEvent': {'type': 'disconnect', 'time': time.time()}})
        # self.__pc.push(self.__onDisonnectUnBlock)

    def __onDisonnectUnBlock(self):
        pass

    def sendOk(self):
        #self.logger.info('SendOK')
        self.asynchMethod('sendOk')

    def release(self):
        self.logger.info('stopping...')
        self.stop()
        if self.isAlive():
            self.logger.info('WARNING: PortsClient %s thread is steal alive' % (
                '%s,%s,%s,%s' % (
                    self.__device,
                    self.__ip,
                    self.__portRPC,
                    self.__portSocket)
            ))
        self.logger.info('stopped')


plgn.PluginSupport.install('portsClient2', PortsClient)
