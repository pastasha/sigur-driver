# -*- coding: utf-8 -*-

import threading
import time
import logging
import event_monitor.plugin_support as plgn


class TestClient(plgn.PluginObject):

    def __init__(self, equipName, typeName, id, connStr=10):
        plgn.PluginObject.__init__(self, equipName, typeName, id)

        self._tickPerSecond = int(connStr)
        self._runFlag = True
        self._proc = threading.Thread(target=self._timeoutFunc)
        self._proc.start()

        logging.getLogger('console').info('TestClient run. connStr = %s'%connStr)

    def _timeoutFunc(self):
        last = time.time()
        while self._runFlag:
            t = time.time()
            if (t - last) > 1:
                last = t
                for i in range(self._tickPerSecond):
                    self.eventProcess({'event': 'tick'})

            time.sleep(0)

    def release(self):
        logging.getLogger('console').info('stopping...')

        # Stop actions
        self._runFlag = False
        self._proc.join(2)

        logging.getLogger('console').info('stopped')

    def eventProcess(self, event):
        plgn.PluginObject.eventProcess(self, event)

    def sendCommand(self, cmd):
        return None


plgn.PluginSupport.install('testClient', TestClient)
