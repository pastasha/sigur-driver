# -*- coding: utf-8 -*-

import event_monitor.plugin_support as plgn
import logging
from . import uus


class ULDClientError(Exception):
    def __init__(self, msg=''):
        self.__msg = msg

    def __str__(self):
        return 'ULDClientError'


class ULDClient(plgn.PluginObject, uus.UluModule):
    def __init__(self, equipName, typeName, id, connStr=''):
        plgn.PluginObject.__init__(self, equipName, typeName, id)
        connParams = connStr.split(',')
        uus.UluModule.__init__(self, connParams[0], int(connParams[1]))

        logging.getLogger('console').info('ULDClient run. connStr = %s'%connStr)

    def release(self):
        logging.getLogger('console').info('stopping...')

        # Stop actions
        uus.UluModule.close(self)

        logging.getLogger('console').info('stopped')

    def eventProcess(self, event):
        plgn.PluginObject.eventProcess(self, event)

    def sendCommand(self, cmd):
        return uus.UluModule.command(self, cmd)


plgn.PluginSupport.install('uldClient', ULDClient)
