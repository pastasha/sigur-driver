# -*- coding: utf-8 -*-
# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$13.01.2012 15:24:34$"


ConnectionString = "host='' dbname='trunk' user='postgres' password='1233' port='5433'"

NotifyPullAddr = 'localhost:5111'

RequestServerPort = '5561'

AllEvents = True


title = "ESM Менеджер оборудования"

language = "ru"

useDllQueue = False  # полный путь к папке с фотографиями в ESM. Для экспорта в БД Орион
photoPath = "D:\\serverTest\\esm_web_server\\esm_web_service_v1.0\\person_photo"
# флаг проверки уникальности табельного номера (True|False)
checkEmployeeNumber = False

# путь до папки event_photo
EVENT_PHOTO_PATH = 'D:\\SERVER\\Hikvision\\esm_web_server\\esm_web_service_v1.0\\event_photo\\'

Redis_host = '127.0.0.1'
Redis_port = 6379
Redis_password = ''
Redis_db = 1
Redis_messages_per_logger = 10000
