# -*- coding: utf-8 -*-

import threading
import time
import logging
from servicebase import ServiceBase


class SynchronizationTime(ServiceBase):
    def __init__(self, EquipmentInterface):
        super(SynchronizationTime, self).__init__()
        self.__thread = threading.Thread(target=self.__process)
        self.__thread.setName("SynchronizationTime")
        self.__EquipmentInterface = EquipmentInterface
        self.__synchEquip = []
        for eqName in EquipmentInterface.getInstanceNameList():
            rootDev = EquipmentInterface.getInstance(eqName).debug_getEquipModel().rootDev
            if rootDev:
                try:
                    for syncObj in EquipmentInterface.getInstance(
                            eqName).debug_getEquipModel().devModel.elementClasses[rootDev].elements:
                        if syncObj.getAttribute('synchronization') != 0:
                            equip = {
                                'equip'	: {
                                    'name'	: eqName,
                                    'id'	: syncObj.getUniID(),
                                    'type'	: rootDev
                                },
                                'synchtime'	: syncObj.getAttribute('synchronization'),
                                'needsynch'	: syncObj.getAttribute('synchronization')
                            }
                            self.__synchEquip.append(equip)
                except Exception as e:
                    logging.getLogger('console').info('%s-%s synchronization not implemented' % (eqName, rootDev))

    def __process(self):
        while self.isRunning():
            try:
                for equip in self.__synchEquip:
                    equip['needsynch'] = int(equip['needsynch']) - 1
                    if equip['needsynch'] == 0:
                        equip['needsynch'] = equip['synchtime']
                        self.__EquipmentInterface.getInstance(equip['equip']['name'])\
                            .execAction(equip['equip']['type'], equip['equip']['id'], '', 'synchTime')
            except Exception as e:
                logging.getLogger('console').info('synch time error '+repr(e))
            time.sleep(60)

    def onStart(self):
        self._setRunning(True)
        self.__thread.start()

    def onStop(self):
        self._setRunning(False)
        self.__thread.join()