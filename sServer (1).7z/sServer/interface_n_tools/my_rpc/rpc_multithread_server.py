# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$21.10.2011 12:46:15$"


import threading
import socket
from . import rpc_server


class RpcMTServer(threading.Thread):
    def __init__(self, host, port, ServerClass):
        threading.Thread.__init__(self)

        self.__ServerClass = ServerClass

        self.__host = host
        self.__port = port

        self.__lock = threading.RLock()
        self.__flag = threading.Event()
        self.__flag.set()

        self.__sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.__sock.bind((host, port))
        self.__sock.listen(1)
        self.__sock.settimeout(rpc_server.RecvTimeout)

        self.__servers = {}
        self.__count = 0

    def __str__(self):
        return 'MultiThread RpcServer %s:%s' % (self.__host, self.__port)

    def run(self):
        while self.__flag.isSet():
            try:
                workSock, addr = self.__sock.accept()
                newServ = self.__ServerClass(workSock)
                with self.__lock:
                    self.__servers[addr] = newServ
                    self.__count = len(self.__servers)
                if hasattr(self, 'onAccept'):
                    self.onAccept(newServ, addr)
                newServ.start()
            except socket.timeout:
                pass

            deadServers = []
            for addr in self.__servers:
                if not self.__servers[addr].isAlive():
                    deadServers.append(addr)

            for addr in deadServers:
                with self.__lock:
                    del self.__servers[addr]
                    self.__count = len(self.__servers)

    def send(self, data):
        servers = []
        with self.__lock:
            for addr in self.__servers:
                if self.__servers[addr].isAlive():
                    servers.append(self.__servers[addr])

        for serv in servers:
            serv.send(data)

    def stop(self):
        self.__flag.clear()
        for addr in self.__servers:
            self.__servers[addr].stop()
        self.join(rpc_server.RecvTimeout * 4 * self.__count)
