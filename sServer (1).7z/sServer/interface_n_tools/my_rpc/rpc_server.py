# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$29.09.2011 9:41:54$"

import threading
import socket
import string
import json
import os
import logging

RecvTimeout = .2

logger = logging.getLogger('sServer')


class RpcServerClientNotExists(Exception):
    def __init__(self, serv):
        self.__serv = serv

    def __str__(self):
        return '%s error: client no connected' % self.__serv


class RpcServer(threading.Thread):
    def __init__(self, host, port=None):
        if port:
            self.run = self.__run1
        else:
            self.run = self.__run2

        threading.Thread.__init__(self)

        self.__lock = threading.RLock()
        self.__flag = threading.Event()
        self.__flag.set()

        self.debug = 'no info'

        self.__host = host
        self.__port = port
        if port:

            self.__sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.__sock.bind((host, port))
            self.__sock.listen(1)
            self.__sock.settimeout(RecvTimeout)
            self.__workSock = None
        else:
            self.__workSock = host
            self.__workSock.settimeout(RecvTimeout)

    def __str__(self):
        return ('RpcServer %s:%s' % (self.__host, self.__port)) \
            if self.__port else 'RpcServer'

    def __recvProcess(self, buff):

        rxData = ''
        try:
            rxData = self.__workSock.recv(1024)

        except socket.timeout:
            return buff
        except BaseException:
            pass

        if not rxData:
            with self.__lock:
                self.__workSock.close()
                self.__workSock = None
            self.onDisconnect()
            return None
        buff = '%s%s' % (buff, rxData)
        while True:
            index = string.find(buff, '\r\n')
            if index == -1:
                break
            self.__requestProcess(buff[:index])
            buff = buff[index + 2:]

        return buff

    def __run2(self):
        buff = ''
        while self.__flag.isSet():
            buff = self.__recvProcess(buff)
            if not buff:
                break

    def __run1(self):
        buff = ''
        while self.__flag.isSet():
            try:
                self.debug = 11
                if not self.__workSock:
                    self.debug = 22
                    try:
                        buff = ''
                        self.debug = 33
                        logging.getLogger('console').info('accepting')
                        workSock, addr = self.__sock.accept()
                        self.debug = 44
                        workSock.settimeout(RecvTimeout)
                        self.debug = 55
                        with self.__lock:
                            self.debug = 66
                            self.__workSock = workSock
                        self.debug = 77
                        self.onAccept(addr)
                        self.debug = 88
                    except socket.timeout:
                        self.debug = 99
                        pass
                    except Exception as e:
                        self.debug = 'AA'
                        logger.exception('__run1 fail 1: %s' % repr(e))
                else:
                    self.debug = 'BB'
                    buff = self.__recvProcess(buff)
                self.debug = 'CC'
            except Exception as e:
                self.debug = 'DD'
                self.debugMsg = '__run1'
                logging.getLogger('console').exception('__run1'+str(e))
        logger.error('debug=%s' % self.debug)
        self.debug = 'EE'
        logger.exception('os exit() EE')
        os._exit(0)

    def __requestProcess(self, msg):
        try:
            msg = json.loads(msg)
            req = str(msg['req'])
        except Exception as e:
            return

        if req == 'ping':
            self.__pingProcess()
        elif req == 'method':
            self.__methodProcess(msg)
        else:
            self.__send({'rep': 'undefReq'})

    def __methodProcess(self, msg):
        try:
            reqId = None
            methodName = str(msg['reqData']['name'])
            methodParams = tuple(msg['reqData']['params'])
            reqId = int(msg['reqId'])
        except BaseException:
            self.__send({
                'rep'		: 'method',
                'repId'		: reqId,
                'repData'	: {
                        'error'		: 'badMethodRequest'
                        }
            })
            return
        if methodName in dir(RpcServer) or \
                not hasattr(self, methodName):
            self.__send({
                'rep'		: 'method',
                'repId'		: reqId,
                'repData'	: {
                        'name'		: methodName,
                        'status'	: 'error',
                        'error'		: 'undefMethod'
                        }
            })
            return

        try:
            result = getattr(self, methodName)(*methodParams)
        except Exception as e:
            self.__send({
                'rep'		: 'method',
                'repId'		: reqId,
                'repData'	: {
                        'name'		: methodName,
                        'status'	: 'exception',
                        'error'		: str(e)
                        }
            })
        else:
            self.__send({
                'rep'		: 'method',
                'repId'		: reqId,
                'repData'	: {
                        'name'		: methodName,
                        'status'	: 'ok',
                        'result'	: result
                        }
            })

    def __pingProcess(self):
        try:
            self.__send({'rep': 'pong'})
        except BaseException:
            pass

    def stop(self):
        self.__flag.clear()
        self.join(RecvTimeout * 4)

    def __send(self, data):
        return self.__sendData('%s\r\n' % json.dumps(data))

    def __sendData(self, data):
        with self.__lock:
            if self.__workSock:
                # sys.__stdout__.write(str(type(data)))
                try:
                    return self.__workSock.send(data)
                except Exception as e:
                    logging.getLogger('console').info('__sendData error'+str(e))
                    self.__workSock.close()
                    self.__workSock = None
            raise RpcServerClientNotExists(self)

    def send(self, data):
        return self.__send({
            'rep'		: 'event',
            'repData'	: {
                'data'		: data
            }
        })
