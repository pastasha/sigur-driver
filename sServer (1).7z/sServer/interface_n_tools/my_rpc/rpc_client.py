# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$29.09.2011 9:52:22$"

import socket
import threading
import time
import json
import string
import logging

Timeout = 10
MethodTimeout = 6


class RpcClientNotConnected(Exception):
    def __init__(self, cln):
        self.__cln = cln

    def __str__(self):
        return '%s error: not connected' % str(self.__cln)


class RpcClientBadReply(Exception):
    def __init__(self, cln):
        self.__cln = cln

    def __str__(self):
        return '%s error: bad reply' % str(self.__cln)


class RpcClientMethodTimeout(Exception):
    def __init__(self, cln, method):
        self.__cln = cln
        self.__method = method

    def __str__(self):
        return '%s error: timeout in "%s" method' % (str(self.__cln), self.__method)


class RpcClientError(Exception):
    def __init__(self, cln, error):
        self.__cln = cln
        self.__error = error

    def __str__(self):
        return '%s error: %s' % (str(self.__cln), self.__error)


class RpcClientMethodException(Exception):
    def __init__(self, cln, exceptionInfo):
        self.__cln = cln
        self.__exceptionInfo = exceptionInfo

    def __str__(self):
        return '%s error: method exception: %s' % (
            str(self.__cln), self.__exceptionInfo)


class RpcClient(threading.Thread):
    DISCONNECT = 0
    CONNECT1 = 1
    CONNECT2 = 2

    def __str__(self):
        return 'RpcClient %s:%s' % (self.__serverAddr, self.__serverPort)

    def __init__(self, serverAddr, serverPort, methodTimeout=MethodTimeout):
        threading.Thread.__init__(self)
        self.setName("RpcClient %s : %s"%(serverAddr, serverPort))
        self.__methodTimeout = methodTimeout

        self.__lock = threading.RLock()
        self.__runFlag = threading.Event()
        self.__runFlag.set()

        self.__serverAddr = serverAddr
        self.__serverPort = serverPort

        self.__sock = None

        self.__state = self.DISCONNECT
        self.__buff = ''

        self.__reqId = 0

        self.__methodWait = threading.Event()
        self.__methodWait.set()
        self.__methodResult = None

    def asynchMethod(self, methodName, *args):
        rxData = '%s\r\n' % json.dumps({
            'req'		: 'amethod',
            'reqData'	: {
                'name'		: methodName,
                'params'	: list(args)
            }
        })
        try:
            self.__sock.send(rxData.encode())
        except socket.error as e:
            self.__state = self.DISCONNECT
        except socket.timeout:
            self.__state = self.DISCONNECT
        except Exception as e:
            logging.getLogger('console').info('rpc_client %s,%s: asynchMethod %s error: - %s' % (self.__serverAddr,self.__serverPort, methodName, repr(e)))

    def __sendPing(self):
        try:
            self.__sock.send(('%s\r\n' % json.dumps({
                'req'		: 'ping'
            })).encode())
        except socket.error as e:
            self.__state = self.DISCONNECT
        except socket.timeout:
            self.__state = self.DISCONNECT
        except Exception as e:
            logging.getLogger('console').info('rpc_client %s,%s: sendPing error %s'% (self.__serverAddr,self.__serverPort,repr(e)))

    def run(self):
        lastTime = time.time()
        while self.__runFlag.isSet():
            if self.__state == self.DISCONNECT:
                self.__sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    time.sleep(1)
                    self.__sock.connect((self.__serverAddr, self.__serverPort))
                except BaseException:
                    if hasattr(self, 'onTryConnectFail'):
                        self.onTryConnectFail()
                else:
                    self.__sock.settimeout(1)
                    with self.__lock:
                        self.__state = self.CONNECT1

                    self.onConnect()

            elif self.__state == self.CONNECT1:
                currTime = time.time()
                res = self.__recv()
                if res == 'n':
                    lastTime = currTime
                elif res == 'd':
                    self.__state = self.DISCONNECT
                    self.onDisconnect()

                if currTime - lastTime > self.__methodTimeout:
                    self.__sendPing()
                    self.__state = self.CONNECT2
                    lastTime = currTime

            elif self.__state == self.CONNECT2:
                currTime = time.time()
                res = self.__recv()
                if res == 'n':
                    lastTime = currTime
                    self.__state = self.CONNECT1
                elif res == 'd':
                    self.__state = self.DISCONNECT
                    self.onDisconnect()

                if currTime - lastTime > self.__methodTimeout:
                    self.__state = self.DISCONNECT
                    self.onDisconnect()

    def __recv(self):
        data = b''
        socketIsDown = False
        try:
            data = self.__sock.recv(4096)
        except socket.timeout:
            return 't'
        except socket.error as e:
            err = e.args[0]
            logging.getLogger('console').info('rpc_client %s,%s: no data available - %s' % (self.__serverAddr,self.__serverPort,repr(e)))
            return 'd'
        except Exception as e:
            logging.getLogger('console').info("rpc_client %s,%s: Exception - %s" % repr(e))
            import traceback
            traceback.print_exc()
            return 'd'

        self.__buff = '%s%s' % (self.__buff, data.decode())
        while True:
            index = self.__buff.find('\r\n')
            if index == -1:
                break
            self.__replyProcess(self.__buff[:index])
            self.__buff = self.__buff[index + 2:]

        return 'n'

    def __replyProcess(self, msg):
        try:
            msg = json.loads(msg)
            rep = str(msg['rep'])
        except Exception as e:
            logging.getLogger('console').info('rpc_client %s,%s replyProcess Error - %s'% (self.__serverAddr,self.__serverPort,repr(e)))
            return

        if rep == 'ping':
            pass  # self.__pingProcess()
        elif rep == 'method':
            self.__methodProcess(msg)
        elif rep == 'event':
            self.__eventProcess(msg)

    def __methodProcess(self, msg):
        with self.__lock:
            if self.__methodResult:
                return
            if self.__methodWait.isSet():
                return
            self.__methodResult = msg
            self.__methodWait.set()

    def __eventProcess(self, msg):
        try:
            data = msg['repData']['data']
        except BaseException:
            pass
        else:
            self.onEvent(data)

    def __getattr__(self, methodName):

        def remoteMethod(*arg):
            with self.__lock:
                if self.__state == self.DISCONNECT:
                    raise RpcClientNotConnected(self)

                self.__reqId += 1
                self.__methodWait.clear()
                self.__sock.send(('%s\r\n' % json.dumps({
                    'req'		: 'method',
                    'reqId'		: self.__reqId,
                    'reqData'	: {
                        'name'		: methodName,
                        'params'	: list(arg)
                    }
                })).encode())

            if self.__methodWait.wait(self.__methodTimeout):
                with self.__lock:
                    try:
                        repId = int(self.__methodResult['repId'])
                        status = str(self.__methodResult['repData']['status'])
                    except BaseException:
                        self.__methodResult = None
                        raise RpcClientBadReply(self)
                    else:
                        if repId != self.__reqId:
                            self.__methodResult = None
                            raise RpcClientBadReply(self)
                        elif status in ('error', 'exception'):
                            try:
                                error = str(
                                    self.__methodResult['repData']['error']
                                )
                            except BaseException:
                                self.__methodResult = None
                                raise RpcClientBadReply(self)
                            else:
                                self.__methodResult = None
                                if status == 'error':
                                    raise RpcClientError(self, error)
                                raise RpcClientMethodException(self, error)
                        elif status == 'ok':
                            result = None
                            if 'result' in self.__methodResult['repData']:
                                result = self.__methodResult['repData']['result']

                            self.__methodResult = None
                            return result
            else:
                with self.__lock:
                    self.__methodResult = None
                    raise RpcClientMethodTimeout(self, methodName)

        return remoteMethod

    def stop(self):
        self.__runFlag.clear()
        self.join()
        self.__state = self.DISCONNECT
        self.__sock.close()
