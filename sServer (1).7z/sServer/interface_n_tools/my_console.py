# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "ananev"
__date__ = "$01.04.2011 10:32:38$"

import threading
import sys
import queue as queue
import time
import logging

class MyConsole(threading.Thread):
    def __init__(self, cmdClass):
        threading.Thread.__init__(self)
        self.cmdClass = cmdClass
        self.__cmdQueue = queue.Queue()
        self.__exitFlag = False

    def run(self):
        self.proc()

    def __executeCmd(self, cmd):
        if cmd == 'help':
            for key in dir(self.cmdClass):
                if key[0:1] != '_':
                    logging.getLogger('console').info(key)
            return

        cmd, params = cmd.split(' ')[0], cmd.split(' ')[1:]

        if not hasattr(self.cmdClass, str(cmd)):
            logging.getLogger('console').info('undefined command')
        else:
            try:
                getattr(self.cmdClass, str(cmd))(params)
            except Exception as e:
                logging.getLogger('console').info('console cmd error: %s' % str(e))

    def executeCmd(self, cmd):
        try:
            self.__cmdQueue.put(cmd)
        except Exception as e:
            logging.getLogger('console').info(str(e))

    def proc(self):
        while True:
            cmd = input('> ')
            if cmd == 'shutdown':
                self.__cmdQueue.put(cmd)
                break
            """if cmd == 'exit':
				break"""
            self.__cmdQueue.put(cmd)
            time.sleep(1)
            # self.executeCmd(cmd)

        logging.getLogger('console').info('Bye')

    def mainLoop(self):
        
        self.start()
        while True:
            try:
                #time.sleep(1)
                cmd = self.__cmdQueue.get()
                logging.getLogger('console').info(cmd)
            except queue.Empty:
                pass
            else:
                if cmd == 'shutdown':
                    break
                self.__executeCmd(cmd)

        self.__exitFlag = True
        sys.__stdin__.close()
        self.join(1)
