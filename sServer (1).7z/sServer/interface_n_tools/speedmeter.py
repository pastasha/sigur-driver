# -*- coding: utf-8 -*-

import time
import logging

class SpeedMeter(object):
    _inst = {}

    def __init__(self, name='SpeedMeter', period=10):
        if name in self._inst:
            raise 'SpeedMeter %s already exists'
        self._inst[name] = self
        self._name = name
        self._period = period
        self._cnt = 0
        self._last = time.time()
        self._avgSum = 0.0
        self._avgCnt = 0

    @classmethod
    def get(self, name):
        return self._inst[name]

    def update(self):
        self._cnt += 1
        t = time.time()
        if t - self._last > self._period:
            speed = (float(self._cnt) / (t - self._last))
            self._avgSum += speed
            self._avgCnt += 1
            logging.getLogger('console').info('\n%s: processed %.1f op/sec, (avg %.1f op/sec)' % (self._name, speed, self._avgSum / self._avgCnt))
            self._cnt = 0
            self._last = t
