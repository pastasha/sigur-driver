"""change incident register table

Revision ID: 25019e3710bc
Revises: 746bbb77303e
Create Date: 2019-07-11 14:17:21.188000

"""
from alembic import op


# revision identifiers, used by Alembic.
revision = '25019e3710bc'
down_revision = '746bbb77303e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        delete from incidents.incident_register
        where typeid not in (select id from incidents.incident_type);

        create table incidents.incident_sop_register(
            id serial primary key,
            incident_id bigint references incidents.incident_register(id),
            sop_id bigint references incidents.incident_sop(id),
            status bigint references incidents.incident_status(id),
            worker_respondresource bigint,
            acceptiondt bigint,
            startdt bigint,
            enddt bigint,
            closed boolean default false,
            accepting_expired boolean default false,
            processing_expired boolean default false
        );

        insert into incidents.incident_sop_register(incident_id, sop_id, status, worker_respondresource,
        acceptiondt, startdt, enddt, closed, accepting_expired, processing_expired)
        select id, (
            select id
            from incidents.incident_sop
            where (
                select sops::text from incidents.incident_type
                where id = typeid
            ) = '["' || identifier || '"]'
        ), status, worker_respondresource, acceptiondt, startdt, closedt, closed, accepting_expired,
        processing_expired
        from incidents.incident_register;

        alter table incidents.incident_task_register
        add column sop_id bigint references incidents.incident_sop_register(id);

        alter table incidents.incident_register
        drop column num,
        drop column name,
        drop column worker_respondresource,
        drop column secondoperator,
        drop column channel,
        add constraint incident_register_typeid_fkey
        foreign key (typeid) references incidents.incident_type(id);

        update incidents.incident_task_register tr
        set sop_id = (
            select sr.id from incidents.incident_sop_register sr
            where sr.incident_id = tr.incident_id
        );

        alter table incidents.incident_task_register
        drop column incident_id;
    """)


def downgrade():
    pass
