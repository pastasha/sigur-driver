"""add event for milestone

Revision ID: 7ce1f4abe1ac
Revises: 76b3b15eafc3
Create Date: 2019-10-29 14:41:37.348944

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '7ce1f4abe1ac'
down_revision = '76b3b15eafc3'
branch_labels = None
depends_on = None
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'milestone', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })

add_event(60000, 'Тревога "Оставленный предмет" началась', 'Тревога "Оставленный предмет" началась %statement.directObj.name')
add_event(60001, 'Конец тревоги "Оставленный предмет"', 'Конец тревоги "Оставленный предмет" %statement.directObj.name')
add_event(60002, 'Тревога "Адаптивный датчик движения" началась', 'Тревога "Адаптивный датчик движения" началась %statement.directObj.name')
add_event(60003, 'Конец тревоги "Адаптивный датчик движения"', 'Конец тревоги "Адаптивный датчик движения" %statement.directObj.name')
add_event(60004, 'Начало аналитики', 'Начало аналитики %statement.directObj.name')
add_event(60005, 'Конец аналитики', 'Конец аналитики %statement.directObj.name')
add_event(60006, 'Тревога "Анти-маскировка" началась', 'Тревога "Анти-маскировка" началась %statement.directObj.name')
add_event(60007, 'Конец тревоги "Анти-маскировка"', 'Конец тревоги "Анти-маскировка" %statement.directObj.name')
add_event(60008, 'Тревога "Анти-вращение" началась', 'Тревога "Анти-вращение" началась %statement.directObj.name')
add_event(60009, 'Конец тревоги "Анти-вращение"', 'Конец тревоги "Анти-вращение" %statement.directObj.name')
add_event(60010, 'Ошибка архивирования', 'Ошибка архивирования %statement.directObj.name')
add_event(60011, 'Ошибка звука', 'Ошибка звука %statement.directObj.name')
add_event(60012, 'Передача звука', 'Передача звука %statement.directObj.name')
add_event(60013, 'Поднятие звука', 'Поднятие звука %statement.directObj.name')
add_event(60014, 'Тревога "Автоматическое отслеживание" началась', 'Тревога "Автоматическое отслеживание" началась %statement.directObj.name')
add_event(60015, 'Конец тревоги "Автоматическое отслеживание"', 'Конец тревоги "Автоматическое отслеживание" %statement.directObj.name')
add_event(60016, 'Запрошена ссылка', 'Запрошена ссылка %statement.directObj.name')
add_event(60017, 'Сильное воздействие', 'Сильное воздействие %statement.directObj.name')
add_event(60018, 'Сдвиг камеры', 'Сдвиг камеры %statement.directObj.name')
add_event(60019, 'Ошибка связи', 'Ошибка связи %statement.directObj.name')
add_event(60020, 'Начало связи', 'Начало связи %statement.directObj.name')
add_event(60021, 'Конец связи', 'Конец связи %statement.directObj.name')
add_event(60022, 'Проход-2', 'Проход-2 %statement.directObj.name')
add_event(60023, 'Кибер-атака', 'Кибер-атака %statement.directObj.name')
add_event(60024, 'Конец режиму день/ночь', 'Конец режиму день/ночь %statement.directObj.name')
add_event(60025, 'Начало режима день/ночь', 'Начало режима день/ночь %statement.directObj.name')
add_event(60026, 'Начало расфокусировки', 'Начало расфокусировки %statement.directObj.name')
add_event(60027, 'Конец расфокусировки', 'Конец расфокусировки %statement.directObj.name')
add_event(60028, 'Сбой записи устройства', 'Сбой записи устройства %statement.directObj.name')
add_event(60029, 'Цифровое автоматическое отслеживание', 'Цифровое автоматическое отслеживание %statement.directObj.name')
add_event(60030, 'Тревога "Направленное движение" началась', 'Тревога "Направленное движение" началась %statement.directObj.name')
add_event(60031, 'Конец тревоги "Направленное движение"', 'Конец тревоги "Направленное движение" %statement.directObj.name')
add_event(60032, 'Продолжительное пребывание', 'Продолжительное пребывание %statement.directObj.name')
add_event(60033, 'Начало Эдо', 'Начало Эдо %statement.directObj.name')
add_event(60034, 'Конец Эдо', 'Конец Эдо %statement.directObj.name')
add_event(60035, 'Покозания шлюза изменились', 'Покозания шлюза изменились %statement.directObj.name')
add_event(60036, 'Обнаружен взрыв', 'Обнаружен взрыв %statement.directObj.name')
add_event(60037, 'Обнаружено лицо', 'Обнаружено лицо %statement.directObj.name')
add_event(60038, 'Лицо исчезло', 'Лицо исчезло %statement.directObj.name')
add_event(60039, 'Лицо опущено', 'Лицо опущено %statement.directObj.name')
add_event(60040, 'Лицо поднято', 'Лицо поднято %statement.directObj.name')
add_event(60041, 'Начало неисправности', 'Начало неисправности %statement.directObj.name')
add_event(60042, 'Конец неисправности', 'Конец неисправности %statement.directObj.name')
add_event(60043, 'Наачло переполнения устройство записи', 'Наачло переполнения устройство записи %statement.directObj.name')
add_event(60044, 'Конец переполнения устройство', 'Конец переполнения устройство %statement.directObj.name')
add_event(60045, 'Тревога "Устройсво записи переполнено" началась', 'Тревога "Устройсво записи переполнено" началась %statement.directObj.name')
add_event(60046, 'Конец тревоги "Устройсво записи переполнено"', 'Конец тревоги "Устройсво записи переполнено" %statement.directObj.name')
add_event(60047, 'Тревога "Пожар" началась', 'Тревога "Пожар" началась %statement.directObj.name')
add_event(60048, 'Конец тревоги "Пожар"', 'Конец тревоги "Пожар" %statement.directObj.name')
add_event(60049, 'Обнаружено задымление', 'Обнаружено задымление %statement.directObj.name')
add_event(60050, 'Обнаружено разбитое стекло', 'Обнаружено разбитое стекло %statement.directObj.name')
add_event(60051, 'Событие от группы', 'Событие от группы %statement.directObj.name')
add_event(60052, 'Обнаружен выстрел', 'Обнаружен выстрел %statement.directObj.name')
add_event(60053, 'Обнаружен незаконный доступ', 'Обнаружен незаконный доступ %statement.directObj.name')
add_event(60054, 'Получение изображения', 'Получение изображения %statement.directObj.name')
add_event(60055, 'Вход активирован', 'Вход активирован %statement.directObj.name')
add_event(60056, 'Вход изменен', 'Вход изменен %statement.directObj.name')
add_event(60057, 'Вход деактивирован', 'Вход деактивирован %statement.directObj.name')
add_event(60058, 'Конец проникновения', 'Конец проникновения %statement.directObj.name')
add_event(60059, 'Начало проникновения', 'Начало проникновения %statement.directObj.name')
add_event(60060, 'Тревога "Конфликт IP" началась', 'Тревога "Конфликт IP" началась %statement.directObj.name')
add_event(60061, 'Конец тревоги "Конфликт IP"', 'Конец тревоги "Конфликт IP" %statement.directObj.name')
add_event(60062, 'Счетчик линии 1', 'Счетчик линии 1 %statement.directObj.name')
add_event(60063, 'Счетчик линии 2', 'Счетчик линии 2 %statement.directObj.name')
add_event(60064, 'Связанное событие падает', 'Связанное событие падает %statement.directObj.name')
add_event(60065, 'Связанное событие восстанавливается', 'Связанное событие восстанавливается %statement.directObj.name')
add_event(60066, 'Прямая трансляция клиента началась', 'Прямая трансляция клиента началась %statement.directObj.name')
add_event(60067, 'Прямая трансляция клиента закончилась', 'Прямая трансляция клиента закончилась %statement.directObj.name')
add_event(60068, 'Тревога "Праздношатания" началась', 'Тревога "Праздношатания" началась %statement.directObj.name')
add_event(60069, 'Конец тревоги "Праздношатания"', 'Конец тревоги "Праздношатания" %statement.directObj.name')
add_event(60070, 'Низкий заряд батареи', 'Низкий заряд батареи %statement.directObj.name')
add_event(60071, 'Начало режима ручной записи', 'Начало режима ручной записи %statement.directObj.name')
add_event(60072, 'Конец режима ручной записи', 'Конец режима ручной записи %statement.directObj.name')
add_event(60073, 'Запрос спавочных данных', 'Запрос спавочных данных %statement.directObj.name')
add_event(60074, 'Запуск мастера тревоги', 'Запуск мастера тревоги %statement.directObj.name')
add_event(60075, 'Конец мастера тревоги', 'Конец мастера тревоги %statement.directObj.name')
add_event(60076, 'Начало движения', 'Начало движения %statement.directObj.name')
add_event(60077, 'Конец движения', 'Конец движения %statement.directObj.name')
add_event(60078, 'Движение началось', 'Движение началось %statement.directObj.name')
add_event(60079, 'Движение закончилось', 'Движение закончилось %statement.directObj.name')
add_event(60080, 'Появление объекта', 'Появление объекта %statement.directObj.name')
add_event(60081, 'Начало подсчета объектов', 'Начало подсчета объектов %statement.directObj.name')
add_event(60082, 'Конец подсчета объектов', 'Конец подсчета объектов %statement.directObj.name')
add_event(60083, 'Тревога "Направленное движение"', 'Тревога "Направленное движение" %statement.directObj.name')
add_event(60084, 'Исчезновление объекта', 'Исчезновление объекта %statement.directObj.name')
add_event(60085, 'Объект задерживается', 'Объект задерживается %statement.directObj.name')
add_event(60086, 'Вход объекта', 'Вход объекта %statement.directObj.name')
add_event(60087, 'Выход объекта', 'Выход объекта %statement.directObj.name')
add_event(60088, 'Присутсвие объекта', 'Присутсвие объекта %statement.directObj.name')
add_event(60089, 'Начало удаления объекта', 'Начало удаления объекта %statement.directObj.name')
add_event(60090, 'Конец удаления объекта', 'Конец удаления объекта %statement.directObj.name')
add_event(60091, 'Скорость объекта', 'Скорость объекта %statement.directObj.name')
add_event(60092, 'Объект отсановился', 'Объект отсановился %statement.directObj.name')
add_event(60093, 'Противоположное направление 2', 'Противоположное направление 2 %statement.directObj.name')
add_event(60094, 'Выход активирован', 'Выход активирован %statement.directObj.name')
add_event(60095, 'Выход изменен', 'Выход изменен %statement.directObj.name')
add_event(60096, 'Выход деактивирован', 'Выход деактивирован %statement.directObj.name')
add_event(60097, 'Парковка', 'Парковка %statement.directObj.name')
add_event(60098, 'Обнаружение людей', 'Обнаружение людей %statement.directObj.name')
add_event(60099, 'Начало тревоги "PIR датчик"', 'Начало тревоги "PIR датчик" %statement.directObj.name')
add_event(60100, 'Сеанс мануала  PTZ начался  ', 'Сеанс мануала  PTZ начался   %statement.directObj.name')
add_event(60101, 'Сеанс мануала  PTZ остановлен  ', 'Сеанс мануала  PTZ остановлен   %statement.directObj.name')
add_event(60102, 'Тревога "Карантин"', 'Тревога "Карантин" %statement.directObj.name')
add_event(60103, 'Запуск радара', 'Запуск радара %statement.directObj.name')
add_event(60104, 'Остановка радара', 'Остановка радара %statement.directObj.name')
add_event(60105, 'Начало тревоги "Быстрое движение"', 'Начало тревоги "Быстрое движение" %statement.directObj.name')
add_event(60106, 'Конец тревоги "Быстрое движение"', 'Конец тревоги "Быстрое движение" %statement.directObj.name')
add_event(60107, 'Начало записи', 'Начало записи %statement.directObj.name')
add_event(60108, 'Остановка записи', 'Остановка записи %statement.directObj.name')
add_event(60109, 'Тревога "Доступные записи"', 'Тревога "Доступные записи" %statement.directObj.name')
add_event(60110, 'Записанные данные заблокированы', 'Записанные данные заблокированы %statement.directObj.name')
add_event(60111, 'Записанные данные разблокированы', 'Записанные данные разблокированы %statement.directObj.name')
add_event(60112, 'Тревога "Запретная зона 2"', 'Тревога "Запретная зона 2" %statement.directObj.name')
add_event(60113, 'Изменение сцены', 'Изменение сцены %statement.directObj.name')
add_event(60114, 'Изменение места остановки', 'Изменение места остановки %statement.directObj.name')
add_event(60115, 'Начало тревоги "Обноружен звук"', 'Начало тревоги "Обноружен звук" %statement.directObj.name')
add_event(60116, 'Конец тревоги "Обноружен звук"', 'Конец тревоги "Обноружен звук" %statement.directObj.name')
add_event(60117, 'SD карта отключена', 'SD карта отключена %statement.directObj.name')
add_event(60118, 'Ошибка SD карты', 'Ошибка SD карты %statement.directObj.name')
add_event(60119, 'Установлена SD карта', 'Установлена SD карта %statement.directObj.name')
add_event(60120, 'Запись на SD карту', 'Запись на SD карту %statement.directObj.name')
add_event(60121, 'SD карта удалена', 'SD карта удалена %statement.directObj.name')
add_event(60122, 'Старт SD карты', 'Старт SD карты %statement.directObj.name')
add_event(60123, 'Остановка SD карты', 'Остановка SD карты %statement.directObj.name')
add_event(60124, 'Настройки изменены', 'Настройки изменены %statement.directObj.name')
add_event(60125, 'Ошибка изменения настроек', 'Ошибка изменения настроек %statement.directObj.name')
add_event(60126, 'Обнаружение удара', 'Обнаружение удара %statement.directObj.name')
add_event(60127, 'Начало тревоги "Курение"', 'Начало тревоги "Курение" %statement.directObj.name')
add_event(60128, 'Конец тревоги "Курение"', 'Конец тревоги "Курение" %statement.directObj.name')
add_event(60129, 'Начало тревоги "Грязное окно"', 'Начало тревоги "Грязное окно" %statement.directObj.name')
add_event(60130, 'Конец тревоги "Грязное окно"', 'Конец тревоги "Грязное окно" %statement.directObj.name')
add_event(60131, 'Тревога "Скорость-2"', 'Тревога "Скорость-2" %statement.directObj.name')
add_event(60132, 'Начало тревоги "Запуск двигателя"', 'Начало тревоги "Запуск двигателя" %statement.directObj.name')
add_event(60133, 'Конец тревоги "Запуск двигателя"', 'Конец тревоги "Запуск двигателя" %statement.directObj.name')
add_event(60134, 'Контроллер вход закрыт', 'Контроллер вход закрыт %statement.directObj.name')
add_event(60135, 'Контроллер вход оборван', 'Контроллер вход оборван %statement.directObj.name')
add_event(60136, 'Контроллер вход открыт', 'Контроллер вход открыт %statement.directObj.name')
add_event(60137, 'Контроллер вход закоротило', 'Контроллер вход закоротило %statement.directObj.name')
add_event(60138, 'Тревога "Задняя дверь"', 'Тревога "Задняя дверь" %statement.directObj.name')
add_event(60139, 'Тревога "Фальсификация"', 'Тревога "Фальсификация" %statement.directObj.name')
add_event(60140, 'Конец взлома', 'Конец взлома %statement.directObj.name')
add_event(60141, 'Начало взлома', 'Начало взлома %statement.directObj.name')
add_event(60142, 'Тревога "Температура"', 'Тревога "Температура" %statement.directObj.name')
add_event(60143, 'Повышение температуры', 'Повышение температуры %statement.directObj.name')
add_event(60144, 'Понижение температуры', 'Понижение температуры %statement.directObj.name')
add_event(60145, 'Конец тревоги "Температура"', 'Конец тревоги "Температура" %statement.directObj.name')
add_event(60146, 'Тревога "Температура внутри"', 'Тревога "Температура внутри" %statement.directObj.name')
add_event(60147, 'Начало тревоги "Температура"', 'Начало тревоги "Температура" %statement.directObj.name')
add_event(60148, 'Тревога "Тепловое радио"', 'Тревога "Тепловое радио" %statement.directObj.name')
add_event(60149, 'Тревога "Тепловое пятно"', 'Тревога "Тепловое пятно" %statement.directObj.name')
add_event(60150, 'Тревога "Растяжение"', 'Тревога "Растяжение" %statement.directObj.name')
add_event(60151, 'Начало ревоги "Проблема"', 'Начало ревоги "Проблема" %statement.directObj.name')
add_event(60152, 'Конец тревоги "Проблема"', 'Конец тревоги "Проблема" %statement.directObj.name')
add_event(60153, 'Тревога "Поворот 2"', 'Тревога "Поворот 2" %statement.directObj.name')
add_event(60154, 'Начало слежения двух камер', 'Начало слежения двух камер %statement.directObj.name')
add_event(60155, 'Конец слежения двух камер', 'Конец слежения двух камер %statement.directObj.name')
add_event(60156, 'Тревога Отворот 2"', 'Тревога Отворот 2" %statement.directObj.name')
add_event(60157, 'Потеря видео', 'Потеря видео %statement.directObj.name')
add_event(60158, 'Конец тревоги "Потеря видео"', 'Конец тревоги "Потеря видео" %statement.directObj.name')
add_event(60159, 'Начало тревоги "Потеря видео"', 'Начало тревоги "Потеря видео" %statement.directObj.name')
add_event(60160, 'Конец тревоги "Вскрытие окна"', 'Конец тревоги "Вскрытие окна" %statement.directObj.name')
add_event(60161, 'Начало тревоги "Вскрытие окна"', 'Начало тревоги "Вскрытие окна" %statement.directObj.name')

def downgrade():
    op.execute('''
    delete from event_catalog where code >= 60000 and code < 60162
    ''')
