# -*- coding: utf-8 -*-

"""update format of zone events

Revision ID: 2b60971670c7
Revises: d0f631db735c
Create Date: 2018-09-17 10:42:23.093000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2b60971670c7'
down_revision = 'd0f631db735c'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"""
        update event_catalog set format = '["Вход в геозону: %statement.adverbialTo.name", ""]' where code = 6639;
        update event_catalog set format = '["Выход из геозоны: %statement.adverbialFrom.name", ""]' where code = 6640;
    """)


def downgrade():
    pass
