"""adding remote_guid to oo_table

Revision ID: 790b8c184abc
Revises: c00dd3a449a5
Create Date: 2018-04-23 12:23:28.022000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '790b8c184abc'
down_revision = 'c00dd3a449a5'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('oo_table',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute('update oo_table set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')

def downgrade():
    op.drop_column('oo_table', 'remote_guid')