# -*- coding: utf-8 -*-

"""create trigger function for update subject last pass event

Revision ID: 8100cf407afa
Revises: 55324469ca2d
Create Date: 2018-10-26 14:18:48.812000

Раньше колонка last_pass_event обновлялась в функции store_event. Так как эту функцию упразднили, то пока обновление
этой колонки будет делаться через триггерную функцию.
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8100cf407afa'
down_revision = '55324469ca2d'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create or replace function events.set_subject_last_pass_event()
        RETURNS trigger AS 
        $BODY$
            declare
                last_event_tm timestamp;
                last_event_num bigint;
            begin
                if new.subjectobj_devid is null or new.pass_type is null then
                    return new;
                end if;
                
                select last_pass_event from common_subject where uniid = new.subjectobj_devid into last_event_num;
                if last_event_num is not null then
                    select adverbialtime_value from event_register_v2 where evnum = last_event_num into last_event_tm;
                    if last_event_tm > new.adverbialtime_value then
                        return new;
                    end if;
                end if;
                
                update common_subject set last_pass_event = new.evnum
                where uniid = new.subjectobj_devid; 
                
                return new;
            end; 
        $BODY$ 
        LANGUAGE plpgsql;
    """)

    conn = op.get_bind()
    tables = conn.execute("select tablename from pg_tables where tablename like 'events_v2_%%'")
    tables = [t[0] for t in tables.fetchall()]
    for t in tables:
        op.execute("""
            create trigger %s_inserted_trig_after_insert 
            after insert on events.%s 
            for each row execute procedure events.set_subject_last_pass_event();
        """ % (t, t))


def downgrade():
    pass
