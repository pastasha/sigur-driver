# -*- coding: utf-8 -*-

"""fix uld event codes

Revision ID: 9f1a8907c7e3
Revises: b2258059c063
Create Date: 2018-09-03 13:30:56.126000

С какого-то момента коды событий ULD вдруг стали начинаться с 40000 а раньше были с 20000. В разных базах получилось по разному.
Миграция делает корректировку кодов событий в каталоге и в обработчиках.
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9f1a8907c7e3'
down_revision = 'b2258059c063'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set code = code + 20000
        where code >= 20001 and code <= 20043 and lower(equipment) = 'uld';
        
        update event_table
        set code = code + 20000
        where code >= 20001 and code <= 20043
    """)


def downgrade():
    pass
