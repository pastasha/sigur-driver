"""add column protocol_settings for surguard_driver

Revision ID: cf307d154da3
Revises: 4ae6e073fa19
Create Date: 2019-10-15 09:32:02.481390

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cf307d154da3'
down_revision = '4ae6e073fa19'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE surguard_driver ADD protocol_settings text')


def downgrade():
    op.execute('ALTER TABLE surguard_driver drop column protocol_settings')
