# -*- coding: utf-8 -*-
"""add event onvif base for rec

Revision ID: adc16801b41c
Revises: 17d4e6032890
Create Date: 2018-11-27 10:03:51.308000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'adc16801b41c'
down_revision = '17d4e6032890'
branch_labels = None
depends_on = None
events = []



event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"onvif", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(128303, u"Видеокамера начала запись", u"[\"%statement.directObj.name видеокамера начала запись %statement.adverbialMode.params\", \"Видеокамера начала запись\"]")
addEv(128304, u"Видеокамера закончила запись", u"[\"%statement.directObj.name видеокамера закончила запись %statement.adverbialMode.params\", \"Видеокамера закончила запись\"]")


def downgrade():
    pass
