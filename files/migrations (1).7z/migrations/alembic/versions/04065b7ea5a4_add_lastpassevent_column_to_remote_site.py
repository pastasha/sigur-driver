"""add lastpassevent column to remote_site

Revision ID: 04065b7ea5a4
Revises: 1c13b862b106
Create Date: 2018-07-23 11:17:59.042000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '04065b7ea5a4'
down_revision = '1c13b862b106'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('remote_site', sa.Column('lastpassevent', sa.BigInteger(), default=0))
    op.execute('update remote_site set lastpassevent = 0')


def downgrade():
    op.drop_column('remote_site', 'lastpassevent')
