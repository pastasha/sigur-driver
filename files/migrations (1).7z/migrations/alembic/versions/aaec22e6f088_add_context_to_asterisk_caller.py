"""add context to asterisk caller

Revision ID: aaec22e6f088
Revises: a405dce8d9e8
Create Date: 2019-04-29 10:26:43.417000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'aaec22e6f088'
down_revision = 'a405dce8d9e8'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('system_workstation', sa.Column('call_context', sa.String()))
    op.add_column('common_phone', sa.Column('call_context', sa.String()))

def downgrade():
    pass
