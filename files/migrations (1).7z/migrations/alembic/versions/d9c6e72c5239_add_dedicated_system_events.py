# -*- coding: utf-8 -*-

"""add dedicated system events

Revision ID: d9c6e72c5239
Revises: b04a069ee345
Create Date: 2018-07-11 11:33:55.150000

Добавляет системые события для оборудовани remote_site

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date
import json

# revision identifiers, used by Alembic.
revision = 'd9c6e72c5239'
down_revision = '95fa9e1c4e62'
branch_labels = None
depends_on = None

events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def addEv(code, descr, format, equipment = u"remote", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })

addEv(800, u"Установлена связь с удаленным сервером", json.dumps(["Связь с удаленным сервером %statement.directObj.name установлена", ""]))
addEv(801, u"Ошибка авторизации на удаленном сервере", json.dumps(["Ошибка авторизации на удаленном сервере %statement.directObj.name по причине %statement.adverbialMode.param", ""]))
addEv(802, u"Потеряна связь с удаленным сервером", json.dumps(["Связь с удаленным сервером %statement.directObj.name потеряна", ""]))

def upgrade():
    op.execute('delete from event_catalog where code in(800, 801, 802)')
    op.bulk_insert(event_catalog, events)

def downgrade():
    op.execute('delete from event_catalog where code in(800, 801, 802)')
