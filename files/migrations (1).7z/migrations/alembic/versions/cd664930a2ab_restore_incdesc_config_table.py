"""restore incdesc config table

Revision ID: cd664930a2ab
Revises: e1faa10a5a0a
Create Date: 2019-06-25 12:19:10.120000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cd664930a2ab'
down_revision = 'e1faa10a5a0a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create table if not exists incdesc_config(
            uniid serial primary key,
            manager_id bigint not null default 0,
            config text default '',
            ts timestamp not null default now()
        )
    """)


def downgrade():
    pass
