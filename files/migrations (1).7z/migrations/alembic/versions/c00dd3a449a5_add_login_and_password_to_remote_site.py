"""add login and password to remote_site

Revision ID: c00dd3a449a5
Revises: d8c6d270a123
Create Date: 2018-04-19 18:00:48.255000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c00dd3a449a5'
down_revision = 'd8c6d270a123'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('remote_site',
    	sa.Column('login', sa.String())
    )
    op.add_column('remote_site',
    	sa.Column('password', sa.String())
    )
def downgrade():
    op.execute("""
    	ALTER TABLE remote_site
		DROP COLUMN login;
    """)
    op.execute("""
    	ALTER TABLE remote_site
		DROP COLUMN password;
    """)
