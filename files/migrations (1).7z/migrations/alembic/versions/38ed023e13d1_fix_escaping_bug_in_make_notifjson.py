"""fix escaping bug in make_notifjson

Revision ID: 38ed023e13d1
Revises: 743e634a7a48
Create Date: 2019-04-29 14:54:49.528000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '38ed023e13d1'
down_revision = '743e634a7a48'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        CREATE OR REPLACE FUNCTION make_notifjson(evnum bigint) returns text as
        $BODY$
            declare
                evdevcode bigint;
                channel text;
                level int;
                securlevel int;
                checkJson int;
                
                subjectEquip text;
                subjectType text;
                subjectDevid bigint;
                subjectValue text;
                subjectName text;
                subjectValueIsInt boolean;
                subjectNotif text;
                subjectEquipNotif text;
                
                directObjobsobjid bigint;
                directObjdevequip text;
                directObjdevtype text;
                directObjdevid bigint;
                directObjdevvalue text;
                
                indirectObjobsobjid bigint;
                indirectObjdevequip text;
                indirectObjdevtype text;
                indirectObjdevid bigint;
                indirectObjdevvalue text;
                
                adverbialPlaceobsobjid bigint;
                adverbialPlacedevequip text;
                adverbialPlacedevtype text;
                adverbialPlacedevid bigint;
                adverbialPlacedevvalue text;
                
                adverbialFromobsobjid bigint;
                adverbialFromdevequip text;
                adverbialFromdevtype text;
                adverbialFromdevid bigint;
                adverbialFromdevvalue text;
                
                adverbialToobsobjid bigint;
                adverbialTodevequip text;
                adverbialTodevtype text;
                adverbialTodevid bigint;
                adverbialTodevvalue text;
                
                adverbialCondobsobjid bigint;
                adverbialConddevequip text;
                adverbialConddevtype text;
                adverbialConddevid bigint;
                adverbialConddevvalue text;
                
                adverbialWhyobsobjid bigint;
                adverbialWhydevequip text;
                adverbialWhydevtype text;
                adverbialWhydevid bigint;
                adverbialWhydevvalue text;
                
                adverbialModeobsobjid bigint;
                adverbialModedevequip text;
                adverbialModedevtype text;
                adverbialModedevid bigint;
                adverbialModedevvalue text;
                
                directObj_value text;
                indirectObj_value text;
                adverbialPlace_value text;
                adverbialFrom_value text;
                adverbialTo_value text;
                adverbialCond_value text;
                adverbialWhy_value text;
                adverbialMode_value text;
                
                domainId bigint;
                domainName text;
                
                statement text;
                notifjson text;
                notification text;
            begin
                execute 'select evdevcode, domain, COALESCE(channel, ''notif''), COALESCE(level, 0), COALESCE(securlevel, 1),
                notifjson, subjectobj_devequip, subjectobj_devtype, subjectobj_devid, subjectobj_value,
                subjectobj_value~ ''^[0-9\.]+$'',
                directObj_obsobjid, directObj_devequip, directObj_devtype, directObj_devid, directObj_value,
                indirectObj_obsobjid, indirectObj_devequip, indirectObj_devtype, indirectObj_devid, indirectObj_value,
                adverbialPlace_obsobjid, adverbialPlace_devequip, adverbialPlace_devtype, adverbialPlace_devid, adverbialPlace_value,
                adverbialFrom_obsobjid, adverbialFrom_devequip, adverbialFrom_devtype, adverbialFrom_devid, adverbialFrom_value,
                adverbialTo_obsobjid, adverbialTo_devequip, adverbialTo_devtype, adverbialTo_devid, adverbialTo_value,
                adverbialCond_obsobjid, adverbialCond_devequip, adverbialCond_devtype, adverbialCond_devid, adverbialCond_value,
                adverbialWhy_obsobjid, adverbialWhy_devequip, adverbialWhy_devtype, adverbialWhy_devid, adverbialWhy_value,
                adverbialMode_obsobjid, adverbialMode_devequip, adverbialMode_devtype, adverbialMode_devid, adverbialMode_value
                from event_register_v2 where evnum = $1'
                into evdevcode, domainId, channel, level, securlevel,
                notifjson, subjectEquip, subjectType, subjectDevid, subjectValue,
                subjectValueIsInt,
                directObjobsobjid, directObjdevequip, directObjdevtype, directObjdevid, directObjdevvalue,
                indirectObjobsobjid, indirectObjdevequip, indirectObjdevtype, indirectObjdevid, indirectObjdevvalue,
                adverbialPlaceobsobjid, adverbialPlacedevequip, adverbialPlacedevtype, adverbialPlacedevid, adverbialPlacedevvalue,
                adverbialFromobsobjid, adverbialFromdevequip, adverbialFromdevtype, adverbialFromdevid, adverbialFromdevvalue,
                adverbialToobsobjid, adverbialTodevequip, adverbialTodevtype, adverbialTodevid, adverbialTodevvalue,
                adverbialCondobsobjid, adverbialConddevequip, adverbialConddevtype, adverbialConddevid, adverbialConddevvalue,
                adverbialWhyobsobjid, adverbialWhydevequip, adverbialWhydevtype, adverbialWhydevid, adverbialWhydevvalue,
                adverbialModeobsobjid, adverbialModedevequip, adverbialModedevtype, adverbialModedevid, adverbialModedevvalue
                using evnum;
                
                if evdevcode >= 10000 and evdevcode <= 10100 then
                    return notifjson;
                end if;
                
                checkJson =  position('notification' in notifjson);
                if checkJson > 0 then
                    return notifjson;
                end if;
                
                statement = '"statement":{';
                
                if subjectEquip is not null then
                    execute 'select description from common_person where devparent = $1'
                    into subjectName
                    using subjectDevid;
                    if subjectName is null then
                        execute 'select description from common_mobile where devparent = $1'
                        into subjectName
                        using subjectDevid;
                    end if;
                    subjectEquipNotif = jsonb_build_object('equip', subjectEquip, 'type', subjectType, 'id', subjectDevid, 'name', subjectName)::text;
                    subjectNotif = '"subject": {"dev":' || subjectEquipNotif || ',"card": ';
                    if subjectValueIsInt then
                        subjectNotif = subjectNotif || subjectValue;
                    else
                        subjectNotif = subjectNotif || '"' || subjectValue || '"';
                    end if;
                    subjectNotif = subjectNotif || '}';
                    statement = statement || subjectNotif || ',';
                else
                    if subjectValue is not null then
                        subjectNotif = '"subject": {"card": ';
                        if subjectValueIsInt then
                            subjectNotif = subjectNotif || subjectValue;
                        else
                            subjectNotif = subjectNotif || '"' || subjectValue || '"';
                        end if;
                        subjectNotif = subjectNotif || '}';
                        statement = statement || subjectNotif || ',';
                    end if;
                end if;
                
                select make_notifjson_for_role('directObj', directObjobsobjid, directObjdevequip, directObjdevtype, directObjdevid, directObjdevvalue) into directObj_value;
                select make_notifjson_for_role('indirectObj', indirectObjobsobjid, indirectObjdevequip, indirectObjdevtype, indirectObjdevid, indirectObjdevvalue) into indirectObj_value;
                select make_notifjson_for_role('adverbialPlace', adverbialPlaceobsobjid, adverbialPlacedevequip, adverbialPlacedevtype, adverbialPlacedevid, adverbialPlacedevvalue) into adverbialPlace_value;
                select make_notifjson_for_role('adverbialFrom', adverbialFromobsobjid, adverbialFromdevequip, adverbialFromdevtype, adverbialFromdevid, adverbialFromdevvalue) into adverbialFrom_value;
                select make_notifjson_for_role('adverbialTo', adverbialToobsobjid, adverbialTodevequip, adverbialTodevtype, adverbialTodevid, adverbialTodevvalue) into adverbialTo_value;
                select make_notifjson_for_role('adverbialCond', adverbialCondobsobjid, adverbialConddevequip, adverbialConddevtype, adverbialConddevid, adverbialConddevvalue) into adverbialCond_value;
                select make_notifjson_for_role('adverbialWhy', adverbialWhyobsobjid, adverbialWhydevequip, adverbialWhydevtype, adverbialWhydevid, adverbialWhydevvalue) into adverbialWhy_value;
                select make_notifjson_for_role('adverbialMode', adverbialModeobsobjid, adverbialModedevequip, adverbialModedevtype, adverbialModedevid, adverbialModedevvalue) into adverbialMode_value;
                
                if directObj_value is not null then
                    statement = statement || directObj_value || ',';
                end if;
                if indirectObj_value is not null then
                    statement = statement || indirectObj_value || ',';
                end if;
                if adverbialPlace_value is not null then
                    statement = statement || adverbialPlace_value || ',';
                end if;
                if adverbialFrom_value is not null then
                    statement = statement || adverbialFrom_value || ',';
                end if;
                if adverbialTo_value is not null then
                    statement = statement || adverbialTo_value || ',';
                end if;
                if adverbialCond_value is not null then
                    statement = statement || adverbialCond_value || ',';
                end if;
                if adverbialWhy_value is not null then
                    statement = statement || adverbialWhy_value || ',';
                end if;
                if adverbialMode_value is not null then
                    statement = statement || adverbialMode_value || ',';
                end if;
                
                domainName = '';
                if domainId is not null then
                    if domainId <> 0 then
                        execute 'select description from common_domain where uniid = $1'
                        into domainName
                        using domainId;
                    end if;
                else
                    domainId = 0;
                end if;
                
                statement = statement || '"domain": {"name": "' || domainName || '", "id": ' || domainId || '}';
                
                statement = statement || '}';
                
                notification = '{"channel": "' || channel || '", "notification":{' || notifjson || ', "level": ' || level || ', "num": ' || evnum || ', "securLevel": ' || securLevel || '}, ' || statement || '}';
                
                return notification;
            end;
        $BODY$
      LANGUAGE plpgsql
    """)


def downgrade():
    pass
