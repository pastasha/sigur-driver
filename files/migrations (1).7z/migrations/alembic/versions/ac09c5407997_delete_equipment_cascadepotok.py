"""delete equipment cascadepotok

Revision ID: ac09c5407997
Revises: dd85367a0a6a
Create Date: 2018-09-19 13:07:36.840000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ac09c5407997'
down_revision = 'dd85367a0a6a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop table if exists cascadepotok_server;
        drop table if exists cascadepotok_identificationdevice;
        drop table if exists cascadepotok_event;
        
        delete from opright_equip where equip = 'cascadepotok';
        
        delete from equipments where name = 'cascadepotok';
    """)


def downgrade():
    pass
