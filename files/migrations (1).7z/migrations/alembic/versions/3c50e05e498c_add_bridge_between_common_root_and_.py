# -*- coding: utf-8 -*-

"""add bridge between common root and common tinterval

Revision ID: 3c50e05e498c
Revises: 6bd3a5ad9a5a
Create Date: 2018-04-23 09:30:05.362000

Создает мостовую связь между объектом Настройки и временным интервалом

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3c50e05e498c'
down_revision = '6bd3a5ad9a5a'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('common_root_tinterval', [], ['tinterval',], True)


def downgrade():
    op.drop_table('common_root_tinterval')
    op.execute("delete from equipment_generators where tbl='common_root_tinterval'")
