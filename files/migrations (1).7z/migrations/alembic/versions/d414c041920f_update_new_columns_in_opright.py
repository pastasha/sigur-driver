"""update new columns in opright

Revision ID: d414c041920f
Revises: 576e3abe313e
Create Date: 2019-11-18 10:40:07.173354

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd414c041920f'
down_revision = '576e3abe313e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update opright
        set appanalityc = false, appadmin = false, appsituationcenter = false
    """)


def downgrade():
    pass
