# -*- coding: utf-8 -*-

"""create incident_event_brg if not exists

Revision ID: 99a192d5f1b3
Revises: a3eb7cf8b854
Create Date: 2018-10-25 17:31:40.248000

Если разворачивать бэкапы сделанные в версии 2.8 и раньше без событий то там
этой таблицы не будет и не будет работать все что связано с инцидентами

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '99a192d5f1b3'
down_revision = 'a3eb7cf8b854'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create table if not exists incident_event_brg(
            incident bigint not null,
            event_num bigint not null,
            src_event bigint,
            primary key(incident, event_num)
        );
        create index if not exists incident_event_brg_event_num_idx on incident_event_brg using btree(event_num);
        create index if not exists incident_event_brg_incident_idx on incident_event_brg using btree(incident);
    """)

    
def downgrade():
    pass
