"""add deleted flag to incident type

Revision ID: 5f2ed1295360
Revises: 5b59b72d1d1e
Create Date: 2019-11-19 14:21:51.946705

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5f2ed1295360'
down_revision = '5b59b72d1d1e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_type
        add column deleted boolean default false;
        
        alter table incidents.incident_sop
        add column deleted boolean default false;
        
        alter table incidents.incident_task
        add column deleted boolean default false;
    """)


def downgrade():
    op.execute("""
        alter table incidents.incident_type
        drop column deleted;
        
        alter table incidents.incident_sop
        drop column deleted;
        
        alter table incidents.incident_task
        drop column deleted;
    """)
