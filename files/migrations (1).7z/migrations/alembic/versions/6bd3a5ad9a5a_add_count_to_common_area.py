# -*- coding: utf-8 -*-

"""add count to common area

Revision ID: 6bd3a5ad9a5a
Revises: 556d9c93e3d2
Create Date: 2018-04-20 12:39:15.776000

Добавляет колонку для хранения числа людей в зоне

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6bd3a5ad9a5a'
down_revision = 'bfa2cb74a7a6'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('common_area',
        sa.Column('persons_count', sa.Integer())
    )
    op.execute('update common_area set persons_count = 0')


def downgrade():
    op.drop_column('common_area', 'persons_count')
