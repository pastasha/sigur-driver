# -*- coding: utf-8 -*-

"""new events for arm disarm in surguard

Revision ID: aaab2d658478
Revises: d30f84d41bae
Create Date: 2018-03-26 13:34:51.854000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'aaab2d658478'
down_revision = 'd30f84d41bae'
branch_labels = None
depends_on = None

events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)
def addEv(code, descr, format, equipment = u"surguard", options = 7, level = 0, channel = "notif", color = "#000000"):
        events.append({
            u"code": code,
            u"description": descr,
            u"equipment": equipment,
            u"format": format,
            u"options": options,
            u"level": level,
            u"channel": channel,
            u"color": color
        })
addEv(15000, u"Норма", u"[\"Норма Снятие %statement.directObj.name\", \"\"]")
addEv(15001, u"Норма", u"[\"Норма Взятие %statement.directObj.name\", \"\"]")

def upgrade():
    op.bulk_insert(event_catalog, events)


def downgrade():
    op.execute('delete from event_catalog where code = 15000 or code = 15001')