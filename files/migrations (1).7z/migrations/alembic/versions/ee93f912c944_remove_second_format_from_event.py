"""remove second format from event

Revision ID: ee93f912c944
Revises: 5134fa3f79ac
Create Date: 2018-08-27 15:58:50.329000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ee93f912c944'
down_revision = '5134fa3f79ac'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        delete from event_catalog where deletemark = 1;
        update event_catalog set format = format::json->>0;
    """)


def downgrade():
    op.execute("update event_catalog set format = json_build_array(format, '')")
