"""creating tables for connected hardware

Revision ID: 542f1c47d433
Revises: fcc062a01054
Create Date: 2018-03-01 14:55:22.504000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '542f1c47d433'
down_revision = '559289e64fb3'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('rusguard_connectedequipmenttodoor',(
			('id', 'varchar(256)', ''),
			('description', 'varchar(256)', ''),
			('isactive', 'boolean', 'default false'),
			('type', 'varchar(256)', '')			
		),[], 'True'
	)


def downgrade():
    pass
