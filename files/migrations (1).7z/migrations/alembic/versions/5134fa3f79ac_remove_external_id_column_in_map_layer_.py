"""remove external_id column in map_layer table

Revision ID: 5134fa3f79ac
Revises: 3be4f0e2581f
Create Date: 2018-08-27 15:44:31.651000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5134fa3f79ac'
down_revision = '3be4f0e2581f'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column('map_layer', 'external_id')


def downgrade():
    op.add_column('map_layer', sa.Column('external_id', sa.String()))    
