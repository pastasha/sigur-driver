"""add remote guid to incident register

Revision ID: 26155e65d0c5
Revises: 5d5478b4ebed
Create Date: 2019-12-17 12:04:34.744120

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '26155e65d0c5'
down_revision = '5d5478b4ebed'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_sop_register
        add column remote_guid text default (md5(((random())::text || (clock_timestamp())::text)))::uuid;
        
        alter table incidents.incident_task_register
        add column remote_guid text default (md5(((random())::text || (clock_timestamp())::text)))::uuid;
    """)


def downgrade():
    op.execute("""
        alter table incidents.incident_sop_register
        drop column remote_guid;
        
        alter table incidents.incident_task_register
        drop column remote_guid;
    """)
