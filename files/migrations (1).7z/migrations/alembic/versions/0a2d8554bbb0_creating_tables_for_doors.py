"""creating tables for doors

Revision ID: 0a2d8554bbb0
Revises: cae85ae602c0
Create Date: 2018-03-01 15:10:22.624000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0a2d8554bbb0'
down_revision = 'b6f6ec43ed4f'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('rusguard_doors',(
			('id', 'varchar(256)', ''),
			('description', 'varchar(256)', ''),
			('isactive', 'boolean', 'default false'),
			('type', 'varchar(256)', '')			
		),[], 'True'
	)


def downgrade():
    pass
