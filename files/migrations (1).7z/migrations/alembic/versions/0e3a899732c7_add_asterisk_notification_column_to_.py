"""add asterisk notification column to reaction

Revision ID: 0e3a899732c7
Revises: bb2df7338dd1
Create Date: 2019-07-01 15:38:11.916000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0e3a899732c7'
down_revision = 'bb2df7338dd1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table reaction_options
        add column asterisk_notification integer references asterisk_autodial(id)
    """)


def downgrade():
    op.execute("""
        alter table reaction_options
        drop column asterisk_notification
    """)
