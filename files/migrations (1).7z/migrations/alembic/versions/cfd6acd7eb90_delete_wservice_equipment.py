"""delete wservice equipment

Revision ID: cfd6acd7eb90
Revises: 9e4c5cd6703e
Create Date: 2018-09-19 08:40:39.458000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cfd6acd7eb90'
down_revision = '9e4c5cd6703e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop table if exists wservice_station;
        drop table if exists wservice_module;
        drop table if exists wservice_station_module;
        
        delete from opright_equip where equip = 'wservice';
        
        delete from equipments where name = 'wservice';
    """)


def downgrade():
    pass
