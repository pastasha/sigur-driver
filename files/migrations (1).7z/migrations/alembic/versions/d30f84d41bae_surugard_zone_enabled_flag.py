"""surugard_zone_enabled_flag

Revision ID: d30f84d41bae
Revises: ef5420ed5b89
Create Date: 2018-03-24 13:30:34.129000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd30f84d41bae'
down_revision = 'ef5420ed5b89'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        alter table surguard_zone add column enabled bool
    ''')



def downgrade():
    op.execute('''
        alter table surguard_zone drop column enabled
    ''')
