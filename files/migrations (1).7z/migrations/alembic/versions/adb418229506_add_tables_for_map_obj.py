# -*- coding: utf-8 -*-

"""add tables for map_obj

Revision ID: adb418229506
Revises: e79b2bde9a2c
Create Date: 2018-05-28 15:41:07.155000

Скрипт создает таблицы в которых будет хранится содержимое файла map_obj.xml

"""
from alembic import op
from sqlalchemy import Column, BigInteger, Integer, Float, JSON


# revision identifiers, used by Alembic.
revision = 'adb418229506'
down_revision = 'e79b2bde9a2c'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('observed_objects_on_map', 
        Column('id', BigInteger, primary_key=True),
        Column('map_id', BigInteger),
        Column('obsobj_id', BigInteger),
        Column('icon_type', BigInteger),
        Column('icon_id', Integer),
        Column('x', Float),
        Column('y', Float),
        Column('angle', Float)
    )
    
    op.create_table('observed_objects_on_gismap', 
        Column('id', BigInteger, primary_key=True),
        Column('map_id', BigInteger),
        Column('obsobj_id', BigInteger),
        Column('icon_type', BigInteger),
        Column('icon_id', Integer),
        Column('latitude', Float),
        Column('longitude', Float),
        Column('angle', Float),
        Column('geojson', JSON)
    )


def downgrade():
    op.drop_table('observed_objects_on_map')
    op.drop_table('observed_objects_on_gismap')
