"""change tss host patch column name

Revision ID: 4947c1c0a6f5
Revises: 5198ed502d15
Create Date: 2018-11-16 09:33:26.589000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4947c1c0a6f5'
down_revision = '5198ed502d15'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('tss_host', 'patch', new_column_name='path')


def downgrade():
    op.alter_column('tss_host', 'path', new_column_name='patch')
