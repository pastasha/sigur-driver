"""Apollo - adding column for mode in mainpanel

Revision ID: 9710707aaf0f
Revises: c43b274b5981
Create Date: 2018-07-16 09:18:19.812000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9710707aaf0f'
down_revision = '509ea1b89e43'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table apollo_mainpanel
        add column mode text default 'AAN-100'
    """)


def downgrade():
    op.execute("""
        alter table apollo_mainpanel
        drop column mode
    """)
