"""change geozones events equipment

Revision ID: d0f631db735c
Revises: a2f87c69fecd
Create Date: 2018-09-04 16:41:34.588000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd0f631db735c'
down_revision = 'a2f87c69fecd'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set equipment = 'system'
        where code in (6639, 6640)
    """)


def downgrade():
    op.execute("""
        update event_catalog
        set equipment = 'navigation'
        where code in (6639, 6640)
    """)
