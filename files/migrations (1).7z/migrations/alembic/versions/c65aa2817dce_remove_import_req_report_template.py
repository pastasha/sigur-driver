"""remove_import_req_report_template

Revision ID: c65aa2817dce
Revises: b8a71461455d
Create Date: 2018-04-23 12:36:55.620000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c65aa2817dce'
down_revision = '8d16a012a868'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""DELETE FROM reports_templates WHERE reportbased=1003""")


def downgrade():
    pass
