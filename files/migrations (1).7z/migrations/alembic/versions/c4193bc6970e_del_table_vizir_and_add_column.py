"""del table vizir and add column

Revision ID: c4193bc6970e
Revises: cba04779fa0c
Create Date: 2019-02-08 11:05:33.673000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c4193bc6970e'
down_revision = 'cba04779fa0c'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE vizir_server ADD last_date_event varchar(256)')


def downgrade():
    pass
