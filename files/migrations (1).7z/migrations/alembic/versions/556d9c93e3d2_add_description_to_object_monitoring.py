"""add description to object monitoring

Revision ID: 556d9c93e3d2
Revises: 0f2c77f718ca
Create Date: 2018-03-30 13:06:24.253000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '556d9c93e3d2'
down_revision = '0f2c77f718ca'
branch_labels = None
depends_on = None

def upgrade():
    conn = op.get_bind()
    conn.execute("alter table observed_objects add COLUMN IF NOT EXISTS description text")

def downgrade():
    conn = op.get_bind()
    conn.execute("alter table observed_objects drop COLUMN IF EXISTS description")