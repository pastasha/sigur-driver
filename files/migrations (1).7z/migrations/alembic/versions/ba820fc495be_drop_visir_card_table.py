"""drop visir card table

Revision ID: ba820fc495be
Revises: 9c57ac878771
Create Date: 2019-02-18 09:44:50.973000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ba820fc495be'
down_revision = '9c57ac878771'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('vizir_card')


def downgrade():
    pass
