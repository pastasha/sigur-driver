"""add system_ids fields for support in REST

Revision ID: c6c1c77254a0
Revises: c43b274b5981
Create Date: 2018-06-04 14:29:47.155000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c6c1c77254a0'
down_revision = 'c43b274b5981'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("ALTER TABLE common_person ADD COLUMN IF NOT EXISTS subsystem_ids TEXT")
    op.execute("ALTER TABLE observed_objects ADD COLUMN IF NOT EXISTS subsystem_ids TEXT")

def downgrade():
    pass
