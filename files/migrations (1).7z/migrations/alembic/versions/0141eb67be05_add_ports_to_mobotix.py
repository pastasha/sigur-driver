"""add ports to mobotix

Revision ID: 0141eb67be05
Revises: 5d31fc04cc31
Create Date: 2018-08-02 19:38:10.833000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0141eb67be05'
down_revision = '5d31fc04cc31'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('mobotix_cam',
                  sa.Column('port', sa.Integer(), default=80)
                  )
    op.add_column('mobotix_driver',
                  sa.Column('output_port', sa.Integer(), default=8001)
                  )


def downgrade():
    op.drop_column('mobotix_cam', 'port')
    op.drop_column('mobotix_driver', 'output_port')
