# -*- coding: utf-8 -*-

"""plavnik events

Revision ID: 1bd569a74fd8
Revises: 38a807306cc7
Create Date: 2018-08-15 08:45:52.893000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = '1bd569a74fd8'
down_revision = '38a807306cc7'
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )

def upgrade():
    op.bulk_insert(event_catalog, events)


def addEv(code, descr, format, equipment=u'plavnik', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


addEv(9501, 'Устройство на связи', u'[\"Устройство %statement.directObj.name на связи\", \"Устройство на связи\"]')
addEv(9502, 'Связь с устройством потеряна'
      , u'[\"Связь с контроллером %statement.directObj.name потеряна\", \"Связь с устройством потеряна\"]')
addEv(9505, 'Цель обнаружена'
      , u'[\"Цель обнаружена устройством %statement.directObj.name\", \"Цель обнаружена\"]')
addEv(9506, 'Цель движется'
      , u'[\"Координаты цели изменились\", \"Цель движется\"]')
addEv(9507, 'Цель потеряна'
      , u'[\"Цель потеряна\", \"Тихая тревога\"]')


def downgrade():
    pass
