"""set default color and channel in event catalog

Revision ID: 7d5cb295d615
Revises: 0bd165ae2739
Create Date: 2019-04-12 17:51:24.095000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7d5cb295d615'
down_revision = '0bd165ae2739'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set color = '#000000'
        where color is null;
        
        update event_catalog
        set channel = 'notif'
        where channel is null;
        
        update event_catalog
        set equipment = ''
        where equipment is null;
        
        alter table event_catalog
        alter column equipment set default '',
        alter column color set default '#000000',
        alter column channel set default 'notif'
    """)


def downgrade():
    pass
