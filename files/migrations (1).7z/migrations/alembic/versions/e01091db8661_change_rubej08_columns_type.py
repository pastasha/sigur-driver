"""change rubej08 columns type

Revision ID: e01091db8661
Revises: 3d07ce8071cc
Create Date: 2019-06-27 11:26:21.652000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e01091db8661'
down_revision = '3d07ce8071cc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table rubej08_tco
        alter column tamper type bool using (tamper::int)::bool;
    """)


def downgrade():
    pass
