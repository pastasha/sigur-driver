"""change redirect event from code to id

Revision ID: f29fbae438fc
Revises: ee93f912c944
Create Date: 2018-08-27 16:15:48.417000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f29fbae438fc'
down_revision = 'ee93f912c944'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update obsobj_type_event_brg t set code = (
            select id from event_catalog e
            where e.code = t.code and substr(e.remote_guid, 38) = (
                select substr(types.remote_guid, 38) from observed_objects_types types where types.id = t.typeid
            )
        );
        update obsobj_type_event_brg t set newcode = (
            select id from event_catalog e
            where e.code = t.newcode and substr(e.remote_guid, 38) = (
                select substr(types.remote_guid, 38) from observed_objects_types types where types.id = t.typeid
            )
        );
        alter table obsobj_type_event_brg
        rename code to event_id;
        alter table obsobj_type_event_brg
        rename newcode to newevent_id;
    """)


def downgrade():
    op.execute("""
        alter table obsobj_type_event_brg
        rename event_id to code;
        alter table obsobj_type_event_brg
        rename newevent_id to newcode;
        update obsobj_type_event_brg t set code = (select code from event_catalog where id = t.code);
        update obsobj_type_event_brg t set newcode = (select code from event_catalog where id = t.newcode);
    """)
