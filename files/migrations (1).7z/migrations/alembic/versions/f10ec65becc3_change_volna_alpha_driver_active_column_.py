"""change volna alpha driver active column type

Revision ID: f10ec65becc3
Revises: 370608db70d3
Create Date: 2019-06-06 16:47:40.942000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f10ec65becc3'
down_revision = '370608db70d3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table volnaalpha_driver
        alter column active drop default;
        
        alter table volnaalpha_driver
        alter column active type boolean using active::boolean
    """)


def downgrade():
    op.execute("""
        alter table volnaalpha_driver
        alter column active type integer
    """)
