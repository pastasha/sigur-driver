# -*- coding: utf-8 -*-

"""Change operator column types

Revision ID: f8bc0cd4892f
Revises: 5cb28e70179b
Create Date: 2018-03-22 10:55:23.104000

Обновление меняет типы колонок в таблице operators так как при создании определенных операторов брокер может падать.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f8bc0cd4892f'
down_revision = '5cb28e70179b'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('operators', 'pin', type_=sa.types.BigInteger)
    op.alter_column('operators', 'login', type_=sa.types.String)
    op.alter_column('operators', 'pass', type_=sa.types.String)


def downgrade():
    op.alter_column('operators', 'pin', type_=sa.types.SmallInteger)
    op.alter_column('operators', 'login', type_=sa.types.String(32))
    op.alter_column('operators', 'pass', type_=sa.types.String(32))
