"""add column rtsp_ports for system_videoserver

Revision ID: 56b2c0066d5a
Revises: 30dddeaff198
Create Date: 2019-10-14 09:31:19.758295

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '56b2c0066d5a'
down_revision = '30dddeaff198'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE system_videoserver ADD rtsp_ports int default 0')


def downgrade():
    op.execute('ALTER TABLE system_videoserver drop column rtsp_ports')
