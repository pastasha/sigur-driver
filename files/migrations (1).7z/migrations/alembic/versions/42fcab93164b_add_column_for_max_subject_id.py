"""add column for max subject id

Revision ID: 42fcab93164b
Revises: 4a28fbe5f0ba
Create Date: 2018-11-29 21:26:06.920000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '42fcab93164b'
down_revision = '4a28fbe5f0ba'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE suprema_driver ADD subject_max_id int')


def downgrade():
    op.execute('ALTER TABLE suprema_driver drop column subject_max_id')
