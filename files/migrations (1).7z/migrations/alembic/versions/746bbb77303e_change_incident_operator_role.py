"""change incident operator role

Revision ID: 746bbb77303e
Revises: 0e9a3be981c5
Create Date: 2019-07-08 15:56:00.243000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '746bbb77303e'
down_revision = '0e9a3be981c5'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_operator_role
        drop column alert_level,
        drop column zones,
        drop column task_types,
        add column sops json default '[]'::json
    """)


def downgrade():
    pass
