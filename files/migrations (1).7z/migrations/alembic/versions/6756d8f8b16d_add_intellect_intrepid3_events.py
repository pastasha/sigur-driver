# -*- coding: utf-8 -*-

"""add_intellect_intrepid3_events

Revision ID: 6756d8f8b16d
Revises: d5cd09ed8b91
Create Date: 2019-02-16 14:27:24.363000

Добавляет события для оборудования intellect_intrepid3

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date
import json

# revision identifiers, used by Alembic.
revision = '6756d8f8b16d'
down_revision = 'd5cd09ed8b91'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def addEv(code, descr, format, equipment = u"intellect_intrepid3", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })

addEv(7600, u"Порт открыт успешно intrepid3", u"Порт открыт успешно %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7601, u"Ошибка открытия порта intrepid3", u"Ошибка открытия порта %statement.directObj.name", u"intellect_intrepid3", 7, 1)
addEv(7602, u"Начало поиска устройств intrepid3", u"Начало поиска устройств %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7603, u"Окончание поиска устройств intrepid3", u"Окончание поиска устройств %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7604, u"Системное сообщение intrepid3", u"Системное сообщение %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7605, u"Инсталляционная утилита активна  micropoint II", u"Инсталляционная утилита активна %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7606, u"Инсталляционная утилита неактивна  micropoint II", u"Инсталляционная утилита неактивна %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7607, u"Тревога по датчику вскрытия micropoint II", u"Тревога по датчику вскрытия %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7608, u"Нормализация датчика вскрытия micropoint II", u"Нормализация датчика вскрытия %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7609, u"Программная тревога micropoint II", u"Программная тревога %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7610, u"Конец программной тревоги micropoint II", u"Конец программной тревоги %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7611, u"Связь потеряна micropoint II", u"Связь потеряна %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7612, u"Связь восстановлена micropoint II", u"В норме %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7613, u"Несоответствие типа устройства micropoint II", u"Несоответствие типа устройства %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7614, u"Поставлен на охрану micropoint II", u"Поставлен на охрану %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7615, u"Снят с охраны micropoint II", u"Снят с охраны %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7616, u"Системное сообщение micropoint II", u"Системное сообщение %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7617, u"Неисправность кабеля micropoint II", u"Неисправность кабеля %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7618, u"Связь потеряна с кабелем micropoint II", u"Связь потеряна с кабелем %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7619, u"В норме кабель micropoint II", u"В норме кабель %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7620, u"Несоответствие типа устройств кабеля micropoint II", u"Несоответствие типа устройств %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7621, u"Тревога сегмента micropoint II", u"Тревога сегмента %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7622, u"Все тревоги сегмента micropoint II обработаны", u"Все тревоги сегмента %statement.directObj.name обработаны", u"intellect_intrepid3", 7, 0)
addEv(7623, u"Тревога сегмента micropoint II", u"Тревога сегмента %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7624, u"Связь потеряна сегмент micropoint II", u"Связь с сегментом %statement.directObj.name потеряна", u"intellect_intrepid3", 7, 3)
addEv(7625, u"В норме сегмент micropoint II", u"В норме сегмент %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7626, u"Несоответствие типа устройств сегмента micropoint II", u"Несоответствие типа устройств сегмента %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7627, u"Тревога обработана сегмент micropoint II", u"Тревога сегмента %statement.directObj.name обработана", u"intellect_intrepid3", 7, 0)
addEv(7628, u"Системное сообщение сегмент micropoint II", u"Системное сообщение сегмента %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7629, u"Системное сообщение aim II", u"Системное сообщение %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7630, u"Тревога по датчику вскрытия aim II", u"Тревога по датчику вскрытия %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7631, u"Нормализация датчика вскрытия aim II", u"Нормализация датчика вскрытия %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7632, u"Связь потеряна aim II", u"Связь потеряна %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7633, u"В норме aim II", u"В норме %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7634, u"Несоответствие типа устройств aim II", u"Несоответствие типа устройств %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7635, u"Поставлен на охрану aim II", u"Поставлен на охрану %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7636, u"Снят с охраны aim II", u"Снят с охраны %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7637, u"Тревога тревожный вход aim II", u"Тревога %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7638, u"Связь потеряна тревожный вход aim II", u"Связь потеряна %statement.directObj.name", u"intellect_intrepid3", 7, 3)
addEv(7639, u"В норме тревожный вход aim II", u"В норме %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7640, u"Несоответствие типа устройств тревожный вход aim II", u"Несоответствие типа устройств %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7641, u"Все тревоги обработаны тревожный вход aim II", u"Все тревоги %statement.directObj.name обработаны", u"intellect_intrepid3", 7, 0)
addEv(7642, u"Поставлен на охрану тревожный вход aim II", u"Поставлен на охрану %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7643, u"Снят с охраны тревожный вход aim II", u"Снят с охраны %statement.directObj.name", u"intellect_intrepid3", 7, 0)
addEv(7644, u"Системное сообщение тревожный вход aim II", u"Системное сообщение %statement.directObj.name", u"intellect_intrepid3", 7, 0)
	
def upgrade():
    op.execute('delete from event_catalog where code >= 7600 and code <=7634')
    op.bulk_insert(event_catalog, events)


def downgrade():
    op.execute('delete from event_catalog where code >= 7600 and code <=7634')
