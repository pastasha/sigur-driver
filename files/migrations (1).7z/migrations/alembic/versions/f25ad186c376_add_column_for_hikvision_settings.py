"""add_column_for_hikvision_settings

Revision ID: f25ad186c376
Revises: 9c8fee833f9a
Create Date: 2018-11-13 15:10:03.464000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f25ad186c376'
down_revision = '9c8fee833f9a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE hikvision_cam ADD settings int')


def downgrade():
    op.execute('ALTER TABLE hikvision_cam drop column settings')
