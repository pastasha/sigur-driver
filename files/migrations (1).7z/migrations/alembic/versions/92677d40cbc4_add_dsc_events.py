"""add dsc events

Revision ID: 92677d40cbc4
Revises: 114c9711d6b2
Create Date: 2019-10-28 09:38:50.663135

"""
from alembic import op
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '92677d40cbc4'
down_revision = '114c9711d6b2'
branch_labels = None
depends_on = None

events = []


event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'dsc', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(15501, 'Связь с панелью установлена', u'Связь с панелью %statement.directObj.name установлена')
add_event(15502, 'Связь с панелью потеряна', u'Связь с панелью %statement.directObj.name потеряна')
add_event(15503, 'Ошибка выполнения команды', u'Ошибка выполнения команды', level=1)
add_event(15504, 'Системная ошибка панели', u'Системная ошибка панели %statement.directObj.name', level=2)
add_event(15504, 'Кольцо в телефонной линии', u'Кольцо в телефонной линии', level=2)
add_event(15511, 'Тревога зоны', u'Тревога зоны %statement.directObj.name')
add_event(15512, 'Зона восстановлена', u'Зона %statement.directObj.name восстановлена')
add_event(15513, 'Тревога тампера зоны', u'Тревога тампера зоны %statement.directObj.name')
add_event(15514, 'Сброс тревоги тампера', u'Сброс тревоги тампера')
add_event(15515, 'Неисправность зоны', u'Неисправность зоны %statement.directObj.name')
add_event(15516, 'Неисправность восстановлена', u'Неисправность восстановлена')
add_event(15519, 'Зона не готова', u'Зона %statement.directObj.name не готова')
add_event(15520, 'Зона готова', u'Зона %statement.directObj.name готова')
add_event(15530, 'Тревога под принуждением', u'Тревога под принуждением')
add_event(15531, 'Нажата кнопка пожарной тревоги', u'Нажата кнопка пожарной тревоги', level=2)
add_event(15532, 'Кнопка пожарной тревоги восстановлена', u'Кнопка пожарной тревоги восстановлена')
add_event(15533, 'Нажата кнопка тревоги', u'Нажата кнопка тревоги', level=2)
add_event(15534, 'Кнопка тревоги восстановлена', u'Кнопка тревоги восстановлена')
add_event(15535, 'Нажата кнопка паники', u'Нажата кнопка паники', level=2)
add_event(15536, 'Кнопка паники восстановлена', u'Кнопка паники восстановлена')
add_event(15541, 'Тревога дополнительного входа', u'Тревога дополнительного входа', level=2)
add_event(15542, 'Дополнительный вход восстановлен', u'Дополнительный вход восстановлен')
add_event(15543, 'Раздел полностью поставлен', u'Раздел %statement.directObj.name полностью поставлен')
add_event(15543, 'Раздел поставлен в режиме "Дома"', u'Раздел %statement.directObj.name поставлен в режиме "Дома"')
add_event(15544, 'Раздел полностью поставлен без задержки',
          u'Раздел %statement.directObj.name полностью поставлен без задержки')
add_event(15545, 'Раздел поставлен в режиме "Дома" без задержки',
          u'Раздел %statement.directObj.name поставлен в режиме "Дома" без задержки')
add_event(15560, 'Раздел готов к постановке', u'Раздел %statement.directObj.name готов к постановке')
add_event(15561, 'Раздел не готов', u'Раздел %statement.directObj.name не готов')
add_event(15563, 'Раздел готов к постановке с обходом зон',
          u'Раздел %statement.directObj.name готов к постановке с обходом зон')
add_event(15564, 'Тревога раздела', u'Тревога раздела %statement.directObj.name', level=2)
add_event(15565, 'Раздел снят с охраны', u'Раздел %statement.directObj.name снят с охраны')
add_event(15566, 'Задержка на выход', u'Задержка на выход')
add_event(15567, 'Задержка на вход', u'Задержка на вход')
add_event(15568, 'Клавиатура управления разделов заблокирована', u'Клавиатура управления разделов заблокирована')
add_event(15569, 'Клавиатура управления разделом отключена', u'Клавиатура управления разделом отключена')
add_event(15570, 'Активирована команда управления выходом', u'Активирована команда управления выходом')
add_event(15580, 'Неверный код пользователя', u'Неверный код пользователя', level=1)
add_event(15581, 'Команда управления не может быть выполнена', u'Команда управления не может быть выполнена')
add_event(15582, 'Раздел не поставлен на охрану', u'Раздел %statement.directObj.name не поставлен на охрану')
add_event(15583, 'Раздел занят', u'Раздел %statement.directObj.name занят')
add_event(15610, 'Раздел поставлен на охрану пользователем поcле задержки',
          u'Раздел %statement.directObj.name поставлен на охрану пользователем поcле задержки')
add_event(15611, 'Раздел поставлен под охрану специальной командой',
          u'Раздел %statement.directObj.name поставлен под охрану специальной командой')
add_event(15612, 'Раздел частично поставлен', u'Раздел %statement.directObj.name частично поставлен')
add_event(15660, 'Раздел снят пользователем', u'Раздел %statement.directObj.name снят пользователем')
add_event(15661, 'Раздел снят специальной командой', u'Раздел %statement.directObj.name снят специальной командой',
          level=1)
add_event(15710, 'Неисправность батареи панели', u'Неисправность батареи панели %statement.directObj.name')
add_event(15711, 'Батарея панели восстановлена', u'Батарея панели %statement.directObj.name восстановлена')
add_event(15712, 'Неисправность внешнего питания панели',
          u'Неисправность внешнего питания панели %statement.directObj.name', level=1)
add_event(15713, 'Питание панели восстановлено', u'Питание панели %statement.directObj.name восстановлено')
add_event(15716, 'Неисправность оповещателя панели', u'Неисправность оповещателя панели %statement.directObj.name',
          level=1)
add_event(15717, 'Оповещатель панели исправен', u'Оповещатель панели %statement.directObj.name исправен')
add_event(15720, 'Неисправность первой телефонной линии', u'Неисправность первой телефонной линии', level=1)
add_event(15721, 'Первая телефонная линия исправна', u'Первая телефонная линия исправна')
add_event(15722, 'Неисправность второй телефонной линии', u'Неисправность второй телефонной линии', level=1)
add_event(15723, 'Вторая телефонная линия восстановлена', u'Вторая телефонная линия восстановлена')
add_event(15724, 'Нет связи со станцией мониторинга', u'Нет связи со станцией мониторинга', level=1)
add_event(15726, 'Буфер событий в панели переполнен', u'Буфер событий в панели %statement.directObj.name переполнен',
          level=1)
add_event(15731, 'Низкий заряд батареи беспроводного извещателя', u'Низкий заряд батареи беспроводного извещателя',
          level=1)
add_event(15732, 'Батарея беспроводного извещателя восстановлена', u'Батарея беспроводного извещателя восстановлена')
add_event(15735, 'Низкий заряд беспроводной кнопки', u'Низкий заряд беспроводной кнопки', level=1)
add_event(15736, 'Батарея беспроводной кнопки восстановлена', u'Батарея беспроводной кнопки восстановлена')
add_event(15737, 'Низкий заряд переносной клавиатуры', u'Низкий заряд переносной клавиатуры', level=1)
add_event(15738, 'Батарея переносной клавиатуры восстановлена', u'Батарея переносной клавиатуры восстановлена')
add_event(15739, 'Вскрытие тампера панели', u'Вскрытие тампера панели %statement.directObj.name', level=2)
add_event(15740, 'Тампер панели восстановлен', u'Тампер панели %statement.directObj.name восстановлен')
add_event(15741, 'Неисправен модуль автоматизации', u'Неисправен модуль автоматизации', level=1)
add_event(15742, 'Модуль автоматизации восстановлен', u'Модуль автоматизации восстановлен')
add_event(15750, 'Раздел неисправен', u'Раздел %statement.directObj.name неисправен', level=1)
add_event(15751, 'Неисправность раздела устранена', u'Неисправность раздела %statement.directObj.name устранена')
add_event(15752, 'Пожарная тревога', u'Пожарная тревога', level=3)
add_event(15753, 'Отмена пожарной тревоги', u'Отмена пожарной тревоги')


def downgrade():
    op.execute("""
        delete from event_catalog where code >= 15500 and code < 15800
    """)
