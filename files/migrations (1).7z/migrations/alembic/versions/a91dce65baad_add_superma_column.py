"""add_superma_column

Revision ID: a91dce65baad
Revises: 3839b781befd
Create Date: 2018-09-23 17:21:10.731000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a91dce65baad'
down_revision = '3839b781befd'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""INSERT INTO equipments(name,enabled) VALUES('suprema',TRUE)""")


def downgrade():
    op.execute("""
        DELETE FROM equipments WHERE name = 'suprema';
        DELETE FROM equipment_generators WHERE equipment = 'suprema';
    """)
