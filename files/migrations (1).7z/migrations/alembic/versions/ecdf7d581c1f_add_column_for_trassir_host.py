"""add column for trassir_host

Revision ID: ecdf7d581c1f
Revises: cea78eff5a3e
Create Date: 2019-12-19 11:09:42.013026

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ecdf7d581c1f'
down_revision = 'cea78eff5a3e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table trassir_host
        add column events_timestamp text default '{
            "event": 0,
            "autoevent": 0
        }';
    """)


def downgrade():
    op.execute('ALTER TABLE trassir_host drop column events_timestamp')
