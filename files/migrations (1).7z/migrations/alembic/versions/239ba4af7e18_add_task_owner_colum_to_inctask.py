"""add_task_owner_colum_to_inctask

Revision ID: 239ba4af7e18
Revises: 223c905004ca
Create Date: 2019-10-07 11:22:10.797508

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '239ba4af7e18'
down_revision = '223c905004ca'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_task_register
        add column task_owner int default 0;
        
        update incidents.incident_task_register
        set task_owner = 0;
    """)


def downgrade():
    op.execute("""
        alter table incidents.incident_task_register
        drop column task_owner;
    """)
