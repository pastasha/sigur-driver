"""edit column for apollo

Revision ID: f09d39d6dba2
Revises: 41b1ffbe24ed
Create Date: 2018-12-05 11:39:51.891000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f09d39d6dba2'
down_revision = '41b1ffbe24ed'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    conn.execute("alter table apollo_accesslink alter column command type bool")
    conn.execute("alter table apollo_accesslink alter column download type bool")
    conn.execute("alter table apollo_area alter column lock type bool")
    conn.execute("alter table apollo_area alter column inblockaccess type bool")
    conn.execute("alter table apollo_area alter column twoman type bool")
    conn.execute("alter table apollo_mainpanelparams alter column datastart type bool")
    conn.execute("alter table apollo_mainpanelparams alter column dataend type bool")
    conn.execute("alter table apollo_mainpanelparams alter column apb type bool")
    conn.execute("alter table apollo_mainpanelparams alter column onlypin type bool")
    conn.execute("alter table apollo_mainpanelparams alter column sixzones type bool")
    conn.execute("alter table apollo_mainpanelparams alter column twoatver type bool")
    conn.execute("alter table apollo_mainpanelparams alter column biometry type bool")
    conn.execute("alter table apollo_mainpanelparams alter column rejectaccessreaders type bool")
    conn.execute("alter table apollo_mainpanelparams alter column exclusionreaderslist type bool")
    conn.execute("alter table apollo_mainpanelparams alter column printname type bool")
    conn.execute("alter table apollo_mainpanelparams alter column timedapb type bool")
    conn.execute("alter table apollo_input alter column shunt type bool")
    conn.execute("alter table apollo_output alter column multy type bool")


def downgrade():
    conn = op.get_bind()
    conn.execute("alter table apollo_accesslink alter column command type int")
    conn.execute("alter table apollo_accesslink alter column download type int")
    conn.execute("alter table apollo_area alter column lock type int")
    conn.execute("alter table apollo_area alter column inblockaccess type int")
    conn.execute("alter table apollo_area alter column twoman type int")
    conn.execute("alter table apollo_mainpanelparams alter column datastart type int")
    conn.execute("alter table apollo_mainpanelparams alter column dataend type int")
    conn.execute("alter table apollo_mainpanelparams alter column apb type int")
    conn.execute("alter table apollo_mainpanelparams alter column onlypin type int")
    conn.execute("alter table apollo_mainpanelparams alter column sixzones type int")
    conn.execute("alter table apollo_mainpanelparams alter column twoatver type int")
    conn.execute("alter table apollo_mainpanelparams alter column biometry type int")
    conn.execute("alter table apollo_mainpanelparams alter column rejectaccessreaders type int")
    conn.execute("alter table apollo_mainpanelparams alter column exclusionreaderslist type int")
    conn.execute("alter table apollo_mainpanelparams alter column printname type int")
    conn.execute("alter table apollo_mainpanelparams alter column timedapb type int")
    conn.execute("alter table apollo_input alter column shunt type int")
    conn.execute("alter table apollo_output alter column multy type int")
