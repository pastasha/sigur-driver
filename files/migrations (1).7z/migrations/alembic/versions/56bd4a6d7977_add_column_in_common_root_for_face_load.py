"""add column in common_root for face load

Revision ID: 56bd4a6d7977
Revises: d4f90bf4bbdc
Create Date: 2019-04-01 10:56:38.445000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '56bd4a6d7977'
down_revision = 'd4f90bf4bbdc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_root
        add column create_person_from_third_face boolean default false
    """)


def downgrade():
    op.execute("""
        alter table common_root
        drop column create_person_from_third_face
    """)
