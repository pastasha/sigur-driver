# -*- coding: utf-8 -*-

"""add default for remote_guid

Revision ID: 2a1ead1d3cf9
Revises: 7e3cec671cf0
Create Date: 2018-09-14 09:24:04.066000

Добавляет дефолтное значение для всех колонок remote_guid. Это будет удобно при добавлении новых событий в каталог или при написании разных
конвертеров под объекты

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2a1ead1d3cf9'
down_revision = '7e3cec671cf0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table observed_objects
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table observed_objects_types
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table map_layer
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table oo_table
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table opright
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table operators
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table event_table
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table handler_group
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table obsobj_type_event_brg
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table observed_objects_on_map
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
        
        alter table observed_objects_on_gismap
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid;
    """)
    
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'" % equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            conn.execute("alter table %s alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid" % t)


def downgrade():
    pass
