"""trassir_subserver_addr

Revision ID: 785f4cd6f366
Revises: 2e3a8911c39e
Create Date: 2018-12-24 18:19:24.548000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '785f4cd6f366'
down_revision = '2e3a8911c39e'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('trassir_cam', sa.Column('subserver_addr', sa.String(), default=""))


def downgrade():
    op.drop_column('trassir_cam', 'subserver_addr')
