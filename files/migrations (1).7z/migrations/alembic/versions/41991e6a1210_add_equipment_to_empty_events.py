"""add_equipment_to_empty_events

Revision ID: 41991e6a1210
Revises: f5d03f96de7b
Create Date: 2019-09-19 17:26:49.165381

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '41991e6a1210'
down_revision = 'f5d03f96de7b'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""UPDATE event_catalog SET equipment='RusGuard' WHERE code=345""")
    op.execute("""UPDATE event_catalog SET equipment='pce' WHERE code=48""")
    op.execute("""UPDATE event_catalog SET equipment='pce' WHERE code=2""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=1000""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=2000""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=7777777""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=820""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=821""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=705""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=822""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=823""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=824""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=825""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=826""")
    op.execute("""UPDATE event_catalog SET equipment='Система' WHERE code=827""")
    op.execute("""UPDATE event_catalog SET equipment='hikvision' WHERE code=692""")
    op.execute("""UPDATE event_catalog SET equipment='hikvision' WHERE code=693""")
    op.execute("""UPDATE event_catalog SET equipment='hikvision' WHERE code=694""")

    op.execute("""DELETE FROM event_catalog WHERE code IN (1, 810, 811)""")




def downgrade():
    pass
