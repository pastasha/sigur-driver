"""add_tasktomobapp_param_to_inctask_table

Revision ID: d9078b126fbd
Revises: 3635f8dcd9de
Create Date: 2019-10-01 15:11:41.527488

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd9078b126fbd'
down_revision = '3635f8dcd9de'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_task
        add column task_to_mobileapp bool default False;
        
        update incidents.incident_task
        set task_to_mobileapp = False;
    """)



def downgrade():
    op.execute("""
        alter table incidents.incident_task
        drop column task_to_mobileapp;
    """)

