"""delete srv_handlers column

Revision ID: d71d8b6ba418
Revises: 7d460bb301c1
Create Date: 2019-07-03 13:29:14.650000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd71d8b6ba418'
down_revision = '7d460bb301c1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop view common_subject_plus;
        create view common_subject_plus as
        select subj.uniid, subj.flags, subj.devparent, subj.devaddr, subj.department, subj.photo,
        subj.name, subj.schedule, subj.organization, subj.lastarea, subj.last_pass_event,
        subj.department2, subj.external_id, subj.subsystem_ids, (
            select common_person.description
            from common_person
            where common_person.devparent = subj.uniid and (common_person.flags & 1::bigint) = 0
            union
            select common_mobile.description
            from common_mobile
            where common_mobile.devparent = subj.uniid AND (common_mobile.flags & 1::bigint) = 0
        limit 1) AS description
        from common_subject subj;
    """)
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'" % equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            conn.execute("alter table %s drop column if exists srv_handlers" % t)


def downgrade():
    pass
