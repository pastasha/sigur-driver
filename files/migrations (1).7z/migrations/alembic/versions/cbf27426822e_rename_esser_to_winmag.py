"""rename esser to winmag

Revision ID: cbf27426822e
Revises: 73a01bae1198
Create Date: 2018-12-03 17:05:22.742000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cbf27426822e'
down_revision = '73a01bae1198'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table esser_root rename to winmag_root;
        alter table esser_firedetector rename to winmag_firedetector;
        alter sequence esser_root_uniid_seq rename to winmag_root_uniid_seq;
        alter sequence esser_firedetector_uniid_seq rename to winmag_firedetector_uniid_seq;
        
        update equipments set name = 'winmag' where name = 'esser';
    """)


def downgrade():
    op.execute("""
        alter table winmag_root rename to esser_root;
        alter table winmag_firedetector rename to esser_firedetector;
        alter sequence winmag_root_uniid_seq rename to esser_root_uniid_seq;
        alter sequence winmag_firedetector_uniid_seq rename to esser_firedetector_uniid_seq;
        
        update equipments set name = 'esser' where name = 'winmag';
    """)
