# -*- coding: utf-8 -*-
"""baga_events_trassir

Revision ID: b9aadafc5f51
Revises: bbc5af9d7f7a
Create Date: 2018-09-26 10:01:00.853000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b9aadafc5f51'
down_revision = 'bbc5af9d7f7a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"UPDATE event_catalog SET format='[\"Установлена связь с видеокамерой  %statement.directObj.name\",\"\"]' WHERE code=7007")
    op.execute(u"UPDATE event_catalog SET format='[\"Связь с видеокамерой %statement.directObj.name потеряна\",\"\"]' WHERE code=7008")
    op.execute(u"UPDATE event_catalog SET format='[\"Связь с видеокамерой %statement.directObj.name восстановлена\",\"\"]' WHERE code=7009")
    op.execute(u"UPDATE event_catalog SET format='[\"Нет связи с видеокамерой  %statement.directObj.name\",\"\"]' WHERE code=7010")
    op.execute(u"UPDATE event_catalog SET format='[\"Включена запись на  %statement.directObj.name\",\"\"]' WHERE code=7011")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружено лицо %statement.directObj.name\",\"\"]' WHERE code=7012")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружен дым %statement.directObj.name\",\"\"]' WHERE code=7013")
    op.execute(u"UPDATE event_catalog SET format='[\"Задымление остановлено %statement.directObj.name\",\"\"]' WHERE code=7014")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружен огонь %statement.directObj.name\",\"\"]' WHERE code=7015")
    op.execute(u"UPDATE event_catalog SET format='[\"Пламя остановлено %statement.directObj.name\",\"\"]' WHERE code=7016")
    op.execute(u"UPDATE event_catalog SET format='[\"Перешел границу из A в B %statement.directObj.name\",\"\"]' WHERE code=7017")
    op.execute(u"UPDATE event_catalog SET format='[\"Перешел границу из B в A %statement.directObj.name\",\"\"]' WHERE code=7018")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружено движение %statement.directObj.name\",\"\"]' WHERE code=7019")
    op.execute(u"UPDATE event_catalog SET format='[\"Движение остановлено %statement.directObj.name\",\"\"]' WHERE code=7020")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружен вход в зону %statement.directObj.name\",\"\"]' WHERE code=7021")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружено пересечение границы %statement.directObj.name\",\"\"]' WHERE code=7022")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружен человек %statement.directObj.name\",\"\"]' WHERE code=7023")
    op.execute(u"UPDATE event_catalog SET format='[\"Смещение камеры %statement.directObj.name\",\"\"]' WHERE code=7024")
    op.execute(u"UPDATE event_catalog SET format='[\"Дефокусировка камеры %statement.directObj.name\",\"\"]' WHERE code=7025")
    op.execute(u"UPDATE event_catalog SET format='[\"Засветка камеры %statement.directObj.name\",\"\"]' WHERE code=7026")
    op.execute(u"UPDATE event_catalog SET format='[\"Заслон объектива %statement.directObj.name\",\"\"]' WHERE code=7027")
    op.execute(u"UPDATE event_catalog SET format='[\"Предмет оставлен %statement.directObj.name\",\"\"]' WHERE code=7028")
    op.execute(u"UPDATE event_catalog SET format='[\"Предмет исчез %statement.directObj.name\",\"\"]' WHERE code=7029")
    op.execute(u"UPDATE event_catalog SET format='[\"Оставленный предмет %statement.directObj.name\",\"\"]' WHERE code=7030")
    op.execute(u"UPDATE event_catalog SET format='[\"Обнаружен звук %statement.directObj.name\",\"\"]' WHERE code=7031")
    op.execute(u"UPDATE event_catalog SET format='[\"Звук прекратился %statement.directObj.name\",\"\"]' WHERE code=7032")

def downgrade():
    pass
