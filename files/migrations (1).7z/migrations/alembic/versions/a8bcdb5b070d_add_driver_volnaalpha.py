# -*- coding: utf-8 -*-
"""add driver volnaalpha

Revision ID: a8bcdb5b070d
Revises: 3be4f0e2581f
Create Date: 2019-03-03 10:21:21.642800

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date



# revision identifiers, used by Alembic.
revision = 'a8bcdb5b070d'
down_revision = 'c5b45194d687'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def addEv(code, descr, format, equipment = u"volnaalpha", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })


addEv(7201, u"Подключение к системе", u"Система %statement.directObj.name подключена")
addEv(7202, u"Ошибка протокола обмена", u"Ошибка обмена с системой %statement.directObj.name", level=2)
addEv(7203, u"Сбой связи", u"Сбой связи с системой %statement.directObj.name", level=2)
addEv(7204, u"Сбой драйвера", u"Сбой драйвера взаимодействия с системой %statement.directObj.name", level=3)
addEv(7205, u"Отключение от системы", u"Система %statement.directObj.name отключена", level=1)
addEv(7206, u"Ошибка авторизации драйвера", u"Неуспешная авторизация драйвера в системе %statement.directObj.name", level=1)
addEv(7207, u"Потеря сессии подключения", u"Потеря сессии подключения к системе %statement.directObj.name", level=3)

addEv(7220, u"Зона отключена", u"Зона %statement.directObj.name отключена")
addEv(7221, u"Зона поставлена на охрану", u"Зона %statement.directObj.name поставлена на охрану")
addEv(7222, u"Внимание зоны", u"Зона %statement.directObj.name - внимание", level=1)
addEv(7223, u"Тревога зоны", u"Зона %statement.directObj.name - тревога!", level=3)
addEv(7224, u"Обрыв зоны", u"Зона %statement.directObj.name - обрыв!", level=3)
addEv(7225, u"Зона готова", u"Нет активности в зоне %statement.directObj.name")
addEv(7226, u"Зона не готова", u"Активность в зоне %statement.directObj.name")



def upgrade():
    """
    Добавление таблиц данных для драйвера Волна Альфа
    :return: None
    """
    op.execute('''insert into equipments(name, enabled)
        values('volnaalpha', true)
    ''')
    op.create_equipment('volnaalpha_driver', [
            ('description', 'text', ''),
            ('ports_addr', 'text', ''),
            ('va_url', 'text', ''),
            ('poll_timeout', 'int', 'default 1'),
            ('va_user', 'text', ''),
            ('va_password', 'text', ''),
            ('active', 'int', 'default 1'),
            ('discret', 'float', 'default 0.997'),
            ('geometry', 'text', '')
        ], []
    )
    op.create_equipment('volnaalpha_zone', [
            ('description', 'text', ""),
            ('external_id', 'text', ""),
            ('fiberX1', 'float', "default 0.0"),
            ('fiberX2', 'float', "default 0.0")
        ], [], True
    )
    op.bulk_insert(event_catalog, events)




def downgrade():
    pass
