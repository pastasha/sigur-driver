"""add coloumn key to orioniso part

Revision ID: 1f0d6cfbf399
Revises: 110a02e54595
Create Date: 2018-03-19 14:57:41.757000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1f0d6cfbf399'
down_revision = '26ee8b194f06'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE orioniso_grouppart ADD key bigint')
    op.execute('ALTER TABLE orioniso_part ADD key bigint')
    op.execute('ALTER TABLE orioniso_control ADD column id_array text')


def downgrade():
    op.execute('ALTER TABLE orioniso_grouppart drop column key')
    op.execute('ALTER TABLE orioniso_part drop column key')
    op.execute('ALTER TABLE orioniso_control drop column id_array')
