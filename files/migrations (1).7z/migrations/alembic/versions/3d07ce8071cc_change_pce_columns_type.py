"""change pce columns type

Revision ID: 3d07ce8071cc
Revises: 4fcca59ac1cd
Create Date: 2019-06-27 09:56:16.378000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3d07ce8071cc'
down_revision = '4fcca59ac1cd'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table pce_display
        alter column dontgenerateevents type bool using (dontgenerateevents::int)::bool;
        
        alter table pce_emitter
        alter column useinitstate drop default,
        alter column useinitstate type bool using (useinitstate::int)::bool,
        alter column useinitstate set default false;
        
        alter table pce_input
        alter column armed type bool using (armed::int)::bool,
        alter column autorepair type bool using (autorepair::int)::bool,
        alter column dontgenerateevents type bool using (dontgenerateevents::int)::bool,
        alter column reverseactive type bool using (reverseactive::int)::bool;
        
        alter table pce_instr
        alter column delayfield type bool using (delayfield::int)::bool,
        alter column timefield type bool using (timefield::int)::bool,
        alter column param1field type bool using (param1field::int)::bool,
        alter column param2field type bool using (param2field::int)::bool,
        alter column param3field type bool using (param3field::int)::bool,
        alter column param4field type bool using (param4field::int)::bool;
        
        alter table pce_output
        alter column dontgenerateevents type bool using (dontgenerateevents::int)::bool,
        alter column powerdownonarm type bool using (powerdownonarm::int)::bool,
        alter column initstatefield type bool using (initstatefield::int)::bool;
        
        alter table pce_pceright
        alter column enableallowantipassback type bool using (enableallowantipassback::int)::bool,
        alter column enableallowcommand type bool using (enableallowcommand::int)::bool;
        
        alter table pce_reader
        alter column dontgenerateevents type bool using (dontgenerateevents::int)::bool,
        alter column asstring type bool using (asstring::int)::bool;
        
        alter table pce_schedule
        alter column enablevdays type bool using (enablevdays::int)::bool,
        alter column generatetzevents type bool using (generatetzevents::int)::bool;
        
        alter table pce_statehandler
        alter column alarmlistenable drop default,
        alter column needconfirmenable drop default,
        alter column alarmlistenable type bool using (alarmlistenable::int)::bool,
        alter column needconfirmenable type bool using (needconfirmenable::int)::bool,
        alter column alarmlistenable set default false,
        alter column needconfirmenable set default false;
    """)


def downgrade():
    pass
