"""make auto complete id remote_site

Revision ID: 09b4d3f32a74
Revises: 58d643a68dec
Create Date: 2018-06-26 16:15:12.525000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '09b4d3f32a74'
down_revision = '58d643a68dec'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        UPDATE remote_site SET id = left(md5(random()::text), 8)
    """)

def downgrade():
    pass