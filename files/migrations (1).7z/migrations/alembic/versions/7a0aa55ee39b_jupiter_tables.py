"""jupiter_tables

Revision ID: 7a0aa55ee39b
Revises: 41991e6a1210
Create Date: 2019-09-09 12:03:50.455000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7a0aa55ee39b'
down_revision = '41991e6a1210'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        insert into equipments(name, enabled) values('jupiter', true)
        ''')

    op.create_equipment('jupiter_root', [
        ('description', 'text', ''),
        ('ports_addr', 'text', ''),
        ('ip_addr', 'text', ''),
        ('port', 'int', 'default 9900'),
        ('login', 'text', ''),
        ('password', 'text', ''),
        ('poll_time', 'int', 'default 5'),
        ('active', 'boolean', 'default true'),
        ('synchronization', 'int', 'default 0')
    ], [], False)

    op.create_equipment('jupiter_devicetype', [
        ('description', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_tailtype', [
        ('description', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_equipmenttype', [
        ('description', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_objecttype', [
        ('description', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_object', [
        ('description', 'text', ''),
        ('remark', 'text', ''),
        ('type', 'int', ''),
        ('external_id', 'text', ''),
        ('external_number', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_device', [
        ('description', 'text', ''),
        ('type', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_section', [
        ('description', 'text', ''),
        ('type', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('jupiter_zone', [
        ('description', 'text', ''),
        ('type', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)


def downgrade():
    op.execute('''
        delete from equipments where name='jupiter';
        drop table jupiter_zone;
        drop table jupiter_section;
        drop table jupiter_device;
        drop table jupiter_object;
        drop table jupiter_objecttype;
        drop table jupiter_equipmenttype;
        drop table jupiter_tailtype;
        drop table jupiter_devicetype;
        drop table jupiter_root
    ''')

