"""create sequence for equipment

Revision ID: a97ab1427500
Revises: a940091db679
Create Date: 2018-03-12 17:52:41.147000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a97ab1427500'
down_revision = 'a940091db679'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'"%equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            if t == 'common_department2' or t == 'common_phone' or t == 'common_phonecategory':
                continue
            s = conn.execute('select coalesce(max(uniid), 0) + 1 from %s'%t)
            s = s.fetchall()[0][0]
            conn.execute('create sequence if not exists %s_uniid_seq start %s'%(t, s))
            conn.execute("alter table %s alter column uniid set default nextval('%s_uniid_seq')"%(t, t))
    op.drop_table('equipment_generators')


def downgrade():
    op.create_table(
        'equipment_generators',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('equipment', sa.String(256), sa.ForeignKey('equipments.name', ondelete='CASCADE')),
        sa.Column('tbl', sa.String(64)),
        sa.Column('col', sa.String(64)),
        sa.Column('value', sa.String(256)),
        sa.Column('type', sa.String)
    )
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'"%equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            if t == 'common_department2' or t == 'common_phone' or t == 'common_phonecategory':
                continue
            s = conn.execute('select coalesce(max(uniid), 0) + 1 from %s'%t)
            s = s.fetchall()[0][0]
            conn.execute('alter table %s alter column uniid drop default'%t)
            conn.execute('drop sequence %s_uniid_seq'%t)
            conn.execute("""
                insert into equipment_generators(equipment, tbl, col, value, type)
                values ('%s', '%s', 'uniId', %s, 'AutoIncrement(1, MAX_UINT64)')
            """%(equip, t, s))
