"""fix requisitions static path

Revision ID: a405dce8d9e8
Revises: 4ae1acc1577e
Create Date: 2019-01-16 16:05:35.825000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a405dce8d9e8'
down_revision = '785f4cd6f366'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("update requisition_types set form = replace(form, '/static_folder/', '/static/') where form like '%/static_folder/%'")

def downgrade():
    op.execute("update requisition_types set form = replace(form, '/static/', '/static_folder/') where form like '%/static/%'")
