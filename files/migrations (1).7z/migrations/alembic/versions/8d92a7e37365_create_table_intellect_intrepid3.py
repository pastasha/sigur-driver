"""create_table_intellect_intrepid3

Revision ID: 8d92a7e37365
Revises: 2ecaa7e0af6c
Create Date: 2019-02-16 12:46:21.006000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8d92a7e37365'
down_revision = '2ecaa7e0af6c'
branch_labels = None
depends_on = None


def upgrade():
	op.create_equipment('intellect_intrepid3',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),[], 'True'
	)


def downgrade():
    op.drop_table('intellect_intrepid3')
