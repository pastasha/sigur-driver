"""add colimn for securos_idobject

Revision ID: 1f84736cc0fc
Revises: 38ed023e13d1
Create Date: 2019-05-15 17:31:42.468000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1f84736cc0fc'
down_revision = '38ed023e13d1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE securos_idobject ADD cam bigint')


def downgrade():
    op.execute('ALTER TABLE securos_idobject drop column cam')
