"""fix type of surgard panel state column

Revision ID: b2258059c063
Revises: 0141eb67be05
Create Date: 2018-08-21 12:33:52.479000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b2258059c063'
down_revision = '0141eb67be05'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table surguard_panel
        alter column state drop default;
        
        alter table surguard_panel
        alter column state type text;
        
        alter table surguard_panel
        alter column state set default '{}';
    """)


def downgrade():
    pass
