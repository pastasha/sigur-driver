"""create_intellect_intrepid3_tables

Revision ID: d5cd09ed8b91
Revises: 8d92a7e37365
Create Date: 2019-02-16 13:35:34.819000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd5cd09ed8b91'
down_revision = '8d92a7e37365'
branch_labels = None
depends_on = None


def upgrade():
	op.create_equipment('intellect_intrepid3_pm',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),['slave'], 'True'
	)
	op.create_equipment('intellect_intrepid3_pm_line',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),['slave'], 'True'
	)
	op.create_equipment('intellect_intrepid3_pm_cs',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),['slave'], 'True'
	)
	op.create_equipment('intellect_intrepid3_amodule',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),['slave'], 'True'
	)
	op.create_equipment('intellect_intrepid3_ain',(
			('id_obj', 'varchar(256)', ''),
			('description', 'varchar(256)', '')		
		),['slave'], 'True'
	)


def downgrade():
	op.drop_table('intellect_intrepid3_pm')
	op.drop_table('intellect_intrepid3_pm_line')
	op.drop_table('intellect_intrepid3_pm_cs')
	op.drop_table('intellect_intrepid3_amodule')
	op.drop_table('intellect_intrepid3_ain')