"""drop code unique index in event_catalog table

Revision ID: 1c13b862b106
Revises: d9c6e72c5239
Create Date: 2018-07-12 15:13:10.831000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1c13b862b106'
down_revision = 'd9c6e72c5239'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop index if exists event_catalog_code_ukey;
        alter table event_catalog
        drop constraint if exists event_catalog_ukey;
    """)


def downgrade():
    pass
