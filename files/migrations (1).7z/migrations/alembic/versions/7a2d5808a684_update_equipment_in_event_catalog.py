"""update equipment in event_catalog

Revision ID: 7a2d5808a684
Revises: c4430e849f81
Create Date: 2019-11-07 09:48:33.209305

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7a2d5808a684'
down_revision = 'c4430e849f81'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set equipment = 'orioniso' where equipment = 'OrionISO';

        update event_catalog
        set equipment = 'bosch' where equipment = 'BOSCH';

        update event_catalog
        set equipment = 'biostar' where equipment = 'suprema';

        update event_catalog
        set equipment = 'intellect' where equipment like '%intellect%';

        update event_catalog
        set equipment = 'winmag' where equipment = 'esser';

        update event_catalog
        set equipment = 'system'
        where equipment in ('Система', 'System', 'asterisk', 'common_phone') or (code >= 129000 and code <= 129012);

        delete from event_catalog
        where equipment = 'ARM Orion Pro';

        update event_catalog
        set equipment = 'pce' where equipment in ('PCE', 'рсе', 'РСЕ');

        update event_catalog
        set equipment = 'rusguard' where equipment ilike '%rusguard%';
        
        alter table event_catalog
        add constraint event_catalog_equipment_fkey foreign key(equipment) references equipments(name);
    """)


def downgrade():
    pass
