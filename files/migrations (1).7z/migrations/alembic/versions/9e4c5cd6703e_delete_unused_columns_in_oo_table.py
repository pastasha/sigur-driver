"""delete unused columns in oo table

Revision ID: 9e4c5cd6703e
Revises: aaec22e6f088
Create Date: 2018-08-02 15:18:48.691000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9e4c5cd6703e'
down_revision = 'aaec22e6f088'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column('oo_table', 'id')
    op.drop_column('oo_table', 'ooid')
    op.add_column('oo_table', sa.Column('name', sa.String()))
    op.add_column('oo_table', sa.Column('color', sa.String()))
    op.add_column('oo_table', sa.Column('norma', sa.SmallInteger()))
    op.execute("""
        update oo_table set name = result::json->>'colortext';
        update oo_table set color = result::json->>'color';
        update oo_table set norma = (result::json->>'norma')::boolean::int;
        update oo_table set norma = 0 where norma is null;
    """)
    op.drop_column('oo_table', 'result')


def downgrade():
    op.add_column('result', sa.Column('name', sa.String()))
    op.execute("update oo_table set result = json_build_object('colortext', name, 'color', color, 'norma', norma)::text")
    op.drop_column('oo_table', 'name')
    op.drop_column('oo_table', 'color')
    op.drop_column('oo_table', 'norma')
    op.add_column('oo_table', sa.Column('id', sa.SmallInteger()))
    op.add_column('oo_table', sa.Column('ooid', sa.SmallInteger()))
    