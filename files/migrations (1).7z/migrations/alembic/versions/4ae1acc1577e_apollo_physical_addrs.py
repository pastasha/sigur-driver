"""apollo_physical_addrs

Revision ID: 4ae1acc1577e
Revises: 76098ad2f3bc
Create Date: 2018-12-20 10:44:11.372000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4ae1acc1577e'
down_revision = '76098ad2f3bc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table apollo_alarmpanel add column addr integer default -1;
        alter table apollo_reader add column addr integer default -1;
    """)


def downgrade():
    op.execute("""
        alter table apollo_alarmpanel drop column addr;
        alter table apollo_reader drop column addr;
    """)
