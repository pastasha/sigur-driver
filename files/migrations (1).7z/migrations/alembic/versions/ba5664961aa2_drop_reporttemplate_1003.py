"""drop reporttemplate 1003

Revision ID: ba5664961aa2
Revises: 1f84736cc0fc
Create Date: 2019-05-21 11:15:06.539000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ba5664961aa2'
down_revision = '1f84736cc0fc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('delete from reports_based where uniid = 1003')


def downgrade():
    pass
