"""edit id_obj in intellect

Revision ID: 370608db70d3
Revises: df1a2b0df7e5
Create Date: 2019-01-11 11:20:00.560000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '370608db70d3'
down_revision = 'df1a2b0df7e5'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""ALTER TABLE intellect_bolid RENAME COLUMN id_obj TO id""")
    op.execute("""ALTER TABLE intellect_aam RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_aamcontroller RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_aamreader RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_boliddevice RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_bolidpartition RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_bolidzone RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_cam RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_camfacecapture RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_camipdetector RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_camvmdadetector RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_camzone RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_castleap RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_castlesrv RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_monitor RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_orionpro RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_orionpropult RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_orionprorelaysignal20 RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_orionprosignal20 RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_orionprozonesignal20 RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_rubeg8isb RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbaccesspoint RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbalarmtrain RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbexecdevice RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbsk01 RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_slave RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3 RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3ain RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3amodule RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3pm RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3pmcs RENAME COLUMN id_obj TO id;""")
    op.execute("""ALTER TABLE intellect_intrepid3pmline RENAME COLUMN id_obj TO id;""")


def downgrade():
    op.execute("""ALTER TABLE intellect_bolid RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_aam RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_aamcontroller RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_aamreader RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_boliddevice RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_bolidpartition RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_bolidzone RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_cam RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_camfacecapture RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_camipdetector RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_camvmdadetector RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_camzone RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_castleap RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_castlesrv RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_monitor RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_orionpro RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_orionpropult RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_orionprorelaysignal20 RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_orionprosignal20 RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_orionprozonesignal20 RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_rubeg8isb RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbaccesspoint RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbalarmtrain RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbexecdevice RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_rubeg8isbsk01 RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_slave RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3 RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3ain RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3amodule RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3pm RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3pmcs RENAME COLUMN id TO id_obj;""")
    op.execute("""ALTER TABLE intellect_intrepid3pmline RENAME COLUMN id TO id_obj;""")
