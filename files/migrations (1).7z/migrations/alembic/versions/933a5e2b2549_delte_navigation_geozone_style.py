"""delte navigation geozone style

Revision ID: 933a5e2b2549
Revises: a25ed3c32ca5
Create Date: 2019-11-27 12:06:03.242547

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '933a5e2b2549'
down_revision = 'a25ed3c32ca5'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column('navigation_geozone', 'style')


def downgrade():
    op.execute("""
        alter table navigation_geozone
        add column style text
    """)
