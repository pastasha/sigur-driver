# -*- coding: utf-8 -*-

"""add new state to default types

Revision ID: 70883adebfa6
Revises: ffad0b7ed6ee
Create Date: 2018-10-08 09:51:53.082000

Устанавливает рассчет состояний для типов ом связанных с оборудованием, для стандартных типов (привязка по id) у которых еще нет рассчета
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '70883adebfa6'
down_revision = 'ffad0b7ed6ee'
branch_labels = None
depends_on = None


def upgrade():
    # Тревожная кнопка
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 13 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Кновка выход
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 19 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Сенсор
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 41 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Дверь
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 16 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Видеокамера
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 27 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Сенсор с постановкой/снятием
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 49 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Считыватель
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 18 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # ОШС
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ATTN"]}, "result_function": {"ACC": "or", "TRB": "or", "ALRM": "or", "ACT": "or", "ARM": "or", "CON": "or"}}'
        where id = 12 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Замок
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 17 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Исполнительное устройство
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 24 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Раздел ОТС
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0440\u0430\u0437\u0434\u0435\u043b \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 21 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)


def downgrade():
    pass
