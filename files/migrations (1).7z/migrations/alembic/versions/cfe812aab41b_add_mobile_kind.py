"""add mobile kind

Revision ID: cfe812aab41b
Revises: b2880fdbaaf4
Create Date: 2019-10-24 10:28:43.544547

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cfe812aab41b'
down_revision = 'b2880fdbaaf4'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter type observed_object_type_kind
        rename to observed_object_type_kind_;
        
        create type observed_object_type_kind
        as enum ('reader', 'input', 'output', 'cam', 'key', 'part', 'dev', 'group', 'system', 'monitor', 'mobile');
        
        alter table observed_objects_types
        alter column kind type text;
        
        alter table observed_objects_types
        alter column kind type observed_object_type_kind using kind::observed_object_type_kind;
        
        drop type observed_object_type_kind_;
    """)


def downgrade():
    pass
