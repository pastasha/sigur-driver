"""rename name table suprema in Biostar

Revision ID: 841313edea67
Revises: 097bb74e4f52
Create Date: 2019-01-18 17:17:37.289000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '841313edea67'
down_revision = '097bb74e4f52'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""alter table suprema_entrydevice rename to biostar_entrydevice;""")
    op.execute("""alter table suprema_driver rename to biostar_driver;""")
    op.execute("""alter table suprema_doorreley rename to biostar_doorreley;""")
    op.execute("""alter table suprema_doorgroup rename to biostar_doorgroup;""")
    op.execute("""alter table suprema_door rename to biostar_door;""")
    op.execute("""alter table suprema_devicetype rename to biostar_devicetype;""")
    op.execute("""alter table suprema_devicegroup rename to biostar_devicegroup;""")
    op.execute("""alter table suprema_device rename to biostar_device;""")


def downgrade():
    op.execute("""alter table biostar_entrydevice rename to suprema_entrydevice;""")
    op.execute("""alter table biostar_driver rename to suprema_driver;""")
    op.execute("""alter table biostar_doorreley rename to suprema_doorreley;""")
    op.execute("""alter table biostar_doorgroup rename to suprema_doorgroup;""")
    op.execute("""alter table biostar_door rename to suprema_door;""")
    op.execute("""alter table biostar_devicetype rename to suprema_devicetype;""")
    op.execute("""alter table biostar_devicegroup rename to suprema_devicegroup;""")
    op.execute("""alter table biostar_device rename to suprema_device;""")