"""drop unused common tables

Revision ID: 41b1ffbe24ed
Revises: bc7fa7e2b065
Create Date: 2018-11-21 16:19:35.513000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '41b1ffbe24ed'
down_revision = 'bc7fa7e2b065'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('common_organization_address')
    
    op.drop_table('common_request')
    op.drop_column('common_permit', 'request')
    
    op.drop_table('common_address')
    
    op.drop_table('common_route')
    op.drop_table('common_route_address')
    
    op.drop_table('common_parameter')
    op.drop_table('common_parametergroup')
    op.drop_table('common_parametergrouptype')
    op.drop_column('common_root', 'defaultidcodeparametergroup')
    op.drop_column('common_idcode', 'parametergroup')
    op.drop_column('common_commonright', 'parametergroup')
    
    op.drop_table('common_organization_permit')


def downgrade():
    pass
