# -*- coding: utf-8 -*-

"""create sequence for cmdcode

Revision ID: d1d581eef6f4
Revises: fb8be90dbc99
Create Date: 2018-06-06 11:31:05.333000

Теперь значение колонки cmdcode в таблице для хранения запросов операторов будет генерироватся автоматически а не хранится у самого оператора

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd1d581eef6f4'
down_revision = 'fb8be90dbc99'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create sequence operator_request_cmdcode_seq;
        
        alter table operator_request
        alter column cmdcode set default nextval('operator_request_cmdcode_seq');
        
        select setval('operator_request_cmdcode_seq', (select coalesce(max(cmdcode)+1, 1) from operator_request));
        
        alter table operators
        drop column cmdcode;
    """)
    
def downgrade():
    op.execute("""
        drop sequence operator_request_cmdcode_seq;
        
        alter table operator_request
        alter column cmdcode drop default;
        
        alter table operators
        add column cmdcode bigint;
    """)
