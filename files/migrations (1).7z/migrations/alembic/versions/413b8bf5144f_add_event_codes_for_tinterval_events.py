# -*- coding: utf-8 -*-

"""add event codes for tinterval events

Revision ID: 413b8bf5144f
Revises: 3c50e05e498c
Create Date: 2018-04-23 14:56:10.550000

Доабвляет два события для начала и окончания временного интервала

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date
import json

# revision identifiers, used by Alembic.
revision = '413b8bf5144f'
down_revision = '3c50e05e498c'
branch_labels = None
depends_on = None

events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def addEv(code, descr, format, equipment = u"system", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })

addEv(763, u"Начало временного интервала", json.dumps(["Начало временного интервала %statement.directObj.name", ""]))
addEv(764, u"Окончание временного интервала", json.dumps(["Окончание временного интервала %statement.directObj.name", ""]))

def upgrade():
    op.bulk_insert(event_catalog, events)

def downgrade():
    op.execute('delete from event_catalog where code = 763 or code = 764')
