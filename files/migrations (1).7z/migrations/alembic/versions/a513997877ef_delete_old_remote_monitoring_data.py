"""delete old remote monitoring data

Revision ID: a513997877ef
Revises: 2f1752c432e8
Create Date: 2019-08-18 18:40:33.305000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a513997877ef'
down_revision = '2f1752c432e8'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('common_domain')
    op.drop_column('common_root', 'id')
    op.drop_column('common_root', 'description')
    op.drop_column('common_idcode', 'external_id')
    op.drop_column('common_permit', 'external_id')
    op.drop_column('common_permittype', 'external_id')
    
    op.drop_column('observed_objects', 'external_id')
    op.drop_column('observed_objects', 'remotedomainid')
    op.drop_column('observed_objects_types', 'external_id')
    op.drop_column('vehicle_types', 'external_id')


def downgrade():
    pass
