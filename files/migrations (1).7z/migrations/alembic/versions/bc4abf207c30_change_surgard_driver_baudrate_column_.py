"""change surgard driver baudrate column type to int

Revision ID: bc4abf207c30
Revises: f09d39d6dba2
Create Date: 2018-11-29 09:57:12.668000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bc4abf207c30'
down_revision = 'f09d39d6dba2'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('surguard_driver', 'baudrate', type_=sa.Integer)


def downgrade():
    pass
