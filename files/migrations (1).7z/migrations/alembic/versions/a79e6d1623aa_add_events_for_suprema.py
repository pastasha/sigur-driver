# -*- coding: utf-8 -*-
"""add_events_for_suprema

Revision ID: a79e6d1623aa
Revises: 2b60971670c7
Create Date: 2018-10-11 19:00:29.837000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'a79e6d1623aa'
down_revision = 'a5e21b5bd08c'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def upgrade():
    op.bulk_insert(event_catalog, events)
    
def addEv(code, descr, format, equipment = u"suprema", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(18000, u"Ошибка записи", u"[\"%statement.directObj.name Ошибка записи %statement.subject.dev.name\", \"Ошибка записи\"]")
addEv(18001, u"Ошибка записи - Конец повтора", u"[\"%statement.directObj.name Ошибка записи - Конец повтора %statement.subject.dev.name\", \"Ошибка записи - Конец повтора\"]")
addEv(18002, u"Сбой моментального снимка", u"[\"%statement.directObj.name Сбой моментального снимка %statement.subject.dev.name\", \"Сбой моментального снимка\"]")
addEv(18003, u"Сбой моментального снимка - Конец повтора", u"[\"%statement.directObj.name Сбой моментального снимка - Конец повтора %statement.subject.dev.name\", \"Сбой моментального снимка - Конец повтора\"]")
addEv(18004, u"Обнаружено отключение устройства", u"[\"%statement.directObj.name Обнаружено отключение устройства %statement.subject.dev.name\", \"Обнаружено отключение устройства\"]")
addEv(18005, u"1: 1 аутентификация выполнена успешно (Идентификатор + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Идентификатор + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Идентификатор + ПИН)\"]")
addEv(18006, u"1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток)\"]")
addEv(18007, u"1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН)\"]")
addEv(18008, u"1: 1 аутентификация выполнена успешно (Идентификатор + Лицо)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Идентификатор + Лицо) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Идентификатор + Лицо)\"]")
addEv(18009, u"1: 1 аутентификация выполнена успешно (Идентификатор + Лицо + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Идентификатор + Лицо + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Идентификатор + Лицо + ПИН)\"]")
addEv(18010, u"1: 1 аутентификация выполнена успешно (Карта)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта)\"]")
addEv(18011, u"1: 1 аутентификация выполнена успешно (Карта + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта + ПИН)\"]")
addEv(18012, u"1: 1 аутентификация выполнена успешно (Карта + Отпечаток)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта + Отпечаток) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта + Отпечаток)\"]")
addEv(18013, u"1: 1 аутентификация выполнена успешно (Карта + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта + Отпечаток + ПИН)\"]")
addEv(18014, u"1: 1 аутентификация выполнена успешно (Карта + Лицо)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта + Лицо) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта + Лицо)\"]")
addEv(18015, u"1: 1 аутентификация выполнена успешно (Карта + Лицо + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Карта + Лицо + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Карта + Лицо + ПИН)\"]")
addEv(18016, u"1: 1 аутентификация выполнена успешно (Доступ по карте)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Доступ по карте) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Доступ по карте)\"]")
addEv(18017, u"1: 1 аутентификация выполнена успешно (Доступ по карте + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Доступ по карте + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Доступ по карте + ПИН)\"]")
addEv(18018, u"1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток)\"]")
addEv(18019, u"1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН)\"]")
addEv(18020, u"1: 1 ошибка аутентификации (Идентификатор)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Идентификатор) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Идентификатор)\"]")
addEv(18021, u"1: 1 ошибка аутентификации (Карта)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Карта) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Карта)\"]")
addEv(18022, u"1: 1 ошибка аутентификации (ПИН)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (ПИН) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (ПИН)\"]")
addEv(18023, u"1: 1 ошибка аутентификации (Отпечаток)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Отпечаток) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Отпечаток)\"]")
addEv(18024, u"1: 1 ошибка аутентификации (Лицо)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Лицо) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Лицо)\"]")
addEv(18025, u"1: 1 ошибка аутентификации (Доступ по карте + ПИН)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Доступ по карте + ПИН) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Доступ по карте + ПИН)\"]")
addEv(18026, u"1: 1 ошибка аутентификации (Доступ по карте + Отпечаток)", u"[\"%statement.directObj.name 1: 1 ошибка аутентификации (Доступ по карте + Отпечаток) %statement.subject.dev.name\", \"1: 1 ошибка аутентификации (Доступ по карте + Отпечаток)\"]")
addEv(18027, u"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Идентификатор + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + ПИН)\"]")
addEv(18028, u"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток)\"]")
addEv(18029, u"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Отпечаток + ПИН)\"]")
addEv(18030, u"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо)\"]")
addEv(18031, u"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Идентификатор + Лицо + ПИН)\"]")
addEv(18032, u"1: 1 принудительная аутентификация выполнена успешно (карта)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (карта) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (карта)\"]")
addEv(18033, u"1: 1 принудительная аутентификация выполнена успешно (Карта + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Карта + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Карта + ПИН)\"]")
addEv(18034, u"1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток)\"]")
addEv(18035, u"1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Карта + Отпечаток + ПИН)\"]")
addEv(18036, u"1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо)\"]")
addEv(18037, u"1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Карта + Лицо + ПИН)\"]")
addEv(18038, u"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Доступ по карте) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте)\"]")
addEv(18039, u"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + ПИН)\"]")
addEv(18040, u"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток)\"]")
addEv(18041, u"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН) %statement.subject.dev.name\", \"1: 1 принудительная аутентификация выполнена успешно (Доступ по карте + Отпечаток + ПИН)\"]")
addEv(18042, u"1: N аутентификация выполнена успешно (Отпечаток)", u"[\"%statement.directObj.name 1: N аутентификация выполнена успешно (Отпечаток) %statement.subject.dev.name\", \"1: N аутентификация выполнена успешно (Отпечаток)\"]")
addEv(18043, u"1: N аутентификация выполнена успешно (Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: N аутентификация выполнена успешно (Отпечаток + ПИН) %statement.subject.dev.name\", \"1: N аутентификация выполнена успешно (Отпечаток + ПИН)\"]")
addEv(18044, u"1: N аутентификация выполнена успешно (Лицо)", u"[\"%statement.directObj.name 1: N аутентификация выполнена успешно (Лицо) %statement.subject.dev.name\", \"1: N аутентификация выполнена успешно (Лицо)\"]")
addEv(18045, u"1: N аутентификация выполнена успешно (Лицо + ПИН)", u"[\"%statement.directObj.name 1: N аутентификация выполнена успешно (Лицо + ПИН) %statement.subject.dev.name\", \"1: N аутентификация выполнена успешно (Лицо + ПИН)\"]")
addEv(18046, u"1: N ошибка аутентификации (ПИН)", u"[\"%statement.directObj.name 1: N ошибка аутентификации (ПИН) %statement.subject.dev.name\", \"1: N ошибка аутентификации (ПИН)\"]")
addEv(18047, u"1: N ошибка аутентификации (отпечаток пальца)", u"[\"%statement.directObj.name 1: N ошибка аутентификации (отпечаток пальца) %statement.subject.dev.name\", \"1: N ошибка аутентификации (отпечаток пальца)\"]")
addEv(18048, u"1: N ошибка аутентификации (Лицо)", u"[\"%statement.directObj.name 1: N ошибка аутентификации (Лицо) %statement.subject.dev.name\", \"1: N ошибка аутентификации (Лицо)\"]")
addEv(18049, u"1: N ошибка аутентификации (Доступ по карте + ПИН)", u"[\"%statement.directObj.name 1: N ошибка аутентификации (Доступ по карте + ПИН) %statement.subject.dev.name\", \"1: N ошибка аутентификации (Доступ по карте + ПИН)\"]")
addEv(18050, u"1: N ошибка аутентификации (доступ на карту + отпечаток пальца)", u"[\"%statement.directObj.name 1: N ошибка аутентификации (доступ на карту + отпечаток пальца) %statement.subject.dev.name\", \"1: N ошибка аутентификации (доступ на карту + отпечаток пальца)\"]")
addEv(18051, u"1: N принудительная аутентификация выполнена успешно (Отпечаток)", u"[\"%statement.directObj.name 1: N принудительная аутентификация выполнена успешно (Отпечаток) %statement.subject.dev.name\", \"1: N принудительная аутентификация выполнена успешно (Отпечаток)\"]")
addEv(18052, u"1: N принудительная аутентификация выполнена успешно (Отпечаток + ПИН)", u"[\"%statement.directObj.name 1: N принудительная аутентификация выполнена успешно (Отпечаток + ПИН) %statement.subject.dev.name\", \"1: N принудительная аутентификация выполнена успешно (Отпечаток + ПИН)\"]")
addEv(18053, u"1: N принудительная аутентификация выполнена успешно (Лицо)", u"[\"%statement.directObj.name 1: N принудительная аутентификация выполнена успешно (Лицо) %statement.subject.dev.name\", \"1: N принудительная аутентификация выполнена успешно (Лицо)\"]")
addEv(18054, u"1: N принудительная аутентификация выполнена успешно (Лицо + ПИН)", u"[\"%statement.directObj.name 1: N принудительная аутентификация выполнена успешно (Лицо + ПИН) %statement.subject.dev.name\", \"1: N принудительная аутентификация выполнена успешно (Лицо + ПИН)\"]")
addEv(18055, u"Ошибка двойной аутентификации (Таймаут)", u"[\"%statement.directObj.name Ошибка двойной аутентификации (Таймаут) %statement.subject.dev.name\", \"Ошибка двойной аутентификации (Таймаут)\"]")
addEv(18056, u"Ошибка двойной аутентификации (Недействительная группа доступа)", u"[\"%statement.directObj.name Ошибка двойной аутентификации (Недействительная группа доступа) %statement.subject.dev.name\", \"Ошибка двойной аутентификации (Недействительная группа доступа)\"]")
addEv(18057, u"Ошибка аутентификации (Неверный режим проверки подлинности)", u"[\"%statement.directObj.name Ошибка аутентификации (Неверный режим проверки подлинности) %statement.subject.dev.name\", \"Ошибка аутентификации (Неверный режим проверки подлинности)\"]")
addEv(18058, u"Ошибка аутентификации (Недопустимые учетные данные)", u"[\"%statement.directObj.name Ошибка аутентификации (Недопустимые учетные данные) %statement.subject.dev.name\", \"Ошибка аутентификации (Недопустимые учетные данные)\"]")
addEv(18059, u"Ошибка аутентификации (Таймаут)", u"[\"%statement.directObj.name Ошибка аутентификации (Таймаут) %statement.subject.dev.name\", \"Ошибка аутентификации (Таймаут)\"]")
addEv(18060, u"Ошибка аутентификации (Совпадение серверов выключено)", u"[\"%statement.directObj.name Ошибка аутентификации (Совпадение серверов выключено) %statement.subject.dev.name\", \"Ошибка аутентификации (Совпадение серверов выключено)\"]")
addEv(18061, u"Доступ запрещен (Недействительная группа доступа)", u"[\"%statement.directObj.name Доступ запрещен (Недействительная группа доступа) %statement.subject.dev.name\", \"Доступ запрещен (Недействительная группа доступа)\"]")
addEv(18062, u"Доступ запрещен (Пользователь отключен)", u"[\"%statement.directObj.name Доступ запрещен (Пользователь отключен) %statement.subject.dev.name\", \"Доступ запрещен (Пользователь отключен)\"]")
addEv(18063, u"Доступ запрещен (Истек)", u"[\"%statement.directObj.name Доступ запрещен (Истек) %statement.subject.dev.name\", \"Доступ запрещен (Истек)\"]")
addEv(18064, u"Доступ запрещен (Черный список)", u"[\"%statement.directObj.name Доступ запрещен (Черный список) %statement.subject.dev.name\", \"Доступ запрещен (Черный список)\"]")
addEv(18065, u"Доступ запрещен (Жесткий Anti-passback)", u"[\"%statement.directObj.name Доступ запрещен (Жесткий Anti-passback) %statement.subject.dev.name\", \"Доступ запрещен (Жесткий Anti-passback)\"]")
addEv(18066, u"Доступ запрещен (Временный Anti-passback)", u"[\"%statement.directObj.name Доступ запрещен (Временный Anti-passback) %statement.subject.dev.name\", \"Доступ запрещен (Временный Anti-passback)\"]")
addEv(18067, u"Доступ запрещен (Принудительноая блокировка расписания)", u"[\"%statement.directObj.name Доступ запрещен (Принудительноая блокировка расписания) %statement.subject.dev.name\", \"Доступ запрещен (Принудительноая блокировка расписания)\"]")
addEv(18068, u"Доступ запрещен (Мягкий Anti-passback)", u"[\"%statement.directObj.name Доступ запрещен (Мягкий Anti-passback) %statement.subject.dev.name\", \"Доступ запрещен (Мягкий Anti-passback)\"]")
addEv(18069, u"Доступ запрещен (Мягкий временный Anti-passback)", u"[\"%statement.directObj.name Доступ запрещен (Мягкий временный Anti-passback) %statement.subject.dev.name\", \"Доступ запрещен (Мягкий временный Anti-passback)\"]")
addEv(18070, u"Доступ запрещен (Ошибка обнаружения лица)", u"[\"%statement.directObj.name Доступ запрещен (Ошибка обнаружения лица) %statement.subject.dev.name\", \"Доступ запрещен (Ошибка обнаружения лица)\"]")
addEv(18071, u"Доступ запрещен (Ошибка захвата)", u"[\"%statement.directObj.name Доступ запрещен (Ошибка захвата) %statement.subject.dev.name\", \"Доступ запрещен (Ошибка захвата)\"]")
addEv(18072, u"Обнаружен фальшивый отпечаток", u"[\"%statement.directObj.name Обнаружен фальшивый отпечаток %statement.subject.dev.name\", \"Обнаружен фальшивый отпечаток\"]")
addEv(18073, u"Доступ к сигнализации о вторжении запрещен", u"[\"%statement.directObj.name Доступ к сигнализации о вторжении запрещен %statement.subject.dev.name\", \"Доступ к сигнализации о вторжении запрещен\"]")
addEv(18074, u"Успешная регистрация пользователя", u"[\"%statement.directObj.name Успешная регистрация пользователя %statement.subject.dev.name\", \"Успешная регистрация пользователя\"]")
addEv(18075, u"Ошибка регистрации пользователя", u"[\"%statement.directObj.name Ошибка регистрации пользователя %statement.subject.dev.name\", \"Ошибка регистрации пользователя\"]")
addEv(18076, u"Успешное обновление пользователя", u"[\"%statement.directObj.name Успешное обновление пользователя %statement.subject.dev.name\", \"Успешное обновление пользователя\"]")
addEv(18077, u"Не удалось выполнить обновление пользователя", u"[\"%statement.directObj.name Не удалось выполнить обновление пользователя %statement.subject.dev.name\", \"Не удалось выполнить обновление пользователя\"]")
addEv(18078, u"Успешное удаление пользователя", u"[\"%statement.directObj.name Успешное удаление пользователя %statement.subject.dev.name\", \"Успешное удаление пользователя\"]")
addEv(18079, u"Ошибка удаления пользователя", u"[\"%statement.directObj.name Ошибка удаления пользователя %statement.subject.dev.name\", \"Ошибка удаления пользователя\"]")
addEv(18080, u"Успешное удаление всех пользователей", u"[\"%statement.directObj.name Успешное удаление всех пользователей %statement.subject.dev.name\", \"Успешное удаление всех пользователей\"]")
addEv(18081, u"Успешная выдача карты доступа", u"[\"%statement.directObj.name Успешная выдача карты доступа %statement.subject.dev.name\", \"Успешная выдача карты доступа\"]")
addEv(18082, u"Устройство перезапущено", u"[\"%statement.directObj.name Устройство перезапущено %statement.subject.dev.name\", \"Устройство перезапущено\"]")
addEv(18083, u"Устройство запущено", u"[\"%statement.directObj.name Устройство запущено %statement.subject.dev.name\", \"Устройство запущено\"]")
addEv(18084, u"Время устройства изменилось", u"[\"%statement.directObj.name Время устройства изменилось %statement.subject.dev.name\", \"Время устройства изменилось\"]")
addEv(18085, u"Изменена часовая зона", u"[\"%statement.directObj.name Изменена часовая зона %statement.subject.dev.name\", \"Изменена часовая зона\"]")
addEv(18086, u"Соединение с сетью установлено", u"[\"Соединение с %statement.directObj.name сетью установлено %statement.subject.dev.name\", \"Соединение с сетью установлено\"]")
addEv(18087, u"Соединение с сетью потеряно", u"[\"Соединение с %statement.directObj.name сетью потеряно %statement.subject.dev.name\", \"Соединение с сетью потеряно\"]")
addEv(18088, u"Соединение с DHCP установлено", u"[\"Соединение с %statement.directObj.name DHCP установлено %statement.subject.dev.name\", \"Соединение с DHCP установлено\"]")
addEv(18089, u"Вход в меню администратора", u"[\"%statement.directObj.name Вход в меню администратора %statement.subject.dev.name\", \"Вход в меню администратора\"]")
addEv(18090, u"Устройство заблокировано", u"[\"%statement.directObj.name Устройство заблокировано %statement.subject.dev.name\", \"Устройство заблокировано\"]")
addEv(18091, u"Устройство разблокировано", u"[\"%statement.directObj.name Устройство разблокировано %statement.subject.dev.name\", \"Устройство разблокировано\"]")
addEv(18092, u"Связь с BioStar заблокирована", u"[\"%statement.directObj.name Связь с BioStar заблокирована %statement.subject.dev.name\", \"Связь с BioStar заблокирована\"]")
addEv(18093, u"Связь с BioStar разблокирована", u"[\"%statement.directObj.name Связь с BioStar разблокирована %statement.subject.dev.name\", \"Связь с BioStar разблокирована\"]")
addEv(18094, u"Соединение с BioStar установлено", u"[\"Соединение с %statement.directObj.name BioStar установлено  %statement.subject.dev.name\", \"Соединение с BioStar установлено\"]")
addEv(18095, u"Соединение с BioStar потеряно", u"[\"Соединение с %statement.directObj.name BioStar потеряно  %statement.subject.dev.name\", \"Соединение с BioStar потеряно\"]")
addEv(18096, u"Соединение с RS-485 установлено", u"[\"Соединение с %statement.directObj.name RS-485 установлено  %statement.subject.dev.name\", \"Соединение с RS-485 установлено\"]")
addEv(18097, u"Соединение с RS-485 потеряно", u"[\"Соединение с %statement.directObj.name RS-485 потеряно  %statement.subject.dev.name\", \"Соединение с RS-485 потеряно\"]")
addEv(18098, u"Вход обнаружен", u"[\"%statement.directObj.name Вход обнаружен %statement.subject.dev.name\", \"Вход обнаружен\"]")
addEv(18099, u"Тампер включен", u"[\"%statement.directObj.name Тампер включен %statement.subject.dev.name\", \"Тампер включен\"]")
addEv(18100, u"Тампер выключен", u"[\"%statement.directObj.name Тампер выключен %statement.subject.dev.name\", \"Тампер выключен\"]")
addEv(18101, u"Журнал событий очищен", u"[\"%statement.directObj.name Журнал событий очищен %statement.subject.dev.name\", \"Журнал событий очищен\"]")
addEv(18102, u"Обновление прошивки прошло успешно", u"[\"%statement.directObj.name Обновление прошивки прошло успешно %statement.subject.dev.name\", \"Обновление прошивки прошло успешно\"]")
addEv(18103, u"Обновление ресурсов прошло успешно", u"[\"%statement.directObj.name Обновление ресурсов прошло успешно %statement.subject.dev.name\", \"Обновление ресурсов прошло успешно\"]")
addEv(18104, u"Сброс устройства", u"[\"%statement.directObj.name Сброс устройства %statement.subject.dev.name\", \"Сброс устройства\"]")
addEv(18105, u"Сброс базы данных", u"[\"%statement.directObj.name Сброс базы данных %statement.subject.dev.name\", \"Сброс базы данных\"]")
addEv(18106, u"Сброс к заводским настройкам", u"[\"%statement.directObj.name Сброс к заводским настройкам %statement.subject.dev.name\", \"Сброс к заводским настройкам\"]")
addEv(18107, u"Контролируемый вход (короткий)", u"[\"%statement.directObj.name Контролируемый вход (короткий) %statement.subject.dev.name\", \"Контролируемый вход (короткий)\"]")
addEv(18108, u"Контролируемый вход (открытый)", u"[\"%statement.directObj.name Контролируемый вход (открытый) %statement.subject.dev.name\", \"Контролируемый вход (открытый)\"]")
addEv(18109, u"Ошибка питания переменного тока", u"[\"%statement.directObj.name Ошибка питания переменного тока %statement.subject.dev.name\", \"Ошибка питания переменного тока\"]")
addEv(18110, u"Успешное  питание переменного тока", u"[\"%statement.directObj.name Успешное  питание переменного тока %statement.subject.dev.name\", \"Успешное  питание переменного тока\"]")
addEv(18111, u"Дверь разблокирована", u"[\"%statement.directObj.name Дверь разблокирована %statement.subject.dev.name\", \"Дверь разблокирована\"]")
addEv(18112, u"Дверь заблокирована", u"[\"%statement.directObj.name Дверь заблокирована %statement.subject.dev.name\", \"Дверь заблокирована\"]")
addEv(18113, u"Дверь открыта", u"[\"%statement.directObj.name Дверь открыта %statement.subject.dev.name\", \"Дверь открыта\"]")
addEv(18114, u"Дверь закрыта", u"[\"%statement.directObj.name Дверь закрыта %statement.subject.dev.name\", \"Дверь закрыта\"]")
addEv(18115, u"Дверь принудительно открыта", u"[\"%statement.directObj.name Дверь принудительно открыта %statement.subject.dev.name\", \"Дверь принудительно открыта\"]")
addEv(18116, u"Удержанная дверь открыта", u"[\"%statement.directObj.name Удержанная дверь открыта %statement.subject.dev.name\", \"Удержанная дверь открыта\"]")
addEv(18117, u"Дверь принудительно открыта с тревогой", u"[\"%statement.directObj.name Дверь принудительно открыта с тревогой %statement.subject.dev.name\", \"Дверь принудительно открыта с тревогой\"]")
addEv(18118, u"Дверь принудительно открыта с очисткой", u"[\"%statement.directObj.name Дверь принудительно открыта с очисткой %statement.subject.dev.name\", \"Дверь принудительно открыта с очисткой\"]")
addEv(18119, u"Удержанная дверь открыта с тревогой", u"[\"%statement.directObj.name Удержанная дверь открыта с тревогой %statement.subject.dev.name\", \"Удержанная дверь открыта с тревогой\"]")
addEv(18120, u"Удержанная дверь открыта с очисткой", u"[\"%statement.directObj.name Удержанная дверь открыта с очисткой %statement.subject.dev.name\", \"Удержанная дверь открыта с очисткой\"]")
addEv(18121, u"Тревога Anti-passback", u"[\"%statement.directObj.name Тревога Anti-passback %statement.subject.dev.name\", \"Тревога Anti-passback\"]")
addEv(18122, u"Антипробег очищен", u"[\"%statement.directObj.name Антипробег очищен %statement.subject.dev.name\", \"Антипробег очищен\"]")
addEv(18123, u"Запрос на открытие двери по расписанию", u"[\"%statement.directObj.name Запрос на открытие двери по расписанию %statement.subject.dev.name\", \"Запрос на открытие двери по расписанию\"]")
addEv(18124, u"Запрос на открытие двери пожарной сигнализацией", u"[\"%statement.directObj.name Запрос на открытие двери пожарной сигнализацией %statement.subject.dev.name\", \"Запрос на открытие двери пожарной сигнализацией\"]")
addEv(18125, u"Запрос на открытие двери оператором", u"[\"%statement.directObj.name Запрос на открытие двери оператором %statement.subject.dev.name\", \"Запрос на открытие двери оператором\"]")
addEv(18126, u"Запрос на блокировку двери по расписанию", u"[\"%statement.directObj.name Запрос на блокировку двери по расписанию %statement.subject.dev.name\", \"Запрос на блокировку двери по расписанию\"]")
addEv(18127, u"Запрос на блокировку двери пожарной сигнализацией", u"[\"%statement.directObj.name Запрос на блокировку двери пожарной сигнализацией %statement.subject.dev.name\", \"Запрос на блокировку двери пожарной сигнализацией\"]")
addEv(18128, u"Запрос на блокировку двери оператором", u"[\"%statement.directObj.name Запрос на блокировку двери оператором %statement.subject.dev.name\", \"Запрос на блокировку двери оператором\"]")
addEv(18129, u"Запрос на разблокировку двери по расписанию", u"[\"%statement.directObj.name Запрос на разблокировку двери по расписанию %statement.subject.dev.name\", \"Запрос на разблокировку двери по расписанию\"]")
addEv(18130, u"Запрос на разблокировку двери пожарной сигнализацией", u"[\"%statement.directObj.name Запрос на разблокировку двери пожарной сигнализацией %statement.subject.dev.name\", \"Запрос на разблокировку двери пожарной сигнализацией\"]")
addEv(18131, u"Запрос на разблокировку двери оператором", u"[\"%statement.directObj.name Запрос на разблокировку двери оператором %statement.subject.dev.name\", \"Запрос на разблокировку двери оператором\"]")
addEv(18132, u"Обнаружено нарушение Anti-passback", u"[\"%statement.directObj.name Обнаружено нарушение Anti-passback %statement.subject.dev.name\", \"Обнаружено нарушение Anti-passback\"]")
addEv(18133, u"Обнаружено нарушение жесткого Anti-passback", u"[\"%statement.directObj.name Обнаружено нарушение жесткого Anti-passback %statement.subject.dev.name\", \"Обнаружено нарушение жесткого Anti-passback\"]")
addEv(18134, u"Обнаружено нарушение мягкого Anti-passback", u"[\"%statement.directObj.name Обнаружено нарушение мягкого Anti-passback %statement.subject.dev.name\", \"Обнаружено нарушение мягкого Anti-passback\"]")
addEv(18135, u"Обнаружен аварийный сигнал зоны Anti-passback", u"[\"%statement.directObj.name Обнаружен аварийный сигнал зоны Anti-passback %statement.subject.dev.name\", \"Обнаружен аварийный сигнал зоны Anti-passback\"]")
addEv(18136, u"Сброс зоны тревоги Anti-passback", u"[\"%statement.directObj.name Сброс зоны тревоги Anti-passback %statement.subject.dev.name\", \"Сброс зоны тревоги Anti-passback\"]")
addEv(18137, u"Обнаружено нарушение временного Anti-passback", u"[\"%statement.directObj.name Обнаружено нарушение временного Anti-passback %statement.subject.dev.name\", \"Обнаружено нарушение временного Anti-passback\"]")
addEv(18138, u"Обнаружен аварийный сигнал временного Anti-passback", u"[\"%statement.directObj.name Обнаружен аварийный сигнал временного Anti-passback %statement.subject.dev.name\", \"Обнаружен аварийный сигнал временного Anti-passback\"]")
addEv(18139, u"Сброс аварийной сигнализации временного Anti-passback", u"[\"%statement.directObj.name Сброс аварийной сигнализации временного Anti-passback %statement.subject.dev.name\", \"Сброс аварийной сигнализации временного Anti-passback\"]")
addEv(18140, u"Обнаружен вход пожарной тревоги", u"[\"%statement.directObj.name Обнаружен вход пожарной тревоги %statement.subject.dev.name\", \"Обнаружен вход пожарной тревоги\"]")
addEv(18141, u"Обнаружена тревога зоны пожарной тревоги", u"[\"%statement.directObj.name Обнаружена тревога зоны пожарной тревоги %statement.subject.dev.name\", \"Обнаружена тревога зоны пожарной тревоги\"]")
addEv(18142, u"Сброс зоны тревоги пожарной тревоги", u"[\"%statement.directObj.name Сброс зоны тревоги пожарной тревоги %statement.subject.dev.name\", \"Сброс зоны тревоги пожарной тревоги\"]")
addEv(18143, u"Зафиксировано нарушение запланированной блокировки", u"[\"%statement.directObj.name Зафиксировано нарушение запланированной блокировки %statement.subject.dev.name\", \"Зафиксировано нарушение запланированной блокировки\"]")
addEv(18144, u"Запущена зона запланированной блокировки", u"[\"%statement.directObj.name Запущена зона запланированной блокировки %statement.subject.dev.name\", \"Запущена зона запланированной блокировки\"]")
addEv(18145, u"Запланированная блокировка зоны завершена", u"[\"%statement.directObj.name Запланированная блокировка зоны завершена %statement.subject.dev.name\", \"Запланированная блокировка зоны завершена\"]")
addEv(18146, u"Запущена запланированная разблокировка зоны", u"[\"%statement.directObj.name Запущена запланированная разблокировка зоны %statement.subject.dev.name\", \"Запущена запланированная разблокировка зоны\"]")
addEv(18147, u"Запланированная разблокировка зоны завершена", u"[\"%statement.directObj.name Запланированная разблокировка зоны завершена %statement.subject.dev.name\", \"Запланированная разблокировка зоны завершена\"]")
addEv(18148, u"Обнаружен аварийный сигнал запланированной блокировки зоны", u"[\"%statement.directObj.name Обнаружен аварийный сигнал запланированной блокировки зоны %statement.subject.dev.name\", \"Обнаружен аварийный сигнал запланированной блокировки зоны\"]")
addEv(18149, u"Сброс запланированной блокировки зоны", u"[\"%statement.directObj.name Сброс запланированной блокировки зоны %statement.subject.dev.name\", \"Сброс запланированной блокировки зоны\"]")
addEv(18150, u"Лифт активирован", u"[\"%statement.directObj.name Лифт активирован %statement.subject.dev.name\", \"Лифт активирован\"]")
addEv(18151, u"Лифт дезактивирован", u"[\"%statement.directObj.name Лифт дезактивирован %statement.subject.dev.name\", \"Лифт дезактивирован\"]")
addEv(18152, u"Открытие по расписанию", u"[\"%statement.directObj.name Открытие по расписанию %statement.subject.dev.name\", \"Открытие по расписанию\"]")
addEv(18153, u"Открытие по причине аварии", u"[\"%statement.directObj.name Открытие по причине аварии %statement.subject.dev.name\", \"Открытие по причине аварии\"]")
addEv(18154, u"Открытие оператором", u"[\"%statement.directObj.name Открытие оператором %statement.subject.dev.name\", \"Открытие оператором\"]")
addEv(18155, u"Разблокировка оператором", u"[\"%statement.directObj.name Разблокировка оператором %statement.subject.dev.name\", \"Разблокировка оператором\"]")
addEv(18156, u"Разблокировка по причине аварии", u"[\"%statement.directObj.name Разблокировка по причине аварии %statement.subject.dev.name\", \"Разблокировка по причине аварии\"]")
addEv(18157, u"Разблокировка оператором", u"[\"%statement.directObj.name Разблокировка оператором %statement.subject.dev.name\", \"Разблокировка оператором\"]")
addEv(18158, u"Блокировка по графику", u"[\"%statement.directObj.name Блокировка по графику %statement.subject.dev.name\", \"Блокировка по графику\"]")
addEv(18159, u"Заблокировать по причине аварии", u"[\"%statement.directObj.name Заблокировать по причине аварии %statement.subject.dev.name\", \"Заблокировать по причине аварии\"]")
addEv(18160, u"Блокировка оператором", u"[\"%statement.directObj.name Блокировка оператором %statement.subject.dev.name\", \"Блокировка оператором\"]")
addEv(18161, u"Обнаружен тревожный вход лифта", u"[\"%statement.directObj.name Обнаружен тревожный вход лифта %statement.subject.dev.name\", \"Обнаружен тревожный вход лифта\"]")
addEv(18162, u"Тревога лифта", u"[\"%statement.directObj.name Тревога лифта %statement.subject.dev.name\", \"Тревога лифта\"]")
addEv(18163, u"Сброс аварийной сигнализации лифта", u"[\"%statement.directObj.name Сброс аварийной сигнализации лифта %statement.subject.dev.name\", \"Сброс аварийной сигнализации лифта\"]")
addEv(18164, u"Включить все напольные реле", u"[\"%statement.directObj.name Включить все напольные реле %statement.subject.dev.name\", \"Включить все напольные реле\"]")
addEv(18165, u"Отключите все напольные реле", u"[\"%statement.directObj.name Отключите все напольные реле %statement.subject.dev.name\", \"Отключите все напольные реле\"]")
addEv(18166, u"Доступ запрещен (Статус На охране)", u"[\"%statement.directObj.name Доступ запрещен (Статус На охране) %statement.subject.dev.name\", \"Доступ запрещен (Статус На охране)\"]")
addEv(18167, u"Успешная авторизация (На охране)", u"[\"%statement.directObj.name Успешная авторизация (На охране) %statement.subject.dev.name\", \"Успешная авторизация (На охране)\"]")
addEv(18168, u"На охране", u"[\"%statement.directObj.name На охране %statement.subject.dev.name\", \"На охране\"]")
addEv(18169, u"Постановка на охрану не выполнена", u"[\"%statement.directObj.name Постановка на охрану не выполнена %statement.subject.dev.name\", \"Постановка на охрану не выполнена\"]")
addEv(18170, u"Успешная авторизация (Снят с охраны)", u"[\"%statement.directObj.name Успешная авторизация (Снят с охраны) %statement.subject.dev.name\", \"Успешная авторизация (Снят с охраны)\"]")
addEv(18171, u"Снят с охраны", u"[\"%statement.directObj.name Снят с охраны %statement.subject.dev.name\", \"Снят с охраны\"]")
addEv(18172, u"Обнаружен аварийный сигнал вторжения", u"[\"%statement.directObj.name Обнаружен аварийный сигнал вторжения %statement.subject.dev.name\", \"Обнаружен аварийный сигнал вторжения\"]")
addEv(18173, u"Сброс аварийной сигнализации вторжения", u"[\"%statement.directObj.name Сброс аварийной сигнализации вторжения %statement.subject.dev.name\", \"Сброс аварийной сигнализации вторжения\"]")
addEv(18174, u"Ошибка постановки на охрану", u"[\"%statement.directObj.name Ошибка постановки на охрану %statement.subject.dev.name\", \"Ошибка постановки на охрану\"]")
addEv(18175, u"Ошибка снятия с охраны", u"[\"%statement.directObj.name Ошибка снятия с охраны %statement.subject.dev.name\", \"Ошибка снятия с охраны\"]")
addEv(18176, u"Подклчение к оборудованию BioStar", u"[\"%statement.directObj.name Подклчение к оборудованию BioStar\", \"Подклчение к оборудованию BioStar\"]")
addEv(18177, u"Отключение от оборудования BioStar", u"[\"%statement.directObj.name Отключение от оборудования BioStar\", \"Отключение от оборудования BioStar\"]")


def downgrade():
    pass
