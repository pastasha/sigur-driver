"""change_types_of_rubezhglobal_columns

Revision ID: 85cc20093b84
Revises: 84b1cd73c240
Create Date: 2018-04-03 13:08:56.413000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '85cc20093b84'
down_revision = '84b1cd73c240'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''ALTER TABLE rubezhglobal_device
        ALTER COLUMN description TYPE text,
        ALTER COLUMN type TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN addr TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_direction
        ALTER COLUMN description TYPE text,
        ALTER COLUMN type TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_door
        ALTER COLUMN description TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_driver
        ALTER COLUMN description TYPE text,
        ALTER COLUMN driver_addr TYPE text,
        ALTER COLUMN server_addr TYPE text,
        ALTER COLUMN admin_login TYPE text,
        ALTER COLUMN admin_password TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_guardzone
        ALTER COLUMN description TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_mpt
        ALTER COLUMN description TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_skdzone
        ALTER COLUMN description TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')
    op.execute('''ALTER TABLE rubezhglobal_zone
        ALTER COLUMN description TYPE text,
        ALTER COLUMN type TYPE text,
        ALTER COLUMN uid TYPE text,
        ALTER COLUMN origin TYPE text
    ''')

def downgrade():
    pass
