"""add_table_from_doors_gruop_supema

Revision ID: 005a694ba9a1
Revises: a91dce65baad
Create Date: 2018-09-30 14:37:05.359000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '005a694ba9a1'
down_revision = 'a91dce65baad'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('suprema_doorgroup', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('description', 'varchar(256)', '')
        ), [], False
    )
    op.create_equipment('suprema_doorreley', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('description', 'varchar(256)', '')
        ), [], False
    )
    op.create_equipment('suprema_entrydevice', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('description', 'varchar(256)', '')
        ), [], False
    )
    op.drop_table('suprema_door')
    op.create_equipment('suprema_door', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('description', 'varchar(256)', ''),
        ('name', 'varchar(256)', ''),
        ('open_duration', 'varchar(256)', ''),
        ('held_open_timeout', 'varchar(256)', ''),
        ('dual_authentication', 'varchar(256)', ''),
        ('open_once', 'varchar(256)', '')
        ), [], False
    )
    


def downgrade():
    op.drop_table('suprema_doorgroup')
    op.drop_table('suprema_doorreley')
    op.drop_table('suprema_entrydevice')
    op.drop_table('suprema_door')
