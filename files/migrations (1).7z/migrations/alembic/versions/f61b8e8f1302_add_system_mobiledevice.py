"""add system mobiledevice

Revision ID: f61b8e8f1302
Revises: 41c1d4ba3f93
Create Date: 2019-06-17 11:13:18.334000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f61b8e8f1302'
down_revision = '41c1d4ba3f93'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('system_mobiledevice',(
            ('description', 'text', ''),
            ('imei', 'text', ''),
        ),[], False
    )


def downgrade():
    pass
