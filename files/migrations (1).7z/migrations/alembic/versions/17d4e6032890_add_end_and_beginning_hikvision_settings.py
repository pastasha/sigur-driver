"""add_end_and_beginninghikvision_settings

Revision ID: 17d4e6032890
Revises: 8399366be4ca
Create Date: 2018-11-13 15:26:07.899000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '17d4e6032890'
down_revision = '8399366be4ca'
branch_labels = None
depends_on = None


def upgrade():    
    op.execute('ALTER TABLE hikvision_settings ADD beginning_of_port_range bigint')
    op.execute('ALTER TABLE hikvision_settings ADD end_of_port_range bigint')


def downgrade():
    op.execute('ALTER TABLE hikvision_settings drop column beginning_of_port_range')
    op.execute('ALTER TABLE hikvision_settings drop column end_of_port_range')