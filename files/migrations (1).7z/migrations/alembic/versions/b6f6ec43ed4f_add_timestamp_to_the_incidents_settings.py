"""add timestamp to the incidents settings

Revision ID: b6f6ec43ed4f
Revises: c43b274b5981
Create Date: 2018-05-28 13:17:18.750000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b6f6ec43ed4f'
down_revision = 'c6c1c77254a0'
branch_labels = None
depends_on = None


def upgrade():
     op.execute('ALTER TABLE public.stat_panel_config ADD ts timestamp NOT NULL DEFAULT now()')
     op.execute('ALTER TABLE public.incdesc_config ADD ts timestamp NOT NULL DEFAULT now()')


def downgrade():
    pass
