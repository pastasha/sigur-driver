# -*- coding: utf-8 -*-
"""add_column_for_trassir

Revision ID: dffadbc2bd22
Revises: 04b8c4051004
Create Date: 2018-10-08 12:56:04.302000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'dffadbc2bd22'
down_revision = '04b8c4051004'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)
def upgrade():
    op.bulk_insert(event_catalog, events)
	
def addEv(code, descr, format, equipment = u"trassir", options = 7, level = 0, channel = "notif", color = "#000000"):
        events.append({
            u"code": code,
            u"description": descr,
            u"equipment": equipment,
            u"format": format,
            u"options": options,
            u"level": level,
            u"channel": channel,
            u"color": color
        })
addEv(7036, u"Номер распознан", u"Номер распознан %statement.directObj.name - Номер: %statement.subject.card, Скорость: %statement.subject.speed, Список - %statement.subject.lists")
addEv(7037, u"Номер не распознан", u"Номер не распознан %statement.directObj.name - Номер: %statement.subject.card, Скорость: %statement.subject.speed")


def downgrade():
    op.execute('delete from event_catalog where code in (7036, 7037)')
