"""add_string_object_for_rubej08

Revision ID: 8218f653634a
Revises: 8366efc20c49
Create Date: 2018-06-01 15:56:48.047000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8218f653634a'
down_revision = '8366efc20c49'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table rubej08_tco add column string_object bigint;
        alter table rubej08_group add column string_object bigint;
        alter table rubej08_zone add column string_object bigint;
		alter table rubej08_string add column devparent bigint, add column devaddr bigint;
    """)


def downgrade():
    op.execute("""
        alter table rubej08_tco drop column string_object bigint;
        alter table rubej08_group drop column string_object bigint;
        alter table rubej08_zone drop column string_object bigint;
		alter table rubej08_string drop column devparent bigint, drop column devaddr bigint;
    """)
