"""change common wantedface

Revision ID: 9c57ac878771
Revises: 48cea1b8d420
Create Date: 2019-02-15 16:14:52.968000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9c57ac878771'
down_revision = '48cea1b8d420'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_wantedface
        drop column devparent,
        drop column devaddr,
        drop column uuidid,
        drop column name,
        drop column surname,
        drop column patronymic,
        drop column department,
        drop column comment,
        drop column spisik,
        drop column fame,
        drop column image,
        drop column personid,
        drop column activity
    """)
    
    op.execute("""
        alter table common_wantedface
        add column person bigint,
        add column description text default '',
        add column blacklist boolean default false,
        add column photos text default '',
        add column sync boolean default false,
        add column subsystem_ids text default '{}'
    """)


def downgrade():
    pass
