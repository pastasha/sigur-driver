"""add column for trassir_host

Revision ID: cea78eff5a3e
Revises: 04b56254aab9
Create Date: 2019-12-18 12:07:22.507530

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cea78eff5a3e'
down_revision = '04b56254aab9'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table trassir_host add column time_change_not_place int;
    """)	
    op.execute("""
        UPDATE trassir_host SET time_change_not_place = 60
    """)


def downgrade():
    op.execute('ALTER TABLE trassir_host drop column time_change_not_place')
