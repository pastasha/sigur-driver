"""edit_event_auto_analitics

Revision ID: 792aa8a697f0
Revises: 99a192d5f1b3
Create Date: 2018-11-14 17:20:59.825000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '792aa8a697f0'
down_revision = '99a192d5f1b3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"UPDATE event_catalog SET equipment=DEFAULT WHERE code=692")
    op.execute(u"UPDATE event_catalog SET equipment=DEFAULT WHERE code=693")
    op.execute(u"UPDATE event_catalog SET equipment=DEFAULT WHERE code=694")


def downgrade():
    op.execute(u"UPDATE event_catalog SET equipment='hikvision' WHERE code=692")
    op.execute(u"UPDATE event_catalog SET equipment='hikvision' WHERE code=693")
    op.execute(u"UPDATE event_catalog SET equipment='hikvision' WHERE code=694")

