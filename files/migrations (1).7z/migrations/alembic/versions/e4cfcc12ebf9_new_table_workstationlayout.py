"""new_table_workstationlayout

Revision ID: e4cfcc12ebf9
Revises: ced5996a8fb8
Create Date: 2019-09-02 11:55:45.145503

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e4cfcc12ebf9'
down_revision = 'ced5996a8fb8'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'web_arm_workstationlayout',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('layout', sa.dialects.postgresql.JSONB, nullable=False),
            sa.Column('workstation', sa.Integer, sa.ForeignKey("system_workstation.uniid", ondelete='CASCADE')),
            sa.Column('operator', sa.Integer, sa.ForeignKey("operators.id", ondelete='CASCADE'))
    )


def downgrade():
    op.drop_table('workstation_layout')
