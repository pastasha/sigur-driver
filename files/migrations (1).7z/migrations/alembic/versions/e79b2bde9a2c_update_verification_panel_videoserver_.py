"""update verification panel videoserver column

Revision ID: e79b2bde9a2c
Revises: 3f663d6526ba
Create Date: 2018-05-23 10:29:26.398000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e79b2bde9a2c'
down_revision = '3f663d6526ba'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update system_videoverificationpanel
        set videoserver = '0'
        where videoserver is null or videoserver = '-1' or videoserver = '';
        
        alter table system_videoverificationpanel
        alter column videoserver drop default;
        
        alter table system_videoverificationpanel
        alter column videoserver type bigint using videoserver::bigint;
        
        alter table system_videoverificationpanel
        alter column videoserver set default 0;
    """)


def downgrade():
    op.execute("""
        alter table system_videoverificationpanel
        alter column videoserver type text;
        
        alter table system_videoverificationpanel
        alter column videoserver set default '';
    """)
