# -*- coding: utf-8 -*-

"""Fix surguard events

Revision ID: ef5420ed5b89
Revises: f8bc0cd4892f
Create Date: 2018-03-22 12:05:37.217000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date

# revision identifiers, used by Alembic.
revision = 'ef5420ed5b89'
down_revision = 'f8bc0cd4892f'
branch_labels = None
depends_on = None

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def upgrade():
    op.execute(
        event_catalog.update().where(event_catalog.c.code==13001).\
        values({'format':op.inline_literal(u"[\"Потеря связи с объектом %statement.directObj.name\", \"\"]")})
    )
    op.execute(
        event_catalog.update().where(event_catalog.c.code==14001).\
        values({'format':op.inline_literal(u"[\"Потеря связи с объектом %statement.directObj.name\", \"\"]")})
    )

def downgrade():
    pass
