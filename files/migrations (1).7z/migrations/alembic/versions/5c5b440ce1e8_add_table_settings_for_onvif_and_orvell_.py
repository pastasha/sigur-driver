"""add_table_settings_for_onvif_and_orvell_and_golard

Revision ID: 5c5b440ce1e8
Revises: 22356b826047
Create Date: 2018-07-26 09:43:04.076000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5c5b440ce1e8'
down_revision = '22356b826047'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('orwell_settings',(
            ('timeout', 'int', 'default 5'),
            ('disable_ssl', 'int', 'default 1'),
            ('event_handler_type', 'text', 'default \'BaseNotification\''),
            ('bn_consumer_addr', 'text', ''),	
            ('bn_consumer_port', 'int', 'default 560'),
            ('update_xaddrs', 'int', 'default 1'),
            ('get_velocity_spaces', 'int', 'default 0')		
        ),[], True
    )
    op.create_equipment('onvif_settings',(
            ('timeout', 'int', 'default 5'),
            ('disable_ssl', 'int', 'default 1'),
            ('event_handler_type', 'text', 'default \'BaseNotification\''),
            ('bn_consumer_addr', 'text', ''),	
            ('bn_consumer_port', 'int', 'default 560'),
            ('update_xaddrs', 'int', 'default 1'),
            ('get_velocity_spaces', 'int', 'default 0')		
        ),[], True
    )



def downgrade():
    pass
