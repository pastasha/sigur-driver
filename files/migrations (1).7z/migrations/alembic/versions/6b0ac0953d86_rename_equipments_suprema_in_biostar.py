"""rename equipments suprema in biostar

Revision ID: 6b0ac0953d86
Revises: 841313edea67
Create Date: 2019-01-21 09:53:22.679000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6b0ac0953d86'
down_revision = '841313edea67'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update equipments set name = 'biostar' where name = 'suprema';
        update event_catalog set equipment = 'biostar' where equipment = 'suprema';
        
        update observed_objects set devequipment = 'biostar' where devequipment = 'suprema';
    """)


def downgrade():
    op.execute("""
        update equipments set name = 'suprema' where name = 'biostar';
        update event_catalog set equipment = 'suprema' where equipment = 'biostar';
        
        update observed_objects set devequipment = 'suprema' where devequipment = 'biostar';
    """)
