# -*- coding: utf-8 -*-

"""add foreign keys for opright

Revision ID: 12fd3c40df7a
Revises: b224e2a24075
Create Date: 2018-05-21 09:07:57.122000

Добавляет внешние ключи к таблицам прав и удаляет пару лишних колонок

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '12fd3c40df7a'
down_revision = 'b224e2a24075'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table opright_equip add constraint opright_equip_opright_fkey foreign key(opright) references opright(id) on delete cascade;
        
        alter table opright_ootype add constraint opright_ootype_opright_fkey foreign key(opright) references opright(id) on delete cascade;
        alter table opright_ootype add constraint opright_ootype_ootype_fkey foreign key(ootype) references observed_objects_types(id) on delete cascade;
        
        alter table opright_oobject add constraint opright_oobject_opright_fkey foreign key(opright) references opright(id) on delete cascade;
        alter table opright_oobject add constraint opright_oobject_ootype_fkey foreign key(oobject) references observed_objects(id) on delete cascade;
        
        alter table opright_act_ootype add constraint opright_act_ootype_opright_fkey foreign key(opright) references opright(id) on delete cascade;
        alter table opright_act_ootype add constraint opright_act_ootype_ootype_fkey foreign key(ootype) references observed_objects_types(id) on delete cascade;
        
        alter table opright_act_oobject add constraint opright_act_oobject_opright_fkey foreign key(opright) references opright(id) on delete cascade;
        alter table opright_act_oobject add constraint opright_act_oobject_ootype_fkey foreign key(oobject) references observed_objects(id) on delete cascade;
        
        alter table opright_act_oobject
        drop column execright;
        
        alter table opright_act_ootype
        drop column execright;
    """)


def downgrade():
    op.execute("""
        alter table opright_equip drop constraint opright_equip_opright_fkey;
        
        alter table opright_ootype drop constraint opright_ootype_opright_fkey;
        alter table opright_ootype drop constraint opright_ootype_ootype_fkey;
        
        alter table opright_oobject drop constraint opright_oobject_opright_fkey;
        alter table opright_oobject drop constraint opright_oobject_ootype_fkey;
        
        alter table opright_act_ootype drop constraint opright_act_ootype_opright_fkey;
        alter table opright_act_ootype drop constraint opright_act_ootype_ootype_fkey;
        
        alter table opright_act_oobject drop constraint opright_act_oobject_opright_fkey;
        alter table opright_act_oobject drop constraint opright_act_oobject_ootype_fkey;
        
        alter table opright_act_oobject
        add column execright smallint;
        
        alter table opright_act_ootype
        add column execright smallint;
    """)
