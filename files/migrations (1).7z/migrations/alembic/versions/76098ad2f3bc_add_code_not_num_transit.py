# -*- coding: utf-8 -*-

"""add_code_not_num_transit

Revision ID: a7018b9342d3
Revises: 9d9a5a00c22d
Create Date: 2018-03-16 12:40:40.078000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date

# revision identifiers, used by Alembic.
revision = '76098ad2f3bc'
down_revision = 'd3d31dc6deca'
branch_labels = None
depends_on = None
events = []



event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def upgrade():
    op.bulk_insert(event_catalog, events)


	
def addEv(code, descr, format, equipment = u"securos", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
	

addEv(843, u"Номер не распознан", u"[\"%statement.directObj.name Номер не распознан: поезд № пп %statement.adverbialMode.params.train_id, вагон № пп %statement.adverbialMode.params.wagon_number_in_train\", \"Номер не распознан\"]")

def downgrade():
    pass