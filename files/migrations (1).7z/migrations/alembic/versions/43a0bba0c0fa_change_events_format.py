"""change events format

Revision ID: 43a0bba0c0fa
Revises: 6f61d25ef2ab
Create Date: 2019-12-19 17:52:35.108293

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '43a0bba0c0fa'
down_revision = '6f61d25ef2ab'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set format = replace(format, 'statement.subject.name', 'statement.subject.dev.name')
        where format like '%statement.subject.name%'
    """)


def downgrade():
    pass
