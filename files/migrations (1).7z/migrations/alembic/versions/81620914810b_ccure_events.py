# -*- coding: utf-8 -*-
"""ccure_events

Revision ID: 81620914810b
Revises: 5c64dbbec41a
Create Date: 2019-09-02 09:30:43.408000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '81620914810b'
down_revision = '5c64dbbec41a'
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'ccure', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(50050, 'Найдено устройство', 'Найдено устройство %statement.directObj.name')
add_event(50000, 'Связь с устройством потеряна', 'Связь с устройством %statement.directObj.name потеряна')
add_event(50001, 'Устройство отключено', 'Устройство %statement.directObj.name отключено')
add_event(50002, 'Норма', 'Устройство %statement.directObj.name в норме')
add_event(50003, 'Проблема', 'На устройстве %statement.directObj.name обнаружена проблема')
add_event(50004, 'Обслуживание', 'Устройство %statement.directObj.name в режиме обслуживания')
add_event(50005, 'Открыто', 'Устройство %statement.directObj.name открыто')
add_event(50006, 'Удержание открытым', 'Устройство %statement.directObj.name удерживается открытым')
add_event(50007, 'Заблокировано', 'Устройство %statement.directObj.name заблокировано')
add_event(50008, 'Разблокировано', 'Устройство %statement.directObj.name разблокировано')
add_event(50009, 'Доступ запрещён', 'К устройству %statement.directObj.name доступ запрещён')
add_event(50010, 'Принудительно открыто', 'Устройство %statement.directObj.name принудительно открыто')
add_event(50011, 'Кратковременно разблокировано', 'Устройство %statement.directObj.name кратковременно разблокировано')
add_event(50012, 'Активно', 'Устройство %statement.directObj.name активно')
add_event(50013, 'Ошибка коммуникации', 'На устройстве %statement.directObj.name обнаружена ошибка коммуникации')
add_event(50014, 'Вмешательство', 'На устройстве %statement.directObj.name обнаружено вмешательство')
add_event(50015, 'Взято на охрану', 'Устройство %statement.directObj.name взято на охрану')
add_event(50016, 'Снято с охраны', 'Устройство %statement.directObj.name снято с охраны')
add_event(50017, 'Неактивно', 'Устройство %statement.directObj.name неактивно')
add_event(50018, 'Обновление отключено', 'На устройстве %statement.directObj.name обновление отключено')
add_event(50019, 'Сигнал', 'Устройство %statement.directObj.name сигнализирует')
add_event(50020, 'Проверьте двигатель', 'Проверьте двигатель на устройстве %statement.directObj.name')
add_event(50021, 'Проверьте панель', 'Проверьте панель для устройства %statement.directObj.name')
add_event(50022, 'Низкий заряд батареи', 'На устройстве %statement.directObj.name низкий заряд батареи')
add_event(50023, 'Разблокированно вручную', 'Устройство %statement.directObj.name разблокировано вручную')
add_event(50024, 'Нажата кнопка', 'На устройстве %statement.directObj.name нажата кнопка')
add_event(50025, 'APERIO личинка переопределена', 'Устройство %statement.directObj.name: APERIO личинка переопределена')
add_event(50026, 'APERIO заблокирован', 'Устройство %statement.directObj.name: APERIO заблокирован')
add_event(50027, 'APERIO зажат', 'Устройство %statement.directObj.name: APERIO зажат')


def downgrade():
    op.execute('''
    delete from event_catalog where code >= 50000 and code < 50100
    ''')

