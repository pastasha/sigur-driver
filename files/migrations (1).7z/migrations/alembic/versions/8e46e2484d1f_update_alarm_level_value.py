"""update alarm level value

Revision ID: 8e46e2484d1f
Revises: c4193bc6970e
Create Date: 2019-03-29 13:18:36.849000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8e46e2484d1f'
down_revision = 'c4193bc6970e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update system_usersettings
        set alertlevel = least(alertlevel, 4);
        
        update event_table
        set alarm_level = least(alarm_level, 4);
    """)


def downgrade():
    pass
