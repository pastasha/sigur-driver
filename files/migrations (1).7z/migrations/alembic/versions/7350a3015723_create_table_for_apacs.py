"""create table for apacs

Revision ID: 7350a3015723
Revises: c64d8cab86d2
Create Date: 2019-01-22 22:45:31.853000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7350a3015723'
down_revision = 'c64d8cab86d2'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('apacsbio_equipments',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', '')
        ),[], 'True'
    )
    op.create_equipment('apacsbio_device',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )
    op.create_equipment('apacsbio_door',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )
    op.create_equipment('apacsbio_input',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )
    op.create_equipment('apacsbio_output',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )
    op.create_equipment('apacsbio_childrendevice',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )
    op.execute("""alter table apacsbio_driver add column login text;""")
    op.execute("""alter table apacsbio_driver add column password text;""")


def downgrade():
    pass
