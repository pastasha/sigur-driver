"""delete equipment orion

Revision ID: dd85367a0a6a
Revises: cfd6acd7eb90
Create Date: 2018-09-19 08:47:02.423000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'dd85367a0a6a'
down_revision = 'cfd6acd7eb90'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop table if exists orion_master;
        drop table if exists orion_schedule;
        
        delete from opright_equip where equip = 'orion';
        
        delete from equipments where name = 'orion';
    """)


def downgrade():
    pass
