"""add column for milestone

Revision ID: 76b3b15eafc3
Revises: 5f2ed1295360
Create Date: 2019-10-25 13:49:45.866092

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '76b3b15eafc3'
down_revision = '5f2ed1295360'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE milestone_managmentserver ADD user_name text')
    op.execute('ALTER TABLE milestone_managmentserver ADD password text')
    op.execute('ALTER TABLE milestone_managmentserver ADD ip_server text')
    op.execute('ALTER TABLE milestone_managmentserver ADD rtsp_port int default 580')
    op.execute('ALTER TABLE milestone_managmentserver ADD last_alarm int default 0')
    op.execute('ALTER TABLE milestone_managmentserver ADD archive_port int default 4443')


def downgrade():
    op.execute('ALTER TABLE milestone_managmentserver drop column user_name')
    op.execute('ALTER TABLE milestone_managmentserver drop column password')
    op.execute('ALTER TABLE milestone_managmentserver drop column ip_server')
    op.execute('ALTER TABLE milestone_managmentserver drop column rtsp_port')
    op.execute('ALTER TABLE milestone_managmentserver drop column last_alarm')
    op.execute('ALTER TABLE milestone_managmentserver drop column archive_port')
