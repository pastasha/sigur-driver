"""create equipments for apacx bio

Revision ID: c64d8cab86d2
Revises: c68b12614bd1
Create Date: 2019-01-12 18:52:21.293000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c64d8cab86d2'
down_revision = 'c68b12614bd1'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('apacsbio_driver',(
            ('description', 'text', ''),
            ('server_port', 'text', ''),
            ('active', 'boolean', ''),
        ),[], 'True'
    )
    op.execute("""INSERT INTO equipments(name,enabled) VALUES('apacsbio',TRUE)""")


def downgrade():
    op.execute("""DELETE FROM equipments WHERE name = 'apacsbio';""")
    op.drop_table('apaxbio_driver')
