"""add indexes for requisitions

Revision ID: e0e31a12f24d
Revises: cfe812aab41b
Create Date: 2019-10-28 12:49:06.580988

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e0e31a12f24d'
down_revision = 'cfe812aab41b'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""CREATE INDEX IF NOT EXISTS requisition_status_idx ON public.requisition USING btree (status)""")
    op.execute("""CREATE INDEX IF NOT EXISTS requisition_info_create_dt_idx ON public.requisition_info USING btree (create_dt)""")


def downgrade():
    op.execute("""DROP INDEX IF EXISTS requisition_status_idx""")
    op.execute("""DROP INDEX IF EXISTS requisition_info_create_dt_idx""")
