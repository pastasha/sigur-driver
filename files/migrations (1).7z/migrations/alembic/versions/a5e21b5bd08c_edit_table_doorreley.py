"""edit_table_doorreley

Revision ID: a5e21b5bd08c
Revises: 7b13d428d4c0
Create Date: 2018-09-30 22:21:40.620000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a5e21b5bd08c'
down_revision = '7b13d428d4c0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""        
        alter table suprema_doorreley drop column id;
        alter table suprema_doorreley drop column description;
        alter table suprema_doorreley add column link_device bigint;
        alter table suprema_doorreley add column index bigint;
    """)


def downgrade():
    pass
