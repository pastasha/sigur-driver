"""add system videoserver equipment

Revision ID: fd19e528337b
Revises: 8b33e893d5f5
Create Date: 2019-09-05 11:56:14.874000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fd19e528337b'
down_revision = '8b33e893d5f5'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('system_videoserver', (
        ('description', 'text', ''),
        ('ip_addr', 'text', "default ''"),
        ('port', 'int', 'default 0'),
        ('login', 'text', "default ''"),
        ('password', 'text', "default ''")
    ), [])


def downgrade():
    op.drop_table('system_videoserver')
