# -*- coding: utf-8 -*-

"""add remote guid for event redirect

Revision ID: d8c6d270a123
Revises: 6248ed9f0d94
Create Date: 2018-04-18 11:53:29.680000

Добавляет колонку remote_guid к переопределениям событий для типов объектов мониторинга

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd8c6d270a123'
down_revision = '6248ed9f0d94'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('obsobj_type_event_brg',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute('update obsobj_type_event_brg set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')

def downgrade():
    op.drop_column('obsobj_type_event_brg', 'remote_guid')
