"""addition bytes for apollo

Revision ID: b1bb34bf9efe
Revises: 9710707aaf0f
Create Date: 2018-08-06 15:49:25.403000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b1bb34bf9efe'
down_revision = '9710707aaf0f'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('apollo_additionalbytes', [
            ('description', 'text', ''),
            ('byte_a', 'int', 'default 0'),
            ('byte_b', 'int', 'default 0'),
            ('byte_c', 'int', 'default 0'),
            ('byte_d', 'int', 'default 0'),
            ('type', 'text', "default 'rdr'")
        ], [], False
    )
    op.add_column('apollo_reader', sa.Column('additional', sa.BigInteger(), nullable=True))
    op.add_column('apollo_alarmpanel', sa.Column('additional', sa.BigInteger(), nullable=True))


def downgrade():
    pass
