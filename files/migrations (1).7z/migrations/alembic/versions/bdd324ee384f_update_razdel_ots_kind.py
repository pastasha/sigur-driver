# -*- coding: utf-8 -*-

"""update razdel ots kind

Revision ID: bdd324ee384f
Revises: 9f1a8907c7e3
Create Date: 2018-09-03 14:20:04.253000

Обновление kind у типа ОМ Раздел ОТС
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bdd324ee384f'
down_revision = '9f1a8907c7e3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"update observed_objects_types set kind='part' where name='Раздел ОТС'")


def downgrade():
    pass
