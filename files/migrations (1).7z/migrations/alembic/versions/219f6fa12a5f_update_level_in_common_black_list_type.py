"""Update level in common black list type

Revision ID: 219f6fa12a5f
Revises: 56b2c0066d5a
Create Date: 2019-10-15 15:35:31.295584

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '219f6fa12a5f'
down_revision = '56b2c0066d5a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update common_blacklisttype
        set level = 0
        where level is null
    """)


def downgrade():
    pass
