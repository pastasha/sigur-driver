"""add column for cmd for utils

Revision ID: cd1f01a15f23
Revises: 428e8439baac
Create Date: 2019-05-16 22:26:54.700000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cd1f01a15f23'
down_revision = '428e8439baac'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE apacsbio_driver ADD cd_to_exe text')


def downgrade():
    op.execute('ALTER TABLE apacsbio_driver drop column cd_to_exe')
