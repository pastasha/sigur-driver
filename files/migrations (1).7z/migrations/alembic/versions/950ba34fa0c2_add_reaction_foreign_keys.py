"""add reaction foreign keys

Revision ID: 950ba34fa0c2
Revises: 0e3a899732c7
Create Date: 2019-07-02 10:12:13.178000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '950ba34fa0c2'
down_revision = '0e3a899732c7'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        delete from reaction_actions
        where object not in (select id from observed_objects where deletemark = 0);
        
        alter table reaction_actions
        add constraint reaction_actions_object_fkey
        foreign key(object) references observed_objects(id) on delete cascade;
    """)


def downgrade():
    pass
