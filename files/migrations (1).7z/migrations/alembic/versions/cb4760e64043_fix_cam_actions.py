"""fix cam actions

Revision ID: cb4760e64043
Revises: 70883adebfa6
Create Date: 2018-10-09 18:22:01.774000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cb4760e64043'
down_revision = '70883adebfa6'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        DO $$ 
        DECLARE
           json1 jsonb;
        BEGIN 
            json1 = (select actions from observed_objects_types where id=27)::jsonb;
            json1 = jsonb_set(json1, '{"move", "params", "pan_speed"}'
                         , json1->'move'->'params'->'pan') #- '{"move", "params", "pan"}';
            json1 = jsonb_set(json1, '{"move", "params", "tilt_speed"}'
                         , json1->'move'->'params'->'titl') #- '{"move", "params", "titl"}';
            json1 = jsonb_set(json1, '{"move", "params", "zoom_speed"}'
                         , json1->'move'->'params'->'zoom') #- '{"move", "params", "zoom"}';
           json1 = jsonb_set(json1, '{"move", "instr", 0, "params", tilt_speed}', '"&tilt_speed"');
           json1 = jsonb_set(json1, '{"move", "instr", 0, "params", pan_speed}', '"&pan_speed"');
           json1 = jsonb_set(json1, '{"move", "instr", 0, "params", zoom_speed}', '"&zoom_speed"');
           UPDATE observed_objects_types SET actions = jsonb_pretty(json1) where id=27;
        END $$;
    """)


def downgrade():
    pass
