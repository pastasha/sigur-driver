"""add_table_from_device_gruop_supema

Revision ID: 7b13d428d4c0
Revises: 005a694ba9a1
Create Date: 2018-09-30 19:38:44.645000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7b13d428d4c0'
down_revision = '005a694ba9a1'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('suprema_devicegroup', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('description', 'varchar(256)', '')
        ), [], False
    )
    op.create_equipment('suprema_devicetype', (
        ('devparent', 'bigint', ''),
        ('devaddr', 'bigint', ''),
        ('id', 'bigint', ''),
        ('input_port_num', 'bigint', ''),
        ('description', 'varchar(256)', ''),
        ('output_port_num', 'bigint', ''),
        ('relay_num', 'bigint', ''),
        ('rs485_channel_num', 'bigint', ''),
        ('scan_card', 'boolean', ''),
        ('scan_face', 'boolean', ''),
        ('scan_fingerprint', 'boolean', '')
        ), [], False
    )
    op.execute("""
        alter table suprema_device drop column device_group
    """)
    op.execute("""        
        alter table suprema_device add column type bigint;
    """)
    op.execute("""
        alter table suprema_device drop column id;
        alter table suprema_device add column id bigint;
    """)
    


def downgrade():    
    op.drop_table('suprema_devicegroup')
    op.drop_table('suprema_devicetype')
