"""modify oo_table

Revision ID: 23821092682e
Revises: 71e73df10848
Create Date: 2019-04-19 10:49:06.328000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '23821092682e'
down_revision = '71e73df10848'
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table('oo_table', 'obsobj_type_state_handlers')
    op.alter_column('obsobj_type_state_handlers', 'extid', new_column_name='id')
    op.execute("""
        update obsobj_type_state_handlers set type = null where type = -1;
        delete from obsobj_type_state_handlers where type not in (select id from observed_objects_types)
    """)
    op.create_foreign_key('obsobj_type_state_handlers_type_fkey', 'obsobj_type_state_handlers', 'observed_objects_types', ['type'], ['id'], ondelete='CASCADE')


def downgrade():
    pass
