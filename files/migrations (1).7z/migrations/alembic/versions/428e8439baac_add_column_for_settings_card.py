"""add column for settings card

Revision ID: 428e8439baac
Revises: db0dcac577c9
Create Date: 2019-03-17 21:44:58.620000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '428e8439baac'
down_revision = 'db0dcac577c9'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('apacsbio_cardsettings',(
            ('UID', 'text', ''),
            ('description', 'text', '')
        ),[],'True'
    )
    op.execute('ALTER TABLE apacsbio_driver ADD card_settings varchar(256)')


def downgrade():
    op.drop_table('apacsbio_cardsettings')
    op.execute('ALTER TABLE apacsbio_driver drop column card_settings')
