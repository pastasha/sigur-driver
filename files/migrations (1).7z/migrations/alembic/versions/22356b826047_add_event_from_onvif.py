# -*- coding: utf-8 -*-

"""add event from onvif

Revision ID: 22356b826047
Revises: cbf27426822e
Create Date: 2018-06-26 10:39:52.709000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = '22356b826047'
down_revision = 'cbf27426822e'
branch_labels = None
depends_on = None
events = []



event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"onvif", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(128300, u"Видеокамера перешла в пресет", u"[\"%statement.directObj.name видеокамера перешла в пресет %statement.adverbialMode.params\", \"Видеокамера перешла в пресет\"]")
addEv(128301, u"Видеокамера покинула пресет", u"[\"%statement.directObj.name видеокамера покинула пресет %statement.adverbialMode.params\", \"Видеокамера перешла в пресет\"]")
addEv(128302, u"Тревожное событие", u"[\"%statement.directObj.name тревожное событие: %statement.adverbialMode.params\", \"Тревожное событие\"]")


def downgrade():
    pass
