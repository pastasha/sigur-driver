# -*- coding: utf-8 -*-

"""set default values for new columns

Revision ID: bbc5af9d7f7a
Revises: 182e0397f7d6
Create Date: 2018-09-26 11:00:53.811000

Миграция выставляет значения большинству колонок которые были добавлены в последних обновлениях но для существующих записей не было присвоено значений

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bbc5af9d7f7a'
down_revision = '182e0397f7d6'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update common_permittemplate set template_type = 0 where template_type is null;
        
        update mobotix_cam set port = 80 where port is null;
        
        update orioniso_grouppart set key = 0 where key is null;
        update orioniso_part set key = 0 where key is null;
        
        update rubej08_group set string_object = -1 where string_object is null;
        update rubej08_zone set string_object = -1 where string_object is null;
        update rubej08_tco set string_object = -1 where string_object is null;
        
        update system_map set hierarchy_level = 0 where hierarchy_level is null;
        update system_gismap set hierarchy_level = 0 where hierarchy_level is null;
        
        update orionintgrsrv_accessitemzone set dconf = 0 where dconf is null;
        update orionintgrsrv_accessitemzone set tconf = 0 where tconf is null;
        update orionintgrsrv_schedule_accessitempoint set dconf = 0 where dconf is null;
        update orionintgrsrv_schedule_accessitempoint set tconf = 0 where tconf is null;
        
        update orioniso_port set portrate = 9600 where portrate is null;
        
    """)


def downgrade():
    pass
