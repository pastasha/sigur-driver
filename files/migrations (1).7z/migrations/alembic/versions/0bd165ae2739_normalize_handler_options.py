"""normalize handler options

Revision ID: 0bd165ae2739
Revises: 8140861313d0
Create Date: 2019-03-26 11:40:37.504000

"""
import re

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0bd165ae2739'
down_revision = '8140861313d0'
branch_labels = None
depends_on = None


def repl(mathObj):
    strnum = '0x'+mathObj.group(0)[-4:]
    num = int(strnum, 16)
    char = chr(num)
    return char

    
def upgrade():
    op.execute("""
        update handler_options
        set import_post_time = 0
        where import_post_time is null;
        
        update handler_options
        set import_pre_time = 0
        where import_pre_time is null;
        
        update handler_options
        set import_arch = false
        where import_arch is null;
        
        update handler_options
        set capturetimeout = 0
        where capturetimeout is null;
        
        update handler_options
        set incident = substr(incident, 2, length(incident)-2);
        
        update handler_options
        set incident = ''
        where incident is null;
        
        update handler_options
        set channel = substr(channel, 2, length(channel)-2);
        
        update handler_options
        set channel = 'notif'
        where channel = '' or channel is null;
        
        update handler_options
        set sound = substr(sound, 2, length(sound)-2);
        
        update handler_options
        set sound = ''
        where sound is null;
        
        update handler_options
        set color = substr(color, 2, length(color)-2);
        
        update handler_options
        set color = '#000000'
        where color = '' or color is null;
        
        update handler_options
        set alter_text = substr(alter_text, 2, length(alter_text)-2);
        
        update handler_options
        set rtspcam = ''
        where rtspcam = '""' or rtspcam is null;
        
        update handler_options
        set incidentobsobj = '{}'::json
        where incidentobsobj is null;
        
        update handler_options
        set oocam = '[]'::json
        where oocam::text = '""' or oocam is null;
        
        update handler_options
        set user_info = false
        where user_info is null;
        
        update handler_options
        set menu = '{}'::json
        where menu is null;
        
        update handler_options
        set confirmation = false
        where confirmation is null;
        
        update handler_options
        set alter_text = ''
        where alter_text is null;
        
        update handler_options
        set incident = ''
        where incident is null;
        
        update handler_options
        set closesameincident = false
        where closesameincident is null;
        
        update handler_options
        set dutymon = false
        where dutymon is null;
    """)
    conn = op.get_bind()
    res = conn.execute("""
        select id, alter_text, incident, sound
        from handler_options
    """)

    data = [{
        'id': row[0],
        'text': row[1],
        'incident': row[2],
        'sound': row[3]
    } for row in res.fetchall()]
    
    for handler in data:
        newText = re.sub('\\\\u[0-9a-z]{4}', repl, handler['text'], 0, re.U)
        newIncident = re.sub('\\\\u[0-9a-z]{4}', repl, handler['incident'], 0, re.U)
        newSound = re.sub('\\\\u[0-9a-z]{4}', repl, handler['sound'], 0, re.U)
        
        conn.execute("""
            update handler_options
            set alter_text = %s, incident = %s, sound = %s
            where id = %s
        """, (newText, newIncident, newSound, handler['id']))


def downgrade():
    pass
