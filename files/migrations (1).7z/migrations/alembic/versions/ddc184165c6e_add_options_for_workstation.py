"""add options for workstation

Revision ID: ddc184165c6e
Revises: 184fb1969dd0
Create Date: 2019-11-14 14:17:04.327792

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ddc184165c6e'
down_revision = '184fb1969dd0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_usersettings
        add column showcamondutymonitor boolean default false,
        add column alarmonmappolicy integer default 0
    """)


def downgrade():
    op.execute("""
        alter table system_usersettings
        drop column showcamondutymonitor,
        drop column alarmonmappolicy
    """)
