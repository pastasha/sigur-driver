"""change trassir columns

Revision ID: 2f1752c432e8
Revises: 4dacfc15ee4a
Create Date: 2019-08-27 12:18:26.711000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2f1752c432e8'
down_revision = '4dacfc15ee4a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update trassir_detector
        set active = '0' where active = 'false';
        
        update trassir_detector
        set active = '1' where active != '0';
        
        alter table trassir_detector
        alter column active type int using active::int;
    """)


def downgrade():
    pass
