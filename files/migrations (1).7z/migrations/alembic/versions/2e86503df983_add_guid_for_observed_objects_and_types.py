"""add guid for observed objects and types

Revision ID: 2e86503df983
Revises: 547051ab55c1
Create Date: 2018-03-15 14:59:16.269000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2e86503df983'
down_revision = '547051ab55c1'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    conn.execute("alter table observed_objects add column remote_guid text")
    conn.execute("alter table observed_objects_types add column remote_guid text")
    conn.execute("update observed_objects set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid")
    conn.execute("update observed_objects_types set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid")

def downgrade():
    conn = op.get_bind()
    conn.execute("alter table observed_objects drop column remote_guid")
    conn.execute("alter table observed_objects_types drop column remote_guid")
