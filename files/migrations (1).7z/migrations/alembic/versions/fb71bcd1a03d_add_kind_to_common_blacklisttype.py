"""add kind to common blacklisttype

Revision ID: fb71bcd1a03d
Revises: 851ed13d21fe
Create Date: 2019-02-14 13:49:30.327000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fb71bcd1a03d'
down_revision = '851ed13d21fe'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_blacklisttype
        add column kind int default 0
    """)


def downgrade():
    op.execute("""
        alter table common_blacklisttype
        drop column kind
    """)
