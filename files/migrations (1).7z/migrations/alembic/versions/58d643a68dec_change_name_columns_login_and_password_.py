"""change name columns login and password in remote_site to remote_login and remote_password and add columns local_login and local_password

Revision ID: 58d643a68dec
Revises: d1d581eef6f4
Create Date: 2018-06-18 12:18:53.129000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '58d643a68dec'
down_revision = 'd1d581eef6f4'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""ALTER TABLE remote_site RENAME login TO remote_login""")
    op.execute("""ALTER TABLE remote_site RENAME password TO remote_password""")
    op.execute("""ALTER TABLE remote_site ADD local_login VARCHAR(256)""")
    op.execute("""ALTER TABLE remote_site ADD local_password VARCHAR(256)""")


def downgrade():
    op.execute("""ALTER TABLE remote_site RENAME remote_login TO login""")
    op.execute("""ALTER TABLE remote_site RENAME remote_password TO password""")
    op.execute("""ALTER TABLE remote_site DROP local_login""")
    op.execute("""ALTER TABLE remote_site DROP local_password""")
