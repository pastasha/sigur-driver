"""add goalcity events

Revision ID: 29bcbf9d6bbc
Revises: 36921b5c946f
Create Date: 2019-10-16 12:20:52.316629

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '29bcbf9d6bbc'
down_revision = '36921b5c946f'
branch_labels = None
depends_on = None

events = []

event_catalog = table('event_catalog',
    column('code', Integer),
    column('description', String),
    column('equipment', String),
    column('format', String),
    column('options', Integer),
    column('level', Integer),
    column('channel', String),
    column('color', String)
)


def add_event(code, descr, format, equipment=u'goalcity', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


def upgrade():
    op.bulk_insert(event_catalog, events)


def downgrade():
    op.execute('''
        delete from event_catalog where code >= 7250 and code < 7300
    ''')


add_event(7251, 'Видеокамера подключена', u'Видеокамера %statement.directObj.name подключена')
add_event(7252, 'Потеря сигнала видеокамеры',
          u'Потеря сигнала видеокамеры %statement.directObj.name')
add_event(7253, 'Тревога детектора движения',
          u'Тревога детектора движения %statement.directObj.name')
add_event(7254, 'Тревога оставленного предмета',
          u'Тревога оставленного предмета %statement.directObj.name')
add_event(7255, 'Конец тревоги', u'Конец тревоги %statement.directObj.name')
add_event(7256, 'Обнаружено лицо', u'Обнаружено лицо %statement.directObj.name')
add_event(7257, 'Идентификация транспортного средства на видеокамере',
          u'Идентификация транспортного средства %statement.subject.card на видеокамере %statement.directObj.name')
add_event(7258, 'Сервер подключен', u'Сервер %statement.directObj.name подключен')
add_event(7259, 'Сервер отключен', u'Сервер %statement.directObj.name отключен')
add_event(7260, 'Сервер подключился к Web API',
          u'Сервер %statement.directObj.name подключился к Web API')
add_event(7261, 'Сервер ошибка при подключении к Web API',
          u'Сервер %statement.directObj.name ошибка при подключении к Web API')
add_event(7262, 'Сервер ошибка авторизации в Web API',
          u'Сервер %statement.directObj.name ошибка авторизации в Web API')
add_event(7263, 'Сервер отключился от Web API',
          u'Сервер %statement.directObj.name отключился от Web API')
add_event(7264, 'Сервер подключился к Rotor',
          u'Сервер %statement.directObj.name подключился к Rotor')
add_event(7265, 'Сервер ошибка при подключении к Rotor',
          u'Сервер %statement.directObj.name ошибка при подключении к Rotor')
add_event(7266, 'Сервер отключился от Rotor',
          u'Сервер %statement.directObj.name отключился от Rotor')
