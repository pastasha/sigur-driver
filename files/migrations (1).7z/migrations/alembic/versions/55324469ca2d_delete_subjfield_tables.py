"""delete subjfield tables

Revision ID: 55324469ca2d
Revises: 8e46e2484d1f
Create Date: 2018-10-19 08:45:34.382000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '55324469ca2d'
down_revision = '8e46e2484d1f'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('common_subjfield')
    op.drop_table('common_subject_subjfield')


def downgrade():
    pass
