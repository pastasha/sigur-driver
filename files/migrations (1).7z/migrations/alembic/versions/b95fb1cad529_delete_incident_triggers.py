"""delete incident triggers

Revision ID: b95fb1cad529
Revises: f61b8e8f1302
Create Date: 2019-06-20 14:48:23.270000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b95fb1cad529'
down_revision = 'f61b8e8f1302'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop trigger incident_category_deleted_trig_after_delete on incidents.incident_category;
        drop trigger incident_category_inserted_trig_after_insert on incidents.incident_category;
        drop trigger incident_category_updated_trig_after_update on incidents.incident_category;
        drop trigger incident_task_deleted_trig_after_delete on incidents.incident_task;
        drop trigger incident_task_inserted_trig_after_insert on incidents.incident_task;
        drop trigger incident_task_updated_trig_after_update on incidents.incident_task;
        drop trigger incident_task_type_deleted_trig_after_delete on incidents.incident_task_type;
        drop trigger incident_task_type_inserted_trig_after_insert on incidents.incident_task_type;
        drop trigger incident_task_type_updated_trig_after_update on incidents.incident_task_type;
        drop trigger incident_type_deleted_trig_after_delete on incidents.incident_type;
        drop trigger incident_type_inserted_trig_after_insert on incidents.incident_type;
        drop trigger incident_type_updated_trig_after_update on incidents.incident_type;
        drop trigger incident_type_category_deleted_trig_after_delete on incidents.incidenttype_incidentcategory_brg;
        drop trigger incident_type_category_inserted_trig_after_insert on incidents.incidenttype_incidentcategory_brg;
        drop trigger incident_type_category_updated_trig_after_update on incidents.incidenttype_incidentcategory_brg;
        
        drop function incidents.incident_category_changed_proc();
        drop function incidents.incident_task_changed_proc();
        drop function incidents.incident_task_type_changed_proc();
        drop function incidents.incident_type_category_changed_proc();
        drop function incidents.incident_type_changed_proc();
    """)


def downgrade():
    pass
