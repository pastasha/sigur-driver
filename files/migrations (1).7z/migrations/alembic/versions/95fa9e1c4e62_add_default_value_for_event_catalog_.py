"""add default value for event_catalog remote_guid

Revision ID: 95fa9e1c4e62
Revises: d9c6e72c5239
Create Date: 2018-07-11 11:47:58.017000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '95fa9e1c4e62'
down_revision = 'b04a069ee345'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table event_catalog 
        alter column remote_guid set default md5(random()::text || clock_timestamp()::text)::uuid 
    """)


def downgrade():
    op.execute("""
        alter table event_catalog 
        alter column remote_guid drop default
    """)
