# -*- coding: utf-8 -*-

"""add guid for oprights

Revision ID: b224e2a24075
Revises: d8c6d270a123
Create Date: 2018-04-23 10:46:07.119000

Добавляет колонку remote_guid к таблице opright

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b224e2a24075'
down_revision = '790b8c184abc'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('opright',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute("""
        update opright set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid;
        delete from opright_equip
        where opright is null or modifyright is null or equip is null or opright not in (select id from opright);
        
        delete from opright_oobject
        where opright is null or modifyright is null or oobject is null or oobject not in (select id from observed_objects) or opright not in (select id from opright);

        delete from opright_ootype
        where opright is null or modifyright is null or ootype is null or ootype not in (select id from observed_objects_types) or opright not in (select id from opright);

        delete from opright_act_oobject
        where opright is null or act is null or oobject is null or oobject not in (select id from observed_objects) or opright not in (select id from opright);

        delete from opright_act_ootype
        where opright is null or act is null or ootype is null or ootype not in (select id from observed_objects_types) or opright not in (select id from opright);
    """)


def downgrade():
    op.drop_column('opright', 'remote_guid')
