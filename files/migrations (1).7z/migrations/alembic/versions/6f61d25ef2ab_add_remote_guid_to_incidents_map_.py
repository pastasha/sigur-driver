"""add remote_guid to incidents_map_register

Revision ID: 6f61d25ef2ab
Revises: 26155e65d0c5
Create Date: 2019-12-18 17:40:05.781815

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6f61d25ef2ab'
down_revision = '26155e65d0c5'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""CREATE OR REPLACE VIEW public.incident_map_register as SELECT ir.id,
        oom.map_id,
        oogm.map_id AS gismap_id,
        it.name,
        ir.startdt,
        ir.level,
        ir.acceptiondt,
        ir.sourceid,
        ir.placeid,
        ir.closedt,
        ir.status AS incident_status,
        ir.latitude,
        ir.longitude,
        ir.incidentobsobj,
        ir.status,
        ir.remote_guid
       FROM incidents.incident_register ir
         JOIN incidents.incident_type it ON ir.typeid = it.id
         LEFT JOIN observed_objects_on_map oom ON oom.obsobj_id = ir.placeid OR oom.obsobj_id = ir.sourceid
         LEFT JOIN observed_objects_on_gismap oogm ON oogm.obsobj_id = ir.placeid OR oogm.obsobj_id = ir.sourceid
      WHERE ir.closedt IS NULL
      GROUP BY ir.id, oom.map_id, oogm.map_id, it.name, ir.startdt, ir.level, ir.acceptiondt, ir.sourceid, ir.placeid, ir.status, ir.longitude, ir.latitude, ir.remote_guid
    """)


def downgrade():
    pass
