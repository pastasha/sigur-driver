"""add comment field to pce instr

Revision ID: da98c19eeb5c
Revises: 5ba7ef593a57
Create Date: 2019-09-25 22:43:48.586849

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'da98c19eeb5c'
down_revision = '5ba7ef593a57'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table pce_instr
        rename column description to comment
    """)


def downgrade():
    op.execute("""
        alter table pce_instr
        rename column comment to description
    """)
