"""esser tables

Revision ID: 2763709f8a18
Revises: 1deaef1d626d
Create Date: 2018-09-25 18:45:48.328487

"""
from alembic import op

# revision identifiers, used by Alembic.
revision = '2763709f8a18'
down_revision = '037ad7d36b98'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''insert into equipments(name, enabled)
            values('esser', true)
        ''')

    op.create_equipment('esser_root', [
        ('description', 'text', ''),
        ('driver_addr', 'text', ''),
        ('dev_addr', 'text', ''),
        ('dev_port', 'int', ''),
        ('login', 'text', ''),
        ('password', 'text', ''),
        ('prefix', 'text', ''),
        ('interval', 'int', 'default 5'),
        ('dead_count', 'int', 'default 3'),
        ('command_interval', 'int', 'default 100'),
        ('conn_lose_timeout', 'int', 'default 10'),
        ('active', 'boolean', 'default false'),
        ('synchronization', 'int', 'default 0')
    ], [], True
                        )
    op.create_equipment('esser_firedetector', [
        ('description', 'text', ''),
        ('type', 'text', ''),
        ('external_id', 'text', '')
    ], [], True
                        )


def downgrade():
    pass
