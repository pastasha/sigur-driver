# -*- coding: utf-8 -*-
"""missing_events_trassir

Revision ID: 182e0397f7d6
Revises: 2a1ead1d3cf9
Create Date: 2018-09-13 10:44:06.646000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date

# revision identifiers, used by Alembic.
revision = '182e0397f7d6'
down_revision = '2a1ead1d3cf9'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"trassir", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(7035, u"Запись выключена", u"[\"%statement.directObj.name запись выключена %statement.adverbialMode.params\", \"Запись выключена\"]")
addEv(7033, u"Объект вошел в зону", u"[\"%statement.directObj.name объект вошел в зону %statement.adverbialMode.params\", \"Объект вошел в зону\"]")
addEv(7034, u"Объект покинул зону", u"[\"%statement.directObj.name объект покинул зону %statement.adverbialMode.params\", \"Объект покинул зону\"]")


def downgrade():
    pass
