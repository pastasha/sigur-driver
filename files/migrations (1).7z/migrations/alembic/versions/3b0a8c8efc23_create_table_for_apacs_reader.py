"""create table for apacs_reader

Revision ID: 3b0a8c8efc23
Revises: 7350a3015723
Create Date: 2019-01-29 23:12:20.644000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3b0a8c8efc23'
down_revision = '7350a3015723'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('apacsbio_reader',(
            ('UID', 'text', ''),
            ('description', 'text', ''),
            ('str_name', 'text', ''),
            ('apacs_type', 'text', ''),
            ('str_desc', 'text', ''),
            ('site_ID', 'text', ''),
            ('str_alias', 'text', ''),
            ('str_ip_address', 'text', '')
        ),[], 'True'
    )


def downgrade():
    pass
