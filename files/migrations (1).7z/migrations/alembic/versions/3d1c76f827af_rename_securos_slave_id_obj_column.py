"""rename securos slave id_obj column

Revision ID: 3d1c76f827af
Revises: 595d051ef080
Create Date: 2019-01-15 15:30:48.563000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3d1c76f827af'
down_revision = '595d051ef080'
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column('securos_slave', 'id_obj', new_column_name='network_name')


def downgrade():
    op.alter_column('securos_slave', 'network_name', new_column_name='id_obj')
