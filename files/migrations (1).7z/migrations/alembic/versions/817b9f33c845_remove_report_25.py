"""remove report 25

Revision ID: 817b9f33c845
Revises: bdd324ee384f
Create Date: 2018-09-05 14:01:47.827000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '817b9f33c845'
down_revision = 'bdd324ee384f'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("delete from operator_report_brg where report=25")
    op.execute("delete from reports_params where idreport=25")
    op.execute("delete from reports where uniid=25")

def downgrade():
    pass
