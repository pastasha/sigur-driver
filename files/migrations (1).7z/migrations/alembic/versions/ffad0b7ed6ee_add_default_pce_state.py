# -*- coding: utf-8 -*-

"""add default pce_state

Revision ID: ffad0b7ed6ee
Revises: b9aadafc5f51
Create Date: 2018-10-01 11:19:07.508000

Добавляет состояния для разделов и входов, а так же соответствующие обработчики состояний. При обновлении на не пустую БД могут появиться дубли.
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ffad0b7ed6ee'
down_revision = 'b9aadafc5f51'
branch_labels = None
depends_on = None


def upgrade():
    strings = {
        1 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - готов'
        },
        2 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - не готов'
        },
        3 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - неисправен'
        },
        4 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - нет связи'
        },
        5 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - поставлен на охрану'
        },
        6 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - пропущен'
        },
        7 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - тревога принята'
        },
        8 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - ТРЕВОГА!'
        },
        9 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Ш: %OBJECT - блокирован'
        },
        
        10 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - ТРЕВОГА!'
        },
        11 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - все тревоги приняты'
        },
        12 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - готов к постановке на охрану'
        },
        13 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - неисправен'
        },
        14 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - имеет обойденные устройства'
        },
        15 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - не готов к постановке на охрану'
        },
        16 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - нет связи'
        },
        17 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - полностью на охране'
        },
        18 : {
            'uniid': None,
            'description': u'[%DATE %TIME] Р: %OBJECT - частично взят на охрану'
        }
    }
    
    state_handlers = {
        1 : {
            'uniid': None,
            'description': u'Вход - Готов',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':1
        },
        2 : {
            'uniid': None,
            'description': u'Вход - Не готов',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':2
        },
        3 : {
            'uniid': None,
            'description': u'Вход - Неисправен',
            'alarmlistenable': 1,
            'needconfirmenable': 0,
            'formatstring':3
        },
        4 : {
            'uniid': None,
            'description': u'Вход - Нет связи',
            'alarmlistenable': 1,
            'needconfirmenable': 0,
            'formatstring':4
        },
        5 : {
            'uniid': None,
            'description': u'Вход - поставлен на охрану',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':5
        },
        6 : {
            'uniid': None,
            'description': u'Вход - пропущен',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':6
        },
        7 : {
            'uniid': None,
            'description': u'Вход - тревога принята',
            'alarmlistenable': 1,
            'needconfirmenable': 0,
            'formatstring':7
        },
        8 : {
            'uniid': None,
            'description': u'Вход - ТРЕВОГА!',
            'alarmlistenable': 1,
            'needconfirmenable': 1,
            'formatstring':8
        },
        9 : {
            'uniid': None,
            'description': u'Вход - блокирован',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':9
        },      
        10 : {
            'uniid': None,
            'description': u'Раздел - ТРЕВОГА!',
            'alarmlistenable': 1,
            'needconfirmenable': 1,
            'formatstring':10
        },
        11 : {
            'uniid': None,
            'description': u'Раздел - все тревоги приняты',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':11
        },
        12 : {
            'uniid': None,
            'description': u'Раздел - готов к постановке на охрану',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':12
        },
        13 : {
            'uniid': None,
            'description': u'Раздел - неисправен',
            'alarmlistenable': 1,
            'needconfirmenable': 0,
            'formatstring':13
        },
        14 : {
            'uniid': None,
            'description': u'Раздел - имеет обойденные устройства',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':14
        },
        15 : {
            'uniid': None,
            'description': u'Раздел - не готов к постановке на охрану',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring':15
        },
        16 : {
            'uniid': None,
            'description': u'Раздел - нет связи',
            'alarmlistenable': 1,
            'needconfirmenable': 0,
            'formatstring':16
        },
        17 : {
            'uniid': None,
            'description': u'Раздел - полностью на охране',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring': 17
        },
        18 : {
            'uniid': None,
            'description': u'Раздел - частично взят на охрану',
            'alarmlistenable': 0,
            'needconfirmenable': 0,
            'formatstring': 18
        }
    }
    flags = ['mconn', 'mdef', 'mtrb', 'mack', 'malrm', 'mfrc', 'majar', 'mtamp',
    'mattn', 'marm', 'mbps', 'mact', 'mact2', 'mact3', 'mblock', 'mdelay', 'msmod',
    'mdmon', 'mamon', 'vconn', 'vdef', 'vtrb', 'vack', 'valrm', 'vfrc', 'vajar',
    'vtamp', 'vattn', 'varm', 'vbps', 'vact', 'vact2', 'vact3', 'vblock', 'vdelay',
    'vsmod', 'vdmon', 'vamon']
    states = [{
        'description': u'Вход - Готов (пассивен)',
        'flags': [2,2,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':1,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Нет связи',
        'flags': [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':4,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Неисправен',
        'flags': [2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':3,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Тревога принята, не готов (активен)',
        'flags': [2,2,1,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':7,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Тревога принята, готов (пассивен)',
        'flags': [2,2,1,2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':7,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Тревога, готов (пассивен)',
        'flags': [2,2,1,1,2,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':8,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Шунтирован (блокирован)',
        'flags': [2,2,1,1,1,0,0,0,0,0,1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':9,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Тревога, не готов (активен)',
        'flags': [2,2,1,1,2,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':8,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - пропущен',
        'flags': [2,2,1,1,1,0,0,0,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':6,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Не готов (активен)',
        'flags': [2,2,1,1,1,0,0,0,0,1,1,2,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':2,
        'statehandler_uniid':0
    },
    {
        'description': u'Вход - Поставлен на охрану',
        'flags': [2,2,1,1,1,0,0,0,0,2,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 2,
        'statehandler':5,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Нет связи',
        'flags': [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':16,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Не готов к постановке на охрану',
        'flags': [2,2,1,0,1,0,0,0,0,1,1,2,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':15,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Частично взят на охрану и не готов',
        'flags': [2,2,1,0,1,0,0,0,0,2,2,2,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':18,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - В тревоге',
        'flags': [2,2,1,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':10,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Все тревоги приняты',
        'flags': [2,2,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':11,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Имеет неисправные устройства',
        'flags': [2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':13,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Имеет обойденные устройства',
        'flags': [2,2,1,1,1,0,0,0,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':14,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Полностью на охране',
        'flags': [2,2,1,1,1,0,0,0,0,2,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':17,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Готов к постановке на охрану',
        'flags': [2,2,1,0,1,0,0,0,0,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':12,
        'statehandler_uniid':0
    },
    {
        'description': u'Раздел - Частично взят на охрану и готов',
        'flags': [2,2,1,0,1,0,0,0,0,2,2,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
        'devicetype': 79,
        'statehandler':18,
        'statehandler_uniid':0
    }]
    conn = op.get_bind()
    for id, value in strings.items():
        res = conn.execute('insert into pce_string(description) values(%s) returning uniid', (value['description'],))
        value['uniid'] = res.fetchall()[0][0]
    for id, value in state_handlers.items():
        res = conn.execute("""
            insert into pce_statehandler(alarmlistenable, needconfirmenable, formatstring, description) values(%s, %s, %s, %s)
            returning uniid
        """, (value['alarmlistenable'], value['needconfirmenable'], strings[value['formatstring']]['uniid'], value['description']))
        value['uniid'] = res.fetchall()[0][0]
    for state in states:
        values = [state['description'],]
        values.extend(state['flags'])
        values.append(state_handlers[state['statehandler']]['uniid'])
        values.append(state['devicetype'])
        conn.execute("""
            insert into pce_state(description, mconn, mdef, mtrb, mack, malrm, mfrc, majar, mtamp, mattn, marm, mbps, mact, mact2, mact3, mblock,
            mdelay, msmod, mdmon, mamon, vconn, vdef, vtrb, vack, valrm, vfrc, vajar, vtamp, vattn, varm, vbps, vact, vact2, vact3, vblock, vdelay,
            vsmod, vdmon, vamon, statehandler, devicetype) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, values)


def downgrade():
    pass
