# -*- coding: utf-8 -*-

"""add index column to maps

Revision ID: 01a3936dedd1
Revises: c65aa2817dce
Create Date: 2018-04-26 09:47:15.478000

Добавляет колонки index для таблиц связанных с иерархией карт. Будет использоватся в клиенте.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '01a3936dedd1'
down_revision = 'c65aa2817dce'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_mapshierarchy add column index bigint;
        alter table system_mapshierarchy_gismap add column index bigint;
        alter table system_mapshierarchy_map add column index bigint;
    """)


def downgrade():
    op.execute("""
        alter table system_mapshierarchy drop column index;
        alter table system_mapshierarchy_gismap drop column index;
        alter table system_mapshierarchy_map drop column index;
    """)
