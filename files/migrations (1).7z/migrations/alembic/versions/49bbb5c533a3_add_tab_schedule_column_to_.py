"""add tab schedule column to permitofficesettings

Revision ID: 49bbb5c533a3
Revises: c6d611f45881
Create Date: 2019-06-11 09:55:37.001000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '49bbb5c533a3'
down_revision = 'c6d611f45881'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_permitofficesettings
        add column tabschedule boolean default true;
        
        update system_permitofficesettings
        set tabschedule = true
    """)


def downgrade():
    op.execute("""
        alter table system_permitofficesettings
        drop column tabschedule
    """)
