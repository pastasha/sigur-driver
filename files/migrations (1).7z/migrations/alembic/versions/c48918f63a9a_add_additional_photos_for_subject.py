"""add additional photos for subject

Revision ID: c48918f63a9a
Revises: 16aefd7843e8
Create Date: 2019-02-14 12:33:25.043000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c48918f63a9a'
down_revision = '16aefd7843e8'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_subject
        add column photo2 text default '',
        add column photo3 text default '',
        add column photo4 text default '',
        add column photo5 text default '',
        add column photo6 text default ''
    """)


def downgrade():
    op.execute("""
        alter table common_subject
        drop column photo2,
        drop column photo3,
        drop column photo4,
        drop column photo5,
        drop column photo6
    """)
