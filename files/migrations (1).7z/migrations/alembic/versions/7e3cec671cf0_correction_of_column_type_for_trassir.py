"""correction_of_column_type_for_trassir

Revision ID: 7e3cec671cf0
Revises: 1deaef1d626d
Create Date: 2018-09-10 16:42:47.701000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7e3cec671cf0'
down_revision = '1deaef1d626d'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    conn.execute("alter table trassir_host alter column origin type text")


def downgrade():
    conn = op.get_bind()
    conn.execute("alter table trassir_host alter column origin type varchar(40)")
