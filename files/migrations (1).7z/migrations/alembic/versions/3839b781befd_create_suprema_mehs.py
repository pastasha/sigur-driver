"""create_suprema_mehs

Revision ID: 3839b781befd
Revises: 366aaae8354f
Create Date: 2018-08-29 13:19:05.782000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3839b781befd'
down_revision = '366aaae8354f'
branch_labels = None
depends_on = None
"""and_the_lord_said_thy_shall_have_suprema_tables

Revision ID: a90c264201f2
Revises: 8218f653634a
Create Date: 2018-07-30 10:21:45.756000

"""
from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_equipment('suprema_driver',(
            ('description', 'varchar(256)', ''),
            ('driver_addr', 'varchar(256)', ''),
            ('server_addr', 'varchar(256)', ''),
            ('server_port', 'varchar(256)', ''),
            ('cloud_name', 'varchar(256)', ''),
            ('login', 'varchar(256)', ''),
            ('password', 'varchar(256)', ''),
            ('active', 'boolean', ''),
        ),[], 'True'
    )
    op.create_equipment('suprema_door',(
            ('description', 'varchar(256)', ''),
            ('door_group', 'varchar(256)', ''),
            ('dual_authentication', 'varchar(256)', ''),
            ('held_open_timeout', 'varchar(256)', ''),
            ('open_duration', 'varchar(256)', ''),
            ('open_once', 'varchar(256)', ''),
        ),[], 'True'
    )
    op.create_equipment('suprema_device',(
            ('id', 'varchar(256)', ''),
            ('description', 'varchar(256)', ''),
            ('device_group', 'varchar(256)', ''),
        ),[], 'True'
    )
    op.create_equipment('suprema_user',(
            ('user_id', 'varchar(256)', ''),
            ('description', 'varchar(256)', ''),
            ('user_group', 'varchar(256)', ''),
        ),[], 'True'
    )


def downgrade():
    pass