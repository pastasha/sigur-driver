"""ccure_tables

Revision ID: 5c64dbbec41a
Revises: 3d2d2f53b47b
Create Date: 2019-09-02 09:30:07.497000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5c64dbbec41a'
down_revision = '3d2d2f53b47b'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        insert into equipments(name, enabled) values('ccure', true)
    ''')

    op.execute('''
        alter table common_commonright add ccure_access_level bigint;
    ''')

    op.create_equipment('ccure_driver', [
        ('description', 'text', ''),
        ('driver_addr', 'text', ''),
        ('enable_auto_import', 'boolean', 'default false'),
        ('active', 'boolean', 'default true'),
        ('synchronization', 'int', 'default 0')
    ], [], True)

    op.create_equipment('ccure_controller', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_door', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_elevator', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_reader', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_input', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_output', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_floor', [
        ('description', 'text', ''),
        ('device_class', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)

    op.create_equipment('ccure_accesslevel', [
        ('description', 'text', ''),
        ('external_id', 'text', '')
    ], [], True)


def downgrade():
    op.execute('''
        delete from equipments where name='ccure';
        alter table common_commonright drop column ccure_access_level;
        drop table ccure_controller;
        drop table ccure_door;
        drop table ccure_elevator;
        drop table ccure_reader;
        drop table ccure_input;
        drop table ccure_output;
        drop table ccure_floor;
        drop table ccure_accesslevel;
        drop table ccure_driver;
    ''')
