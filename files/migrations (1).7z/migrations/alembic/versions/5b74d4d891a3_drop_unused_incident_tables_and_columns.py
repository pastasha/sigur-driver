"""drop unused incident tables and columns

Revision ID: 5b74d4d891a3
Revises: fd19e528337b
Create Date: 2019-09-10 11:20:52.056207

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5b74d4d891a3'
down_revision = 'fd19e528337b'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('incident_event_brg')
    op.drop_column('event_register_v2', 'incident_comment')
    op.drop_column('event_register_v2', 'incident_state')
    op.drop_column('event_register_v2', 'incident_type')
    op.drop_column('event_register_v2', 'incident')


def downgrade():
    pass
