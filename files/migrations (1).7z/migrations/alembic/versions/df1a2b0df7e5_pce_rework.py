"""pce rework

Revision ID: df1a2b0df7e5
Revises: 3d1c76f827af
Create Date: 2019-01-26 15:10:15.039287

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'df1a2b0df7e5'
down_revision = '3d1c76f827af'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
            ALTER TABLE pce_class RENAME TO pce_algclass;
            ALTER TABLE pce_alg RENAME COLUMN class TO algclass;
            ALTER TABLE pce_bus_class RENAME TO pce_bus_algclass;
            ALTER TABLE pce_bus_algclass RENAME COLUMN class TO algclass;
            ALTER TABLE pce_output DROP COLUMN areaField;
            ALTER TABLE pce_input DROP COLUMN areaField;
            ALTER TABLE pce_display DROP COLUMN areaField;
        """)


def downgrade():
    pass
