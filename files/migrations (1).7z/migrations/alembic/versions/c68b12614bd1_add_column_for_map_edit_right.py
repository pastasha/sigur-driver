"""add column for map edit right

Revision ID: c68b12614bd1
Revises: 8a4ab01e52d1
Create Date: 2019-05-30 17:26:27.717000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c68b12614bd1'
down_revision = '8a4ab01e52d1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table opright
        add column mapeditright boolean default false;
        
        update opright
        set mapeditright = false;
    """)


def downgrade():
    op.execute("""
        alter table opright
        drop column mapeditright;
    """)
