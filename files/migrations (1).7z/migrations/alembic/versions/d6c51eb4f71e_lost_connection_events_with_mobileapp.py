# -*- coding: utf-8 -*-
"""lost connection events with mobileapp

Revision ID: d6c51eb4f71e
Revises: 4c45991fdf4c
Create Date: 2019-06-27 15:49:56.650000

"""
from alembic import op
import sqlalchemy as sa
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer


# revision identifiers, used by Alembic.
revision = 'd6c51eb4f71e'
down_revision = '4c45991fdf4c'
branch_labels = None
depends_on = None
events = []


event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"system", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(715, u"Пользователь потерял связь с мобильным приложением", u"Пользователь %statement.subject.dev.name потерял связь с мобильным приложением %statement.directObj.name")
addEv(716, u"Ресурс реагирования потерял связь с мобильным приложением", u"Ресурс реагирования %statement.subject.dev.name потерял связь с мобильным приложением %statement.directObj.name")

def downgrade():
    op.execute('delete from event_catalog where code in(715, 716)')
