"""add round photo column to common_subject

Revision ID: d4f90bf4bbdc
Revises: 7d5cb295d615
Create Date: 2019-03-13 13:07:33.713000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd4f90bf4bbdc'
down_revision = '7d5cb295d615'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_subject
        add column round_photo text default ''
    """)


def downgrade():
    op.execute("""
        alter table common_subject
        drop column round_photo
    """)
