"""rename_workstationlayout

Revision ID: 184fb1969dd0
Revises: e7a6315ec986
Create Date: 2019-11-06 10:58:35.110463

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '184fb1969dd0'
down_revision = 'e7a6315ec986'
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table('web_arm_workstationlayout', 'web_arm_settings')
    op.drop_column('web_arm_settings', 'workstation')
    op.drop_column('web_arm_settings', 'name')
    op.alter_column('web_arm_settings', 'layout', nullable=False, new_column_name='settings')	


def downgrade():
    op.rename_table('web_arm_settings', 'web_arm_workstationlayout')
    op.add_column('web_arm_workstationlayout', sa.Column('workstation', sa.Integer, sa.ForeignKey("system_workstation.uniid", ondelete='CASCADE')))
    op.drop_column('web_arm_workstationlayout', sa.Column('name', sa.Text()))
    op.alter_column('web_arm_workstationlayout', 'settings', nullable=False, new_column_name='layout')	
