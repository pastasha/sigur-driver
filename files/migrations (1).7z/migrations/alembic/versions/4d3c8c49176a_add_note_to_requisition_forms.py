"""add note to requisition forms

Revision ID: 4d3c8c49176a
Revises: aaab2d658478
Create Date: 2018-03-26 14:26:57.864000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4d3c8c49176a'
down_revision = 'aaab2d658478'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
    alter table requisition_info
    add column note text
    """)


def downgrade():
    op.execute("""
    alter table requisition_info
    drop column note
    """)
