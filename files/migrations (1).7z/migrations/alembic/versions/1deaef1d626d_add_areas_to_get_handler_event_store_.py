# -*- coding: utf-8 -*-

"""add areas to get_handler_event store function

Revision ID: 1deaef1d626d
Revises: 817b9f33c845
Create Date: 2018-09-07 09:49:50.127000

Так как в обработчиках можно указывать области надо добавить их в функцию get_event_handler. Но так же надо изменить и те функции которые
ее вызывают set_subject_last_pass_event и store_event

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1deaef1d626d'
down_revision = '817b9f33c845'
branch_labels = None
depends_on = None


def upgrade():
    # обновим get_event_handler
    op.execute("""
        drop function if exists get_event_handler(code_ bigint, obj_ bigint, place_ bigint, subj_ bigint, securlevel_ bigint, OUT result_ text,
            OUT pass_type_ text);
            
        create or replace function get_event_handler(in code_ bigint, in obj_ bigint, in place_ bigint, in subj_ bigint, in from_ bigint,
            in to_ bigint, in securlevel_ bigint, out pass_type_ text
        ) as 
        $$
        declare
        begin
            if code_ is null then
                code_ := 0;
            end if;
            if obj_ is null then
                obj_ := 0;
            end if;
            if place_ is null then
                place_ := 0;
            end if;
            if subj_ is null then
                subj_ := 0;
            end if;
            if from_ is null then
                from_ := 0;
            end if;
            if to_ is null then
                to_ := 0;
            end if;
            if securlevel_ is null then
                securlevel_ := 0;
            end if;
        
            select pass_type, ((code <> 0)::int + (obj <> 0)::int + (place <> 0)::int + (subj <> 0)::int + (fromarea <> 0)::int +
                (toarea <> 0)::int + (securlevel <> 0)::int) as w
            from (
                select 
                    code,
                    coalesce((select id from observed_objects where id = obj and deletemark = 0), 0) as obj,
                    coalesce((select id from observed_objects where id = place and deletemark = 0), 0) as place,
                    coalesce((select id from observed_objects where id = fromarea and deletemark = 0), 0) as fromarea,
                    coalesce((select id from observed_objects where id = toarea and deletemark = 0), 0) as toarea,
                    subj,
                    securlevel,
                    pass_type
                from event_table
            ) et
            where code in (0, code_) and 
                obj in (0, obj_) and 
                place in (0, place_) and 
                subj in (0, subj_) and 
                fromarea in (0, from_) and 
                toarea in (0, to_) and 
                securlevel in (0, securLevel_)
            order by w desc
            limit 1
            into pass_type_;
        end;
        $$ language plpgsql;
    """)
    # обновим set_subject_last_pass_event
    op.execute("""
        drop function if exists set_subject_last_pass_event(event_num bigint, tm timestamp, subj bigint, code bigint, obj bigint, place bigint,
            level bigint);
        
        create or replace function set_subject_last_pass_event(event_num bigint, tm timestamp, subj bigint, 
            code bigint, obj bigint, place bigint, from_area bigint, to_area bigint, level bigint
        ) returns bigint as
        $$
        declare
            pass_type text;
            last_event_tm timestamp;
            last_event_num bigint;
        begin
            if subj is null then
                return 0;
            end if;

            pass_type = null;
            select pass_type_ from get_event_handler(code, obj, place, subj, from_area, to_area, level) into pass_type;
            if pass_type is null then
                return 0;
            end if;
            
            execute 'update events.events_v2_' || to_char(tm, 'YYYYMM') || ' set pass_type = $1 where evnum = $2'
            using pass_type, event_num;

            select last_pass_event from common_subject where uniid = subj into last_event_num;
            if last_event_num is not null then
                select adverbialtime_value from event_register_v2 where evnum = last_event_num into last_event_tm;
                if last_event_tm > tm then
                    return 0;
                end if;
            end if;
            
            update common_subject set last_pass_event = event_num
            where uniid = subj;
            
            return event_num;
        end;
        $$ language plpgsql;
    """)
    # обновим store_event
    op.execute("""
        create or replace function store_event(
            evnum bigint,
            evdevcode bigint,
            evusercode bigint,
            adverbialtime_value timestamp without time zone,
            subjectobj_obsobjid bigint,
            subjectobj_obsobjstate text,
            subjectobj_devequip text,
            subjectobj_devtype text,
            subjectobj_devid bigint,
            subjectobj_value text,
            directobj_obsobjid bigint,
            directobj_obsobjstate text,
            directobj_devequip text,
            directobj_devtype text,
            directobj_devid bigint,
            directobj_value text,
            indirectobj_obsobjid bigint,
            indirectobj_obsobjstate text,
            indirectobj_devequip text,
            indirectobj_devtype text,
            indirectobj_devid bigint,
            indirectobj_value text,
            adverbialplace_obsobjid bigint,
            adverbialplace_obsobjstate text,
            adverbialplace_devequip text,
            adverbialplace_devtype text,
            adverbialplace_devid bigint,
            adverbialplace_value text,
            adverbialfrom_obsobjid bigint,
            adverbialfrom_obsobjstate text,
            adverbialfrom_devequip text,
            adverbialfrom_devtype text,
            adverbialfrom_devid bigint,
            adverbialfrom_value text,
            adverbialto_obsobjid bigint,
            adverbialto_obsobjstate text,
            adverbialto_devequip text,
            adverbialto_devtype text,
            adverbialto_devid bigint,
            adverbialto_value text,
            adverbialcond_obsobjid bigint,
            adverbialcond_obsobjstate text,
            adverbialcond_devequip text,
            adverbialcond_devtype text,
            adverbialcond_devid bigint,
            adverbialcond_value text,
            adverbialwhy_obsobjid bigint,
            adverbialwhy_obsobjstate text,
            adverbialwhy_devequip text,
            adverbialwhy_devtype text,
            adverbialwhy_devid bigint,
            adverbialwhy_value text,
            adverbialmode_obsobjid bigint,
            adverbialmode_obsobjstate text,
            adverbialmode_devequip text,
            adverbialmode_devtype text,
            adverbialmode_devid bigint,
            adverbialmode_value text,
            incident bigint,
            incident_type text,
            incident_state text,
            incident_comment text,
            securlevel bigint,
            flags bigint,
            authentic bigint,
            permit_uniid bigint,
            permit_commonright bigint[]
            ) RETURNS bigint AS
        $$
        declare
            tbl_name text;
            member_tbl_name text;
            res bigint;
            operator_id bigint;
            operator_subj_id bigint;
        begin
            select op_id, op_subj_id from get_current_operator() into operator_id, operator_subj_id;

            tbl_name = 'events_v2_' || to_char(adverbialtime_value, 'YYYYMM');

            SELECT create_new_event_table(adverbialtime_value) INTO res;

            EXECUTE 'INSERT INTO events.' || tbl_name || '(
                evNum, evDevCode, evUserCode, evRegTime,
                adverbialTime_value,

                subjectobj_obsobjid, subjectobj_obsobjstate, subjectobj_devequip,
                subjectobj_devtype, subjectobj_devid, subjectobj_value,

                directObj_obsObjId, directObj_obsObjState, directObj_devEquip,
                directObj_devType, directObj_devId, directObj_value,

                indirectObj_obsObjId,indirectObj_obsObjState,indirectObj_devEquip,
                indirectObj_devType, indirectObj_devId, indirectObj_value,

                adverbialPlace_obsObjId,adverbialPlace_obsObjState,adverbialPlace_devEquip,
                adverbialPlace_devType, adverbialPlace_devId, adverbialPlace_value,

                adverbialFrom_obsObjId,adverbialFrom_obsObjState,adverbialFrom_devEquip,
                adverbialFrom_devType, adverbialFrom_devId, adverbialFrom_value,

                adverbialTo_obsObjId,adverbialTo_obsObjState,adverbialTo_devEquip,
                adverbialTo_devType, adverbialTo_devId, adverbialTo_value,

                adverbialCond_obsObjId,adverbialCond_obsObjState,adverbialCond_devEquip,
                adverbialCond_devType, adverbialCond_devId, adverbialCond_value,

                adverbialWhy_obsObjId,adverbialWhy_obsObjState,adverbialWhy_devEquip,
                adverbialWhy_devType, adverbialWhy_devId, adverbialWhy_value,

                adverbialMode_obsObjId,adverbialMode_obsObjState,adverbialMode_devEquip,
                adverbialMode_devType, adverbialMode_devId, adverbialMode_value,

                incident, incident_type, incident_state, incident_comment,
                securlevel, flags, authentic,

                operator, operator_subject,

                permit_uniid, permit_commonright
            )
            VALUES(
                $1, $2, $3, $4,
                $5,
                $6,     $7,     $8,     $9,     $10,    $11,
                $12,	$13,	$14,	$15,	$16,	$17,
                $18,	$19,	$20,	$21,	$22,	$23,
                $24,	$25,	$26,	$27,	$28,	$29,
                $30,	$31,	$32,	$33,	$34,	$35,
                $36,	$37,	$38,	$39,	$40,	$41,
                $42,	$43,	$44,	$45,	$46,	$47,
                $48,	$49,	$50,	$51,	$52,	$53,
                $54,	$55,	$56,	$57,	$58,	$59,
                $60,	$61,	$62,	$63,
                $64,	$65,	$66,
                $67,    $68,
                $69,    $70
            )' USING evNum, evDevCode, evUserCode, NOW(),

                adverbialTime_value,

                subjectobj_obsobjid, subjectobj_obsobjstate, subjectobj_devequip,
                subjectobj_devtype, subjectobj_devid, subjectobj_value,

                directObj_obsObjId, directObj_obsObjState, directObj_devEquip,
                directObj_devType, directObj_devId, directObj_value,

                indirectObj_obsObjId, indirectObj_obsObjState, indirectObj_devEquip,
                indirectObj_devType, indirectObj_devId, indirectObj_value,

                adverbialPlace_obsObjId, adverbialPlace_obsObjState, adverbialPlace_devEquip,
                adverbialPlace_devType, adverbialPlace_devId, adverbialPlace_value,

                adverbialFrom_obsObjId, adverbialFrom_obsObjState, adverbialFrom_devEquip,
                adverbialFrom_devType, adverbialFrom_devId, adverbialFrom_value,

                adverbialTo_obsObjId, adverbialTo_obsObjState, adverbialTo_devEquip,
                adverbialTo_devType, adverbialTo_devId, adverbialTo_value,

                adverbialCond_obsObjId, adverbialCond_obsObjState, adverbialCond_devEquip,
                adverbialCond_devType, adverbialCond_devId, adverbialCond_value,

                adverbialWhy_obsObjId, adverbialWhy_obsObjState, adverbialWhy_devEquip,
                adverbialWhy_devType, adverbialWhy_devId, adverbialWhy_value,

                adverbialMode_obsObjId, adverbialMode_obsObjState, adverbialMode_devEquip,
                adverbialMode_devType, adverbialMode_devId, adverbialMode_value,

                incident, incident_type, incident_state, incident_comment,
                securlevel, flags, authentic,
                
                operator_id, operator_subj_id,
                
                permit_uniid, permit_commonright;

            perform store_event_member(adverbialtime_value, evNum, 'subject',
                subjectobj_obsobjid, subjectobj_obsobjstate,
                subjectobj_devequip, subjectobj_devtype, subjectobj_devid,
                subjectobj_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'directObj',
                directObj_obsObjId, directObj_obsObjState,
                directObj_devEquip, directObj_devType, directObj_devId,
                directObj_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'indirectObj',
                indirectObj_obsObjId, indirectObj_obsObjState,
                indirectObj_devEquip, indirectObj_devType, indirectObj_devId,
                indirectObj_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialPlace',
                adverbialPlace_obsObjId, adverbialPlace_obsObjState,
                adverbialPlace_devEquip, adverbialPlace_devType, adverbialPlace_devId,
                adverbialPlace_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialFrom',
                adverbialFrom_obsObjId, adverbialFrom_obsObjState,
                adverbialFrom_devEquip, adverbialFrom_devType, adverbialFrom_devId,
                adverbialFrom_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialTo',
                adverbialTo_obsObjId, adverbialTo_obsObjState,
                adverbialTo_devEquip, adverbialTo_devType, adverbialTo_devId,
                adverbialTo_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialCond',
                adverbialCond_obsObjId, adverbialCond_obsObjState,
                adverbialCond_devEquip, adverbialCond_devType, adverbialCond_devId,
                adverbialCond_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialWhy',
                adverbialWhy_obsObjId, adverbialWhy_obsObjState,
                adverbialWhy_devEquip, adverbialWhy_devType, adverbialWhy_devId,
                adverbialWhy_value
            );

            perform store_event_member(adverbialtime_value, evNum, 'adverbialMode',
                adverbialMode_obsObjId, adverbialMode_obsObjState,
                adverbialMode_devEquip, adverbialMode_devType, adverbialMode_devId,
                adverbialMode_value
            );

            perform set_subject_last_pass_event(
                evnum, adverbialtime_value, subjectobj_devid, evDevCode, 
                directObj_obsObjId, adverbialPlace_obsObjId, adverbialFrom_obsObjId,
                adverbialTo_obsObjId, securlevel
            );

            return res;
        end;
        $$ language plpgsql;
    """)


def downgrade():
    pass
