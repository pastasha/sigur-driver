"""create handler parameters table

Revision ID: 8140861313d0
Revises: 9b7779b5a7bf
Create Date: 2019-03-25 13:41:27.108000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import Column, BigInteger, Integer, Float, JSON, String, Boolean, ForeignKey


# revision identifiers, used by Alembic.
revision = '8140861313d0'
down_revision = '9b7779b5a7bf'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('handler_options', 
        Column('id', BigInteger, primary_key=True),
        Column('handler', BigInteger, ForeignKey('handlers.id', ondelete='CASCADE')),
        Column('oocam', JSON),
        Column('rtspcam', String),
        Column('alter_text', String),
        Column('color', String),
        Column('sound', String),
        Column('channel', String),
        Column('flashing_timeout', String),
        Column('user_info', Boolean),
        Column('menu', JSON),
        Column('alarmlevel', String),
        Column('confirmation', Boolean),
        Column('incident', String),
        Column('incident_tm', String),
        Column('incident_treshold', String),
        Column('closesameincident', Boolean),
        Column('capturetimeout', String),
        Column('dutymon', Boolean),
        Column('import_arch', Boolean),
        Column('import_pre_time', String),
        Column('import_post_time', String),
        Column('incidentobsobj', JSON)
    )
    op.execute("""
        insert into handler_options(handler, oocam, rtspcam, alter_text, color, sound, channel, flashing_timeout, 
        user_info, menu, alarmLevel, confirmation, incident, incident_tm, incident_treshold, closesameincident,
        capturetimeout, dutymon, import_arch, import_pre_time, import_post_time, incidentobsobj)
        select id, result::json->'OOcam', result::json->'RTSPcam', result::json->'alter_text', result::json->'color',
        result::json->'sound', result::json->'channel', (result::json->>'flashing_timeout'),
        (result::json->>'user_info')::bool, result::json->'menu', (result::json->>'alarmLevel'),
        (result::json->>'confirmation')::bool, result::json->'incident', (result::json->>'incident_tm'),
        (result::json->>'incident_treshold'), (result::json->>'closeSameIncident')::bool,
        (result::json->>'captureTimeout'), (result::json->>'dutyMon')::bool, (result::json->>'import_arch')::bool,
        (result::json->>'import_pre_time'), (result::json->>'import_post_time'),
        result::json->'incidentObsObj'
        from handlers;
        
        alter table handlers drop column result;
        
        update handler_options
        set flashing_timeout = 0
        where flashing_timeout = '' or flashing_timeout is null;
        
        update handler_options
        set alarmlevel = 0
        where alarmlevel = '' or alarmlevel is null;
        
        update handler_options
        set incident_tm = 0
        where incident_tm = '' or incident_tm is null;
        
        update handler_options
        set incident_treshold = 0
        where incident_treshold = '' or incident_treshold is null;
        
        update handler_options
        set capturetimeout = 0
        where capturetimeout = '' or capturetimeout is null;
        
        update handler_options
        set import_pre_time = 0
        where import_pre_time = '' or import_pre_time is null;
        
        update handler_options
        set import_post_time = 0
        where import_post_time = '' or import_post_time is null;
        
        alter table handler_options
        alter column flashing_timeout type int using flashing_timeout::int,
        alter column alarmlevel type int using alarmlevel::int,
        alter column incident_tm type int using incident_tm::int,
        alter column incident_treshold type int using incident_treshold::int,
        alter column capturetimeout type int using capturetimeout::int,
        alter column import_pre_time type int using import_pre_time::int,
        alter column import_post_time type int using import_post_time::int
    """)


def downgrade():
    pass
