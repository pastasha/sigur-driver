# -*- coding: utf-8 -*-

"""change make make notif json for role

Revision ID: 8d16a012a868
Revises: 85cc20093b84
Create Date: 2018-04-13 11:16:00.823000

Обновление меняет функцию make_notif_json_for_role чтобы она корректно работала с теми ролями где нет объекта оборудования а есть тольк объект мониторинга

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8d16a012a868'
down_revision = '85cc20093b84'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create or replace function make_notifjson_for_role(role text, obsobjid bigint, devequip text, devtype text, devid bigint, devvalue text) returns text as
        $BODY$
            declare
                obsobjname text;
                subjectname text;
                res jsonb;
                dev jsonb;
                obsobj jsonb;
            begin
                if devtype is not null then
                    dev = jsonb_build_object('equip', devequip, 'type', devtype, 'id', devid);
                    if devtype = 'subject' then
                        execute 'select description from common_subject_plus where uniid = $1'
                        using devid
                        into subjectname;
                        dev = dev::jsonb || jsonb_build_object('name', subjectname);
                    end if;
                    res = jsonb_build_object('dev', dev);
                end if;
                if obsobjid is not null then
                    execute 'select name from observed_objects where id = $1'
                    into obsobjname
                    using obsobjid;
                    if obsobjname is not null then
                        obsobj = jsonb_build_object('id', obsobjid, 'name', obsobjname);
                    end if;
                end if;
                if obsobjname is not null then
                    if res is not null then
                        res = res::jsonb || jsonb_build_object('obsObj', obsobj, 'name', obsobjname);
                    else
                        res = jsonb_build_object('obsObj', obsobj, 'name', obsobjname);
                    end if;
                end if;
                if devvalue is not null then
                    res = jsonb_build_object('param', devvalue);
                end if;
                if res is not null then
                    return '"' || role || '":' || res::text;
                end if;
                return res::text;
            end;
        $BODY$
        language plpgsql;
    """)


def downgrade():
    pass
