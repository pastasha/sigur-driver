"""remove_report22_from_db

Revision ID: f5d03f96de7b
Revises: 1f7e939142d0
Create Date: 2019-09-06 14:32:46.211656

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f5d03f96de7b'
down_revision = '1f7e939142d0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('delete from reports where uniid = 22')


def downgrade():
    pass
