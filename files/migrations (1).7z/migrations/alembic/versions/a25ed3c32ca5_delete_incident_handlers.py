"""delete incident handlers

Revision ID: a25ed3c32ca5
Revises: a900103d79d8
Create Date: 2019-11-24 21:08:34.823890

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a25ed3c32ca5'
down_revision = 'a900103d79d8'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        delete from handlers
        where code >= 10001 and code <= 10100;
        
        delete from handler_group
        where description in ('Системные события инцидентов', 'Incident system events')
    """)


def downgrade():
    pass
