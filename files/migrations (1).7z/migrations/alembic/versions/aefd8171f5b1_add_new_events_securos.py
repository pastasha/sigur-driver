# -*- coding: utf-8 -*-
"""add_new_events_securos

Revision ID: aefd8171f5b1
Revises: 8218f653634a
Create Date: 2018-08-07 09:19:43.682000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'aefd8171f5b1'
down_revision = '8218f653634a'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"securos", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(901, u"Камера расфокусирована, фокус потерян", u"[\"%statement.directObj.name камера расфокусирована, фокус потерян %statement.adverbialMode.params\", \"Камера расфокусирована, фокус потерян\"]")
addEv(902, u"Камера сфокусирована, изображение нормализовано", u"[\"%statement.directObj.name камера сфокусирована, изображение нормализовано %statement.adverbialMode.params\", \"Камера сфокусирована, изображение нормализовано\"]")


def downgrade():
    pass