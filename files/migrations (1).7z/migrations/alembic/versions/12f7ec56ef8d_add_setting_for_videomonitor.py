"""add setting for videomonitor

Revision ID: 12f7ec56ef8d
Revises: 933a5e2b2549
Create Date: 2019-11-27 13:23:12.358219

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '12f7ec56ef8d'
down_revision = '933a5e2b2549'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE system_incidentsettings ADD display_video_selected_incident bool default false')
    op.execute('ALTER TABLE system_incidentsettings ADD management_cammodule_selected_incident bool default false')


def downgrade():
    op.execute('ALTER TABLE system_incidentsettings drop column display_video_selected_incident')
    op.execute('ALTER TABLE system_incidentsettings drop column management_cammodule_selected_incident')
