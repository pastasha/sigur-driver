"""add column description to rusguard_device

Revision ID: 8507e9d10715
Revises: 542f1c47d433
Create Date: 2018-07-04 11:07:56.284000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8507e9d10715'
down_revision = '542f1c47d433'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE rusguard_device ADD description text')


def downgrade():
    op.execute('ALTER TABLE rusguard_device drop column description')
