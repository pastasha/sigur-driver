# -*- coding: utf-8 -*-
"""add mobile auth events

Revision ID: 9fee58a8ca6d
Revises: c8bc1860b8c5
Create Date: 2019-06-24 11:35:29.042000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer


# revision identifiers, used by Alembic.
revision = '9fee58a8ca6d'
down_revision = 'c8bc1860b8c5'
branch_labels = None
depends_on = None
events = []


event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"system", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(710, u"Пользователь успешно зарегистрирован в мобильном приложении", u"Пользователь %statement.subject.dev.name успешно зарегистрирован в мобильном приложении %statement.directObj.name")
addEv(711, u"Ошибка авторизации в мобильном приложении", u"Ошибка авторизации %statement.subject.dev.name в мобильном приложении %statement.directObj.name")
addEv(713, u"Ресурс реагирования успешно зарегистрирован в мобильном приложении", u"Ресурс реагирования %statement.subject.dev.name успешно зарегистрирован в мобильном приложении %statement.directObj.name")

def downgrade():
    op.execute('delete from event_catalog where code in(710, 711, 713)')
