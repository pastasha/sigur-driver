"""create table for store incident notifications

Revision ID: 8b33e893d5f5
Revises: 25019e3710bc
Create Date: 2019-08-29 09:14:04.047000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8b33e893d5f5'
down_revision = '25019e3710bc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create table incidents.incident_history(
            id serial primary key,
            incident_id bigint references incidents.incident_register(id) on delete cascade,
            time bigint,
            code integer,
            notif json
        )
    """)


def downgrade():
    op.execute("""
        drop table incidents.incident_history
    """)
