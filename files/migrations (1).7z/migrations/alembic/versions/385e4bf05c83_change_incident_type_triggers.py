# -*- coding: utf-8 -*-

"""Change incident type triggers

Revision ID: 385e4bf05c83
Revises: f22239eb29e2
Create Date: 2018-03-20 16:50:39.156000

Обновление меняет триггер по изменению в таблице incidents.incident_type так как старый триггер падал при сохранении большого инцидента.
Падение связано с тем что pg_notify позволяет отправлять только небольшие блоки данных.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '385e4bf05c83'
down_revision = 'f22239eb29e2'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create or replace function incidents.incident_type_changed_proc()
        RETURNS trigger AS
        $BODY$
            begin
                IF (TG_OP = 'DELETE') THEN
                    perform pg_notify('incident_update_channel', json_build_object('evt', 'DELETE', 'type', 'INCIDENT_TYPE', 'data', json_build_object('name', OLD.name)::text)::text);
                ELSIF (TG_OP = 'UPDATE') THEN
                    perform pg_notify('incident_update_channel', json_build_object('evt', 'UPDATE', 'type', 'INCIDENT_TYPE', 'data', json_build_object('id', NEW.id)::text)::text);
                ELSIF (TG_OP = 'INSERT') THEN
                    perform pg_notify('incident_update_channel', json_build_object('evt', 'INSERT', 'type', 'INCIDENT_TYPE', 'data', json_build_object('id', NEW.id)::text)::text);
                END IF;
                return new;
            end;
        $BODY$
        LANGUAGE plpgsql;
    """)


def downgrade():
    pass
