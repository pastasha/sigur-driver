"""add analitycs integration support

Revision ID: 4dacfc15ee4a
Revises: 950ba34fa0c2
Create Date: 2019-06-27 17:19:18.276000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4dacfc15ee4a'
down_revision = '950ba34fa0c2'
branch_labels = None
depends_on = None


def upgrade():
    # workspace table
    op.create_table('analityc_workspace',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('name', sa.VARCHAR(200)),
                    sa.Column('is_default', sa.BOOLEAN),
                    sa.Column('user_id', sa.INTEGER),
                    sa.Column('layouts', sa.JSON),
                    sa.Column('fixed_position', sa.BOOLEAN, default=False, nullable=False),
                    sa.PrimaryKeyConstraint('id'))
    op.create_foreign_key('analityc_workspace_operators_fk',
                          'analityc_workspace',
                          'operators',
                          ['user_id'],
                          ['id'],
                          ondelete='CASCADE')

    # reports table
    op.create_table('analityc_report',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('user_id', sa.INTEGER),
                    sa.Column('name', sa.VARCHAR(200)),
                    sa.Column('filters', sa.JSON),
                    )
    op.create_foreign_key('analityc_report_operators_fk',
                          'analityc_report',
                          'operators',
                          ['user_id'],
                          ['id'],
                          ondelete='CASCADE')
    # widget table
    op.create_table('analityc_widget',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('workspace_id', sa.INTEGER),
                    sa.Column('report_id', sa.INTEGER),
                    sa.Column('chart_type', sa.VARCHAR, nullable=False, default='line'),
                    sa.Column('state', sa.JSON, nullable=False, default='{}'),
                    )

    op.create_foreign_key('analityc_widget_analityc_report_fk',
                          'analityc_widget',
                          'analityc_report',
                          ['report_id'],
                          ['id'],
                          ondelete='CASCADE')

    op.create_foreign_key('analityc_widget_analityc_workspace_fk',
                          'analityc_widget',
                          'analityc_workspace',
                          ['workspace_id'],
                          ['id'],
                          ondelete='CASCADE')

    # incidenttypecolor table
    op.create_table('analityc_incident_type_color',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('incident_type_id', sa.INTEGER, sa.ForeignKey('incidents.incident_type.id', ondelete='CASCADE')),
                    sa.Column('user_id', sa.INTEGER),
                    sa.Column('color', sa.JSON, nullable=False, default='{}'),
                    )

    op.create_foreign_key('analityc_incident_type_color_operators_fk',
                          'analityc_incident_type_color',
                          'operators',
                          ['user_id'],
                          ['id'],
                          ondelete='CASCADE')

    # incidentstate table
    op.create_table('analityc_incidents_state',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('first_shift_start_time', sa.TIME),
                    sa.Column('first_shift_end_time', sa.TIME),
                    sa.Column('second_shift_start_time', sa.TIME),
                    sa.Column('second_shift_end_time', sa.TIME),
                    sa.Column('report_ptr_id', sa.INTEGER),
                    sa.Column('update_interval', sa.Interval),
                    sa.Column('second_shift_end_time', sa.TIME),
                    )

    op.create_foreign_key('analityc_incidents_state_analityc_report_fk',
                          'analityc_incidents_state',
                          'analityc_report',
                          ['report_ptr_id'],
                          ['id'],
                          ondelete='CASCADE')

    # incidentsanalityc table
    op.create_table('analityc_incidentsanalytic',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('default_chart_type', sa.VARCHAR(50), nullable=False, default='line_diagram'),
                    sa.Column('line_diagram_interval', sa.VARCHAR(50), nullable=False, default='month'),
                    sa.Column('selected_intervals', sa.JSON),
                    sa.Column('report_ptr_id', sa.INTEGER),
                    sa.Column('aggregation_field', sa.VARCHAR(50)),
                    )

    op.create_foreign_key('analityc_incidentsanalytic_analityc_report_fk',
                          'analityc_incidents_state',
                          'analityc_report',
                          ['report_ptr_id'],
                          ['id'],
                          ondelete='CASCADE')

    # incidentstatistic table
    op.create_table('analityc_incidentsstatistic',
                    sa.Column('id', sa.BigInteger, nullable=False, primary_key=True),
                    sa.Column('default_chart_type', sa.VARCHAR(50), nullable=False, default='line_diagram'),
                    sa.Column('line_diagram_interval', sa.VARCHAR(50), nullable=False, default='month'),
                    sa.Column('date_from', sa.TIMESTAMP),
                    sa.Column('date_to', sa.TIMESTAMP),
                    sa.Column('aggregation_field', sa.VARCHAR(50)),
                    sa.Column('report_ptr_id', sa.INTEGER),
                    sa.Column('update_interval', sa.Interval)
                    )

    op.create_foreign_key('analityc_incidentsstatistic_analityc_report_fk',
                          'analityc_incidentsstatistic',
                          'analityc_report',
                          ['report_ptr_id'],
                          ['id'],
                          ondelete='CASCADE')


def downgrade():
    op.drop_table('analityc_incidentsstatistic')
    op.drop_table('analityc_incidentsanalytic')
    op.drop_table('analityc_incidents_state')
    op.drop_table('analityc_incident_type_color')
    op.drop_table('analityc_widget')
    op.drop_table('analityc_report')
    op.drop_table('analityc_workspace')
