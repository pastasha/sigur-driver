"""add parent for group

Revision ID: cba04779fa0c
Revises: ba820fc495be
Create Date: 2019-01-09 17:32:42.466000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cba04779fa0c'
down_revision = 'ba820fc495be'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('handler_group',
        sa.Column('parent', sa.BigInteger(), sa.ForeignKey('handler_group.uniid', ondelete='CASCADE'))
    )


def downgrade():
    pass
