"""update description of observed objects

Revision ID: 509ea1b89e43
Revises: 04065b7ea5a4
Create Date: 2018-08-02 08:58:24.476000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '509ea1b89e43'
down_revision = '04065b7ea5a4'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("update observed_objects set description = '' where description is null")


def downgrade():
    pass
