# -*- coding: utf-8 -*-

"""add Orion RO events

Revision ID: c43b274b5981
Revises: 1490294f41bc
Create Date: 2018-04-22 15:20:57.994000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = 'c43b274b5981'
down_revision = '1490294f41bc'
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def addEv(code, descr, format, equipment=u'orionro', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


addEv(15003, 'Контроллер на связи', u'[\"Контроллер %statement.directObj.name на связи\", \"Контроллер на связи\"]')
addEv(15004, 'Связь с контроллером потеряна'
      , u'[\"Связь с контроллером %statement.directObj.name потеряна\", \"Связь с контроллером потеряна\"]')
addEv(15018, 'Тихая тревога'
      , u'[\"Тихая тревога зоны %statement.directObj.name\", \"Тихая тревога\"]')
addEv(15014, 'Тревога внутренней зоны'
      , u'[\"Тревога внутренней зоны %statement.directObj.name\", \"Тревога внутренней зоны\"]')
addEv(15010, 'Контроллер был перезапущен'
      , u'[\"Контроллер %statement.directObj.name был перезапущен\", \"Контроллер был перезапущен\"]')
addEv(15021, 'Контроллер потерял связь'
      , u'[\"Контроллер %statement.directObj.name потерял связь\", \"Контроллер потерял связь\"]')
addEv(15022, 'Контроллер восстановил связь'
      , u'[\"Контроллер %statement.directObj.name восстановил связь\", \"Контроллер восстановил связь\"]')
addEv(15019, 'Пожар в зоне'
      , u'[\"Пожар в зоне %statement.directObj.name\", \"Пожар в зоне\"]')
addEv(15020, 'Зона в норме'
      , u'[\"Зона %statement.directObj.name в норме\", \"Зона в норме\"]')
addEv(15015, 'Тревога тампера'
      , u'[\"Тревога тампера контроллера %statement.directObj.name\", \"Тревога тампера\"]')
addEv(15016, 'Тампер пришел в норму'
      , u'[\"Тампер контроллера %statement.directObj.name пришел в норму\", \"Тампер пришел в норму\"]')
addEv(15012, 'Взятие на охрану'
      , u'[\"%statement.directObj.name взят на охрану пользователем %statement.subject.name\", \"Взятие на охрану\"]')
addEv(15013, 'Снятие с охраны'
      , u'[\"%statement.directObj.name снят с охраны пользователем %statement.subject.name\", \"Снятие с охраны\"]')
addEv(15011, 'Неудачная попытка постановки/снятия'
      , u'[\"Неудачная попытка постановки/снятия %statement.directObj.name\", \"Неудачная попытка постановки/снятия\"]')
addEv(15017, 'Доступ запрещен'
      , u'[\"Доступ запрещен устройством %statement.directObj.name\", \"Доступ запрещен\"]')
addEv(15023, 'Неисправность пожарного шлейфа'
      , u'[\"Неисправность пожарного шлейфа %statement.directObj.name\", \"Неисправность пожарного шлейфа\"]')
addEv(15024, 'Опасность пожара'
      , u'[\"Опасность пожара в зоне %statement.directObj.name\", \"Опасность пожара\"]')
addEv(15025, 'Тревога входной зоны'
      , u'[\"Тревога входной зоны %statement.directObj.name\", \"Тревога входной зоны\"]')
addEv(15026, 'Обрыв ШС'
      , u'[\"Обрыв ШС %statement.directObj.name\", \"Обрыв ШС\"]')
addEv(15027, 'Восстановление ШС, после обрыва'
      , u'[\"Восстановление ШС %statement.directObj.name, после обрыва\", \"Восстановление ШС, после обрыва\"]')
addEv(15028, 'Короткое замыкание ШС'
      , u'[\"Короткое замыкание ШС %statement.directObj.name\", \"Короткое замыкание ШС\"]')
addEv(15029, 'Восстановление ШС, после КЗ'
      , u'[\"Восстановление ШС %statement.directObj.name, после КЗ\", \"Восстановление ШС, после КЗ\"]')
addEv(15030, 'Нарушение питания'
      , u'[\"Нарушение питания устройства %statement.directObj.name\", \"Нарушение питания\"]')
addEv(15031, 'Восстановление питания'
      , u'[\"Восстановление питания устройства %statement.directObj.name\", \"Восстановление питания\"]')
addEv(15032, 'Нарушение сети'
      , u'[\"Нарушение сети устройства %statement.directObj.name\", \"Нарушение сети\"]')
addEv(15033, 'Восстановление сети'
      , u'[\"Восстановление сети устройства %statement.directObj.name\", \"Восстановление сети\"]')

def downgrade():
    pass
