"""add_column_in_setting_for_ports

Revision ID: 9c8fee833f9a
Revises: 618bb96dcfd0
Create Date: 2018-07-27 12:21:09.395000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9c8fee833f9a'
down_revision = '618bb96dcfd0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE orwell_settings ADD beginning_of_port_range bigint')
    op.execute('ALTER TABLE orwell_settings ADD end_of_port_range bigint')
    op.execute('ALTER TABLE onvif_settings ADD beginning_of_port_range bigint')
    op.execute('ALTER TABLE onvif_settings ADD end_of_port_range bigint')


def downgrade():
    op.execute('ALTER TABLE orwell_settings drop column beginning_of_port_range')
    op.execute('ALTER TABLE orwell_settings drop column end_of_port_range')
    op.execute('ALTER TABLE onvif_settings drop column beginning_of_port_range')
    op.execute('ALTER TABLE onvif_settings drop column end_of_port_range')
