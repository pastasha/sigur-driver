"""add rights flags for situation center

Revision ID: 576e3abe313e
Revises: ddc184165c6e
Create Date: 2019-11-06 12:42:52.834889

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '576e3abe313e'
down_revision = 'ddc184165c6e'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('opright', sa.Column('appanalityc', sa.Boolean()))
    op.add_column('opright', sa.Column('appadmin', sa.Boolean()))
    op.add_column('opright', sa.Column('appsituationcenter', sa.Boolean()))


def downgrade():
    op.drop_column('opright', 'appanalityc')
    op.drop_column('opright', 'appadmin')
    op.drop_column('opright', 'appsituationcenter')
