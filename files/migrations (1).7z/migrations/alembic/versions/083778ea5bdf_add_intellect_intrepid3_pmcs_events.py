# -*- coding: utf-8 -*-

"""add_intellect_intrepid3_pmcs_events

Revision ID: 083778ea5bdf
Revises: 6756d8f8b16d
Create Date: 2019-02-23 15:07:52.466000

Добавляет события для постановки снятия сегмента для оборудования intellect_intrepid3

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date
import json

# revision identifiers, used by Alembic.
revision = '083778ea5bdf'
down_revision = '6756d8f8b16d'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def addEv(code, descr, format, equipment = u"intellect_intrepid3", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })

addEv(7645, u"Поставлен на охрану сегмент micropoint II", u"Сегмент %statement.directObj.name поставлен на охрану", u"intellect_intrepid3", 7, 0)
addEv(7646, u"Снят с охраны сегмент micropoint II", u"Сегмент %statement.directObj.name снят с охраны", u"intellect_intrepid3", 7, 0)

def upgrade():
    op.execute('delete from event_catalog where code=7645 or code=7646')
    op.bulk_insert(event_catalog, events)


def downgrade():
    op.execute('delete from event_catalog where code=7645 or code=7646')
