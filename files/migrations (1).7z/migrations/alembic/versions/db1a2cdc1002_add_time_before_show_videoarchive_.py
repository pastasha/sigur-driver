"""add time before show videoarchive column to usersettings

Revision ID: db1a2cdc1002
Revises: 49bbb5c533a3
Create Date: 2019-06-11 10:22:49.695000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'db1a2cdc1002'
down_revision = '49bbb5c533a3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_usersettings
        add column timebeforeshowvideoarchive integer default 0;
        
        update system_usersettings
        set timebeforeshowvideoarchive = 0
    """)


def downgrade():
    op.execute("""
        alter table system_usersettings
        drop column timebeforeshowvideoarchive
    """)
