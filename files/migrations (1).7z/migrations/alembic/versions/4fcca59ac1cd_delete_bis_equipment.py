"""delete bis equipment

Revision ID: 4fcca59ac1cd
Revises: f10ec65becc3
Create Date: 2019-06-10 16:52:43.266000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4fcca59ac1cd'
down_revision = 'f10ec65becc3'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('bis_accesspoint')
    op.drop_table('bis_bisright')
    op.drop_table('bis_devices')
    op.drop_table('bis_root')
    op.drop_column('common_commonright', 'bisright')
    op.drop_column('common_root', 'bisorganization')
    op.execute("delete from equipments where name='bis'")


def downgrade():
    pass
