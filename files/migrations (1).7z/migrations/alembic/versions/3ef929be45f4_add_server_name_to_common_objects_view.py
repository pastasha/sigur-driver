"""add server name to common_objects view

Revision ID: 3ef929be45f4
Revises: 92677d40cbc4
Create Date: 2019-11-01 13:34:42.918822

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3ef929be45f4'
down_revision = '92677d40cbc4'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
            DROP VIEW IF EXISTS common_object;
            CREATE VIEW common_object as
            select ROW_NUMBER() OVER(ORDER BY (SELECT 1)) id, uniid, description, type, kind, equipment, remote_guid 
            from (select uniid, description, 'person' as type, null as kind, null as equipment, remote_guid from common_person
            union
            select uniid, description, 'mobile' as type, null as kind, null as equipment, remote_guid from common_mobile
            union
            select uniid, description, 'thing' as type, null as kind, null as equipment, remote_guid from common_thing objects
            union
            select id, name, 'observed_object' as type, devtype as kind, devequipment as kind, remote_guid from observed_objects) observed_objects;
    """)


def downgrade():
    pass
