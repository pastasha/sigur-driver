"""fix common_object view

Revision ID: 9b9513d2b4b5
Revises: 12f7ec56ef8d
Create Date: 2019-12-03 14:10:20.260914

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9b9513d2b4b5'
down_revision = '12f7ec56ef8d'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
            DROP VIEW IF EXISTS common_object;
            CREATE VIEW common_object as
            select ROW_NUMBER() OVER(ORDER BY (SELECT 1)) id, uniid, description, type, kind, equipment, remote_guid 
            from (select uniid, description, 'person' as type, null as kind, null as equipment, remote_guid from common_person where flags=0
            union
            select uniid, description, 'mobile' as type, null as kind, null as equipment, remote_guid from common_mobile where flags=0
            union
            select uniid, description, 'thing' as type, null as kind, null as equipment, remote_guid from common_thing objects where flags=0
            union
            select id, name, 'observed_object' as type, devtype as kind, devequipment as kind, remote_guid from observed_objects where deletemark=0) observed_objects;
    """)


def downgrade():
    pass
