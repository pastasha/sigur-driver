"""creating tables for hardware

Revision ID: 559289e64fb3
Revises: 08cede13be63
Create Date: 2018-03-01 12:29:44.084000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '559289e64fb3'
down_revision = 'cae85ae602c0'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('rusguard_controllers',(
			('id', 'varchar(256)', ''),
			('description', 'varchar(256)', ''),
			('isactive', 'boolean', 'default false'),
			('type', 'varchar(256)', '')			
		),[], 'True'
	)


def downgrade():
    pass
