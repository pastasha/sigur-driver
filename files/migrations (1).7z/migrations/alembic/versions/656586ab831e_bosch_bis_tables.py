# -*- coding: utf-8 -*-

"""bosch bis tables

Revision ID: 656586ab831e
Revises: adc16801b41c
Create Date: 2018-09-28 19:58:38.307000

"""
from alembic import op

# revision identifiers, used by Alembic.
revision = '656586ab831e'
down_revision = 'adc16801b41c'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''insert into equipments(name, enabled)
                values('boschbis', true)
            ''')

    op.create_equipment('boschbis_root', [
        ('description', 'text', ''),
        ('driver_addr', 'text', ''),
        ('dev_server', 'text', ''),
        ('dev_host', 'text', ''),
        ('prefix', 'text', ''),
        ('ae_device_base', 'text', 'default \'Map.\''),
        ('interval', 'int', 'default 5'),
        ('dead_count', 'int', 'default 3'),
        ('command_interval', 'int', 'default 100'),
        ('conn_lose_timeout', 'int', 'default 10'),
        ('active', 'boolean', 'default false'),
        ('synchronization', 'int', 'default 0')
    ], [], True
                        )
    op.create_equipment('boschbis_detector', [
        ('description', 'text', ''),
        ('type', 'text', ''),
        ('external_id', 'text', '')
    ], [], True
                        )
def downgrade():
    pass
