"""rename_taskowner_column_in_inctask

Revision ID: 30dddeaff198
Revises: 239ba4af7e18
Create Date: 2019-10-09 09:50:12.443929

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '30dddeaff198'
down_revision = '239ba4af7e18'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_task_register
        rename column task_owner to owner;
    """)


def downgrade():
    pass
