# -*- coding: utf-8 -*-

"""drop functions for store events

Revision ID: d13aa773eb95
Revises: 8100cf407afa
Create Date: 2018-10-26 14:43:48.738000

Так как теперь события в БД пишет дисплеер все эти функции не нужны
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd13aa773eb95'
down_revision = '8100cf407afa'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop function if exists create_new_event_member_table(text);
        drop function if exists create_new_event_table(timestamp without time zone);
        drop function if exists get_current_operator();
        drop function if exists get_event_handler(bigint, bigint, bigint, bigint, bigint);
        drop function if exists init_esm_session_variables();
        drop function if exists set_current_operator(bigint, bigint);
        drop function if exists set_subject_last_pass_event(bigint, timestamp without time zone, bigint, bigint, bigint, bigint,
            bigint);
        drop function if exists store_event(bigint, bigint, bigint, timestamp without time zone, bigint, text, text, text,
            bigint, text, bigint, text, text, text, bigint, text, bigint, text, text, text, bigint, text, bigint, text,
            text, text, bigint, text, bigint, text, text, text, bigint, text, bigint, text, text, text, bigint, text,
            bigint, text, text, text, bigint, text, bigint, text, text, text, bigint, text, bigint, text, text, text,
            bigint, text, bigint, text, text, text, bigint, bigint, bigint, bigint, bigint[]);
        drop function if exists store_event_member(timestamp without time zone, bigint, character varying, bigint, text,
            character varying, character varying, bigint, text);
    """)


def downgrade():
    pass
