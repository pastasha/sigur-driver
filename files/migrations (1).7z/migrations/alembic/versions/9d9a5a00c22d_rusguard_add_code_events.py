# -*- coding: utf-8 -*-

"""rusguard add code events

Revision ID: 9d9a5a00c22d
Revises: df0620b3abd4
Create Date: 2018-03-13 17:42:33.490000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = "9d9a5a00c22d"
down_revision = "0a2d8554bbb0"
branch_labels = None
depends_on = None
events = []



event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)

def upgrade():
    op.bulk_insert(event_catalog, events)


	
def addEv(code, descr, format, equipment = u"rusguard", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(128001, u"Контроллер перезагрузился", u"[\"%statement.directObj.name Контроллер перезагрузился %statement.adverbialMode.params\", \"Контроллер перезагрузился\"]")
addEv(128002, u"Взлом тампера контроллера", u"[\"%statement.directObj.name Взлом тампера контроллера %statement.adverbialMode.params\", \"Взлом тампера контроллера\"]")
addEv(128003, u"Тампер контроллера в норме", u"[\"%statement.directObj.name Тампер контроллера в норме %statement.adverbialMode.params\", \"Тампер контроллера в норме\"]")
addEv(128004, u"Питание в норме", u"[\"%statement.directObj.name Питание в норме %statement.adverbialMode.params\", \"Питание в норме\"]")
addEv(128005, u"Переход на резервное питание", u"[\"%statement.directObj.name Переход на резервное питание %statement.adverbialMode.params\", \" Переход на резервное питание\"]")
addEv(128006, u"Аккумулятор в норме", u"[\"%statement.directObj.name Аккумулятор в норме %statement.adverbialMode.params\", \" Аккумулятор в норме\"]")
addEv(128007, u"Аккумулятор разряжен", u"[\"%statement.directObj.name Аккумулятор разряжен %statement.adverbialMode.params\", \" Аккумулятор разряжен\"]")
addEv(128008, u"Неисправность канала питания", u"[\"%statement.directObj.name Неисправность канала питания %statement.adverbialMode.params\", \" Неисправность канала питания\"]")
addEv(128009, u"Канал питания в норме", u"[\"%statement.directObj.name Канал питания в норме %statement.adverbialMode.params\", \" Канал питания в норме\"]")
addEv(128010, u"Неисправность платы контроллера", u"[\"%statement.directObj.name Неисправность платы контроллера %statement.adverbialMode.params\", \" Неисправность платы контроллера\"]")
addEv(128011, u"Тревога охранного датчика", u"[\"%statement.directObj.name Тревога охранного датчика %statement.adverbialMode.params\", \" Тревога охранного датчика\"]")
addEv(128012, u"Взлом двери", u"[\"%statement.directObj.name Взлом двери %statement.adverbialMode.params\", \" Взлом двери\"]")
addEv(128013, u"Поставлено на охрану", u"[\"%statement.directObj.name Поставлено на охрану %statement.adverbialMode.params\", \" Поставлено на охрану\"]")
addEv(128014, u"Снято с охраны", u"[\"%statement.directObj.name Снято с охраны %statement.adverbialMode.params\", \" Снято с охраны\"]")
addEv(128015, u"Заблокировано", u"[\"%statement.directObj.name Заблокировано %statement.adverbialMode.params\", \" Заблокировано\"]")
addEv(128016, u"Разблокировано", u"[\"%statement.directObj.name Разблокировано %statement.adverbialMode.params\", \" Разблокировано\"]")
addEv(128017, u"Недостаточно прав для постановки на охрану", u"[\"%statement.directObj.name Недостаточно прав для постановки на охрану %statement.adverbialMode.params\", \" Недостаточно прав для постановки на охрану\"]")
addEv(128018, u"Недостаточно апрв для блокировки", u"[\"%statement.directObj.name Недостаточно апрв для блокировки %statement.adverbialMode.params\", \" Недостаточно апрв для блокировки\"]")
addEv(128019, u"Невозможно поставить на охрану - датчик в сработке", u"[\"%statement.directObj.name Невозможно поставить на охрану - датчик в сработке %statement.adverbialMode.params\", \" Невозможно поставить на охрану - датчик в сработке\"]")
addEv(128020, u"Аварийно открыто", u"[\"%statement.directObj.name Аварийно открыто %statement.adverbialMode.params\", \" Аварийно открыто\"]")
addEv(128021, u"Конец 'аварийно открыто'", u"[\"%statement.directObj.name Конец 'аварийно открыто' %statement.adverbialMode.params\", \" Конец 'аварийно открыто'\"]")
addEv(128022, u"Невозможно снять режим 'Аварийно открыто' - кнопка аварийной разблокировки нажата", u"[\"%statement.directObj.name Невозможно снять режим 'Аварийно открыто' - кнопка аварийной разблокировки нажата %statement.adverbialMode.params\", \" Невозможно снять режим 'Аварийно открыто' - кнопка аварийной разблокировки нажата\"]")
addEv(128023, u"Проход запрещён", u"[\"%statement.directObj.name Проход запрещён %statement.adverbialMode.params\", \" Проход запрещён\"]")
addEv(128024, u"Запрос (на фотоидентификацию)", u"[\"%statement.directObj.name Запрос (на фотоидентификацию) %statement.adverbialMode.params\", \" Запрос (на фотоидентификацию)\"]")
addEv(128025, u"Вход", u"[\"%statement.directObj.name Вход %statement.adverbialMode.params\", \" Вход\"]")
addEv(128026, u"Выход", u"[\"%statement.directObj.name Выход %statement.adverbialMode.params\", \" Выход\"]")
addEv(128027, u"Выход по считывателю картоприёмника", u"[\"%statement.directObj.name Выход по считывателю картоприёмника %statement.adverbialMode.params\", \" Выход по считывателю картоприёмника\"]")
addEv(128028, u"Проход", u"[\"%statement.directObj.name Проход %statement.adverbialMode.params\", \" Проход\"]")
addEv(128029, u"Вход первого лица", u"[\"%statement.directObj.name Вход первого лица %statement.adverbialMode.params\", \" Вход первого лица\"]")
addEv(128030, u"Выход первого лица", u"[\"%statement.directObj.name Выход первого лица %statement.adverbialMode.params\", \" Выход первого лица\"]")
addEv(128031, u"Выход первого лица по считывателю картоприёмника", u"[\"%statement.directObj.name Выход первого лица по считывателю картоприёмника %statement.adverbialMode.params\", \" Выход первого лица по считывателю картоприёмника\"]")
addEv(128032, u"Проход первого лица", u"[\"%statement.directObj.name Проход первого лица %statement.adverbialMode.params\", \" Проход первого лица\"]")
addEv(128033, u"Вход второго лица", u"[\"%statement.directObj.name Вход второго лица %statement.adverbialMode.params\", \" Вход второго лица\"]")
addEv(128034, u"Выход второго лица", u"[\"%statement.directObj.name Выход второго лица %statement.adverbialMode.params\", \" Выход второго лица\"]")
addEv(128035, u"Выход второго лица по считывателю картоприёмника", u"[\"%statement.directObj.name Выход второго лица по считывателю картоприёмника %statement.adverbialMode.params\", \" Выход второго лица по считывателю картоприёмника\"]")
addEv(128036, u"Проход второго лица", u"[\"%statement.directObj.name Проход второго лица %statement.adverbialMode.params\", \" Проход второго лица\"]")
addEv(128037, u"Отказ от прохода", u"[\"%statement.directObj.name Отказ от прохода %statement.adverbialMode.params\", \" Отказ от прохода\"]")
addEv(128038, u"Введён пин-код под принуждением", u"[\"%statement.directObj.name Введён пин-код под принуждением %statement.adverbialMode.params\", \" Введён пин-код под принуждением\"]")
addEv(128039, u"Дверь оставлена открытой", u"[\"%statement.directObj.name Дверь оставлена открытой %statement.adverbialMode.params\", \" Дверь оставлена открытой\"]")
addEv(128040, u"Открыто надолго", u"[\"%statement.directObj.name Открыто надолго %statement.adverbialMode.params\", \" Открыто надолго\"]")
addEv(128041, u"Снятие режима 'Открыто надолго'", u"[\"%statement.directObj.name Снятие режима 'Открыто надолго' %statement.adverbialMode.params\", \" Снятие режима 'Открыто надолго'\"]")
addEv(128042, u"Не получено разрешение на проход", u"[\"%statement.directObj.name Не получено разрешение на проход %statement.adverbialMode.params\", \" Не получено разрешение на проход\"]")
addEv(128043, u"Нажата кнопка", u"[\"%statement.directObj.name Нажата кнопка %statement.adverbialMode.params\", \" Нажата кнопка\"]")
addEv(128044, u"Началась задержка постановки на охрану", u"[\"%statement.directObj.name Началась задержка постановки на охрану %statement.adverbialMode.params\", \" Началась задержка постановки на охрану\"]")
addEv(128045, u"Включена сирена", u"[\"%statement.directObj.name Включена сирена %statement.adverbialMode.params\", \" Включена сирена\"]")
addEv(128046, u"Выключена сирена", u"[\"%statement.directObj.name Выключена сирена %statement.adverbialMode.params\", \" Выключена сирена\"]")
addEv(128047, u"Взлом тампера картоприёмника", u"[\"%statement.directObj.name Взлом тампера картоприёмника %statement.adverbialMode.params\", \" Взлом тампера картоприёмника\"]")
addEv(128048, u"Тампер картоприёмника в норме", u"[\"%statement.directObj.name Тампер картоприёмника в норме %statement.adverbialMode.params\", \" Тампер картоприёмника в норме\"]")
addEv(128049, u"Запущен опрос устройства", u"[\"%statement.directObj.name Запущен опрос устройства %statement.adverbialMode.params\", \" Запущен опрос устройства\"]")
addEv(128050, u"Остановлен опрос устройства", u"[\"%statement.directObj.name Остановлен опрос устройства %statement.adverbialMode.params\", \" Остановлен опрос устройства\"]")
addEv(128051, u"Установлена связь с устройством", u"[\"%statement.directObj.name Установлена связь с устройством %statement.adverbialMode.params\", \" Установлена связь с устройством\"]")
addEv(128052, u"Потеряна связь с устройством", u"[\"%statement.directObj.name Потеряна связь с устройством %statement.adverbialMode.params\", \" Потеряна связь с устройством\"]")
addEv(128053, u"Контейнер картоприёмника заполнен", u"[\"%statement.directObj.name Контейнер картоприёмника заполнен %statement.adverbialMode.params\", \" Контейнер картоприёмника заполнен\"]")
addEv(128054, u"Конец взома двери", u"[\"%statement.directObj.name Конец взома двери %statement.adverbialMode.params\", \" Конец взома двери\"]")
addEv(128055, u"Началась задержка срабатывания тревоги", u"[\"%statement.directObj.name Началась задержка срабатывания тревоги %statement.adverbialMode.params\", \" Началась задержка срабатывания тревоги\"]")
addEv(128056, u"Дверь закрыта", u"[\"%statement.directObj.name Дверь закрыта %statement.adverbialMode.params\", \" Дверь закрыта\"]")
addEv(128057, u"Конвертер не подключен", u"[\"%statement.directObj.name Конвертер не подключен %statement.adverbialMode.params\", \" Конвертер не подключен\"]")
addEv(128058, u"Конвертер - обрыв связи на CAN-шине", u"[\"%statement.directObj.name Конвертер - обрыв связи на CAN-шине %statement.adverbialMode.params\", \" Конвертер - обрыв связи на CAN-шине\"]")
addEv(128059, u"Конвертер в порядке", u"[\"%statement.directObj.name Конвертер в порядке %statement.adverbialMode.params\", \" Конвертер в порядке\"]")
addEv(128060, u"Поставлено на охрану ключом", u"[\"%statement.directObj.name Поставлено на охрану ключом %statement.adverbialMode.params\", \" Поставлено на охрану ключом\"]")
addEv(128061, u"Снято с охраны ключом", u"[\"%statement.directObj.name Снято с охраны ключом %statement.adverbialMode.params\", \" Снято с охраны ключом\"]")
addEv(128062, u"Заблокировано ключом", u"[\"%statement.directObj.name Заблокировано ключом %statement.adverbialMode.params\", \" Заблокировано ключом\"]")
addEv(128063, u"Разблокировано ключом", u"[\"%statement.directObj.name Разблокировано ключом %statement.adverbialMode.params\", \" Разблокировано ключом\"]")
addEv(128064, u"Невозможно поставить на охрану ключом - датчик в сработке", u"[\"%statement.directObj.name Невозможно поставить на охрану ключом - датчик в сработке %statement.adverbialMode.params\", \" Невозможно поставить на охрану ключом - датчик в сработке\"]")
addEv(128065, u"Вход по ключу", u"[\"%statement.directObj.name Вход по ключу %statement.adverbialMode.params\", \" Вход по ключу\"]")
addEv(128066, u"Выход по ключу", u"[\"%statement.directObj.name Выход по ключу %statement.adverbialMode.params\", \" Выход по ключу\"]")
addEv(128067, u"Проход по ключу", u"[\"%statement.directObj.name Проход по ключу %statement.adverbialMode.params\", \" Проход по ключу\"]")
addEv(128068, u"Отказ от прохода по ключу", u"[\"%statement.directObj.name Отказ от прохода по ключу %statement.adverbialMode.params\", \" Отказ от прохода по ключу\"]")
addEv(128069, u"Открыто надолго ключом", u"[\"%statement.directObj.name Открыто надолго ключом %statement.adverbialMode.params\", \" Открыто надолго ключом\"]")
addEv(128070, u"Снятие режима 'Открыто надолго' ключом", u"[\"%statement.directObj.name Снятие режима 'Открыто надолго' ключом %statement.adverbialMode.params\", \" Снятие режима 'Открыто надолго' ключом\"]")
addEv(128071, u"Началась задержка постановки на охрану по ключу", u"[\"%statement.directObj.name Началась задержка постановки на охрану по ключу %statement.adverbialMode.params\", \" Началась задержка постановки на охрану по ключу\"]")
addEv(128072, u"Оставлено открытым после открытия ключом", u"[\"%statement.directObj.name Оставлено открытым после открытия ключом %statement.adverbialMode.params\", \" Оставлено открытым после открытия ключом\"]")
addEv(128073, u"Закрыто после открытия ключом", u"[\"%statement.directObj.name Закрыто после открытия ключом %statement.adverbialMode.params\", \" Закрыто после открытия ключом\"]")
addEv(128074, u"Приложен ключ на вход", u"[\"%statement.directObj.name Приложен ключ на вход %statement.adverbialMode.params\", \" Приложен ключ на вход\"]")
addEv(128075, u"Приложен ключ на выход", u"[\"%statement.directObj.name Приложен ключ на выход %statement.adverbialMode.params\", \" Приложен ключ на выход\"]")
addEv(128076, u"Запрет проезда", u"[\"%statement.directObj.name Запрет проезда %statement.adverbialMode.params\", \" Запрет проезда\"]")
addEv(128077, u"Пожар", u"[\"%statement.directObj.name Пожар %statement.adverbialMode.params\", \" Пожар\"]")
addEv(128078, u"«Внимание! Опасность пожара»", u"[\"%statement.directObj.name «Внимание! Опасность пожара» %statement.adverbialMode.params\", \" «Внимание! Опасность пожара»\"]")
addEv(128079, u"Неисправность пожарного оборудования", u"[\"%statement.directObj.name Неисправность пожарного оборудования %statement.adverbialMode.params\", \" Неисправность пожарного оборудования\"]")
addEv(128080, u"Тревога проникновения", u"[\"%statement.directObj.name Тревога проникновения %statement.adverbialMode.params\", \" Тревога проникновения\"]")
addEv(128081, u"Обрыв ШС", u"[\"%statement.directObj.name Обрыв ШС %statement.adverbialMode.params\", \" Обрыв ШС\"]")
addEv(128082, u"Авария сети 220В", u"[\"%statement.directObj.name Авария сети 220В %statement.adverbialMode.params\", \" Авария сети 220В\"]")
addEv(128083, u"Восстановление сети 220В", u"[\"%statement.directObj.name Восстановление сети 220В %statement.adverbialMode.params\", \" Восстановление сети 220В\"]")
addEv(128084, u"Повышение температуры", u"[\"%statement.directObj.name Повышение температуры %statement.adverbialMode.params\", \" Повышение температуры\"]")
addEv(128085, u"Температура в норме", u"[\"%statement.directObj.name Температура в норме %statement.adverbialMode.params\", \" Температура в норме\"]")
addEv(128086, u"Тревога входа", u"[\"%statement.directObj.name Тревога входа %statement.adverbialMode.params\", \" Тревога входа\"]")
addEv(128087, u"КЗ выхода", u"[\"%statement.directObj.name КЗ выхода %statement.adverbialMode.params\", \" КЗ выхода\"]")
addEv(128088, u"Обрыв выхода", u"[\"%statement.directObj.name Обрыв выхода %statement.adverbialMode.params\", \" Обрыв выхода\"]")
addEv(128089, u"Выход отключен", u"[\"%statement.directObj.name Выход отключен %statement.adverbialMode.params\", \" Выход отключен\"]")
addEv(128090, u"Выход подключен", u"[\"%statement.directObj.name Выход подключен %statement.adverbialMode.params\", \" Выход подключен\"]")
addEv(128091, u"Восстановление выхода", u"[\"%statement.directObj.name Восстановление выхода %statement.adverbialMode.params\", \" Восстановление выхода\"]")
addEv(128092, u"Изменение состояния выхода", u"[\"%statement.directObj.name Изменение состояния выхода %statement.adverbialMode.params\", \" Изменение состояния выхода\"]")
addEv(128093, u"Открыт корпус прибора", u"[\"%statement.directObj.name Открыт корпус прибора %statement.adverbialMode.params\", \" Открыт корпус прибора\"]")
addEv(128094, u"Закрыт корпус прибора", u"[\"%statement.directObj.name Закрыт корпус прибора %statement.adverbialMode.params\", \" Закрыт корпус прибора\"]")
addEv(128095, u"Пуск речевого оповещения", u"[\"%statement.directObj.name Пуск речевого оповещения %statement.adverbialMode.params\", \" Пуск речевого оповещения\"]")
addEv(128096, u"Сброс пуска речевого оповещения", u"[\"%statement.directObj.name Сброс пуска речевого оповещения %statement.adverbialMode.params\", \" Сброс пуска речевого оповещения\"]")
addEv(128097, u"Срабатывание клапана", u"[\"%statement.directObj.name Срабатывание клапана %statement.adverbialMode.params\", \" Срабатывание клапана\"]")
addEv(128098, u"Отказ клапана", u"[\"%statement.directObj.name Отказ клапана %statement.adverbialMode.params\", \" Отказ клапана\"]")
addEv(128099, u"Ошибка клапана", u"[\"%statement.directObj.name Ошибка клапана %statement.adverbialMode.params\", \" Ошибка клапана\"]")
addEv(128100, u"Восстановление клапана", u"[\"%statement.directObj.name Восстановление клапана %statement.adverbialMode.params\", \" Восстановление клапана\"]")
addEv(128101, u"Ошибка параметров ШС", u"[\"%statement.directObj.name Ошибка параметров ШС %statement.adverbialMode.params\", \" Ошибка параметров ШС\"]")
addEv(128102, u"ШС отключен", u"[\"%statement.directObj.name ШС отключен %statement.adverbialMode.params\", \" ШС отключен\"]")
addEv(128103, u"ШС подключен", u"[\"%statement.directObj.name ШС подключен %statement.adverbialMode.params\", \" ШС подключен\"]")
addEv(128104, u"Нет связи ДПЛС 1", u"[\"%statement.directObj.name Нет связи ДПЛС 1 %statement.adverbialMode.params\", \" Нет связи ДПЛС 1\"]")
addEv(128105, u"Нет связи ДПЛС 2", u"[\"%statement.directObj.name Нет связи ДПЛС 2 %statement.adverbialMode.params\", \" Нет связи ДПЛС 2\"]")
addEv(128106, u"Восстановлена связь ДПЛС 1", u"[\"%statement.directObj.name Восстановлена связь ДПЛС 1 %statement.adverbialMode.params\", \" Восстановлена связь ДПЛС 1\"]")
addEv(128107, u"Восстановлена связь ДПЛС 2", u"[\"%statement.directObj.name Восстановлена связь ДПЛС 2 %statement.adverbialMode.params\", \" Восстановлена связь ДПЛС 2\"]")
addEv(128108, u"Короткое замыкание ДПЛС", u"[\"%statement.directObj.name Короткое замыкание ДПЛС %statement.adverbialMode.params\", \" Короткое замыкание ДПЛС\"]")
addEv(128109, u"Авария двухпроводной линии связи прибора 'С2000-КДЛ'", u"[\"%statement.directObj.name Авария двухпроводной линии связи прибора 'С2000-КДЛ' %statement.adverbialMode.params\", \" Авария двухпроводной линии связи прибора 'С2000-КДЛ'\"]")
addEv(128110, u"Короткое замыкание ШС", u"[\"%statement.directObj.name Короткое замыкание ШС %statement.adverbialMode.params\", \" Короткое замыкание ШС\"]")
addEv(128111, u"Сработка датчика", u"[\"%statement.directObj.name Сработка датчика %statement.adverbialMode.params\", \" Сработка датчика\"]")
addEv(128112, u"Срабатывание СДУ", u"[\"%statement.directObj.name Срабатывание СДУ %statement.adverbialMode.params\", \" Срабатывание СДУ\"]")
addEv(128113, u"Отказ СДУ", u"[\"%statement.directObj.name Отказ СДУ %statement.adverbialMode.params\", \" Отказ СДУ\"]")
addEv(128114, u"Потеряна связь с прибором", u"[\"%statement.directObj.name Потеряна связь с прибором %statement.adverbialMode.params\", \" Потеряна связь с прибором\"]")
addEv(128115, u"Восстановлена связь с прибором", u"[\"%statement.directObj.name Восстановлена связь с прибором %statement.adverbialMode.params\", \" Восстановлена связь с прибором\"]")
addEv(128116, u"Насос включен", u"[\"%statement.directObj.name Насос включен %statement.adverbialMode.params\", \" Насос включен\"]")
addEv(128117, u"Насос выключен", u"[\"%statement.directObj.name Насос выключен %statement.adverbialMode.params\", \" Насос выключен\"]")
addEv(128118, u"Срабатывание цепи пуска", u"[\"%statement.directObj.name Срабатывание цепи пуска %statement.adverbialMode.params\", \" Срабатывание цепи пуска\"]")
addEv(128119, u"Неудачный пуск пожаротушения", u"[\"%statement.directObj.name Неудачный пуск пожаротушения %statement.adverbialMode.params\", \" Неудачный пуск пожаротушения\"]")
addEv(128120, u"Задержка автоматического пуска", u"[\"%statement.directObj.name Задержка автоматического пуска %statement.adverbialMode.params\", \" Задержка автоматического пуска\"]")
addEv(128121, u"Тушение", u"[\"%statement.directObj.name Тушение %statement.adverbialMode.params\", \" Тушение\"]")
addEv(128122, u"Аварийный пуск АСПТ", u"[\"%statement.directObj.name Аварийный пуск АСПТ %statement.adverbialMode.params\", \" Аварийный пуск АСПТ\"]")
addEv(128123, u"Пуск АУП", u"[\"%statement.directObj.name Пуск АУП %statement.adverbialMode.params\", \" Пуск АУП\"]")
addEv(128124, u"Блокировка пуска АУП", u"[\"%statement.directObj.name Блокировка пуска АУП %statement.adverbialMode.params\", \" Блокировка пуска АУП\"]")
addEv(128125, u"Автоматика включена", u"[\"%statement.directObj.name Автоматика включена %statement.adverbialMode.params\", \" Автоматика включена\"]")
addEv(128126, u"Автоматика выключена", u"[\"%statement.directObj.name Автоматика выключена %statement.adverbialMode.params\", \" Автоматика выключена\"]")
addEv(128127, u"Отмена пуска АСПТ", u"[\"%statement.directObj.name Отмена пуска АСПТ %statement.adverbialMode.params\", \" Отмена пуска АСПТ\"]")
addEv(128128, u"Ошибка при автоматическом тестировании", u"[\"%statement.directObj.name Ошибка при автоматическом тестировании %statement.adverbialMode.params\", \" Ошибка при автоматическом тестировании\"]")
addEv(128129, u"Ручной тест", u"[\"%statement.directObj.name Ручной тест %statement.adverbialMode.params\", \" Ручной тест\"]")
addEv(128130, u"Авария питания", u"[\"%statement.directObj.name Авария питания %statement.adverbialMode.params\", \" Авария питания\"]")
addEv(128131, u"Ошибка теста АКБ", u"[\"%statement.directObj.name Ошибка теста АКБ %statement.adverbialMode.params\", \" Ошибка теста АКБ\"]")
addEv(128132, u"АКБ разряжена", u"[\"%statement.directObj.name АКБ разряжена %statement.adverbialMode.params\", \" АКБ разряжена\"]")
addEv(128133, u"Неисправность батареи", u"[\"%statement.directObj.name Неисправность батареи %statement.adverbialMode.params\", \" Неисправность батареи\"]")
addEv(128134, u"Неисправность ЗУ РИП", u"[\"%statement.directObj.name Неисправность ЗУ РИП %statement.adverbialMode.params\", \" Неисправность ЗУ РИП\"]")
addEv(128135, u"Перегрузка РИП", u"[\"%statement.directObj.name Перегрузка РИП %statement.adverbialMode.params\", \" Перегрузка РИП\"]")
addEv(128136, u"Устранена перегрузка РИП", u"[\"%statement.directObj.name Устранена перегрузка РИП %statement.adverbialMode.params\", \" Устранена перегрузка РИП\"]")
addEv(128137, u"Неисправность ЗУ РИП устранена", u"[\"%statement.directObj.name Неисправность ЗУ РИП устранена %statement.adverbialMode.params\", \" Неисправность ЗУ РИП устранена\"]")
addEv(128138, u"Восстановление питания", u"[\"%statement.directObj.name Восстановление питания %statement.adverbialMode.params\", \" Восстановление питания\"]")
addEv(128139, u"Восстановление батареи", u"[\"%statement.directObj.name Восстановление батареи %statement.adverbialMode.params\", \" Восстановление батареи\"]")
addEv(128140, u"Отключен РИП", u"[\"%statement.directObj.name Отключен РИП %statement.adverbialMode.params\", \" Отключен РИП\"]")
addEv(128141, u"Включен РИП", u"[\"%statement.directObj.name Включен РИП %statement.adverbialMode.params\", \" Включен РИП\"]")
addEv(128142, u"Сброс прибора", u"[\"%statement.directObj.name Сброс прибора %statement.adverbialMode.params\", \" Сброс прибора\"]")
addEv(128143, u"Необходимо обслуживание", u"[\"%statement.directObj.name Необходимо обслуживание %statement.adverbialMode.params\", \" Необходимо обслуживание\"]")
addEv(128144, u"Отключение ветви RS-485", u"[\"%statement.directObj.name Отключение ветви RS-485 %statement.adverbialMode.params\", \" Отключение ветви RS-485\"]")
addEv(128145, u"Восстановление ветви RS-485", u"[\"%statement.directObj.name Восстановление ветви RS-485 %statement.adverbialMode.params\", \" Восстановление ветви RS-485\"]")
addEv(128146, u"Нарушение ШС", u"[\"%statement.directObj.name Нарушение ШС %statement.adverbialMode.params\", \" Нарушение ШС\"]")
addEv(128147, u"Восстановление ШС", u"[\"%statement.directObj.name Восстановление ШС %statement.adverbialMode.params\", \" Восстановление ШС\"]")
addEv(128148, u"Сброс тревоги ШС", u"[\"%statement.directObj.name Сброс тревоги ШС %statement.adverbialMode.params\", \" Сброс тревоги ШС\"]")
addEv(128149, u"ШС снят", u"[\"%statement.directObj.name ШС снят %statement.adverbialMode.params\", \" ШС снят\"]")
addEv(128150, u"Восстановление термометра", u"[\"%statement.directObj.name Восстановление термометра %statement.adverbialMode.params\", \" Восстановление термометра\"]")
addEv(128151, u"Аварийное повышение уровня", u"[\"%statement.directObj.name Аварийное повышение уровня %statement.adverbialMode.params\", \" Аварийное повышение уровня\"]")
addEv(128152, u"Аварийное понижение уровня", u"[\"%statement.directObj.name Аварийное понижение уровня %statement.adverbialMode.params\", \" Аварийное понижение уровня\"]")
addEv(128153, u"Повышение уровня", u"[\"%statement.directObj.name Повышение уровня %statement.adverbialMode.params\", \" Повышение уровня\"]")
addEv(128154, u"Норма уровня", u"[\"%statement.directObj.name Норма уровня %statement.adverbialMode.params\", \" Норма уровня\"]")
addEv(128155, u"Понижение уровня", u"[\"%statement.directObj.name Понижение уровня %statement.adverbialMode.params\", \" Понижение уровня\"]")
addEv(128156, u"Тихая тревога", u"[\"%statement.directObj.name Тихая тревога %statement.adverbialMode.params\", \" Тихая тревога\"]")
addEv(128157, u"Восстановление ДПЛС", u"[\"%statement.directObj.name Восстановление ДПЛС %statement.adverbialMode.params\", \" Восстановление ДПЛС\"]")
addEv(128158, u"Восстановление нормы пожарного оборудования", u"[\"%statement.directObj.name Восстановление нормы пожарного оборудования %statement.adverbialMode.params\", \" Восстановление нормы пожарного оборудования\"]")
addEv(128159, u"Пониженная температура", u"[\"%statement.directObj.name Пониженная температура %statement.adverbialMode.params\", \" Пониженная температура\"]")
addEv(128160, u"Неизвестное устройство", u"[\"%statement.directObj.name Неизвестное устройство %statement.adverbialMode.params\", \" Неизвестное устройство\"]")
addEv(128161, u"Восстановление контроля", u"[\"%statement.directObj.name Восстановление контроля %statement.adverbialMode.params\", \" Восстановление контроля\"]")
addEv(128162, u"Задержка взятия", u"[\"%statement.directObj.name Задержка взятия %statement.adverbialMode.params\", \" Задержка взятия\"]")
addEv(128163, u"ШС взят на охрану", u"[\"%statement.directObj.name ШС взят на охрану %statement.adverbialMode.params\", \" ШС взят на охрану\"]")
addEv(128164, u"Идентификация", u"[\"%statement.directObj.name Идентификация %statement.adverbialMode.params\", \" Идентификация\"]")
addEv(128165, u"Восстановление технологического ШС", u"[\"%statement.directObj.name Восстановление технологического ШС %statement.adverbialMode.params\", \" Восстановление технологического ШС\"]")
addEv(128166, u"Нарушение технологического ШС", u"[\"%statement.directObj.name Нарушение технологического ШС %statement.adverbialMode.params\", \" Нарушение технологического ШС\"]")
addEv(128167, u"Неисправность термометра", u"[\"%statement.directObj.name Неисправность термометра %statement.adverbialMode.params\", \" Неисправность термометра\"]")
addEv(128168, u"Нарушение 2 технологического ШС", u"[\"%statement.directObj.name Нарушение 2 технологического ШС %statement.adverbialMode.params\", \" Нарушение 2 технологического ШС\"]")
addEv(128169, u"Неудачное взятие", u"[\"%statement.directObj.name Неудачное взятие %statement.adverbialMode.params\", \" Неудачное взятие\"]")
addEv(128170, u"Внутренняя зона восстановлена", u"[\"%statement.directObj.name Внутренняя зона восстановлена %statement.adverbialMode.params\", \" Внутренняя зона восстановлена\"]")
addEv(128171, u"Раздел взят", u"[\"%statement.directObj.name Раздел взят %statement.adverbialMode.params\", \" Раздел взят\"]")
addEv(128172, u"Раздел снят", u"[\"%statement.directObj.name Раздел снят %statement.adverbialMode.params\", \" Раздел снят\"]")
addEv(128173, u"Реле включено", u"[\"%statement.directObj.name Реле включено %statement.adverbialMode.params\", \" Реле включено\"]")
addEv(128174, u"Реле выключено", u"[\"%statement.directObj.name Реле выключено %statement.adverbialMode.params\", \" Реле выключено\"]")
addEv(128175, u"Нажата кнопка Аварийного выхода", u"[\"%statement.directObj.name Нажата кнопка Аварийного выхода %statement.adverbialMode.params\", \" Нажата кнопка Аварийного выхода\"]")
addEv(128176, u"Конец нажатия кнопки Аварийного выхода", u"[\"%statement.directObj.name Конец нажатия кнопки Аварийного выхода %statement.adverbialMode.params\", \" Конец нажатия кнопки Аварийного выхода\"]")
addEv(128177, u"Отказ открытия дверцы", u"[\"%statement.directObj.name Отказ открытия дверцы %statement.adverbialMode.params\", \" Отказ открытия дверцы\"]")
addEv(128178, u"Дверца открыта", u"[\"%statement.directObj.name Дверца открыта %statement.adverbialMode.params\", \" Дверца открыта\"]")
addEv(128179, u"Неправильный номер дверцы", u"[\"%statement.directObj.name Неправильный номер дверцы %statement.adverbialMode.params\", \" Неправильный номер дверцы\"]")
addEv(128180, u"Связь с модулем востановленна", u"[\"%statement.directObj.name Связь с модулем востановленна %statement.adverbialMode.params\", \" Связь с модулем востановленна\"]")
addEv(128181, u"Появился новый модуль", u"[\"%statement.directObj.name Появился новый модуль %statement.adverbialMode.params\", \" Появился новый модуль\"]")
addEv(128182, u"Нет связи с модулем", u"[\"%statement.directObj.name Нет связи с модулем %statement.adverbialMode.params\", \" Нет связи с модулем\"]")
addEv(128183, u"Не возможно выполнить операцию с валидным ключем по причине отсутствия связи с модулем.", u"[\"%statement.directObj.name Не возможно выполнить операцию с валидным ключем по причине отсутствия связи с модулем. %statement.adverbialMode.params\", \" Не возможно выполнить операцию с валидным ключем по причине отсутствия связи с модулем.\"]")
addEv(128184, u"Невозможно открыть дверь", u"[\"%statement.directObj.name Невозможно открыть дверь %statement.adverbialMode.params\", \" Невозможно открыть дверь\"]")
addEv(128185, u"Проверка алкотестером прошла успешно", u"[\"%statement.directObj.name Проверка алкотестером прошла успешно %statement.adverbialMode.params\", \" Проверка алкотестером прошла успешно\"]")
addEv(128186, u"Время проверки истекло", u"[\"%statement.directObj.name Время проверки истекло %statement.adverbialMode.params\", \" Время проверки истекло\"]")
addEv(128187, u"Запрет по временному интервалу", u"[\"%statement.directObj.name Запрет по временному интервалу %statement.adverbialMode.params\", \" Запрет по временному интервалу\"]")
addEv(128188, u"Сообщение о изменении состояния устройства", u"[\"%statement.directObj.name Сообщение о изменении состояния устройства %statement.adverbialMode.params\", \" Сообщение о изменении состояния устройства\"]")
addEv(128189, u"Сообщение о вызове метода драйвера устройства оператором", u"[\"%statement.directObj.name Сообщение о вызове метода драйвера устройства оператором %statement.adverbialMode.params\", \" Сообщение о вызове метода драйвера устройства оператором\"]")


def downgrade():
    pass