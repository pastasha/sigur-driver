# -*- coding: utf-8 -*-

"""add context to asterisk caller fix

Revision ID: 743e634a7a48
Revises: 23821092682e
Create Date: 2019-04-30 10:22:17.435000

Это специальная миграция которая дублирует действие миграции
aaec22e6f088 add context to asterisk caller.
Это необходимо так как та миграция была сделана в мастере и попала в середину
очереди. Из-за этого на тех объектах где стоит trunk эта мигарция не сделается
и это приведет к тому что сервер не запустится.

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '743e634a7a48'
down_revision = '23821092682e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_workstation
        add column if not exists call_context text default '';
        alter table common_phone
        add column if not exists call_context text default '';
    """)


def downgrade():
    pass
