"""delete unused tables

Revision ID: 71e73df10848
Revises: 28eca456285c
Create Date: 2019-04-18 13:07:32.827000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '71e73df10848'
down_revision = '28eca456285c'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop table if exists arduino_board;
        drop table if exists arduino_input;
        drop table if exists commands;
        drop table if exists common_alarm;
        drop table if exists esm2sw_settings;
        drop table if exists filter;
        drop table if exists filter_theme;
        drop table if exists react_event_table;
        drop table if exists react_oo_table;
        drop table if exists rules;
        drop table if exists safety_journal;
        drop table if exists servers;
        drop table if exists state_tree;
        drop table if exists theme;
        drop table if exists theme_event;
        drop table if exists theme_oo;
        drop table if exists wconfigstation;
        drop table if exists wmodules;
        drop table if exists wstations;
    
        drop table if exists automatons;
        drop table if exists incident_forms;
        drop table if exists incident_types;
    
        drop table if exists requests_rights_association;
        drop table if exists requests;
        drop table if exists idcodes;
        drop table if exists rights;
        drop table if exists persons;
    """)


def downgrade():
    pass
