"""add_column_setting_for_root_orvell_and_cam_onvif

Revision ID: 618bb96dcfd0
Revises: 5c5b440ce1e8
Create Date: 2018-07-26 11:01:21.310000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '618bb96dcfd0'
down_revision = '5c5b440ce1e8'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE onvif_cam ADD settings int')
    op.execute('ALTER TABLE orwell_root ADD settings int')


def downgrade():
    op.execute('ALTER TABLE onvif_cam drop column settings')
    op.execute('ALTER TABLE orwell_root drop column settings')
