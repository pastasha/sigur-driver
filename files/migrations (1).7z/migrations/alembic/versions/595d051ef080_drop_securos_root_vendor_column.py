"""drop securos root vendor column

Revision ID: 595d051ef080
Revises: bc4abf207c30
Create Date: 2019-01-15 15:28:19.248000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '595d051ef080'
down_revision = 'bc4abf207c30'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column('securos_root', 'vendor')


def downgrade():
    op.add_column('securos_root',
        sa.Column('vendor', sa.String())
    )
