"""create custom catalog

Revision ID: 59d0281b0742
Revises: 2b60971670c7
Create Date: 2018-10-18 12:22:21.727000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '59d0281b0742'
down_revision = '2b60971670c7'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('common_customcatalog',(
			('description', 'text', ''),
		),[]
	)
    op.create_equipment('common_customcatalogvalue',(
			('description', 'text', ''),
		),[], True
	)
    

def downgrade():
    op.drop_table('common_customcatalog')
    op.drop_table('common_customcatalogvalue')
