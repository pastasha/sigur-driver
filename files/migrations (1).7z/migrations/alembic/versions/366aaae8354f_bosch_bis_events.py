# -*- coding: utf-8 -*-

"""bosch bis fa events

Revision ID: 366aaae8354f
Revises: 656586ab831e
Create Date: 2018-09-28 19:58:46.997000

"""
from alembic import op
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column

# revision identifiers, used by Alembic.
revision = '366aaae8354f'
down_revision = '656586ab831e'
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'boschbis', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(9601, 'Контроллер на связи', u'[\"Контроллер %statement.directObj.name на связи\", \"Контроллер на связи\"]')
add_event(9602, 'Связь с контроллером потеряна',
          u'[\"Связь с контроллером %statement.directObj.name потеряна\", \"Связь с контроллером потеряна\"]')
add_event(9603, 'Найдено устройство', u'[\"Найдено устройство %statement.directObj.name\", \"Найдено устройство\"]')

add_event(9610, 'Связь с устройством потеряна',
          u'[\"Связь с устройством %statement.directObj.name потеряна\", \"Связь с устройством потеряна\"]')
add_event(9611, 'Снято с охраны',
          u'[\"Устройство %statement.directObj.name снято с охраны\", \"Устройство снято с охраны\"]')
add_event(9612, 'На охране', u'[\"Устройство %statement.directObj.name на охране\", \"Устройство на охране\"]')
add_event(9613, 'Тревога', u'[\"Тревога на %statement.directObj.name\", \"Тревога\"]')
add_event(9614, 'Неисправность',
          u'[\"Неисправность получения состояния %statement.directObj.name\", \"Неисправность\"]')
add_event(9615, 'Активен', u'[\"Устройство %statement.directObj.name в активном состояний\", \"Активен\"]')
add_event(9616, 'Норма', u'[\"Устройство %statement.directObj.name в нормальном состояний\", \"Норма\"]')
add_event(9617, 'Отключено', u'[\"Устройство %statement.directObj.name отключено\", \"Отключено\"]')
add_event(9618, 'Готово к постановке на охрану',
          u'[\"Устройство %statement.directObj.name готово к постановке на охрану\", '
          u'\"Готово к постановке на охрану\"]')
add_event(9619, 'Не готово к постановке на охрану',
          u'[\"Устройство %statement.directObj.name не готово к постановке на охрану\", '
          u'\"Не готово к постановке на охрану\"]')


def downgrade():
    pass
