"""publish_column

Revision ID: ced5996a8fb8
Revises: 66b9abaac503
Create Date: 2019-01-06 10:36:13.527000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ced5996a8fb8'
down_revision = '66b9abaac503'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('ref_reports', sa.Column('published', sa.Boolean, default=False))
    sql = 'update ref_reports set published = false'
    op.execute(sql)

def downgrade():
    op.drop_column('ref_reports', 'published')
