# -*- coding: utf-8 -*-

"""update part and grouppart orioniso

Revision ID: 84b1cd73c240
Revises: 1f0d6cfbf399
Create Date: 2018-03-21 14:52:51.266000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '84b1cd73c240'
down_revision = '1f0d6cfbf399'
branch_labels = None
depends_on = None


def upgrade():
    '''Выставляет уникальные ключи у всех разделов и групп разделов у которых есть родитель начиная с 1'''
    op.execute('''DO $$
                    declare 
                    keyCodes int:=1;
                    id_String text:='{"list":[';
                    uniid_part bigint;
                    checkFirst boolean:= false;
                    a cursor for select uniid from orioniso_part where devaddr is not null;
                    b cursor for select uniid from orioniso_grouppart where devaddr is not null;
                    begin
                    for uniid_part in a
                    loop
                    update orioniso_part
                    set key = keyCodes
                    where orioniso_part.uniid = uniid_part.uniid;
                    if checkFirst = true then
                    id_String = id_String || ',' || cast(keyCodes as text);
                    else
                    id_String = id_String || cast(keyCodes as text);
                    checkFirst = true;
                    end if;
                    keyCodes = keyCodes+1;
                    end loop;
                    for uniid_part in b
                    loop
                    update orioniso_grouppart
                    set key = keyCodes
                    where orioniso_grouppart.uniid = uniid_part.uniid;
                    if checkFirst = true then
                    id_String = id_String || ',' || cast(keyCodes as text);
                    else
                    id_String = id_String || cast(keyCodes as text);
                    checkFirst = true;
                    end if;
                    keyCodes = keyCodes+1;
                    end loop;
                    id_String = id_String || ']}';
                    update orioniso_control
                    set id_array = id_String;
                    end;
                    $$''')


def downgrade():
    pass
