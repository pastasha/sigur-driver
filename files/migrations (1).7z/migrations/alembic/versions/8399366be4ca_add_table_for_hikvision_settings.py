"""add_table_for_hikvision_settings

Revision ID: 8399366be4ca
Revises: f25ad186c376
Create Date: 2018-11-13 15:21:39.893000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8399366be4ca'
down_revision = 'f25ad186c376'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('hikvision_settings',(
            ('timeout', 'int', 'default 5'),
            ('disable_ssl', 'int', 'default 1'),
            ('event_handler_type', 'text', 'default \'BaseNotification\''),
            ('bn_consumer_addr', 'text', ''),	
            ('bn_consumer_port', 'int', 'default 560'),
            ('update_xaddrs', 'int', 'default 1'),
            ('get_velocity_spaces', 'int', 'default 0')		
        ),[], True
    )


def downgrade():
    pass
