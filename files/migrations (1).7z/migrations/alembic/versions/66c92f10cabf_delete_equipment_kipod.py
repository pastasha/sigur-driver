"""delete equipment kipod

Revision ID: 66c92f10cabf
Revises: ac09c5407997
Create Date: 2018-09-19 13:15:09.942000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '66c92f10cabf'
down_revision = 'ac09c5407997'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop table if exists kipod_cam;
        drop table if exists kipod_bus;
        
        delete from opright_equip where equip = 'kipod';
        
        delete from equipments where name = 'kipod';
    """)


def downgrade():
    pass
