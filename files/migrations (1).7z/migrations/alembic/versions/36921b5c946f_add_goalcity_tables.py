"""add goalcity tables

Revision ID: 36921b5c946f
Revises: 81620914810b
Create Date: 2019-10-16 12:20:48.403238

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '36921b5c946f'
down_revision = '81620914810b'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        insert into equipments(name, enabled) values('goalcity', true)
    ''')

    op.create_equipment('goalcity_host', [
        ('description', 'text', ''),
        ('ports_addr', 'text', ''),
        ('web_ip', 'text', ''),
        ('web_port', 'int', 'default 3107'),
        ('web_login', 'text', ''),
        ('web_password', 'text', ''),
        ('rotor_ip', 'text', ''),
        ('rotor_port', 'text', 'default 2221'),
        ('poll_time', 'int', 'default 5'),
        ('active', 'boolean', 'default true'),
        ('synchronization', 'int', 'default 0')
    ], [], True)

    op.create_equipment('goalcity_cam', [
        ('description', 'text', ''),
        ('moniker_hash', 'text', ''),
        ('arch_moniker_hash', 'text', ''),
        ('rotor', 'text', ''),
        ('detector_enabled', 'boolean', 'default true')
    ], [], True)

    op.create_equipment('goalcity_rotor', [
        ('description', 'text', ''),
        ('password', 'text', '')
    ], [], True)


def downgrade():
    op.execute('''
        delete from equipments where name='goalcity';
        drop table goalcity_cam;
        drop table goalcity_rotor;
        drop table goalcity_host;
    ''')
