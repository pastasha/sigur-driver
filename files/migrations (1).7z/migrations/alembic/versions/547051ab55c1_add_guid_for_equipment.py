"""add guid for equipment

Revision ID: 547051ab55c1
Revises: a97ab1427500
Create Date: 2018-03-13 14:31:11.383000

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '547051ab55c1'
down_revision = 'a97ab1427500'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'"%equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            columnsres = conn.execute("SELECT column_name FROM information_schema.columns WHERE table_name = '%s'"%t)
            columns = [row[0] for row in columnsres]
            if 'remote_guid' not in columns:
                conn.execute("alter table %s add column remote_guid text"%t)
                conn.execute("update %s set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid"%t)
            


def downgrade():
    conn = op.get_bind()
    res = conn.execute('select name from equipments')
    for row in res.fetchall():
        equip = row[0]
        tables = conn.execute("select tablename from pg_tables where tablename like '%s\_%%%%'"%equip)
        tables = [t[0] for t in tables.fetchall()]
        for t in tables:
            conn.execute("alter table %s drop column remote_guid"%t)
