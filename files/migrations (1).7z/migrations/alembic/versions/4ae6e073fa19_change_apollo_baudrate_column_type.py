"""change apollo baudrate column type

Revision ID: 4ae6e073fa19
Revises: 219f6fa12a5f
Create Date: 2019-10-16 10:53:25.235557

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4ae6e073fa19'
down_revision = '219f6fa12a5f'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update apollo_mainpanel
        set baudrate = 0
        where baudrate = '';
        
        alter table apollo_mainpanel
        alter column baudrate type int using baudrate::int;
    """)


def downgrade():
    pass
