# -*- coding: utf-8 -*-

"""add guid for handlers

Revision ID: c6aafb6a6198
Revises: 2e86503df983
Create Date: 2018-03-29 09:59:27.032000

Обновление добавляет колонку remote_guid для обработчиков и групп. Так же обновлеие генерирует начальное значение этой колонки для всех обработчиков

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c6aafb6a6198'
down_revision = '2e86503df983'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('event_table',
        sa.Column('remote_guid', sa.String())
    )
    op.execute('update event_table set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')
    
    op.add_column('handler_group',
        sa.Column('remote_guid', sa.String())
    )
    op.execute('update handler_group set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')
            


def downgrade():
    op.drop_column('event_table', 'remote_guid')
    op.drop_column('handler_group', 'remote_guid')
