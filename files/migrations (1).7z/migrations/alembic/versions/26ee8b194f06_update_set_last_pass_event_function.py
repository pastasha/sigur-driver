# -*- coding: utf-8 -*-

"""update set_last_pass_event function

Revision ID: 26ee8b194f06
Revises: 4d3c8c49176a
Create Date: 2018-03-28 18:00:58.184000

Странная миграция. Почему-то оказалась что в дистрибутивной БД это обновление БД как буд-то бы пропущено. Сделаю его повторно
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '26ee8b194f06'
down_revision = '4d3c8c49176a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create or replace function set_subject_last_pass_event(
            event_num bigint, tm timestamp, subj bigint, 
            code bigint, obj bigint, place bigint, level bigint
        ) returns bigint as
        $$
        declare
            pass_type text;
            last_event_tm timestamp;
            last_event_num bigint;
        begin
            if subj is null then
                return 0;
            end if;

            pass_type = null;
            select pass_type_ from get_event_handler(code, obj, place, subj, level) into pass_type;
            if pass_type is null then
                return 0;
            end if;
            
            execute 'update events.events_v2_' || to_char(tm, 'YYYYMM') || ' 
                    set pass_type = $1 where evnum = $2'
            using pass_type, event_num;

            select last_pass_event from common_subject where uniid = subj into last_event_num;
            if last_event_num is not null then
                select adverbialtime_value from event_register_v2 where evnum = last_event_num into last_event_tm;
                if last_event_tm > tm then
                    return 0;
                end if;
            end if;
            
            update common_subject set last_pass_event = event_num
            where uniid = subj;
            
            return event_num;
        end;
        $$ language plpgsql;
        
        drop function if exists store_event(
            evnum bigint,
            evdevcode bigint,
            evusercode bigint,
            adverbialtime_value timestamp without time zone,
            subjectobj_obsobjid bigint,
            subjectobj_obsobjstate text,
            subjectobj_devequip text,
            subjectobj_devtype text,
            subjectobj_devid bigint,
            subjectobj_value text,
            directobj_obsobjid bigint,
            directobj_obsobjstate text,
            directobj_devequip text,
            directobj_devtype text,
            directobj_devid bigint,
            directobj_value text,
            indirectobj_obsobjid bigint,
            indirectobj_obsobjstate text,
            indirectobj_devequip text,
            indirectobj_devtype text,
            indirectobj_devid bigint,
            indirectobj_value text,
            adverbialplace_obsobjid bigint,
            adverbialplace_obsobjstate text,
            adverbialplace_devequip text,
            adverbialplace_devtype text,
            adverbialplace_devid bigint,
            adverbialplace_value text,
            adverbialfrom_obsobjid bigint,
            adverbialfrom_obsobjstate text,
            adverbialfrom_devequip text,
            adverbialfrom_devtype text,
            adverbialfrom_devid bigint,
            adverbialfrom_value text,
            adverbialto_obsobjid bigint,
            adverbialto_obsobjstate text,
            adverbialto_devequip text,
            adverbialto_devtype text,
            adverbialto_devid bigint,
            adverbialto_value text,
            adverbialcond_obsobjid bigint,
            adverbialcond_obsobjstate text,
            adverbialcond_devequip text,
            adverbialcond_devtype text,
            adverbialcond_devid bigint,
            adverbialcond_value text,
            adverbialwhy_obsobjid bigint,
            adverbialwhy_obsobjstate text,
            adverbialwhy_devequip text,
            adverbialwhy_devtype text,
            adverbialwhy_devid bigint,
            adverbialwhy_value text,
            adverbialmode_obsobjid bigint,
            adverbialmode_obsobjstate text,
            adverbialmode_devequip text,
            adverbialmode_devtype text,
            adverbialmode_devid bigint,
            adverbialmode_value text,
            incident bigint,
            incident_type text,
            incident_state text,
            incident_comment text,
            securlevel bigint,
            flags bigint,
            authentic bigint,
            permit_uniid bigint
        );
        """)

def downgrade():
    pass
