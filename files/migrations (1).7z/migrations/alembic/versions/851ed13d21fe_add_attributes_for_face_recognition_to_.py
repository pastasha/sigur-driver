"""add attributes for face recognition to common root

Revision ID: 851ed13d21fe
Revises: c48918f63a9a
Create Date: 2019-02-14 13:18:09.204000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '851ed13d21fe'
down_revision = 'c48918f63a9a'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_root
        add column add_face_to_recognition_list_when_activate_permit boolean default false,
        add column archive_face_when_deactivate_permit boolean default false,
        add column add_face_to_recognition_list_when_add_to_blacklist boolean default false
    """)


def downgrade():
    op.execute("""
        alter table common_root
        drop column add_face_to_recognition_list_when_activate_permit,
        drop column archive_face_when_deactivate_permit,
        drop column add_face_to_recognition_list_when_add_to_blacklist
    """)
