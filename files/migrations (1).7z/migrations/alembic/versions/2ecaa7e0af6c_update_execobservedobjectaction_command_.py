# -*- coding: utf-8 -*-

"""update execObservedObjectAction command format in reactions

Revision ID: 2ecaa7e0af6c
Revises: 2b806417d822
Create Date: 2019-02-05 12:34:43.697000

Обновляет реакции под новый формат команды execObservedObjectAction. Делает из такого
{
    "req": "execObservedObjectAction",
    "reqData": {
        "id": 205,
        "act": {
            "params": {},
            "name": "readerDeblock"
        }
    }
}
такое
{
    "req": "execObservedObjectAction",
    "reqData": {
        "act": "readerDeblock",
        "params": {},
        "obsObj": {
            "id": 205
        }
    }
}
для каждого элемента массива cmd

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2ecaa7e0af6c'
down_revision = '2b806417d822'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_table
        set reaction_result = json_build_object(
            'snapshotSubject', reaction_result::json->'snapshotSubject',
            'sendEmail', reaction_result::json->'sendEmail',
            'cams', reaction_result::json->'cams',
            'import_pre_time', reaction_result::json->'import_pre_time',
            'import_post_time', reaction_result::json->'import_post_time',
            'cmd', (
                select json_agg(t1.result) from (
                    select t.extid, json_build_object(
                        'req', 'execObservedObjectAction',
                        'reqData', json_build_object(
                            'act', t.act->'reqData'->'act'->'name'::text,
                            'params', t.act->'reqData'->'act'->'params',
                            'obsObj', json_build_object(
                                'id', t.act->'reqData'->'id'
                            )
                        )
                    ) as result
                    from (
                        select extid, json_array_elements(reaction_result::json->'cmd') as act
                        from event_table as et where et.extid = event_table.extid
                    ) as t
                ) as t1
                group by t1.extid
            )
        )
        where reaction_result like '%execObservedObjectAction%'
    """)


def downgrade():
    pass
