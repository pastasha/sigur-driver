# -*- coding: utf-8 -*-
"""add events for closing mobile app

Revision ID: 4c45991fdf4c
Revises: 9fee58a8ca6d
Create Date: 2019-06-26 12:42:01.708000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer


# revision identifiers, used by Alembic.
revision = '4c45991fdf4c'
down_revision = '9fee58a8ca6d'
branch_labels = None
depends_on = None
events = []


event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"system", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(712, u"Пользователь завершил работу в мобильном приложении", u"Пользователь %statement.subject.dev.name завершил работу в мобильном приложении %statement.directObj.name")
addEv(714, u"Ресурс реагирования завершил работу в мобильном приложении", u"Ресурс реагирования %statement.subject.dev.name завершил работу в мобильном приложении %statement.directObj.name")

def downgrade():
    op.execute('delete from event_catalog where code in(712, 714)')
