"""plavniks tables

Revision ID: 38a807306cc7
Revises: 9e4c5cd6703e
Create Date: 2018-08-09 10:51:35.326000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '38a807306cc7'
down_revision = '66c92f10cabf'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''insert into equipments(name, enabled)
        values('plavnik', true)
    ''')
    op.create_equipment('plavnik_root', [
            ('description', 'text', ''),
            ('driver_addr', 'text', ''),
            ('is_active', 'boolean', 'default false'),
            ('gateway_url', 'text', ''),
            ('socket_timeout', 'int', 'default 500'),
            ('poll_timeout', 'int', 'default 3000'),
            ('fails_count', 'int', 'default 3'),
            ('target_lost_time', 'int', 'default 300')
        ], [], True
    )
    op.create_equipment('plavnik_izoha', [
            ('description', 'text', ''),
            ('dev_id', 'int', 'default 0'),
            ('dev_type', 'text', "default '0'"),
            ('dev_state', 'text', "default '0'"),
            ('is_active', 'boolean', 'default false'),
            ('latitude', 'double precision', 'default 0'),
            ('longitude', 'double precision', 'default 0'),
            ('azimuth', 'double precision', 'default 0'),
            ('hysteresis', 'double precision', 'default 0')
        ], [], True
    )
    op.create_equipment('plavnik_camera', [
        ('description', 'text', ''),
        ('dev_id', 'int', 'default 0'),
        ('dev_type', 'text', "default '0'"),
        ('dev_state', 'text', "default '0'"),
        ('is_active', 'boolean', 'default false'),
        ('latitude', 'double precision', 'default 0'),
        ('longitude', 'double precision', 'default 0'),
        ('azimuth', 'double precision', 'default 0'),
        ('vertical_angle', 'double precision', 'default 0'),
        ('hysteresis', 'double precision', 'default 0'),
        ('speed', 'int', 'default 0'),
        ('is_static', 'boolean', 'default false')
    ], [], True
    )
    op.create_equipment('plavnik_rtsp', [
            ('description', 'text', ''),
            ('url', 'text', ''),
            ('video_qua', 'text', '')
        ], [], True
    )
    op.create_equipment('plavnik_zone', [
        ('description', 'text', ''),
        ('dev_id', 'int', 'default 0'),
        ('zone_id', 'int', "default '0'"),
        ('is_active', 'boolean', 'default false'),
        ('min_azimut', 'double precision', 'default 0'),
        ('max_azimut', 'double precision', 'default 0'),
        ('min_distance', 'double precision', 'default 0'),
        ('max_distance', 'double precision', 'default 0')
    ], [], True
                        )


def downgrade():
    pass
