"""change error name in obs obj type

Revision ID: f07212a6bac8
Revises: ba5664961aa2
Create Date: 2019-05-21 11:21:16.767000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f07212a6bac8'
down_revision = 'ba5664961aa2'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
