"""add remote_guid for event catalog

Revision ID: b04a069ee345
Revises: 09b4d3f32a74
Create Date: 2018-07-10 09:29:00.740000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b04a069ee345'
down_revision = '09b4d3f32a74'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('event_catalog',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute('update event_catalog set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')


def downgrade():
    op.drop_column('event_catalog', 'remote_guid')
