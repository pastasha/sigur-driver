"""add guid to operators

Revision ID: bd79675e6946
Revises: c6aafb6a6198
Create Date: 2018-04-10 14:51:24.446000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bd79675e6946'
down_revision = 'c6aafb6a6198'
branch_labels = None
depends_on = None

def upgrade():
    op.add_column('operators',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute('update operators set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')

def downgrade():
    op.drop_column('operators', 'remote_guid')
