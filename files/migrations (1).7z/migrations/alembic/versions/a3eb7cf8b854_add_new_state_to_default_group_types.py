# -*- coding: utf-8 -*-

"""add new state to default group types

Revision ID: a3eb7cf8b854
Revises: cb4760e64043
Create Date: 2018-10-12 10:26:34.793000

Устанавливает рассчет состояний для типов ом связанных с оборудованием, для стандартных типов (привязка по id) у которых еще нет рассчета.
Установка идет для групповых типов и части обычных, которых не было в миграции 70883adebfa6
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a3eb7cf8b854'
down_revision = 'cb4760e64043'
branch_labels = None
depends_on = None


def upgrade():
    # Коридор
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0440\u0430\u0437\u0434\u0435\u043b": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "ACC", "ATTN"], "\u0442\u043e\u0447\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "ERR": "or", "TRB": "or", "ACT": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "ATTN": "or", "ARM": "or", "CON": "or"}}'
        where id = 10 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Этаж
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 15": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 09": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 08": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 07": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 06": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 05": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 04": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 03": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 02": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 01": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 11": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 14": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 12": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0442\u043e\u0447\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 13": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b \u044d\u0442\u0430\u0436\u0430 16": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"]}, "result_function": {"ACC": "or", "TRB": "or", "ALRM": "or", "ACT": "or", "ARM": "and", "CON": "and"}}'
        where id = 11 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Раздел ОШС
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0428\u042105": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042104": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042107": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042106": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042101": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042103": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042102": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042109": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042108": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042112": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042113": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042110": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042111": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042116": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042114": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0428\u042115": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"]}, "result_function": {"ACC": "and", "TRB": "or", "ALRM": "or", "ACT": "or", "ARM": "and", "CON": "or"}}'
        where id = 29 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Терминал
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 23 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Ячейка сейфа
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u044f\u0447\u0435\u0439\u043a\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC", "ATTN"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 26 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Устройство
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u041c\u0435\u0441\u0442\u043e": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "FAST", "SLOW", "BLCK", "ACC"]}, "result_function": {"ACC": "or", "SLOW": "or", "ERR": "or", "ACT": "or", "FAST": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "BLCK": "or", "ATTN": "or", "TRB": "or", "ARM": "or", "CON": "or"}}'
        where id = 36 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Видеосервер
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u041e\u0431\u044a\u0435\u043a\u0442 \u043e\u0431\u043e\u0440\u0443\u0434\u043e\u0432\u0430\u043d\u0438\u044f": ["CON", "TRB", "ACC"]}, "result_function": {"CON": "or"}}'
        where id = 46 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Офис
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 03": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 04": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 05": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 06": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043a\u043b\u044e\u0447 \u043e\u0444\u0438\u0441\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 01": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 02": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0442\u043e\u0447\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 08": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043f\u043e\u043c\u0435\u0449\u0435\u043d\u0438\u0435 07": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"]}, "result_function": {"ACC": "and", "TRB": "or", "ALRM": "and", "ACT": "and", "ARM": "and", "CON": "and"}}'
        where id = 28 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Помещение
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0432\u0438\u0434\u0435\u043e\u043a\u0430\u043c\u0435\u0440\u0430 04": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0432\u0438\u0434\u0435\u043e\u043a\u0430\u043c\u0435\u0440\u0430 02": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0432\u0438\u0434\u0435\u043e\u043a\u0430\u043c\u0435\u0440\u0430 03": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0432\u0438\u0434\u0435\u043e\u043a\u0430\u043c\u0435\u0440\u0430 01": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043a\u043b\u044e\u0447": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u043e\u043b\u044c\u0441\u0442\u0430\u0432\u043d\u0438": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0442\u043e\u0447\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"]}, "result_function": {"ACC": "and", "TRB": "or", "ALRM": "or", "ACT": "or", "ARM": "and", "CON": "and"}}'
        where id = 14 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Кабинет
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u043a\u043b\u044e\u0447": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "ACC"], "\u0440\u043e\u043b\u044c\u0441\u0442\u0430\u0432\u043d\u0438": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "ACC"], "\u0440\u0430\u0437\u0434\u0435\u043b": ["CON", "ARM", "ALRM", "ACT", "TRB", "SGN", "ERR", "KEY", "ACC"]}, "result_function": {"ACC": "or", "ERR": "or", "TRB": "or", "ACT": "or", "ALRM": "or", "KEY": "or", "SGN": "or", "ATTN": "or", "ARM": "or", "CON": "or"}}'
        where id = 9 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)
    # Точка доступа
    op.execute("""
        update observed_objects_types
        set calculation_handlers = '{"objects": {"\u0434\u0430\u0442\u0447\u0438\u043a \u0434\u0432\u0435\u0440\u0438": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0441\u0447\u0438\u0442\u044b\u0432\u0430\u0442\u0435\u043b\u044c \u0432\u044b\u0445\u043e\u0434": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0441\u0447\u0438\u0442\u044b\u0432\u0430\u0442\u0435\u043b\u044c \u0432\u0445\u043e\u0434": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043a\u043d\u043e\u043f\u043a\u0430 \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u043a\u0438": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u0437\u0430\u043c\u043e\u043a": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"], "\u043a\u043d\u043e\u043f\u043a\u0430 \u0432\u044b\u0445\u043e\u0434": ["CON", "ARM", "ALRM", "ACT", "TRB", "ACC"]}, "result_function": {"ACC": "or", "TRB": "or", "ALRM": "or", "ACT": "or", "ARM": "and", "CON": "and"}}'
        where id = 15 and (calculation_handlers = '{}' or calculation_handlers = '' or calculation_handlers is null)
    """)


def downgrade():
    pass
