"""drop special face recognition tables in equipments

Revision ID: df23ed37c55b
Revises: fb71bcd1a03d
Create Date: 2019-02-14 14:43:41.976000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'df23ed37c55b'
down_revision = 'fb71bcd1a03d'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('intellect_faceintellect')
    op.drop_table('securos_users')


def downgrade():
    pass
