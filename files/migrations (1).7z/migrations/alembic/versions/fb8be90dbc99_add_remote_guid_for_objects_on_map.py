"""add remote_guid for objects on map

Revision ID: fb8be90dbc99
Revises: adb418229506
Create Date: 2018-05-30 14:21:15.715000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fb8be90dbc99'
down_revision = 'adb418229506'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('observed_objects_on_map',
        sa.Column('remote_guid', sa.String())
    )
    op.execute('update observed_objects_on_map set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')
    
    op.add_column('observed_objects_on_gismap',
        sa.Column('remote_guid', sa.String())
    )
    op.execute('update observed_objects_on_gismap set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')

def downgrade():
    op.drop_column('observed_objects_on_map', 'remote_guid')
    op.drop_column('observed_objects_on_gismap', 'remote_guid')
