"""creating tables for device to controller

Revision ID: cae85ae602c0
Revises: 6bd3a5ad9a5a
Create Date: 2018-03-01 15:00:32.178000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cae85ae602c0'
down_revision = 'a764201ee7c6'
branch_labels = None
depends_on = None


def upgrade():
	op.create_equipment('rusguard_devicetocontroller',(
		('id', 'varchar(256)', ''),
		('description', 'varchar(256)', ''),
		('isactive', 'boolean', 'default false'),
		('type', 'varchar(256)', '')			
	),[], 'True'
)


def downgrade():
    pass
