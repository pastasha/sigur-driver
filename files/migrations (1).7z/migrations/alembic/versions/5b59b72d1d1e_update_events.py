"""update events

Revision ID: 5b59b72d1d1e
Revises: d414c041920f
Create Date: 2019-11-18 16:09:45.286353

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5b59b72d1d1e'
down_revision = 'd414c041920f'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog
        set code = 846
        where code = 843 and description = 'Номер не распознан';
        
        delete from event_catalog
        where (code >= 19009 and code <= 19740) and equipment = 'biostar';
    """)


def downgrade():
    pass
