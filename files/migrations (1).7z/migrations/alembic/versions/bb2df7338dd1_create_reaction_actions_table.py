"""create reaction actions table

Revision ID: bb2df7338dd1
Revises: be9d93d599d2
Create Date: 2019-06-17 13:32:30.410000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import Column, Integer, BigInteger, String, JSON, ForeignKey


# revision identifiers, used by Alembic.
revision = 'bb2df7338dd1'
down_revision = 'be9d93d599d2'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('reaction_actions', 
        Column('id', BigInteger, primary_key=True),
        Column('handler', BigInteger, ForeignKey('handlers.id', ondelete='CASCADE')),
        Column('number', Integer),
        Column('object', String),
        Column('action', String),
        Column('params', JSON)
    )
    op.execute("""
        insert into reaction_actions(handler, number, object, action, params)
        select t.handler, t.ordinality, t.act->'reqData'->'obsObj'->'id', (t.act->'reqData'->'act')::text,
        t.act->'reqData'->'params'
        from (
            select handler, value::json as act, ordinality
            from reaction_options cross join json_array_elements_text(cmd) with ordinality
            order by handler, ordinality
        ) as t;
        
        alter table reaction_options
        drop column cmd;
        
        alter table reaction_actions
        alter column object type bigint using object::bigint;
        
        update reaction_actions
        set action = substr(action, 2, length(action)-2);
    """)


def downgrade():
    pass
