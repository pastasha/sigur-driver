"""events_count for apollo_mainpanel

Revision ID: ae19241629c0
Revises: f29fbae438fc
Create Date: 2019-02-02 15:49:50.917000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ae19241629c0'
down_revision = 'f29fbae438fc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE apollo_mainpanel ADD events_count int DEFAULT 0')


def downgrade():
    op.execute('ALTER TABLE apollo_mainpanel DROP COLUMN events_count')
