"""drop unused functions

Revision ID: 037ad7d36b98
Revises: 59d0281b0742
Create Date: 2018-10-26 15:05:49.690000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '037ad7d36b98'
down_revision = '59d0281b0742'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop function if exists install_bis();
        drop function if exists install_housekeeper();
        drop function if exists install_intellect();
        drop function if exists install_milestone();
        drop function if exists install_pce();
        drop function if exists install_uld();
    """)


def downgrade():
    pass
