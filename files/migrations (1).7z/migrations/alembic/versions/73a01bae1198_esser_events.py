# -*- coding: utf-8 -*-

"""esser events

Revision ID: 73a01bae1198
Revises: 2763709f8a18
Create Date: 2018-09-27 21:50:39.665000

"""
from alembic import op
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column

# revision identifiers, used by Alembic.
revision = '73a01bae1198'
down_revision = '2763709f8a18'
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'esser', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(9551, 'Контроллер на связи', u'[\"Контроллер %statement.directObj.name на связи\", \"Контроллер на связи\"]')
add_event(9552, 'Связь с контроллером потеряна',
          u'[\"Связь с контроллером %statement.directObj.name потеряна\", \"Связь с контроллером потеряна\"]')
add_event(9553, 'Найдено устройство', u'[\"Найдено устройство %statement.directObj.name\", \"Найдено устройство\"]')

add_event(9560, 'Связь с устройством потеряна',
          u'[\"Связь с устройством %statement.directObj.name потеряна\", \"Связь с устройством потеряна\"]')
add_event(9561, 'Устройство на связи', u'[\"Устройство %statement.directObj.name на связи\", \"Устройство на связи\"]')
add_event(9562, 'Норма', u'[\"Устройство %statement.directObj.name в норме\", \"Норма\"]')
add_event(9563, 'Пожар', u'[\"Пожарная тревога на %statement.directObj.name\", \"Пожар\"]')
add_event(9564, 'Неисправность', u'[\"Неисправность устройства %statement.directObj.name\", \"Неисправность\"]')


def downgrade():
    pass
