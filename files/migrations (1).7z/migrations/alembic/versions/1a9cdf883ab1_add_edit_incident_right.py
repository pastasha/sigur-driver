# -*- coding: utf-8 -*-
"""add edit incident right

Revision ID: 1a9cdf883ab1
Revises: d6c51eb4f71e
Create Date: 2019-06-28 10:13:30.326000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1a9cdf883ab1'
down_revision = 'd6c51eb4f71e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table opright
        add column editincidentright boolean default false;
    
        update opright
        set editincidentright = false;
    """)


def downgrade():
    op.execute("""
        alter table opright
        drop column editincidentright;
    """)
