# -*- coding: utf-8 -*-
"""add_event_for_face

Revision ID: 28eca456285c
Revises: 56bd4a6d7977
Create Date: 2019-04-14 11:38:14.164000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = '28eca456285c'
down_revision = '56bd4a6d7977'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)
def upgrade():
    op.bulk_insert(event_catalog, events)
	
def addEv(code, descr, format, equipment = u"Система", options = 7, level = 0, channel = "notif", color = "#000000"):
        events.append({
            u"code": code,
            u"description": descr,
            u"equipment": equipment,
            u"format": format,
            u"options": options,
            u"level": level,
            u"channel": channel,
            u"color": color
        })
addEv(19000, u"Обнаружено зарегистрированное лицо", u"%statement.directObj.name зарегистрированное известное лицо: %statement.subject.dev.name")
addEv(19001, u"Обнаружено лицо в розыске", u"%statement.directObj.name обнаружено лицо в розыске: %statement.subject.dev.name")
addEv(19002, u"Обнаружено зарегистрированное лицо в черном списке", u"%statement.directObj.name обнаружено известное лицо в черном списке: %statement.subject.dev.name")
addEv(19003, u"Обнаружено лицо в розыске в черном списке", u"%statement.directObj.name обнаружено лицо в розыске в черном списке: %statement.subject.dev.name")
addEv(19004, u"Обнаружено лицо", u"%statement.directObj.name обнаружено лицо")


def downgrade():
    op.execute('delete from event_catalog where code in (19000, 19004)')