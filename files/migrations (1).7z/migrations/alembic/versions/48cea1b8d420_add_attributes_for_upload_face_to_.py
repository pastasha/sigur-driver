"""add attributes for upload face to common root

Revision ID: 48cea1b8d420
Revises: df23ed37c55b
Create Date: 2019-02-14 14:57:06.698000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '48cea1b8d420'
down_revision = 'df23ed37c55b'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table common_root
        add column upload_face_to_intellect boolean default false,
        add column upload_face_to_securos boolean default false,
        add column upload_face_to_vizir boolean default false
    """)


def downgrade():
    op.execute("""
        alter table common_root
        drop column upload_face_to_intellect,
        drop column upload_face_to_securos,
        drop column upload_face_to_vizir
    """)
