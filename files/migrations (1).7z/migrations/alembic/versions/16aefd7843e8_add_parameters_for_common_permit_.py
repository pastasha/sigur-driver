"""add parameters for common_permit_commonright

Revision ID: 16aefd7843e8
Revises: 083778ea5bdf
Create Date: 2019-02-08 11:21:34.724000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '16aefd7843e8'
down_revision = '083778ea5bdf'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('common_permit_commonright',
        sa.Column('valid_from', sa.BigInteger(), default=0),
    )
    op.add_column('common_permit_commonright',
        sa.Column('valid_to', sa.BigInteger(), default=0),
    )
    op.add_column('common_permit_commonright',
        sa.Column('assigned_subject', sa.BigInteger())
    )
    op.add_column('common_permit_commonright',
        sa.Column('resolution', sa.String(), default=''),
    )
    op.execute("""
        update common_permit_commonright
        set valid_from = 0, valid_to = 0, resolution = ''
    """)


def downgrade():
    op.drop_column('common_permit_commonright', 'valid_from')
    op.drop_column('common_permit_commonright', 'valid_to')
    op.drop_column('common_permit_commonright', 'assigned_subject')
    op.drop_column('common_permit_commonright', 'resolution')
