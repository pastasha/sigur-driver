# -*- coding: utf-8 -*-

"""update handler and reaction params

Revision ID: 3f663d6526ba
Revises: 12fd3c40df7a
Create Date: 2018-05-22 14:24:32.840000

В обработчиках есть параметр OOcam который хранит список идентификаторов объектов мониторинга - камер через запятую.
Теперь он будет хранить их в форрмате [{"id":11},{"id":22"},...].

"""
from alembic import op
import sqlalchemy as sa
import json

# revision identifiers, used by Alembic.
revision = '3f663d6526ba'
down_revision = '12fd3c40df7a'
branch_labels = None
depends_on = None


def upgrade():
    conn = op.get_bind()
    res = conn.execute('select extid, result, reaction_result from event_table')
    for row in res.fetchall():
        result = json.loads(row[1])
        if 'OOcam' in result and result['OOcam']:
            oocam = result['OOcam'].split(',')
            camres = [{
                'id': int(camid)
            } for camid in oocam]
            result['OOcam'] = camres
            conn.execute('update event_table set result = %s where extid = %s', (json.dumps(result), row[0]))
        
        reaction_result = json.loads(row[2])
        if 'cams' in reaction_result and reaction_result['cams']:
            cams = reaction_result['cams'].split(',')
            camres = [{
                'id': int(camid)
            } for camid in cams]
            reaction_result['cams'] = camres
            conn.execute('update event_table set reaction_result = %s where extid = %s', (json.dumps(reaction_result), row[0]))
            


def downgrade():
    conn = op.get_bind()
    res = conn.execute('select extid, result, reaction_result from event_table')
    for row in res.fetchall():
        result = json.loads(row[1])
        if 'OOcam' in result and result['OOcam']:
            oocam = result['OOcam']
            camres = [str(cam['id']) for cam in oocam]
            result['OOcam'] = ','.join(camres)
            conn.execute('update event_table set result = %s where extid = %s', (json.dumps(result), row[0]))
            
        reaction_result = json.loads(row[2])
        if 'cams' in reaction_result and reaction_result['cams']:
            cams = reaction_result['cams']
            camres = [str(cam['id']) for cam in cams]
            reaction_result['cams'] = ','.join(camres)
            conn.execute('update event_table set reaction_result = %s where extid = %s', (json.dumps(reaction_result), row[0]))
