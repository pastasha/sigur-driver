# -*- coding: utf-8 -*-
"""add mobile right

Revision ID: 41c1d4ba3f93
Revises: b2ed374214e0
Create Date: 2019-06-14 17:10:50.876000

"""
from alembic import op


# revision identifiers, used by Alembic.
revision = '41c1d4ba3f93'
down_revision = 'b2ed374214e0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table opright
        add column mobileappright boolean default false;

        update opright
        set mobileappright = false;
   """)


def downgrade():
    op.execute("""
        alter table opright
        drop column mobileappright;
    """)
