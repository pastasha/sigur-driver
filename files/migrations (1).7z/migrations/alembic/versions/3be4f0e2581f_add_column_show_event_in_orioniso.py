"""add column show event in orioniso

Revision ID: 3be4f0e2581f
Revises: 6b0ac0953d86
Create Date: 2019-01-23 15:02:35.361000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3be4f0e2581f'
down_revision = '6b0ac0953d86'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE orioniso_control ADD generate_events_sections bool')


def downgrade():
    op.execute('ALTER TABLE orioniso_control drop column generate_events_sections')