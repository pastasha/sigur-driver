"""jupiter_events

Revision ID: 5ba7ef593a57
Revises: 7a0aa55ee39b
Create Date: 2019-09-09 12:05:03.734000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '5ba7ef593a57'
down_revision = '7a0aa55ee39b'
branch_labels = None
depends_on = None

events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'jupiter', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(130001, 'Тревога', u'Тревога %statement.directObj.name')
add_event(130002, 'Взятие/Снятие', u'Взятие/Снятие %statement.directObj.name')
add_event(130003, 'Неисправность', u'Неисправность %statement.directObj.name')
add_event(130004, 'Внимание', u'Внимание %statement.directObj.name')
add_event(130005, 'Саботаж', u'Саботаж %statement.directObj.name')
add_event(130006, 'Питание', u'Питание %statement.directObj.name')
add_event(130007, 'Связь', u'Связь %statement.directObj.name')
add_event(130008, 'Диагностика', u'Диагностика %statement.directObj.name')
add_event(130010, 'Пожар', u'Пожар %statement.directObj.name')
add_event(130011, 'Дым', u'Дым %statement.directObj.name')
add_event(130012, 'Пламя', u'Пламя %statement.directObj.name')
add_event(130013, 'Сработка пожарного датчика (переопрос)',
          u'Сработка пожарного датчика (переопрос) %statement.directObj.name')
add_event(130014, 'Нападение', u'Нападение %statement.directObj.name')
add_event(130015, 'Тревога, принуждение', u'Тревога, принуждение %statement.directObj.name')
add_event(130016, 'Тихая тревога', u'Тихая тревога %statement.directObj.name')
add_event(130017, 'Тревога ШС', u'Тревога ШС %statement.directObj.name')
add_event(130018, 'Тревога, проникновение', u'Тревога, проникновение %statement.directObj.name')
add_event(130019, 'Тревога, перемещение', u'Тревога, перемещение %statement.directObj.name')
add_event(130020, 'Тревога, газ', u'Тревога, газ %statement.directObj.name')
add_event(130021, 'Тревога, затопление', u'Тревога, затопление %statement.directObj.name')
add_event(130022, 'Тревога, высокая температура', u'Тревога, высокая температура %statement.directObj.name')
add_event(130023, 'Тревога, низкая температура', u'Тревога, низкая температура %statement.directObj.name')
add_event(130024, 'Взятие раньше времени начала графика охраны',
          u'Взятие раньше времени начала графика охраны %statement.directObj.name')
add_event(130025, 'Взятие позже времени окончания графика охраны',
          u'Взятие позже времени окончания графика охраны %statement.directObj.name')
add_event(130026, 'Не взят оператором', u'Не взят оператором %statement.directObj.name')
add_event(130027, 'Невзятие раздела/зоны', u'Невзятие раздела/зоны %statement.directObj.name')
add_event(130028, 'Невзятие СМС', u'Невзятие СМС %statement.directObj.name')
add_event(130029, 'Замена СИМ-карты', u'Замена СИМ-карты %statement.directObj.name')
add_event(130030, 'Выход за пределы контролируемого параметра',
          u'Выход за пределы контролируемого параметра %statement.directObj.name')
add_event(130031, 'Превышение контролируемого параметра',
          u'Превышение контролируемого параметра %statement.directObj.name')
add_event(130032, 'Снижение контролируемого параметра', u'Снижение контролируемого параметра %statement.directObj.name')
add_event(130033, 'Тревога ручная', u'Тревога ручная %statement.directObj.name')
add_event(130034, 'Внешняя тревога', u'Внешняя тревога %statement.directObj.name')
add_event(130035, 'Внутренняя тревога', u'Внутренняя тревога %statement.directObj.name')
add_event(130036, 'Взятие вне графика охраны', u'Взятие вне графика охраны %statement.directObj.name')
add_event(130037, 'Снятие вне графика охраны', u'Снятие вне графика охраны %statement.directObj.name')
add_event(130038, 'Начало снятия (Вероятная тревога)', u'Начало снятия (Вероятная тревога) %statement.directObj.name')
add_event(130039, 'Вход в геозону', u'Вход в геозону %statement.directObj.name')
add_event(130040, 'Выход из геозоны', u'Выход из геозоны %statement.directObj.name')
add_event(130041, 'Не взят пользователем', u'Не взят пользователем %statement.directObj.name')
add_event(130042, 'Снят с охраны пользователем', u'Снят с охраны пользователем %statement.directObj.name')
add_event(130043, 'Взят под охрану пользователем', u'Взят под охрану пользователем %statement.directObj.name')
add_event(130044, 'Снят с охраны под принуждением', u'Снят с охраны под принуждением %statement.directObj.name')
add_event(130045, 'Взят под охрану под принуждением', u'Взят под охрану под принуждением %statement.directObj.name')
add_event(130046, 'Снятие с охраны', u'Снятие с охраны %statement.directObj.name')
add_event(130047, 'Взятие под охрану', u'Взятие под охрану %statement.directObj.name')
add_event(130048, 'Снят с охраны оператором', u'Снят с охраны оператором %statement.directObj.name')
add_event(130049, 'Взят под охрану оператором', u'Взят под охрану оператором %statement.directObj.name')
add_event(130050, 'Снятие СМС', u'Снятие СМС %statement.directObj.name')
add_event(130051, 'Взятие СМС', u'Взятие СМС %statement.directObj.name')
add_event(130052, 'Перевзятие', u'Перевзятие %statement.directObj.name')
add_event(130053, 'Частичное взятие', u'Частичное взятие %statement.directObj.name')
add_event(130054, 'Взятие с задержкой', u'Взятие с задержкой %statement.directObj.name')
add_event(130055, 'Снятие с задержкой', u'Снятие с задержкой %statement.directObj.name')
add_event(130056, 'Обрыв ШС', u'Обрыв ШС %statement.directObj.name')
add_event(130057, 'Короткое замыкание ШС', u'Короткое замыкание ШС %statement.directObj.name')
add_event(130058, 'Неисправность оперативной памяти', u'Неисправность оперативной памяти %statement.directObj.name')
add_event(130059, 'Неисправность модуля внешней памяти',
          u'Неисправность модуля внешней памяти %statement.directObj.name')
add_event(130060, 'Ошибка программного кода', u'Ошибка программного кода %statement.directObj.name')
add_event(130061, 'Неисправность выхода реле', u'Неисправность выхода реле %statement.directObj.name')
add_event(130062, 'Неисправность периферийных устройств',
          u'Неисправность периферийных устройств %statement.directObj.name')
add_event(130063, 'Неисправность расширителя', u'Неисправность расширителя %statement.directObj.name')
add_event(130064, 'Неисправность повторителя', u'Неисправность повторителя %statement.directObj.name')
add_event(130065, 'Ошибка процедуры самотестирования', u'Ошибка процедуры самотестирования %statement.directObj.name')
add_event(130066, 'Неисправность линии связи', u'Неисправность линии связи %statement.directObj.name')
add_event(130067, 'Неисправность радиоканала', u'Неисправность радиоканала %statement.directObj.name')
add_event(130068, 'Неисправность канала', u'Неисправность канала %statement.directObj.name')
add_event(130069, 'Неисправность ШС', u'Неисправность ШС %statement.directObj.name')
add_event(130070, 'Неисправность (взлом)', u'Неисправность (взлом) %statement.directObj.name')
add_event(130071, 'Превышение параметром границы', u'Превышение параметром границы %statement.directObj.name')
add_event(130072, 'Сбой часов системного времени', u'Сбой часов системного времени %statement.directObj.name')
add_event(130073, 'Неисправность шины данных', u'Неисправность шины данных %statement.directObj.name')
add_event(130074, 'Снижение параметра ниже границы', u'Снижение параметра ниже границы %statement.directObj.name')
add_event(130075, 'Невзятие вне графика охраны', u'Невзятие вне графика охраны %statement.directObj.name')
add_event(130076, 'Потеря управления устройством', u'Потеря управления устройством %statement.directObj.name')
add_event(130077, 'Неисправность схемотехники', u'Неисправность схемотехники %statement.directObj.name')
add_event(130078, 'Неисправность механической части', u'Неисправность механической части %statement.directObj.name')
add_event(130079, 'Выход параметра за границы зоны норма',
          u'Выход параметра за границы зоны норма %statement.directObj.name')
add_event(130080, 'Потеря связи с устройством', u'Потеря связи с устройством %statement.directObj.name')
add_event(130081, 'Помехи в канале связи с ПЦО', u'Помехи в канале связи с ПЦО %statement.directObj.name')
add_event(130082, 'Отключение канала связи с ПЦО', u'Отключение канала связи с ПЦО %statement.directObj.name')
add_event(130083, 'Потеря связи с расширителем объектовой сети',
          u'Потеря связи с расширителем объектовой сети %statement.directObj.name')
add_event(130084, 'Восстановление (пожар)', u'Восстановление (пожар) %statement.directObj.name')
add_event(130085, 'Восстановление (дым)', u'Восстановление (дым) %statement.directObj.name')
add_event(130086, 'Восстановление (нападение)', u'Восстановление (нападение) %statement.directObj.name')
add_event(130087, 'Восстановление ШС', u'Восстановление ШС %statement.directObj.name')
add_event(130088, 'Восстановление', u'Восстановление %statement.directObj.name')
add_event(130089, 'Вход', u'Вход %statement.directObj.name')
add_event(130090, 'Блокировка корпуса', u'Блокировка корпуса %statement.directObj.name')
add_event(130091, 'Восстановление (проникновение)', u'Восстановление (проникновение) %statement.directObj.name')
add_event(130092, 'В норме (Обрыв ШС)', u'В норме (Обрыв ШС) %statement.directObj.name')
add_event(130093, 'В норме (КЗ ШС)', u'В норме (КЗ ШС) %statement.directObj.name')
add_event(130094, 'Температура в норме', u'Температура в норме %statement.directObj.name')
add_event(130095, 'Восстановление (газ)', u'Восстановление (газ) %statement.directObj.name')
add_event(130096, 'Восстановление (затопление)', u'Восстановление (затопление) %statement.directObj.name')
add_event(130097, 'Восстановление (высокая температура)',
          u'Восстановление (высокая температура) %statement.directObj.name')
add_event(130098, 'Восстановление (низкая температура)',
          u'Восстановление (низкая температура) %statement.directObj.name')
add_event(130099, 'Сброс пожарных датчиков пользователь',
          u'Сброс пожарных датчиков пользователь %statement.directObj.name')
add_event(130100, 'Сброс пожарных датчиков', u'Сброс пожарных датчиков %statement.directObj.name')
add_event(130101, 'Сброс пожарных датчиков СМС', u'Сброс пожарных датчиков СМС %statement.directObj.name')
add_event(130102, 'Разблокирование КТС', u'Разблокирование КТС %statement.directObj.name')
add_event(130103, 'Вскрытие КТС', u'Вскрытие КТС %statement.directObj.name')
add_event(130104, 'Закрытие КТС', u'Закрытие КТС %statement.directObj.name')
add_event(130105, 'Автоматический сброс устройства', u'Автоматический сброс устройства %statement.directObj.name')
add_event(130106, 'Расширитель в норме', u'Расширитель в норме %statement.directObj.name')
add_event(130107, 'Отсутствие помехи в радиоканале', u'Отсутствие помехи в радиоканале %statement.directObj.name')
add_event(130108, 'Восстановление канала', u'Восстановление канала %statement.directObj.name')
add_event(130109, 'ШС в норме', u'ШС в норме %statement.directObj.name')
add_event(130110, 'Техническое обслуживание устройства',
          u'Техническое обслуживание устройства %statement.directObj.name')
add_event(130111, 'Завершение технического обслуживания устройства',
          u'Завершение технического обслуживания устройства %statement.directObj.name')
add_event(130112, 'Удалённое управление устройством', u'Удалённое управление устройством %statement.directObj.name')
add_event(130113, 'Выполнена удалённая команда', u'Выполнена удалённая команда %statement.directObj.name')
add_event(130114, 'Регистрация нового пользователя', u'Регистрация нового пользователя %statement.directObj.name')
add_event(130115, 'Авторизация пользователя', u'Авторизация пользователя %statement.directObj.name')
add_event(130116, 'Смена IP адреса', u'Смена IP адреса %statement.directObj.name')
add_event(130117, 'Отказ от взятия раздела', u'Отказ от взятия раздела %statement.directObj.name')
add_event(130118, 'Сброс тревоги', u'Сброс тревоги %statement.directObj.name')
add_event(130119, 'Сброс тревоги с пульта', u'Сброс тревоги с пульта %statement.directObj.name')
add_event(130120, 'Сброс тревоги СМС', u'Сброс тревоги СМС %statement.directObj.name')
add_event(130121, 'Сброс тревоги под принуждением', u'Сброс тревоги под принуждением %statement.directObj.name')
add_event(130122, 'Сброс сирены пользователь', u'Сброс сирены пользователь %statement.directObj.name')
add_event(130123, 'Сброс сирены с пульта', u'Сброс сирены с пульта %statement.directObj.name')
add_event(130124, 'Сброс сирены СМС', u'Сброс сирены СМС %statement.directObj.name')
add_event(130125, 'Неизвестное сообщение', u'Неизвестное сообщение %statement.directObj.name')
add_event(130126, 'Радиопомеха', u'Радиопомеха %statement.directObj.name')
add_event(130127, 'Ошибка опроса баланса', u'Ошибка опроса баланса %statement.directObj.name')
add_event(130128, 'Команда не выполнена', u'Команда не выполнена %statement.directObj.name')
add_event(130129, 'Ошибка изменения ключа шифрации', u'Ошибка изменения ключа шифрации %statement.directObj.name')
add_event(130130, 'Обход (исключение) раздела/зоны при взятии',
          u'Обход (исключение) раздела/зоны при взятии %statement.directObj.name')
add_event(130131, 'Контроль наряда', u'Контроль наряда %statement.directObj.name')
add_event(130132, 'Подмена ОУ', u'Подмена ОУ %statement.directObj.name')
add_event(130133, 'Взлом', u'Взлом %statement.directObj.name')
add_event(130134, 'Вскрытие корпуса', u'Вскрытие корпуса %statement.directObj.name')
add_event(130135, 'Саботаж', u'Саботаж %statement.directObj.name')
add_event(130136, 'Подбор кода', u'Подбор кода %statement.directObj.name')
add_event(130137, 'Маскирование', u'Маскирование %statement.directObj.name')
add_event(130138, 'Перенастройка', u'Перенастройка %statement.directObj.name')
add_event(130139, 'Перемещение', u'Перемещение %statement.directObj.name')
add_event(130140, 'Отрыв от поверхности установки', u'Отрыв от поверхности установки %statement.directObj.name')
add_event(130141, 'Программное вмешательство', u'Программное вмешательство %statement.directObj.name')
add_event(130142, 'Блокировка корпуса', u'Блокировка корпуса %statement.directObj.name')
add_event(130143, 'Сбой сетевого питания', u'Сбой сетевого питания %statement.directObj.name')
add_event(130144, 'Восстановление сетевого питания', u'Восстановление сетевого питания %statement.directObj.name')
add_event(130145, 'Авария основного питания', u'Авария основного питания %statement.directObj.name')
add_event(130146, 'Сбой основного питания', u'Сбой основного питания %statement.directObj.name')
add_event(130147, 'Пониженное сетевое питание', u'Пониженное сетевое питание %statement.directObj.name')
add_event(130148, 'Повышенное сетевое питание', u'Повышенное сетевое питание %statement.directObj.name')
add_event(130149, 'Понижено основное питание', u'Понижено основное питание %statement.directObj.name')
add_event(130150, 'Повышено основное питание', u'Повышено основное питание %statement.directObj.name')
add_event(130151, 'Недоступен канал связи', u'Недоступен канал связи %statement.directObj.name')
add_event(130152, 'Восстановление связи с устройством', u'Восстановление связи с устройством %statement.directObj.name')
add_event(130153, 'Отсутствует несущая сигнала', u'Отсутствует несущая сигнала %statement.directObj.name')
add_event(130154, 'Канал занят', u'Канал занят %statement.directObj.name')
add_event(130155, 'Нет ответа от устройства', u'Нет ответа от устройства %statement.directObj.name')
add_event(130156, 'Удалена SIM-карта 1', u'Удалена SIM-карта 1 %statement.directObj.name')
add_event(130157, 'Удалена SIM-карта 2', u'Удалена SIM-карта 2 %statement.directObj.name')
add_event(130158, 'Восстановление связи с расширителем объектовой сети',
          u'Восстановление связи с расширителем объектовой сети %statement.directObj.name')
add_event(130159, 'Разряд батареи', u'Разряд батареи %statement.directObj.name')
add_event(130160, 'Батарея в норме', u'Батарея в норме %statement.directObj.name')
add_event(130161, 'Возникла помеха в канале', u'Возникла помеха в канале %statement.directObj.name')
add_event(130162, 'Баланс ниже критического', u'Баланс ниже критического %statement.directObj.name')
add_event(130163, 'Восстановление основного питания', u'Восстановление основного питания %statement.directObj.name')
add_event(130164, 'Переход на резервное питание', u'Переход на резервное питание %statement.directObj.name')
add_event(130165, 'Слабый уровень сигнала', u'Слабый уровень сигнала %statement.directObj.name')
add_event(130166, 'Уровень сигнала =', u'Уровень сигнала = %statement.directObj.name')
add_event(130167, 'Уровень принимаемого сигнала =', u'Уровень принимаемого сигнала = %statement.directObj.name')
add_event(130168, 'Качество принимаемого сигнала =', u'Качество принимаемого сигнала = %statement.directObj.name')
add_event(130169, 'Емкость аккумулятора =', u'Емкость аккумулятора = %statement.directObj.name')
add_event(130170, 'Емкость аккумулятора ниже критической',
          u'Емкость аккумулятора ниже критической %statement.directObj.name')
add_event(130171, 'Уровень шума в канале =', u'Уровень шума в канале = %statement.directObj.name')
add_event(130172, 'Ошибка передатчика', u'Ошибка передатчика %statement.directObj.name')
add_event(130173, 'Ошибка передатчика', u'Ошибка передатчика %statement.directObj.name')
add_event(130174, 'Баланс в норме', u'Баланс в норме %statement.directObj.name')
add_event(130175, 'Качество связи =', u'Качество связи = %statement.directObj.name')

add_event(130300, 'Соединение с ПО Юпитер потеряно', u'Соединение с ПО Юпитер потеряно %statement.directObj.name')
add_event(130301, 'Ошибка авторизации в ПО Юпитер ', u'Ошибка авторизации в ПО Юпитер  %statement.directObj.name')
add_event(130302, 'Соединение с ПО Юпитер не установлено',
          u'Соединение с ПО Юпитер не установлено %statement.directObj.name')
add_event(130303, 'Соединение с ПО Юпитер установлено', u'Соединение с ПО Юпитер установлено %statement.directObj.name')


def downgrade():
    op.execute('''
    delete from event_catalog where code >= 130000 and code < 130500
    ''')
