"""change action name in reactions

Revision ID: 2b806417d822
Revises: ae19241629c0
Create Date: 2019-02-05 09:42:20.580000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2b806417d822'
down_revision = 'ae19241629c0'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_table set reaction_result = replace(reaction_result, 'execActOO', 'execObservedObjectAction')
    """)


def downgrade():
    pass
