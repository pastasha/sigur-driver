"""add column for intellect_cam

Revision ID: e1faa10a5a0a
Revises: cd1f01a15f23
Create Date: 2019-05-29 12:58:38.944000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e1faa10a5a0a'
down_revision = 'cd1f01a15f23'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE intellect_cam ADD num_sub_stream bigint default 1')


def downgrade():
    op.execute('ALTER TABLE intellect_cam drop column num_sub_stream')
