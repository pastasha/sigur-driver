"""new column phones for miraj

Revision ID: 241d12adf11c
Revises: 385e4bf05c83
Create Date: 2018-03-21 13:18:45.009000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '241d12adf11c'
down_revision = '385e4bf05c83'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        alter table surguard_part add column phones text
    ''')


def downgrade():
    op.execute('''
        alter table surguard_part drop column phones
    ''')
