"""create reaction options table

Revision ID: be9d93d599d2
Revises: d71d8b6ba418
Create Date: 2019-06-15 14:25:42.573000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import Column, BigInteger, JSON, String, ForeignKey


# revision identifiers, used by Alembic.
revision = 'be9d93d599d2'
down_revision = 'd71d8b6ba418'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('reaction_options', 
        Column('id', BigInteger, primary_key=True),
        Column('handler', BigInteger, ForeignKey('handlers.id', ondelete='CASCADE')),
        Column('snapshotsubject', JSON),
        Column('cams', String),
        Column('sendemail', String),
        Column('import_pre_time', String),
        Column('import_post_time', String),
        Column('cmd', JSON),
    )
    op.execute("""
        insert into reaction_options(handler, snapshotsubject, cams, sendemail, import_pre_time, import_post_time, cmd)
        select id, reaction_result::json->'snapshotSubject', reaction_result::json->'cams',
        reaction_result::json->'sendEmail', reaction_result::json->'import_pre_time',
        reaction_result::json->'import_post_time', reaction_result::json->'cmd'
        from handlers;
        
        alter table handlers drop column reaction_result;
        
        update reaction_options
        set cams = '[]'::json
        where cams = '""' or cams is null or cams = 'null';
        
        update reaction_options
        set snapshotsubject = '{}'::json
        where snapshotsubject is null;
        
        update reaction_options
        set sendemail = ''
        where sendemail = '""' or sendemail is null or sendemail = 'null';
        
        update reaction_options
        set import_pre_time = 0
        where import_pre_time = '' or import_pre_time is null or import_pre_time = 'null';
        
        update reaction_options
        set import_post_time = 0
        where import_post_time = '' or import_post_time is null or import_post_time = 'null';
        
        update reaction_options
        set cmd = '[]'::json
        where cmd is null;
        
        alter table reaction_options
        alter column cams type json using cams::json,
        alter column import_pre_time type int using import_pre_time::int,
        alter column import_post_time type int using import_post_time::int
    """)


def downgrade():
    pass
