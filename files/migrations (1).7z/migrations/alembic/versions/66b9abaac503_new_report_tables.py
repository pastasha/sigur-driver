"""new report tables

Revision ID: 66b9abaac503
Revises: da98c19eeb5c
Create Date: 2018-11-23 16:01:15.866000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '66b9abaac503'
down_revision = 'da98c19eeb5c'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'ref_data_source',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('implementation_class_name', sa.String(128), nullable=False),
            sa.Column('field_configuration', sa.dialects.postgresql.JSONB, nullable=False)
    )
    op.create_table(
        'ref_report_groups',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False)
    )
    op.create_table(
        'ref_display_templates',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('data_source', sa.Integer, sa.ForeignKey("ref_data_source.id", ondelete='CASCADE')),
            sa.Column('params', sa.dialects.postgresql.JSONB, nullable=False)
    )
    op.create_table(
        'ref_export_templates',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('data_source', sa.Integer, sa.ForeignKey("ref_data_source.id", ondelete='CASCADE')),
            sa.Column('params', sa.dialects.postgresql.JSONB, nullable=False)
    )
    op.create_table(
        'ref_printing_templates',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('data_source', sa.Integer, sa.ForeignKey("ref_data_source.id", ondelete='CASCADE')),
            sa.Column('params', sa.dialects.postgresql.JSONB, nullable=False)
    )
    op.create_table(
        'ref_reports',
            sa.Column('id', sa.Integer, primary_key=True),
            sa.Column('name', sa.String(128), nullable=False),
            sa.Column('params', sa.dialects.postgresql.JSONB, nullable=False),
            sa.Column('group', sa.Integer, sa.ForeignKey("ref_report_groups.id", ondelete='CASCADE')),
            sa.Column('data_source', sa.Integer, sa.ForeignKey("ref_data_source.id", ondelete='CASCADE')),
            sa.Column('export_templates', sa.Integer, sa.ForeignKey("ref_export_templates.id", ondelete='CASCADE')),
            sa.Column('print_templates', sa.Integer, sa.ForeignKey("ref_printing_templates.id", ondelete='CASCADE'))
    )

def downgrade():
    op.drop_table('ref_reports'),
    op.drop_table('ref_display_templates'),
    op.drop_table('ref_export_templates'),
    op.drop_table('ref_printing_templates'),
    op.drop_table('ref_data_source'),
    op.drop_table('ref_report_groups')
   