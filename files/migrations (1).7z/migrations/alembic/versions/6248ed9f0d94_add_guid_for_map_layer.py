# -*- coding: utf-8 -*-

"""add guid for map layer

Revision ID: 6248ed9f0d94
Revises: bd79675e6946
Create Date: 2018-04-17 17:32:42.417000

Добавляет колонку remote_guid к слоям объектов мониторинга на плане

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '6248ed9f0d94'
down_revision = 'bd79675e6946'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('map_layer',
                  sa.Column('remote_guid', sa.String())
                  )
    op.execute('update map_layer set remote_guid = md5(random()::text || clock_timestamp()::text)::uuid')

def downgrade():
    op.drop_column('map_layer', 'remote_guid')
