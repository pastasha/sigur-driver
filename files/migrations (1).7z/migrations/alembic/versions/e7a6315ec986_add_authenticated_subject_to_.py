"""add authenticated subject to mobiledevice

Revision ID: e7a6315ec986
Revises: 7a2d5808a684
Create Date: 2019-11-07 14:34:00.577327

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e7a6315ec986'
down_revision = '7a2d5808a684'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_mobiledevice
        add column authenticatedsubject bigint
    """)


def downgrade():
    op.execute("""
        alter table system_mobiledevice
        drop column authenticatedsubject
    """)
