"""add column for action event suprema

Revision ID: 097bb74e4f52
Revises: 42fcab93164b
Create Date: 2018-12-16 21:34:00.534000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '097bb74e4f52'
down_revision = '4ae1acc1577e'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE suprema_driver ADD last_date_event varchar(256)')
    op.execute('ALTER TABLE suprema_driver ADD show_event bool')


def downgrade():
    op.execute('ALTER TABLE suprema_driver drop column show_event')
    op.execute('ALTER TABLE suprema_driver drop column last_date_event')
