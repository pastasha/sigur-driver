"""Drop incident events from catalog

Revision ID: d24bba327d14
Revises: 5b74d4d891a3
Create Date: 2019-09-23 12:42:16.096264

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'd24bba327d14'
down_revision = '5b74d4d891a3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        delete from event_catalog
        where code >= 10000 and code <= 10100
    """)


def downgrade():
    pass
