# -*- coding: utf-8 -*-

"""create table for incident sop

Revision ID: 0e9a3be981c5
Revises: 1a9cdf883ab1
Create Date: 2019-06-27 17:21:11.920000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0e9a3be981c5'
down_revision = '1a9cdf883ab1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"""
        create table incidents.incident_sop(
            id serial primary key,
            identifier text,
            name text,
            accepting_time integer,
            processing_time integer,
            tasks json,
            comment text,
            start_status bigint references incidents.incident_status(id),
            accepted_status bigint references incidents.incident_status(id)
        );
        
        insert into incidents.incident_sop(identifier, name, accepting_time, processing_time, tasks, comment, start_status, accepted_status)
        select 'sop_' || id, name || '_СОП', 0, 0, tasks::json, '',
        (select id from incidents.incident_status where name = 'Новый'),
        (select id from incidents.incident_status where name = 'Обработка')
        from incidents.incident_type;
        
        alter table incidents.incident_type
        add column sops json,
        add column start_status bigint references incidents.incident_status(id),
        drop column tasks;
        
        update incidents.incident_type
        set start_status = (select id from incidents.incident_status where name = 'Новый'),
        sops = ('["sop_' || id || '"]')::json;
        
        alter table incidents.incident_task
        add column start_status bigint references incidents.incident_status(id),
        add column accepted_status bigint references incidents.incident_status(id);
        
        update incidents.incident_task
        set start_status = (select id from incidents.incident_status where name = 'Новый'),
        accepted_status = (select id from incidents.incident_status where name = 'Обработка')
    """)


def downgrade():
    pass
