"""add dsc part zone link

Revision ID: 5d5478b4ebed
Revises: 9b9513d2b4b5
Create Date: 2019-12-17 11:00:41.323040

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5d5478b4ebed'
down_revision = '9b9513d2b4b5'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('dsc_part_zone', [
        ('zone', 'int', '')
    ], [], True)


def downgrade():
    op.execute('''
    drop table dsc_part_zone
    ''')
