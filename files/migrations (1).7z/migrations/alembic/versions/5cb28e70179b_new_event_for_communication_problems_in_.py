# -*- coding: utf-8 -*-

"""new event for communication problems in surguard

Revision ID: 5cb28e70179b
Revises: 241d12adf11c
Create Date: 2018-03-21 16:22:22.382000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date


# revision identifiers, used by Alembic.
revision = '5cb28e70179b'
down_revision = '241d12adf11c'
branch_labels = None
depends_on = None

events = []



event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)
def addEv(code, descr, format, equipment = u"surguard", options = 7, level = 0, channel = "notif", color = "#000000"):
        events.append({
            u"code": code,
            u"description": descr,
            u"equipment": equipment,
            u"format": format,
            u"options": options,
            u"level": level,
            u"channel": channel,
            u"color": color
        })
addEv(13001, u"Потеря связи с объектом", u"[\"Потеря связи с объектом %statement.directObj.name\", \"\"]\"")
addEv(14001, u"Восстановление связи с объектом", u"[\"Потеря связи с объектом %statement.directObj.name\", \"\"]\"")

def upgrade():
    op.bulk_insert(event_catalog, events)


def downgrade():
    op.execute('delete from event_catalog where code = 13001 or code = 14001')
