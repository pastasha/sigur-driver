"""create system geozone equipment

Revision ID: a2f87c69fecd
Revises: 1bd569a74fd8
Create Date: 2018-08-20 12:00:48.416000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a2f87c69fecd'
down_revision = '1bd569a74fd8'
branch_labels = None
depends_on = None


def upgrade():
    op.create_equipment('system_geozone', [
            ('description', 'text', ''),
        ], [], True
    )


def downgrade():
    op.drop_table('system_geozone')
