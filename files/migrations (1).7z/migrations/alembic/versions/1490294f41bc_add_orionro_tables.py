"""add orionRO tables

Revision ID: 1490294f41bc
Revises: 413b8bf5144f
Create Date: 2018-04-19 12:09:12.268000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1490294f41bc'
down_revision = '413b8bf5144f'
branch_labels = None
depends_on = None

#def create_equipment(cls, operations, name, attrs, links, hasParent):
def upgrade():
    op.execute('''insert into equipments(name, enabled)
        values('orionro', true)
    ''')
    op.create_equipment('orionro_gateway', [
            ('description', 'text', ''),
            ('driver_addr', 'text', ''),
            ('isactive', 'boolean', 'default false'),
            ('interface', 'text', ''),
            ('port', 'int', 'default 24416'),
            ('socket_timeout', 'int', 'default 500'),
            ('conn_lose_timeout', 'int', 'default 300'),
            ('synchronization', 'int', 'default 360')
        ], [], True
    )
    op.create_equipment('orionro_device', [
            ('number', 'text', "default '1234'"),
            ('description', 'text', ''),
            ('control_type', 'text', "default 'guard'"),
            ('phone', 'text', ''),
            ('password', 'text', "default '12345'"),
            ('states', 'text', '')
        ], [], True
    )
    op.create_equipment('orionro_key', [
            ('id', 'int', ''),
            ('description', 'text', '')
        ], [], True
    )
    op.create_equipment('orionro_part', [
            ('description', 'text', ''),
            ('states', 'text', '')

        ], [], True
    )
    op.create_equipment('orionro_zone', [('description', 'text', ''),
                                         ('control_type', 'text', "default 'auto'"),
                                         ('states', 'text', '')], [], True)
    op.create_equipment('orionro_part_zone', [], ['zone'], 'True')


def downgrade():
    pass
