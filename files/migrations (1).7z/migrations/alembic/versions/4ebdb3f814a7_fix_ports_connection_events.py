"""fix ports connection events

Revision ID: 4ebdb3f814a7
Revises: aefd8171f5b1
Create Date: 2018-08-08 10:46:07.972000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4ebdb3f814a7'
down_revision = 'b1bb34bf9efe'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update event_catalog set channel = 'notif', color = '#000000'
        where code in (761, 762)
    """)


def downgrade():
    pass
