# -*- coding: utf-8 -*-

"""add common domain connection events

Revision ID: 5d31fc04cc31
Revises: 4ebdb3f814a7
Create Date: 2018-08-08 10:47:22.820000

"""
from alembic import op
import sqlalchemy as sa
from datetime import date
from sqlalchemy.sql import table, column
from sqlalchemy import String, Integer, Date

# revision identifiers, used by Alembic.
revision = '5d31fc04cc31'
down_revision = '4ebdb3f814a7'
branch_labels = None
depends_on = None
events = []

event_catalog = table("event_catalog",
    column("code", Integer),
    column("description", String),
    column("equipment", String),
    column("format", String),
    column("options", Integer),
    column("level", Integer),
    column("channel", String),
    column("color", String)
)


def upgrade():
    op.execute("""
        delete from event_catalog where code in (601, 602);
    """)
    op.bulk_insert(event_catalog, events)

def addEv(code, descr, format, equipment = u"common", options = 7, level = 0, channel = "notif", color = "#000000"):
    events.append({
        u"code": code,
        u"description": descr,
        u"equipment": equipment,
        u"format": format,
        u"options": options,
        u"level": level,
        u"channel": channel,
        u"color": color
    })
addEv(601, u"Установлена связь с удаленным сервером", u"[\"Установлена связь с удаленным сервером %statement.directObj.name\", \"Установлена связь с удаленным сервером\"]")
addEv(602, u"Потеряна связь с удаленным сервером", u"[\"Потеряна связь с удаленным сервером %statement.directObj.name\", \"Потеряна связь с удаленным сервером\"]")


def downgrade():
    pass
