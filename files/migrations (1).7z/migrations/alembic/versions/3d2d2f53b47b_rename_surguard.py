"""rename surguard

Revision ID: 3d2d2f53b47b
Revises: cf307d154da3
Create Date: 2019-10-16 08:59:30.962339

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3d2d2f53b47b'
down_revision = 'cf307d154da3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""alter table surguard_driver rename to nts_driver;""")
    op.execute("""alter table surguard_panel rename to nts_panel;""")
    op.execute("""alter table surguard_part rename to nts_part;""")
    op.execute("""alter table surguard_partuser rename to nts_partuser;""")
    op.execute("""alter table surguard_user rename to nts_user;""")
    op.execute("""alter table surguard_zone rename to nts_zone;""")
    op.execute("""
        update equipments set name = 'nts' where name = 'surguard';
        update event_catalog set equipment = 'nts' where equipment = 'surguard';
        
        update observed_objects set devequipment = 'nts' where devequipment = 'surguard';
    """)


def downgrade():
    pass
