"""add_column_setting_for_biomini

Revision ID: 8366efc20c49
Revises: 8507e9d10715
Create Date: 2018-07-24 14:38:38.049000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8366efc20c49'
down_revision = '8507e9d10715'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
    alter table system_permitofficesettings
    add column tabbiomini boolean
    """)


def downgrade():
    op.execute("""
    alter table system_permitofficesettings
    drop column tabbiomini
    """)