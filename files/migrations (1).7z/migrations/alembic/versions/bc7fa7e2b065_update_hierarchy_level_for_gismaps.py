"""update hierarchy level for gismaps

Revision ID: bc7fa7e2b065
Revises: 4947c1c0a6f5
Create Date: 2018-11-19 15:31:03.867000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bc7fa7e2b065'
down_revision = '4947c1c0a6f5'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('update system_gismap set hierarchy_level = 0 where hierarchy_level is null')


def downgrade():
    pass
