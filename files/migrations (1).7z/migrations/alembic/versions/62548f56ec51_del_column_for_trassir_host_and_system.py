"""del column for trassir_host and system

Revision ID: 62548f56ec51
Revises: ecdf7d581c1f
Create Date: 2019-12-25 13:44:46.403637

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '62548f56ec51'
down_revision = 'ecdf7d581c1f'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE trassir_host drop column events_timestamp')
    op.execute('ALTER TABLE system_incidentsettings drop column display_video_selected_incident')
    op.execute('ALTER TABLE system_incidentsettings drop column management_cammodule_selected_incident')


def downgrade():
    op.execute("""
        alter table trassir_host
        add column events_timestamp text default '{
            "event": 0,
            "autoevent": 0
        }';
    """)
    op.execute('ALTER TABLE system_incidentsettings ADD display_video_selected_incident bool default false')
    op.execute('ALTER TABLE system_incidentsettings ADD management_cammodule_selected_incident bool default false')
