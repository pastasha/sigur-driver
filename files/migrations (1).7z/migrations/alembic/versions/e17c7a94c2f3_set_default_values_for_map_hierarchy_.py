# -*- coding: utf-8 -*-

"""set default values for map_hierarchy index column

Revision ID: e17c7a94c2f3
Revises: 01a3936dedd1
Create Date: 2018-04-27 17:26:29.502000

Присваивает значение колонки в 1 для всех записей где index=null для таблиц иерархии карт

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e17c7a94c2f3'
down_revision = '01a3936dedd1'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        update system_mapshierarchy set index=1 where index is null;
        update system_mapshierarchy_gismap set index=1 where index is null;
        update system_mapshierarchy_map set index=1 where index is null;
    """)


def downgrade():
    pass
