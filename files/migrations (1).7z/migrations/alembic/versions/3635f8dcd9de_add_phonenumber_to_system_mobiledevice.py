"""add_phonenumber_to_system_mobiledevice

Revision ID: 3635f8dcd9de
Revises: 542d4e067117
Create Date: 2019-10-01 12:31:34.601512

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '3635f8dcd9de'
down_revision = '542d4e067117'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table system_mobiledevice
        add column phone_number text default '';
        
        update system_mobiledevice set phone_number = '';
    """)


def downgrade():
    op.execute("""
        alter table system_mobiledevice
        drop column phone_number;
    """)
