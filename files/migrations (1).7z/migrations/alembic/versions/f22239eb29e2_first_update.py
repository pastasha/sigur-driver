"""first update

Revision ID: f22239eb29e2
Revises: 
Create Date: 2018-02-28 14:11:19.305000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f22239eb29e2'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    print ("It's first new update. It need only for merging to other branches and start making new updates")


def downgrade():
    pass
