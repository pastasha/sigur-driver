"""add_column_active_in_server

Revision ID: a764201ee7c6
Revises: 9d9a5a00c22d
Create Date: 2018-06-05 09:56:12.895000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a764201ee7c6'
down_revision = '9d9a5a00c22d'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE rusguard_server ADD active boolean')


def downgrade():
    op.execute('ALTER TABLE rusguard_server drop column active')
