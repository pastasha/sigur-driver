"""add column ip_archive for milestone

Revision ID: a900103d79d8
Revises: 7ce1f4abe1ac
Create Date: 2019-11-07 10:01:13.517986

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a900103d79d8'
down_revision = '7ce1f4abe1ac'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE milestone_managmentserver ADD ip_archive text')


def downgrade():
    op.execute('ALTER TABLE milestone_managmentserver drop column ip_archive')
