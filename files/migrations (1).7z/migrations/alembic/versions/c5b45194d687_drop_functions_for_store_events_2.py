"""drop functions for store events 2

Revision ID: c5b45194d687
Revises: d13aa773eb95
Create Date: 2019-02-04 14:16:53.406000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c5b45194d687'
down_revision = 'd13aa773eb95'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        drop function if exists get_event_handler(bigint, bigint, bigint, bigint, bigint, bigint, bigint);
        drop function if exists set_subject_last_pass_event(bigint, timestamp without time zone, bigint, bigint, bigint, bigint,
            bigint, bigint, bigint);
    """)


def downgrade():
    pass
