"""add table remote

Revision ID: a940091db679
Revises: aefd8171f5b1
Create Date: 2018-03-12 11:03:20.222000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a940091db679'
down_revision = 'aefd8171f5b1'

branch_labels = None
depends_on = None

def upgrade():
    op.execute("""INSERT INTO equipments(name,enabled) VALUES('remote',TRUE)""")

    op.create_equipment('remote_site', (
        ('id', 'varchar(256)', ''),
        ('description', 'varchar(256)', ''),
        ('portConfig', 'varchar(256)', ''),
        ('remoteIp', 'varchar(256)', '')
        ), [], False
    )

def downgrade():
    op.drop_table('remote_site')
    op.execute("""
        DELETE FROM equipments WHERE name = 'remote';
        DELETE FROM equipment_generators WHERE equipment = 'remote';
    """)