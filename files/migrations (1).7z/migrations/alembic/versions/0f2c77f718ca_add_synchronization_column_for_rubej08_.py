"""add synchronization column for rubej08_bcp

Revision ID: 0f2c77f718ca
Revises: e17c7a94c2f3
Create Date: 2018-06-13 13:55:09.799000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0f2c77f718ca'
down_revision = 'e17c7a94c2f3'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table rubej08_bcp
        add column synchronization integer default 0;
        
        update rubej08_bcp set synchronization = 0;
    """)


def downgrade():
    op.execute("""
        alter table rubej08_bcp
        drop column synchronization
    """)
