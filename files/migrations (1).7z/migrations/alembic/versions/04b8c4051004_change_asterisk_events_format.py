# -*- coding: utf-8 -*-

"""change asterisk events format

Revision ID: 04b8c4051004
Revises: f07212a6bac8
Create Date: 2019-05-23 10:14:51.231000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '04b8c4051004'
down_revision = 'f07212a6bac8'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"""
        update event_catalog
        set format = '%statement.directObj.param вызвал абонента %statement.indirectObj.param'
        where code = 30000;
        
        update event_catalog
        set format = '%statement.indirectObj.param ответил на вызов от %statement.directObj.param'
        where code = 30001;
        
        update event_catalog
        set format = 'Вызов абонента %statement.indirectObj.param абонентом %statement.directObj.param не удался, линия занята'
        where code = 30002;
        
        update event_catalog
        set format = 'Вызов абонента %statement.indirectObj.param абонентом %statement.directObj.param не удался, нет ответа'
        where code = 30003;
        
        update event_catalog
        set format = 'Вызов абонента %statement.indirectObj.param абонентом %statement.directObj.param не удался, сброс'
        where code = 30004;
        
        update event_catalog
        set format = 'Создан мост между абонентами %statement.indirectObj.param и %statement.directObj.param'
        where code = 30005;
        
        update event_catalog
        set format = 'Разорван мост между абонентами %statement.indirectObj.param и %statement.directObj.param'
        where code = 30006;
        
        update event_catalog
        set format = 'Готова запись разговора между абонентами %statement.indirectObj.param и %statement.directObj.param'
        where code = 30007;
    """)


def downgrade():
    pass
