"""trassir http port

Revision ID: 2e3a8911c39e
Revises: 792aa8a697f0
Create Date: 2018-11-22 15:47:14.347000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '2e3a8911c39e'
down_revision = '792aa8a697f0'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('trassir_host',
                  sa.Column('http_stream_port', sa.Integer(), default=555)
                  )
    op.execute('UPDATE trassir_host SET http_stream_port = 555')


def downgrade():
    op.drop_column('trassir_host', 'http_stream_port')