"""move far links to equipment tables

Revision ID: f2d246b0b770
Revises: db1a2cdc1002
Create Date: 2018-11-12 11:07:26.442000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f2d246b0b770'
down_revision = 'db1a2cdc1002'
branch_labels = None
depends_on = None


def upgrade():
    # common_permit
    op.add_column('common_permit', sa.Column('ownpart', sa.BigInteger()))
    op.execute("""
        update common_permit
        set ownpart = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'permit' and rightequip = 'pce' and righttype = 'part' and leftid = uniid and deletemark = 0
        )
    """)
    # common_commonright
    op.add_column('common_commonright', sa.Column('rlist', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('accesslevel', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('hkright', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('bisright', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('levelaccess', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('marshrut', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('uldright', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('alevel', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('rzone', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('acc_bcp_tz', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('rzone_tz', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('boschauthorization', sa.BigInteger()))
    op.add_column('common_commonright', sa.Column('schedule_srv', sa.BigInteger()))
    op.execute("""
        update common_commonright
        set rlist = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'pce' and righttype = 'rlist' and leftid = uniid and deletemark = 0
        ),
        accesslevel = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'apollo' and righttype = 'accesslevel' and leftid = uniid and deletemark = 0
        ),
        hkright = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'housekeeper' and righttype = 'hkright' and leftid = uniid and deletemark = 0
        ),
        bisright = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'bis' and righttype = 'bisright' and leftid = uniid and deletemark = 0
        ),
        levelaccess = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'orioniso' and righttype = 'levelaccess' and leftid = uniid and deletemark = 0
        ),
        marshrut = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'tss' and righttype = 'marshrut' and leftid = uniid and deletemark = 0
        ),
        uldright = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'uld' and righttype = 'uldright' and leftid = uniid and deletemark = 0
        ),
        alevel = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'rubej08' and righttype = 'alevel' and leftid = uniid and deletemark = 0
        ),
        rzone = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'rubej08' and righttype = 'zone' and leftid = uniid and deletemark = 0
        ),
        acc_bcp_tz = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'rubej08' and righttype = 'timezone' and leftid = uniid and deletemark = 0 and linkname = 'acc_bcp_tz'
        ),
        rzone_tz = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'rubej08' and righttype = 'timezone' and leftid = uniid and deletemark = 0 and linkname = 'rzone_tz'
        ),
        boschauthorization = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'bosch' and righttype = 'authorization' and leftid = uniid and deletemark = 0
        ),
        schedule_srv = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'commonright' and rightequip = 'orionintgrsrv' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # common_schedule
    op.add_column('common_schedule', sa.Column('timezone', sa.BigInteger()))
    op.execute("""
        update common_schedule
        set timezone = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'schedule' and rightequip = 'tss' and righttype = 'timezone' and leftid = uniid and deletemark = 0
        )
    """)
    # system_workstation
    op.add_column('system_workstation', sa.Column('authenticatedsubject', sa.BigInteger()))
    op.execute("""
        update system_workstation
        set authenticatedsubject = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'workstation' and rightequip = 'common' and righttype = 'subject' and leftid = uniid and deletemark = 0
        )
    """)
    # system_videomonitor
    op.add_column('system_videomonitor', sa.Column('intellectmonitor', sa.BigInteger()))
    op.add_column('system_videomonitor', sa.Column('securosmonitor', sa.BigInteger()))
    op.add_column('system_videomonitor', sa.Column('axxonlayout', sa.BigInteger()))
    op.add_column('system_videomonitor', sa.Column('milestonematrix', sa.BigInteger()))
    op.execute("""
        update system_videomonitor
        set intellectmonitor = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'intellect' and righttype = 'monitor' and leftid = uniid and deletemark = 0
        ),
        securosmonitor = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'securos' and righttype = 'monitor' and leftid = uniid and deletemark = 0
        ),
        axxonlayout = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'axxon' and righttype = 'layout' and leftid = uniid and deletemark = 0
        ),
        milestonematrix = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'milestone' and righttype = 'matrix' and leftid = uniid and deletemark = 0
        )
    """)
    # orioniso_tinterval
    op.add_column('orioniso_tinterval', sa.Column('schedule_rschedule', sa.BigInteger()))
    op.add_column('orioniso_tinterval', sa.Column('rschedule_tzone', sa.BigInteger()))
    op.add_column('orioniso_tinterval', sa.Column('tzone_tinterval', sa.BigInteger()))
    op.execute("""
        update orioniso_tinterval
        set schedule_rschedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'common' and righttype = 'schedule_rschedule' and leftid = uniid and deletemark = 0
        ),
        rschedule_tzone = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'common' and righttype = 'rschedule_tzone' and leftid = uniid and deletemark = 0
        ),
        tzone_tinterval = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videomonitor' and rightequip = 'common' and righttype = 'tzone_tinterval' and leftid = uniid and deletemark = 0
        )
    """)
    # orioniso_accesspoint
    op.add_column('orioniso_accesspoint', sa.Column('in_area', sa.BigInteger()))
    op.add_column('orioniso_accesspoint', sa.Column('out_area', sa.BigInteger()))
    op.execute("""
        update orioniso_accesspoint
        set in_area = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'accesspoint' and rightequip = 'common' and righttype = 'area' and leftid = uniid and deletemark = 0 and linkname = 'in_area'
        ),
        out_area = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'accesspoint' and rightequip = 'common' and righttype = 'area' and leftid = uniid and deletemark = 0 and linkname = 'out_area'
        )
    """)
    # orioniso_levelaccess_part
    op.add_column('orioniso_levelaccess_part', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orioniso_levelaccess_part
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'levelaccess_part' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orioniso_levelaccess_grouppart
    op.add_column('orioniso_levelaccess_grouppart', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orioniso_levelaccess_grouppart
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'levelaccess_grouppart' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orioniso_levelaccess_accesspoint
    op.add_column('orioniso_levelaccess_accesspoint', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orioniso_levelaccess_accesspoint
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'levelaccess_accesspoint' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orioniso_levelaccess_area
    op.add_column('orioniso_levelaccess_area', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orioniso_levelaccess_area
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orioniso' and lefttype = 'levelaccess_area' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # system_videoverificationpanel
    op.add_column('system_videoverificationpanel', sa.Column('photo_template', sa.BigInteger()))
    op.add_column('system_videoverificationpanel', sa.Column('video_template', sa.BigInteger()))
    op.execute("""
        update system_videoverificationpanel
        set photo_template = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videoverificationpanel' and rightequip = 'common' and righttype = 'permittemplate' and leftid = uniid and deletemark = 0 and linkname = 'photo_template'
        ),
        video_template = (
            select rightid
            from equipment_bridge
            where leftequip = 'system' and lefttype = 'videoverificationpanel' and rightequip = 'common' and righttype = 'permittemplate' and leftid = uniid and deletemark = 0 and linkname = 'video_template'
        )
    """)
    # common_root
    op.add_column('common_root', sa.Column('gsmmodem', sa.BigInteger()))
    op.execute("""
        update common_root
        set gsmmodem = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'root' and rightequip = 'gsm' and righttype = 'modem' and leftid = uniid and deletemark = 0
        )
    """)
    # common_subject
    op.add_column('common_subject', sa.Column('navigationdevice', sa.BigInteger()))
    op.add_column('common_subject', sa.Column('rtlstag', sa.BigInteger()))
    op.execute("""
        update common_subject
        set navigationdevice = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'subject' and rightequip = 'navigation' and righttype = 'device' and leftid = uniid and deletemark = 0
        ),
        rtlstag = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'subject' and rightequip = 'rtls' and righttype = 'tag' and leftid = uniid and deletemark = 0
        )
    """)
    # navigation_driver
    op.add_column('navigation_driver', sa.Column('gsmmodem', sa.BigInteger()))
    op.execute("""
        update navigation_driver
        set gsmmodem = (
            select rightid
            from equipment_bridge
            where leftequip = 'navigation' and lefttype = 'driver' and rightequip = 'gsm' and righttype = 'modem' and leftid = uniid and deletemark = 0
        )
    """)
    # orionro_gateway
    op.add_column('orionro_gateway', sa.Column('gsmmodem', sa.BigInteger()))
    op.execute("""
        update orionro_gateway
        set gsmmodem = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionro' and lefttype = 'gateway' and rightequip = 'gsm' and righttype = 'modem' and leftid = uniid and deletemark = 0
        )
    """)
    # orionro_key
    op.add_column('orionro_key', sa.Column('subject', sa.BigInteger()))
    op.execute("""
        update orionro_key
        set subject = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionro' and lefttype = 'key' and rightequip = 'common' and righttype = 'subject' and leftid = uniid and deletemark = 0
        )
    """)
    # surguard_user
    op.add_column('surguard_user', sa.Column('subject', sa.BigInteger()))
    op.execute("""
        update surguard_user
        set subject = (
            select rightid
            from equipment_bridge
            where leftequip = 'surguard' and lefttype = 'user' and rightequip = 'common' and righttype = 'subject' and leftid = uniid and deletemark = 0
        )
    """)
    # surguard_partuser
    op.add_column('surguard_partuser', sa.Column('subject', sa.BigInteger()))
    op.execute("""
        update surguard_partuser
        set subject = (
            select rightid
            from equipment_bridge
            where leftequip = 'surguard' and lefttype = 'partuser' and rightequip = 'common' and righttype = 'subject' and leftid = uniid and deletemark = 0
        )
    """)
    # common_respondresource
    op.add_column('common_respondresource', sa.Column('navigationdevice', sa.BigInteger()))
    op.execute("""
        update common_respondresource
        set navigationdevice = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'respondresource' and rightequip = 'navigation' and righttype = 'device' and leftid = uniid and deletemark = 0
        )
    """)
    # orionintgrsrv_accessitempoint
    op.add_column('orionintgrsrv_accessitempoint', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orionintgrsrv_accessitempoint
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionintgrsrv' and lefttype = 'accessitempoint' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orionintgrsrv_schedule_accessitempoint
    op.add_column('orionintgrsrv_schedule_accessitempoint', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orionintgrsrv_schedule_accessitempoint
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionintgrsrv' and lefttype = 'schedule_accessitempoint' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orionintgrsrv_accessitemzone
    op.add_column('orionintgrsrv_accessitemzone', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orionintgrsrv_accessitemzone
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionintgrsrv' and lefttype = 'accessitemzone' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # orionintgrsrv_schedule_accessitemzone
    op.add_column('orionintgrsrv_schedule_accessitemzone', sa.Column('schedule', sa.BigInteger()))
    op.execute("""
        update orionintgrsrv_schedule_accessitemzone
        set schedule = (
            select rightid
            from equipment_bridge
            where leftequip = 'orionintgrsrv' and lefttype = 'schedule_accessitemzone' and rightequip = 'common' and righttype = 'schedule' and leftid = uniid and deletemark = 0
        )
    """)
    # rtls_map
    op.add_column('rtls_map', sa.Column('reference_map', sa.BigInteger()))
    op.execute("""
        update rtls_map
        set reference_map = (
            select rightid
            from equipment_bridge
            where leftequip = 'rtls' and lefttype = 'map' and rightequip = 'system' and righttype = 'map' and leftid = uniid and deletemark = 0
        )
    """)
    # common_area
    op.execute("""
        update common_area
        set map = (
            select rightid
            from equipment_bridge
            where leftequip = 'common' and lefttype = 'area' and rightequip = 'system' and righttype = 'map' and leftid = uniid and deletemark = 0
        )
    """)
    op.drop_table('equipment_bridge')


def downgrade():
    pass
