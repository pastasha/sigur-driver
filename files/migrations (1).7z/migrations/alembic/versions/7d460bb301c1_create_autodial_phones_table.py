"""create_autodial_phones_table

Revision ID: 7d460bb301c1
Revises: e01091db8661
Create Date: 2019-06-25 21:21:38.722000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '7d460bb301c1'
down_revision = 'e01091db8661'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'asterisk_autodial',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('name', sa.String(80), nullable=False),
		sa.Column('filename', sa.String(80), nullable=False)
    )


def downgrade():
    op.drop_table('asterisk_autodial')