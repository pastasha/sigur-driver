# -*- coding: utf-8 -*-
"""add_ip_and_port_columns_to_remotesite

Revision ID: feb665e63796
Revises: 2f1752c432e8
Create Date: 2019-08-29 14:15:00.958000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'feb665e63796'
down_revision = 'e4cfcc12ebf9'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table remote_site
        add column videoserver_ip text default '',
        add column videoserver_port integer default 0;
        
        update remote_site set videoserver_ip = '';
        update remote_site set videoserver_port = 0
    """)


def downgrade():
    op.execute("""
        alter table remote_site
        drop column if exists videoserver_port,
        drop column if exists videoserver_ip
    """)
