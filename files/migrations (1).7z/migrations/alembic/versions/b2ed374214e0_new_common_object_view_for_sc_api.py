"""new_common_object_view_for_sc_api

Revision ID: b2ed374214e0
Revises: e4cfcc12ebf9
Create Date: 2019-09-02 17:12:19.273597

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b2ed374214e0'
down_revision = 'feb665e63796'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
            DROP VIEW IF EXISTS common_object;
            CREATE VIEW common_object as
            select ROW_NUMBER() OVER(ORDER BY (SELECT 1)) id, uniid, description, type, kind, equipment 
            from (select uniid, description, 'person' as type, null as kind, null as equipment from common_person
            union
            select uniid, description, 'mobile' as type, null as kind, null as equipment from common_mobile
            union
            select uniid, description, 'thing' as type, null as kind, null as equipment from common_thing objects
            union
            select id, name, 'observed_object' as type, devtype as kind, devequipment as kind from observed_objects) observed_objects;
        """)


def downgrade():
    op.execute("""DROP VIEW IF EXISTS common_object;""")
