"""drop_table_suprema_user

Revision ID: 4a28fbe5f0ba
Revises: a79e6d1623aa
Create Date: 2018-10-29 22:47:34.421000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '4a28fbe5f0ba'
down_revision = 'a79e6d1623aa'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_table('suprema_user')


def downgrade():
    pass
