"""add dsc tables

Revision ID: 114c9711d6b2
Revises: e0e31a12f24d
Create Date: 2019-10-28 09:37:51.398135

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '114c9711d6b2'
down_revision = 'e0e31a12f24d'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('''
        insert into equipments(name, enabled) values('dsc', true)
    ''')

    op.create_equipment('dsc_panel', [
        ('description', 'text', ''),
        ('ports_addr', 'text', ''),
        ('key', 'text', 'default \'5555\''),
        ('com_port', 'text', 'default \'1\''),
        ('com_baudrate', 'int', 'default 9600'),
        ('import_flag', 'boolean', 'default false'),
        ('poll_time', 'int', 'default 5'),
        ('active', 'boolean', 'default true'),
        ('synchronization', 'int', 'default 360')
    ], [], True)

    op.create_equipment('dsc_part', [
        ('description', 'text', ''),
        ('number', 'text', '')
    ], [], True)

    op.create_equipment('dsc_zone', [
        ('description', 'text', ''),
        ('number', 'text', '')
    ], [], True)

    op.create_equipment('dsc_user', [
        ('description', 'text', ''),
        ('user_code', 'text', ''),
        ('subject', 'bigint', ''),
    ], [], True)


def downgrade():
    op.execute('''
        delete from equipments where name='dsc';
        drop table dsc_part;
        drop table dsc_zone;
        drop table dsc_user;
        drop table dsc_panel;
    ''')
