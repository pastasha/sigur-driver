"""add coloumn host_controller_mainserver_name to trassir_host

Revision ID: bfa2cb74a7a6
Revises: 556d9c93e3d2
Create Date: 2018-05-18 14:52:57.294000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'bfa2cb74a7a6'
down_revision = '556d9c93e3d2'
branch_labels = None
depends_on = None


def upgrade():
    op.execute('ALTER TABLE trassir_host ADD host_controller_mainserver_name varchar(80)')



def downgrade():
    op.execute('ALTER TABLE trassir_host drop column host_controller_mainserver_name')

