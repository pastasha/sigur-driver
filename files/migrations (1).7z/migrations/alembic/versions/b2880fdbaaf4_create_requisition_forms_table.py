"""create requisition forms table

Revision ID: b2880fdbaaf4
Revises: 29bcbf9d6bbc
Create Date: 2019-08-25 16:57:51.761284

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b2880fdbaaf4'
down_revision = '29bcbf9d6bbc'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create table requisition_forms(
            id serial primary key,
            requisition_type bigint references requisition_types(id) on delete cascade,
            form text,
            version integer not null
        );
        
        alter table requisition_types
        add column form_template bigint references requisition_forms(id);
        
        alter table requisition
        add column form bigint references requisition_forms(id);
        
        insert into requisition_forms(requisition_type, form, version)
        select id, form, 1 from requisition_types;
        
        alter table requisition_types
        drop column form;
        alter table requisition_types
        rename column form_template to form;
        
        update requisition_types rt
        set form = (select id from requisition_forms where requisition_type = rt.id);
        
        update requisition r
        set form = (
            select id from requisition_forms
            where requisition_type = (
                select requisition_type from requisition_info where id = r.info
            )
        );
    """)


def downgrade():
    pass
