"""add department sign stage bridge table

Revision ID: 8a4ab01e52d1
Revises: dffadbc2bd22
Create Date: 2019-05-28 17:41:14.845000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8a4ab01e52d1'
down_revision = 'dffadbc2bd22'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        create table department_requisitionsignstage_brg(
            stage bigint references requisition_sign_stage(id) on delete cascade,
            department bigint references common_department(uniid) on delete cascade,
            priority integer,
            primary key(stage, department)
        )
    """)


def downgrade():
    op.drop_table('department_requisitionsignstage_brg')
