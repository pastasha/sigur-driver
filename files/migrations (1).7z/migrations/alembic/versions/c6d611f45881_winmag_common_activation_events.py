# -*- coding: utf-8 -*-
"""winmag_common_activation_events

Revision ID: c6d611f45881
Revises: cd664930a2ab
Create Date: 2019-07-25 10:08:14.257000

"""
from alembic import op
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column

# revision identifiers, used by Alembic.
revision = 'c6d611f45881'
down_revision = 'cd664930a2ab'
branch_labels = None
depends_on = None

# TODO Please insert here information about alembic revision

events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'winmag', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })


add_event(9565, 'Общая активация Включена',
          u'[\"Общая активация включена на устройства %statement.directObj.name\", \"Общая активация Включена\"]')
add_event(9566, 'Общая активация Выключена',
          u'[\"Общая активация выключена на устройства %statement.directObj.name\", \"Общая активация Выключена\"]')


def downgrade():
    op.execute('''
    delete from event_catalog where code in (9565, 9566)
    ''')
