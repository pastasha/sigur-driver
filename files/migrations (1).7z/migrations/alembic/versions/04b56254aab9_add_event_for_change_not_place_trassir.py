"""add event for change not place trassir

Revision ID: 04b56254aab9
Revises: 43a0bba0c0fa
Create Date: 2019-12-18 09:33:10.827218

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import String, Integer
from sqlalchemy.sql import table, column


# revision identifiers, used by Alembic.
revision = '04b56254aab9'
down_revision = '43a0bba0c0fa'
branch_labels = None
depends_on = None
branch_labels = None
depends_on = None
events = []

event_catalog = table('event_catalog',
                      column('code', Integer),
                      column('description', String),
                      column('equipment', String),
                      column('format', String),
                      column('options', Integer),
                      column('level', Integer),
                      column('channel', String),
                      column('color', String)
                      )


def upgrade():
    op.bulk_insert(event_catalog, events)


def add_event(code, descr, format, equipment=u'trassir', options=7, level=0, channel='notif', color='#000000'):
    events.append({
        u'code': code,
        u'description': descr,
        u'equipment': equipment,
        u'format': format,
        u'options': options,
        u'level': level,
        u'channel': channel,
        u'color': color
    })

add_event(7038, 'Номер был изменен', '%statement.directObj.name: номер %statement.adverbialMode.param.old_plate был изменен оператором - %statement.adverbialMode.param.operator на %statement.adverbialMode.param.new_plate')
add_event(7039, 'Номер не изменен', '%statement.directObj.name: номер %statement.adverbialMode.param.old_plate не изменен')

def downgrade():
    op.execute('''
    delete from event_catalog where code >= 7038 and code <= 7039
    ''')
