# -*- coding: utf-8 -*-

"""change handlers table

Revision ID: 9b7779b5a7bf
Revises: a8bcdb5b070d
Create Date: 2019-03-25 12:20:30.707000

Переименовывает таблицу с обработчиками
extid -> id
Внешние ключи

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9b7779b5a7bf'
down_revision = 'a8bcdb5b070d'
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table('event_table', 'handlers')
    op.alter_column('handlers', 'extid', new_column_name='id')
    op.execute("""
        update handlers set "group" = null where "group" = 0;
        update handlers set obj = null where obj = 0;
        update handlers set place = null where place = 0;
        update handlers set indirectobj = null where indirectobj = 0;
        update handlers set fromarea = null where fromarea = 0;
        update handlers set toarea = null where toarea = 0;
        
        update handlers set obj = null where obj not in (select id from observed_objects);
        update handlers set indirectobj = null where indirectobj not in (select id from observed_objects);
        update handlers set place = null where place not in (select id from observed_objects);
        update handlers set fromarea = null where fromarea not in (select id from observed_objects);
        update handlers set toarea = null where toarea not in (select id from observed_objects);
    """)
    op.create_foreign_key('handlers_group_fkey', 'handlers', 'handler_group', ['group'], ['uniid'], ondelete='CASCADE')
    op.create_foreign_key('handlers_obj_fkey', 'handlers', 'observed_objects', ['obj'], ['id'], ondelete='SET NULL')
    op.create_foreign_key('handlers_place_fkey', 'handlers', 'observed_objects', ['place'], ['id'], ondelete='SET NULL')
    op.create_foreign_key('handlers_indirectobj_fkey', 'handlers', 'observed_objects', ['indirectobj'], ['id'], ondelete='SET NULL')
    op.create_foreign_key('handlers_fromarea_fkey', 'handlers', 'observed_objects', ['fromarea'], ['id'], ondelete='SET NULL')
    op.create_foreign_key('handlers_toarea_fkey', 'handlers', 'observed_objects', ['toarea'], ['id'], ondelete='SET NULL')


def downgrade():
    op.drop_constraint('handlers_toarea_fkey', 'handlers')
    op.drop_constraint('handlers_fromarea_fkey', 'handlers')
    op.drop_constraint('handlers_indirectobj_fkey', 'handlers')
    op.drop_constraint('handlers_place_fkey', 'handlers')
    op.drop_constraint('handlers_obj_fkey', 'handlers')
    op.drop_constraint('handlers_group_fkey', 'handlers')
    op.execute("""
        update handlers set "group" = 0 where "group" is null;
        update handlers set obj = 0 where obj is null;
        update handlers set place = 0 where place is null;
        update handlers set indirectobj = 0 where indirectobj is null;
        update handlers set fromarea = 0 where fromarea is null;
        update handlers set toarea = 0 where toarea is null;
    """)
    op.alter_column('handlers', 'id', new_column_name='extid')
    op.rename_table('handlers', 'event_table')
