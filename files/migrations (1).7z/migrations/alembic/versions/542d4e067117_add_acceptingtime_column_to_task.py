"""add_acceptingtime_column_to_task

Revision ID: 542d4e067117
Revises: d24bba327d14
Create Date: 2019-09-27 11:18:32.844733

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '542d4e067117'
down_revision = 'd24bba327d14'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        alter table incidents.incident_task
        add column accepting_time int default 0;
        
        update incidents.incident_task
        set accepting_time = 0;
    """)


def downgrade():
    op.execute("""
        alter table incidents.incident_task
        drop column accepting_time;
    """)
