# -*- coding: utf-8 -*-

"""create incident status catalog

Revision ID: c8bc1860b8c5
Revises: b95fb1cad529
Create Date: 2019-06-21 09:12:03.380000

Миграция добавляет для инцидента и задач внутри него флаги закрыт, просрочено время взятия и просрочено время обработки
они вычисляются исходя из статусов closed, cancelled, accepting_expired, processing_expired
Создается таблица для ведения справояника статусов в которую сразу добаляются created, accepted, closed
Статусы инцидентов делаются ссылками на эту таблицу
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c8bc1860b8c5'
down_revision = 'b95fb1cad529'
branch_labels = None
depends_on = None


def upgrade():
    op.execute(u"""
        alter table incidents.incident_register
        add column closed boolean default false,
        add column accepting_expired boolean default false,
        add column processing_expired boolean default false,
        alter column status type text;
        
        update incidents.incident_register
        set closed = false, accepting_expired = false, processing_expired = false;
        
        update incidents.incident_register
        set closed = true, status = 'closed'
        where status = 'closed' or status = 'cancelled';
        
        update incidents.incident_register
        set accepting_expired = true, status = 'created'
        where status = 'accepting_expired';
        
        update incidents.incident_register
        set processing_expired = true, status = 'accepted'
        where status = 'processing_expired';
        
        
        alter table incidents.incident_task_register
        add column closed boolean default false,
        add column accepting_expired boolean default false,
        add column processing_expired boolean default false,
        alter column status type text;
        
        update incidents.incident_task_register
        set closed = false, accepting_expired = false, processing_expired = false;
        
        update incidents.incident_task_register
        set closed = true, status = 'closed'
        where status = 'closed' or status = 'cancelled';
        
        update incidents.incident_task_register
        set accepting_expired = true, status = 'created'
        where status = 'accepting_expired';
        
        update incidents.incident_task_register
        set processing_expired = true, status = 'accepted'
        where status = 'processing_expired';
        
        create table incidents.incident_status(
            id serial primary key not null,
            name text default '',
            false_status boolean default false
        );
        
        insert into incidents.incident_status(name)
        values ('created'), ('accepted'), ('closed');
        
        drop type incident_status;
        
        update incidents.incident_register
        set status = (select id from incidents.incident_status where name = status);
        
        alter table incidents.incident_register
        alter column status type int using status::int;
        
        alter table incidents.incident_register
        add constraint incident_register_status_fkey foreign key(status) references incidents.incident_status(id);
        
        update incidents.incident_task_register
        set status = (select id from incidents.incident_status where name = status);
        
        alter table incidents.incident_task_register
        alter column status type int using status::int;
        
        alter table incidents.incident_task_register
        add constraint incident_register_status_fkey foreign key(status) references incidents.incident_status(id);
        
        update incidents.incident_status
        set name = 'Новый'
        where name = 'created';
        
        update incidents.incident_status
        set name = 'Обработка'
        where name = 'accepted';
        
        update incidents.incident_status
        set name = 'Разрешен'
        where name = 'closed';
        
        -- надо очистить icon так как оно теперь хранится по другому и sIncidentProcessor падает
        update incidents.incident_type
        set icon = null;
        
        -- закроем все работающие инциденты
        update incidents.incident_register
        set closed = true, status = (select id from incidents.incident_status where name = 'Разрешен'),
        closedt = (select extract(epoch from now())::int)
        where closed = false;
    """)


def downgrade():
    pass
