"""add incident_map_register

Revision ID: 223c905004ca
Revises: 0cfb25e85f40
Create Date: 2019-10-09 13:46:07.931698

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '223c905004ca'
down_revision = '0cfb25e85f40'
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
	CREATE OR REPLACE VIEW public.incident_map_register
	as SELECT ir.id,
	    oom.map_id,
	    oogm.map_id AS gismap_id,
	    it.name,
	    ir.startdt,
	    ir.level,
	    ir.acceptiondt,
	    ir.sourceid,
	    ir.placeid,
	    ir.closedt,
	    ir.status AS incident_status,
	    ir.latitude,
	    ir.longitude,
	    ir.incidentobsobj,
	    ir.status
	   FROM incidents.incident_register ir
	   JOIN incidents.incident_type it ON ir.typeid = it.id
	   LEFT JOIN observed_objects_on_map oom ON oom.obsobj_id = ir.placeid OR oom.obsobj_id = ir.sourceid
	   left join observed_objects_on_gismap oogm on oogm.obsobj_id = ir.placeid OR oogm.obsobj_id = ir.sourceid
	  WHERE ir.closedt IS NULL
	  GROUP BY ir.id, oom.map_id, oogm.map_id, it.name, ir.startdt, ir.level, ir.acceptiondt, ir.sourceid, ir.placeid, ir.status, ir.longitude, ir.latitude
    """)

def downgrade():
    op.execute("""DROP VIEW public.incident_map_register""")
