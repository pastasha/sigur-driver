"""edit_name_table_intellect

Revision ID: 5198ed502d15
Revises: f2d246b0b770
Create Date: 2018-11-14 14:44:55.814000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers", "used by Alembic.
revision = '5198ed502d15'
down_revision = 'f2d246b0b770'
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table("intellect_orion_pro", "intellect_orionpro")
    op.rename_table("intellect_aam_controller", "intellect_aamcontroller")
    op.rename_table("intellect_aam_reader", "intellect_aamreader")
    op.rename_table("intellect_orion_pro_pult", "intellect_orionpropult")
    op.rename_table("intellect_orion_pro_signal20", "intellect_orionprosignal20")
    op.rename_table("intellect_orion_pro_relay_signal20", "intellect_orionprorelaysignal20")
    op.rename_table("intellect_orion_pro_zone_signal20", "intellect_orionprozonesignal20")
    op.rename_table("intellect_castle_ap", "intellect_castleap")
    op.rename_table("intellect_castle_srv", "intellect_castlesrv")
    op.rename_table("intellect_rubeg8_isb", "intellect_rubeg8isb")
    op.rename_table("intellect_rubeg8_isb_alarm_train", "intellect_rubeg8isbalarmtrain")
    op.rename_table("intellect_rubeg8_isb_exec_device", "intellect_rubeg8isbexecdevice")
    op.rename_table("intellect_rubeg8_isb_sk01", "intellect_rubeg8isbsk01")
    op.rename_table("intellect_rubeg8_isb_access_point", "intellect_rubeg8isbaccesspoint")
    op.rename_table("intellect_bolid_device", "intellect_boliddevice")
    op.rename_table("intellect_bolid_partition", "intellect_bolidpartition")
    op.rename_table("intellect_bolid_zone", "intellect_bolidzone")
    op.rename_table("intellect_intrepid3_ain", "intellect_intrepid3ain")
    op.rename_table("intellect_intrepid3_amodule", "intellect_intrepid3amodule")
    op.rename_table("intellect_intrepid3_pm", "intellect_intrepid3pm")
    op.rename_table("intellect_intrepid3_pm_cs", "intellect_intrepid3pmcs")
    op.rename_table("intellect_intrepid3_pm_line", "intellect_intrepid3pmline")


def downgrade():
    op.rename_table("intellect_orionpro", "intellect_orion_pro")
    op.rename_table("intellect_aamcontroller", "intellect_aam_controller")
    op.rename_table("intellect_aamreader", "intellect_aam_reader")
    op.rename_table("intellect_orionpropult", "intellect_orion_pro_pult")
    op.rename_table("intellect_orionprosignal20", "intellect_orion_pro_signal20")
    op.rename_table("intellect_orionprorelaysignal20", "intellect_orion_pro_relay_signal20")
    op.rename_table("intellect_orionprozonesignal20", "intellect_orion_pro_zone_signal20")
    op.rename_table("intellect_castleap", "intellect_castle_ap")
    op.rename_table("intellect_castlesrv", "intellect_castle_srv")
    op.rename_table("intellect_rubeg8isb", "intellect_rubeg8_isb")
    op.rename_table("intellect_rubeg8isbalarmtrain", "intellect_rubeg8_isb_alarm_train")
    op.rename_table("intellect_rubeg8isbexecdevice", "intellect_rubeg8_isb_exec_device")
    op.rename_table("intellect_rubeg8isbsk01", "intellect_rubeg8_isb_sk01")
    op.rename_table("intellect_rubeg8isbaccesspoint", "intellect_rubeg8_isb_access_point")
    op.rename_table("intellect_boliddevice", "intellect_bolid_device")
    op.rename_table("intellect_bolidpartition", "intellect_bolid_partition")
    op.rename_table("intellect_bolidzone", "intellect_bolid_zone")
    op.rename_table("intellect_intrepid3ain", "intellect_intrepid3_ain")
    op.rename_table("intellect_intrepid3amodule", "intellect_intrepid3_amodule")
    op.rename_table("intellect_intrepid3pm", "intellect_intrepid3_pm")
    op.rename_table("intellect_intrepid3pmcs", "intellect_intrepid3_pm_cs")
    op.rename_table("intellect_intrepid3pmline", "intellect_intrepid3_pm_line")
