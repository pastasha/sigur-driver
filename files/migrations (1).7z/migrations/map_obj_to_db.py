# -*- coding: utf-8 -*-

# Скрипт пегоняет содержимое файла map_obj.xml в БД. Нужно запускать один раз при переходе с 2.9 на 2.10. Файл map_obj.xml а так же файл с 
# настройками для подключения к БД должны лежать в папке скрипта

import os
import psycopg2
from xml.dom.minidom import *

settings = __import__('settings')

dbconn = psycopg2.connect(settings.ConnectionString)
cursor = dbconn.cursor()

cursor.execute('delete from observed_objects_on_map')
cursor.execute('delete from observed_objects_on_gismap')

mapObjFile = parse(os.path.abspath('map_obj.xml'))
sensors = mapObjFile.getElementsByTagName('xml')[0].getElementsByTagName('sensor')
for sensor in sensors:
    obsObjData = {
        'map_id'    : int(sensor.getAttribute('mapid')),
        'obsobj_id'	: int(sensor.getAttribute('id')),
        'icon_type'	: int(sensor.getAttribute('type')),
        'icon_id'	: int(sensor.getAttribute('icon_id')) if sensor.getAttribute('icon_id') != '' else 0,
        'x'		    : float(sensor.getAttribute('x')),  # longitude
        'y'		    : float(sensor.getAttribute('y')),  # latitude
        'angle'     : int(sensor.getAttribute('rotation')) if sensor.hasAttribute('rotation') else 0,
        'geojson'   : sensor.getAttribute('geojson') if sensor.hasAttribute('geojson') and sensor.getAttribute('geojson') != '' else None,
    }
    if obsObjData['map_id'] > 0:
        cursor.execute("""
            insert into observed_objects_on_map(map_id, obsobj_id, icon_type, icon_id, x, y, angle, remote_guid)
            values(%(map_id)s, %(obsobj_id)s, %(icon_type)s, %(icon_id)s, %(x)s, %(y)s, %(angle)s, md5(random()::text || clock_timestamp()::text)::uuid)
        """, obsObjData)
    else:
        cursor.execute("""
            insert into observed_objects_on_gismap(map_id, obsobj_id, icon_type, icon_id, longitude, latitude, angle, geojson, remote_guid)
            values(-%(map_id)s, %(obsobj_id)s, %(icon_type)s, %(icon_id)s, %(x)s, %(y)s, %(angle)s, %(geojson)s, md5(random()::text || clock_timestamp()::text)::uuid)
        """, obsObjData)

cursor.execute("""
    delete from observed_objects_on_map where obsobj_id not in (select id from observed_objects where deletemark = 0);
    delete from observed_objects_on_map where map_id not in (select uniid from system_map);
    
    delete from observed_objects_on_gismap where obsobj_id not in (select id from observed_objects where deletemark = 0);
    delete from observed_objects_on_gismap where map_id not in (select uniid from system_gismap);
""")
dbconn.commit()