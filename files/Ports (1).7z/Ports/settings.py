# -*- coding: utf-8 -*-
# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "raukhvarger"
__date__ = "$18.11.2011 10:03:29$"

from elementtree.ElementTree import ElementTree
from string import strip
import os

class Settings:

    __settingsFile__ = 'settings.xml'
    __tree__ = {}

    def __getSettings__(self, elem, tree):
        if len(elem) > 0:
            tree[elem.tag] = {}

        for node in elem:
            node_val = strip(
                node.text) if (
                isinstance(
                    node.text,
                    type('')) or isinstance(
                    node.text,
                    type(u''))) else ''
            try:
                node_val = int(node_val)
            except Exception:
                pass
            node_tree = {node.tag: node_val}
            tree[elem.tag].update(node_tree)
            self.__getSettings__(node, tree[elem.tag])

    def __getitem__(self, elem):
        return self.__tree__['settings'][elem]

    def __init__(self):
        # костыль для запуска процесса опроса событий
        if 'orionintgrsrv' in os.getcwd():
            cur_path = os.getcwd().replace('orionintgrsrv','')
        else:
            cur_path = ''
        xml = ElementTree(file=cur_path+self.__settingsFile__)
        self.__getSettings__(xml.getroot(), self.__tree__)

setting = Settings()
