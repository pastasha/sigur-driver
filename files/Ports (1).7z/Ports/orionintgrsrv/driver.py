# -*- coding: utf-8 -*-

from command import Command
from command import OrionItgSrvService
import datetime
import logging
import json
import threading
import time
import collections
import structures
from config import orionintgrsrvConfig
from config import EventTimeSave

readSeconds = 30
sleepSeconds = 3


class sender_for_al(threading.Thread):
    def __init__(self, evH, cmd_data, cmd_param=None):
        threading.Thread.__init__(self)
        self.__evHandler = evH
        self.config = orionintgrsrvConfig()
        self.logger = logging.getLogger('__main__.orionDrv.sender')
        self.cmd = cmd_data
        self.cmd_param = cmd_param

    def OISReadAccessLevels(self, orionItgSrv):
        acLvlZones = orionItgSrv.service.GetAccessZones()
        acLvlPoints = orionItgSrv.service.GetEntryPoints()
        if acLvlZones.Success == acLvlPoints.Success == True:
            acLvlZones = structures.accItemsToDict(acLvlZones.OperationResult)
            acLvlPoints = structures.accItemsToDict(acLvlPoints.OperationResult)
        else:
            return {
                "status": "error",
                "res": acLvlZones.ServiceError.InnerExceptionMessage + '\n' +
                       acLvlPoints.ServiceError.InnerExceptionMessage
            }

        allAcclvls = []
        alPackLen = 10
        countAL = orionItgSrv.service.GetAccessLevelsCount().OperationResult
        count_al = countAL / alPackLen + 1
        i = 0
        while i < count_al:
            self.logger.info('taking acclevels')
            data = orionItgSrv.service.GetAccessLevels(i * alPackLen, alPackLen)
            if data.Success != True:
                self.logger.info('Failed alevels, error %s' % data.ServiceError.InnerExceptionMessage)
                continue

            allAcclvls = data.OperationResult
            self.logger.info('++++++++++++++++++++++++++++++++++++++++')
            self.logger.info('taking %s' % len(allAcclvls))
            self.logger.info('++++++++++++++++++++++++++++++++++++++++')
            res = structures.TAccessLevelToDict(allAcclvls)
            try:
                for k in res:
                    items_ = k['items']
                    for z in xrange(len(items_)):
                        current_item = items_[z]
                        if current_item['type'] == 'ACCESSPOINT':
                            if current_item['item_id'] == 0:
                                current_item['name'] = u'Все точки досутпа'
                            else:
                                current_item['name'] = acLvlPoints[str(current_item['item_id'])] if str(
                                    current_item['item_id']) in acLvlPoints else 'undefined access point'
                        elif current_item['type'] == 'ACCESSZONE':
                            if current_item['item_id'] == 0:
                                current_item['name'] = u'Все зоны доступа'
                            else:
                                current_item['name'] = acLvlZones[str(current_item['item_id'])] if str(
                                    current_item['item_id']) in acLvlZones else 'undefined access zone'
            except:
                pass
            self.logger.info(
                'sending acclevel ids %s to %s of %s' % (i * alPackLen, (i * alPackLen) + len(res), countAL))
            i += 1
            if len(res) > 0:
                self.__evHandler({
                    "EventTypeId": 'data_to_server',
                    'event': '',
                    "readAccessLevelsList": json.dumps(res)
                })

    def OISReadPersonList(self, orionItgSrv):
        count_al = orionItgSrv.service.GetPersonsCount().OperationResult
        perPackCount = 5
        if count_al > perPackCount:
            for i in xrange((count_al / perPackCount) + 1):
                data = orionItgSrv.service.GetPersons(False, i * perPackCount, perPackCount)
                if data.Success != True:
                    resmsg = u'Ошибка чтения списка частных лиц: %s' % data.ServiceError.InnerExceptionMessage
                    self.logger.info(resmsg)
                    return {"status": "fail", 'res': resmsg}
                self.logger.info('sending persons from %s to %s of %s' % (i * perPackCount, (i * perPackCount) \
                                                                          + len(data.OperationResult), count_al))

                res = []
                for i in data.OperationResult:
                    try:
                        res.append({
                            'ID': i.Id,
                            'TN': i.TabNum,
                            'Name': i.LastName + ' ' + i.FirstName + ' ' + i.MiddleName,
                            'Status': i.Status,
                            'WP': i.Phone,
                            'HP': '',
                            'BD': '',
                            'cID': i.CompanyId,
                            'dID': i.DepartmentId,
                            'pID': i.PositionId,
                            'schID': i.AccessLevelId,
                            'GUID': i.ExternalId if i.ExternalId else '',
                            'Photo': i.Photo
                        })
                    except:
                        self.logger.error("CMD: OISReadPersonList error when read user data , orion id = %s " % i.Id,
                                          exc_info=True)
                    self.__evHandler({
                        "EventTypeId": 'data_to_server',
                        'event': '',
                        "infoPers": json.dumps(res)
                    })
        else:
            data = orionItgSrv.service.GetPersons(False, 0, perPackCount)
            res = []
            for i in data.OperationResult:
                try:
                    res.append({
                        'ID': i.Id,
                        'TN': i.TabNum,
                        'Name': i.LastName + ' ' + i.FirstName + ' ' + i.MiddleName,
                        'Status': i.Status,
                        'WP': i.Phone,
                        'HP': '',
                        'BD': i.BirthDate.strftime("%Y-%m-%d"),
                        'cID': i.CompanyId,
                        'dID': i.DepartmentId,
                        'pID': i.PositionId,
                        'schID': i.AccessLevelId,
                        'GUID': i.ExternalId if i.ExternalId else '',
                        'Photo': i.Photo
                    })
                except:
                    self.logger.error("CMD: OISReadPersonList error when read user data , orion id = %s " % i.Id,
                                      exc_info=True)
            self.__evHandler({
                "EventTypeId": 'data_to_server',
                'event': '',
                "infoPers": json.dumps(res)
            })

    def OISReadKeyList(self, orionItgSrv):
        keyPackCount = 30
        count_al = orionItgSrv.service.GetKeysCount().OperationResult
        for z in xrange(count_al / keyPackCount + 1):
            data = orionItgSrv.service.GetKeys(z * keyPackCount, keyPackCount)
            if data.Success != True:
                resmsg = u'Ошибка получения ключей %s' % data.ServiceError.InnerExceptionMessage
                self.logger.info(resmsg)
                return {"status": "fail", 'res': resmsg}
            res = []
            acceptKeyTypes = [3, 4]
            self.logger.info('readed %s key ' % len(data.OperationResult))
            for i in data.OperationResult:
                self.logger.info('parsing key %s' % i.Code)
                if i.CodeType in acceptKeyTypes:
                    persData = orionItgSrv.service.GetPersonById(i.PersonId)
                    if persData.Success == True and persData.OperationResult != None:
                        pData = persData.OperationResult
                        res.append({
                            'CodeP': i.Code,
                            'Owner': pData.Id,
                            'GroupID': i.AccessLevelId,
                            'Start': str(i.StartDate),
                            'Finish': str(i.EndDate),
                            'TN': pData.TabNum,  # табельный номер
                            'isBlock': i.IsBlocked,
                            'storeInDevice': i.IsStoreInDevice,
                            'storeIn2k': i.IsStoreInS2000,
                            'inStopList': i.IsInStopList,
                            'GUID': pData.ExternalId if pData.ExternalId else '',
                        })
            self.__evHandler({
                "EventTypeId": 'data_to_server',
                'event': '',
                "infoKeys": json.dumps(res)
            })

    def OISGetTimeWindows(self, orionItgSrv):
        data_ready = False
        while not data_ready:
            self.logger.info('taking timewindows')
            data = orionItgSrv.service.GetTimeWindows()
            if data.Success != True:
                self.logger.info(
                    'Failed timewindows load, error %s' % data.ServiceError.InnerExceptionMessage)
                continue
            else:
                try:
                    res = structures.twindow_to_dict(data.OperationResult)
                    self.logger.info('sending timewindows')
                    self.__evHandler({
                        "EventTypeId": 'data_to_server',
                        'event': '',
                        "infoTW": json.dumps(res)
                    })
                    data_ready = True
                except:
                    pass

    def run(self):
        connected = False
        while not connected:
            try:
                orionItgSrv = OrionItgSrvService(self.config.wsdlFile, self.config.urlDict['IOrionProCompat'],
                                                  self.config.tns, self.config.user, self.config.password)
                connected = True
            except Exception as e:
                if hasattr(e, 'reason') and e.reason.errno == 10061:
                    self.logger.info(u'Ожидание готовности к подключению Модуля интеграции')
                else:
                    self.logger.error(u'Ошибка подключения к модулю интеграции: %s '% e.message)
                time.sleep(3)

        if self.cmd == 'OISReadAccessLevels':
            self.OISReadAccessLevels(orionItgSrv)
        elif self.cmd == 'OISReadPersonList':
            self.OISReadPersonList(orionItgSrv)
        elif self.cmd == 'OISReadKeyList':
            self.OISReadKeyList(orionItgSrv)
        elif self.cmd == 'OISGetTimeWindows':
            self.OISGetTimeWindows(orionItgSrv)


class eventSender(threading.Thread):
    def __init__(self, evH):
        self.logger = logging.getLogger('__main__.orionDrv.evSender')
        self.configEventTime = EventTimeSave()
        threading.Thread.__init__(self)
        self.__evHandler = evH            # передача событий на сервер
        self.OISok = False
        self.stop = threading.Event()     # при установке флага перестает проверять канал от процесса опроса.
                                          # и высылать события
        self.wait = threading.Event()     # при установке завершает процесс опроса и сам поток
        self.config = orionintgrsrvConfig()

    def run(self):
        self.logger.info('Event sender started')

        not_connected = True

        while not_connected:
            try:
                orionItgSrv = OrionItgSrvService(self.config.wsdlFile, self.config.urlDict['IOrionProCompat'],
                                                 self.config.tns, self.config.user, self.config.password)
                not_connected = False
                reply = orionItgSrv.service.GetEventTypes()
                if reply.Success == True:
                    eventTypes = reply.OperationResult
                else:
                    raise Exception(reply.OperationResult)
            except Exception as e:
                if hasattr(e, 'reason') and e.reason.errno == 10061:
                    self.logger.info(u'Ожидание готовности к подключению Модуля интеграции')
                else:
                    self.logger.error(u'Ошибка подключения к модулю интеграции: %s '% e.message)
                time.sleep(3)
                continue
        self.logger.info(u'Драйвер подключен к Модулю интеграции')

        while not self.stop.is_set():
            try:
                orionItgSrv.service.GetReplService()
                if self.OISok == False:
                    self.logger.info(u'Установлено подключение к Серверу интеграции Орион Про')
                    self.OISok = True
            except Exception as e:
                self.logger.error(u'Сервер интеграции Орион Про не отвечает: %s'% e.message)
                self.OISok = False
                time.sleep(3)
                continue
            try:
                # текущее время берем без милисекунд
                timeNow = datetime.datetime.strptime(
                    datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S') - datetime.timedelta(seconds=5)
                # берем следующую секунду, т.к. фильтр собьытий работает включительно
                timeFrom = self.configEventTime.get_last_time_event() + datetime.timedelta(seconds=1)
                timeDeltaEvent = timeNow - timeFrom
                if timeDeltaEvent.seconds == 0 or timeDeltaEvent.days < 0:
                    time.sleep(sleepSeconds)
                    continue
                needTimeSleep = True
                if timeDeltaEvent > datetime.timedelta(seconds=readSeconds):
                    # читаем по 30 секунд
                    timeTo = timeFrom + datetime.timedelta(seconds=readSeconds)
                    needTimeSleep = False
                else:
                    timeTo = timeNow
                self.logger.info('read events from %s to %s' % (timeFrom.strftime("%m-%d %H:%M:%S"),
                                                                timeTo.strftime("%m-%d %H:%M:%S")))
                reply = orionItgSrv.service.GetEvents(timeFrom, timeTo, eventTypes)
            except Exception as e:
                self.logger.error(u'Ошибка чтения событий из Орион Про: %s' % e.message)
                time.sleep(sleepSeconds)
                continue
            if reply.Success == True:
                data = structures.TEventToDict(reply.OperationResult)
                for i in data:
                    self.__evHandler(json.dumps(i))
                self.configEventTime.set_last_time_event(timeTo)
                if needTimeSleep:
                    time.sleep(sleepSeconds)
            else:
                self.logger.info(u'События из Орион Про не считаны: %s' % reply.ServiceError.ErrorCode + ', text: ' + reply.ServiceError.InnerExceptionMessage)
                time.sleep(sleepSeconds)

        self.logger.info('Event sender stopped')


class AsyncCommandRunner(threading.Thread):
    def __init__(self, callbackHandler, logger, stop_event):
        threading.Thread.__init__(self)
        self.__logger = logger
        self.__callbackHandler = callbackHandler
        self.__cmdQue = collections.deque()
        self.__stop_event = stop_event

    def run(self):
        self.__logger.info('Start Async Command executor')
        while not self.__stop_event.is_set():
            try:
                asyncCmd = self.__cmdQue.popleft()
                cmd = Command(asyncCmd['param'])
                data = cmd()
                self.__logger.info('Async command %s execute successfully' % asyncCmd['cmd'])
                self.__callbackHandler({
                    'EventTypeId': 'async_result',
                    'command': asyncCmd['cmd'],
                    'result': 'ok',
                    'data': data})
            except IndexError:
                time.sleep(0.5)
                pass
            except Exception as e:
                self.__callbackHandler({
                    'EventTypeId': 'async_result',
                    'command': asyncCmd['cmd'],
                    'result': 'error',
                    'data': e.message
                })
                self.__logger.exception('DRIVER: failed run %s async command: %s' % (
                    asyncCmd['cmd'] if 'cmd' in asyncCmd else 'Unknown', e.message))

    def add_cmd(self, cmd):
        self.__cmdQue.append({'param': cmd, 'cmd': cmd['cmd']})


class DriverOrion:
    """Драйвер Orion, реализующий интерфейс взаимодействия с Orion PRO"""

    def __init__(self, eventHandler, stateHandler):
        self.logger = logging.getLogger('__main__.orionDrv')
        self.logger.info('Driver: init')
        self.portsEventHandler = eventHandler
        self.portsStateHandler = stateHandler
        self.eventS = eventSender(self.portsEventHandler)
        self.eventS.start()
        self.__stopAsyncThread = threading.Event()
        self.__asyncThread = AsyncCommandRunner(self.portsEventHandler, self.logger, self.__stopAsyncThread)
        self.__asyncThread.start()

        #sys.path.append(os.getcwd().replace('\\orionintgrsrv',''))
        #print(sys.path)

    def connect(self):
        """Подключение к устройству"""
        self.logger.info("Driver: connect")
        self.eventHandler(json.dumps({'Orion': 'connect'}))
        return {"status": "ok"}

    def disconnect(self):
        "Отключение от устройства"
        return {"status": "ok"}

    def sendCommand(self, params):
        "Посылка комманды Orion обработчику"
        try:                        # т.к. опрос событий ведеться достаточно часто , то он же заменяет пинг
            if self.eventS.OISok:   # в случае получения от процесса ошибки соединения с СИО получим False
                if (params['cmd'] in ['OISReadAccessLevels', 'OISReadPersonList',
                                      'OISReadKeyList', 'OISGetTimeWindows']):
                    sender = sender_for_al(self.eventHandler, params['cmd'], params['id'] if 'id' in params else None)
                    sender.start()
                    return {'status': 'ok'}
                else:
                    if params.get('async', False):
                        self.__asyncThread.add_cmd(params)
                        return {'status': 'async_ok', 'cmd': params['cmd']}
                    else:
                        cmd = Command(params)
                        data = cmd()
                        if 'ext_id' in data:
                            self.eventHandler({
                                "EventTypeId": 'data_to_server',
                                'event': '',
                                "info_ext_id": json.dumps({
                                    'ext_id': data['ext_id'],
                                    'params': params['permit']['SubjectID']
                                })
                            })
                        return data
            else:
                self.logger.warning('DRIVER: failed run command: '+params['cmd']+' no connection to OIS.')
                return {'status': 'fail', 'res': u'Нет соединения с модулем интеграции'}
        except Exception as e:
            self.logger.error('DRIVER: failed run command:'+params['cmd'], exc_info=True)

    def eventHandler(self, evt):
        "Обработчик событий от Orion"
        self.logger.info('Driver: %.300s%s' % (evt, '...' if len(str(evt)) > 300 else ''))
        self.portsEventHandler(evt)
        return 0

    def stateHandler(self, evt):
        "Обработчик состояний устройств Orion"
        self.logger.info('Driver: %.300s%s' % (evt, '...' if len(str(evt)) > 300 else ''))
        self.portsStateHandler(evt)
        return 0
