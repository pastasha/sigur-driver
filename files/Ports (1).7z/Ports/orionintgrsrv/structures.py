# -*- coding: utf-8 -*-

# dataTypes словарь, где укзаны структуры данных и необходимые типы данных, для конвертации
# createDataType - создание структур данных для RPC сервера, парамеетры ссылка на подключение, тип данных, и словарь с
# данными для заполнения структуры, если данные не указаын создана будет пустая структура


import logging
import datetime

log = logging.getLogger('__main__.orionDrv.cmd.structures')
todayT = str(type(datetime.datetime.now()))

# основные типы данных из wsdl, если ожидатеся массив то в конце типа приписываем []
dataTypes = {
    "TEventType": {
        "Id": "int",
        "CharId": "str",
        "Description": "str",
        "Comments": "str",
    },
    "TEvent": {
        "EventId": "str",
        "EventTypeId": "int",
        "EventDate": todayT,
        "Description": "str",
        "ComputerId": "int",
        "ComPortNumber": "int",
        "PKUAddress": "int",
        "DevAddress": "int",
        "ZoneAddress": "int",
        "AccessPointId": "int",
        "AccessPointName": "str",
        "AccessZoneId": "int",
        "PassMode": "int",
        "CardNo": "str",
        "PersonId": "int",
        "LastName": "str",
        "FirstName": "str",
        "MiddleName": "str",
        "BirthDate": todayT,
        "TabNum": "str",
        "ItemType": "str",
        "SectionId": "int",
    },
    "TAccessLevel": {
        "Id": "int",
        "Name": "str",
        "Description": "str",
        "Items": "TAccessLevelItem[]",  # array of
    },
    "TAccessLevelItem": {
        "ItemType": "int",
        "ItemId": "int",
        "TimeWindowId": "int",
        "Antipassback": "int",
        "LockTime": "int",
        "IsZonalAntipassback": "bool",
        "DoubleConfirmationId": "int",
        "TripleConfirmationId": "int",
        "IsConfirming": "bool",
        "IsConfirmationButton": "bool",
    },
    "TAccessZone": {
        "Id": "int",
        "Name": "str",
    },
    "TEntryPoint": {
        "Id": "int",
        "Name": "str",
    },
    "TPersonData": {
        "Id": "int",
        "LastName": "str",
        "FirstName": "str",
        "MiddleName": "str",
        "BirthDate": todayT,
        "Birthplace": "str",
        "Company": "str",
        "Department": "str",
        "Position": "str",
        "Address": "str",
        "TabNum": "str",
        "Phone": "str",
        "Photo": "base64Binary",
        "AccessLevelId": "int",
        "Status": "int",
        "ContactIdIndex": "int",
        "IsLockedDayCrossing": "bool",
        "IsFreeShedule": "bool",
        "ExternalId": "int",
        "CompanyId": "int",
        "DepartmentId": "int",
        "PositionId": "int",
        "DocumentType": "int",
        "DocumentIssueDate": todayT,
        "DocumentEndingDate": todayT,
        "DocumentIsser": "str",
        "DocumentIsserCode": "str",
        "Sex": "int",
        "IsInBlackList": "bool",
        "IsDismissed": "bool",
        "BlackListComment": "str",
        "ArchivingTimeStamp": todayT,
    },
    "TCompany": {
        "Id": "int",
        "Name": "str",
        "Address": "str",
        "Phone": "str",
    },
    "TDepartment": {
        "Id": "int",
        "Name": "str",
        "Description": "str",
        "CompanyId": "int",
        "AccessLevelId": "int",
    },
    "TPosition": {
        "Id": "int",
        "Name": "str",
    },
    "TTImeWindow": {
        "Id": "int",
        "Name": "str",
        "Calendar": "bool[]",  # binary calendar code
        "TimeIntervals": "TTimeInterval[]",  # array of
    },
    "TTimeInterval": {
        "StartTime": todayT,
        "EndTime": todayT,
        "Days": "bool[]",
        "IsEnterActivity": "bool",
        "IsExitActivity": "bool",
        "IsAccessSaturday": "bool",
        "IsAccessSunday": "bool",
        "IsAccessHoliday": "bool",
    },
    "TKeyData": {
        "Code": "int",
        "CodeType": "str",
        "IsInStopList": "bool",
        "PersonId": "int",
        "AccessLevelId": "int",
        "StartDate": todayT,
        "EndDate": todayT,
        "IsBlocked": "bool",
        "IsStoreInDevice": "bool",
        "IsStoreInS2000": "bool",
    },
    "TComPort": {
        "Id": "int",
        "Number": "int",
        "ComputerId": "int",
    },
    "TComputer": {
        "Id": "int",
        "Ip": "str",
        "Name": "str",
    },
    "TDevice": {
        "Id": "int",
        "Address": "int",
        "DevType": "int",
        "Name": "str",
        "ComPortId": "int",
        "PKUId": "int",
    },
    "TDeviceItem": {
        "Id": "int",
        "Name": "str",
        "DeviceId": "int",
        "ItemType": "str",
        "Address": "int",
    },
    "TSection": {
        "Id": "int",
        "Number": "int",
        "Name": "str",
        "ComputerId": "int",
    },
    "TSectionsGroup": {
        "Id": "int",
        "Number": "int",
        "Name": "str",
        "ComputerId": "int",
    },
    "TItemState": {
        "ItemType": "str",
        "ItemId": "int",
        "State": "int",
        "ComputerId": "int",
        "OwnerId": "int",
        "TimeStamp": todayT,
    },
}
# TODO написать функцию парсинга wsdl'ки с типами данных и функцию конвертации по созданному словарю  а пока используем созданный ранее dataTypes словарик
defaultData = {'str': '', 'int': 0, 'bool': False}


# создает тип данных, заполняет информацией из переданного словаря, можно бы дописать функцию конвертации данных
def createDataType(client, dataType, data=None):
    log.info('Creating %s' % dataType)
    if dataType not in dataTypes:
        log.error('Invalid data type %s' % dataType)
        return False
    resp = (client.factory.create('ns4:%s' % dataType))
    if (data != None):
        for i in data.keys():
            if hasattr(resp, i):
                if (dataTypes[dataType][i][0] == 'T'):
                    if '[]' == dataTypes[dataType][i][-2:]:
                        resp[i] = []
                        for t in data[i]:
                            resp[i].append(createDataType(client, dataTypes[dataType][i][:-2], t))
                    else:
                        resp[i] = (createDataType(client, dataTypes[dataType][i][:-2], t))
                else:
                    if '[]' == dataTypes[dataType][i][-2:]:
                        resp[i] = []
                        for t in data[i]:
                            try:
                                if dataTypes[dataType][i][:-2] in defaultData and data[i] == '':
                                    resp[i].append(defaultData[dataTypes[dataType][i][:-2]])
                                else:
                                    # здесь должна бы быть функция конвертации
                                    resp[i].append(t)
                            except:
                                resp[i].append(t)
                                log.warning(
                                    'failed convert to "%s", set default value' % (dataTypes[dataType][i][:-2]))
                    else:
                        try:
                            if dataTypes[dataType][i] in defaultData and data[i] == '':
                                resp[i] = defaultData[dataTypes[dataType][i]]
                            else:
                                # здесь должна бы быть функция конвертации
                                resp[i] = data[i]
                        except:
                            resp[i] = dataTypes[dataType][i]
                            log.warning('failed convert to "%s", set default value' % (dataTypes[dataType][i]))
            else:
                log.warning('%s have no attr "%s"' % (dataType, i))
    else:
        log.info('Empty struct created')
    log.info('Finished  %s' % dataType)
    return resp


# конвертация в словари
def TAccessLevelToDict(data):
    resp = []
    for i in data:
        try:
            name = i.Name.encode('utf-8')
        except:
            name = i.Name
        resp.append({
            'id': i.Id,
            'name': name,
            'desc': i.Description,
            'items': [{'type': z.ItemType,
                      'id': z.Id,
                      'item_id': z.ItemId,
                      'timeWID': z.TimeWindowId,
                      'apback': z.Antipassback,
                      'lTime': z.LockTime,
                      'apbackZonal': z.IsZonalAntipassback,
                      'dConf': z.DoubleConfirmationId,
                      'tConf': z.TripleConfirmationId,
                      'isConf': z.IsConfirming,
                      'isConfB': z.IsConfirmationButton,
                      'rights': z.Rights} for z in i.Items if str(z.ItemType) in ['ACCESSZONE', 'ACCESSPOINT']],
        })

    return resp


def TEventToDict(data):
    resp = []
    for i in data:
        try:
            try:
                eventDate = i.EventDate.strftime('%Y-%m-%d %H:%M:%S')
            except:
                eventDate = datetime.datetime.now()
            try:
                bDate = i.BirthDate.strftime('%Y-%m-%d %H:%M:%S')
            except:
                bDate = '2010-01-01 01:01:01'
            try:
                descr = i.Description.encode('utf-8')
            except:
                descr = i.Description
            try:
                lname = i.LastName.encode('utf-8')
            except:
                lname = i.LastName
            try:
                mname = i.MiddleName.encode('utf-8')
            except:
                mname = i.MiddleName
            try:
                fname = i.FirstName.encode('utf-8')
            except:
                fname = i.FirstName
            resp.append({
                'EventId': i.EventId,
                'EventTypeId': i.EventTypeId,
                'EventDate': eventDate,
                'Description': descr,
                'ComputerId': i.ComputerId,
                'ComPortNumber': i.ComPortNumber,
                'PKUAddress': i.PKUAddress,
                'DevAddress': i.DevAddress,
                'ZoneAddress': i.ZoneAddress,
                'ItemType': i.ItemType,
                'AccessPointId': i.AccessPointId,
                'AccessZoneId': i.AccessZoneId,
                'SectionId': i.SectionId,
                'PassMode': i.PassMode,
                'CardNo': i.CardNo,
                'PersonId': i.PersonId,
                'LastName': lname,
                'FirstName': fname,
                'MiddleName': mname,
                'BirthDate': bDate,
                'TabNum': i.TabNum
            })
        except:
            resp.append({'error': 'Failed convert data from event - %s' % i.EventId})
            continue
    return resp


def accItemsToDict(data):
    resp = {}
    for i in data:
        try:
            resp[str(i.Id)] = i.Name
        except:
            log.error('Error in accItemsToDict', exc_info=True)
            continue
    return resp


def twindow_to_dict(data):
    resp = [{'id':z.Id, 'name':z.Name} for z in data]
    return resp


