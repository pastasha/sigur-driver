# -*- coding: utf-8 -*-
from settings import setting
from datetime import datetime
from datetime import timedelta
import os
import sys
import time


class orionintgrsrvConfig:
    def __init__(self):
        self.tns = ['urn:Soap.InvokeRegistry','http://www.borland.com/namespaces/Types','urn:OrionProIntf']
        self.urlDict = {
            'IOrionProCompat': 'http://' + str(setting['orionintgrsrv']['hostsend']) + ':' +
                                          str(setting['orionintgrsrv']['portsend']) + '/wsdl/IOrionProCompat',
            'IOrionPro': 'http://' + str(setting['orionintgrsrv']['hostsend']) + ':' +
                                          str(setting['orionintgrsrv']['portsend']) + '/wsdl/IOrionPro',
            'IWSDLPublish': 'http://'+ str(setting['orionintgrsrv']['hostsend']) + ':' +
                                          str(setting['orionintgrsrv']['portsend']) + '/wsdl/IWSDLPublish'
        }
        self.hostsend = setting['orionintgrsrv']['hostsend']
        self.portsend = setting['orionintgrsrv']['portsend']
        self.user = setting['orionintgrsrv']['user'] if ('user' in setting['orionintgrsrv'] and setting['orionintgrsrv']['user'] != '') else None
        self.password = setting['orionintgrsrv']['pass'] if ('pass' in setting['orionintgrsrv'] and setting['orionintgrsrv']['pass'] != '') else None
        
        self.wsdlFile = os.path.dirname(os.path.realpath(__file__)) + "\\wsdl\\schemas.xmlsoap.org.xml"
        if getattr(sys, 'frozen', False):
            self.wsdlFile = os.path.dirname(sys.executable)+'\\wsdl\\schemas.xmlsoap.org.xml'


class EventTimeSave:
    def __init__(self):
        self.eventSaveFile = os.path.dirname(os.path.realpath(__file__)) + "\\lastevent.save"
        if getattr(sys, 'frozen', False):
            self.eventSaveFile = os.path.dirname(sys.executable) + "\\lastevent.save"
        self.__read_last_time_event()

    def get_last_time_event(self):
        return self.lastTimeEvent
    
    def set_last_time_event(self, timeEvent):
        self.lastTimeEvent = timeEvent
        self.__save_last_time_event()
        
    def __save_last_time_event(self):
        try:
            with open(self.eventSaveFile,'w',0) as file:
                file.write(str(time.mktime(self.lastTimeEvent.timetuple())))
        except Exception as e:
            print u'Ошибка сохранения отметки времени получения событий: %s' % repr(e)
            
    def __read_last_time_event(self):
        try:
            with open(self.eventSaveFile,'r',0) as file:
                s=file.read()
                self.lastTimeEvent = datetime.fromtimestamp(float(s))
        except Exception as e:
            print u'Не удалось прочитать файл %s времени получения событий(ошибка %s)' % (self.eventSaveFile, repr(e))
            self.lastTimeEvent = datetime.now() - timedelta(seconds=5)
