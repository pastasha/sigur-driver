# -*- coding: utf-8 -*-

from command import OrionItgSrvService

wsdlfile = 'E:\\Git\\_server_work\\server\\Ports\\orionintgrsrv\\wsdl\\schemas.xmlsoap.org.xml'
urlSoap = 'http://127.0.0.1:8095/wsdl/IOrionProCompat'
tns = ['urn:Soap.InvokeRegistry', 'http://www.borland.com/namespaces/Types', 'urn:OrionProIntf']
user = 'admin1'
password = 'admin1'


srv = OrionItgSrvService(wsdlfile, urlSoap,tns, user, password)

res = srv.service.GetAccessZones()

print (res)
print ('---------------------------------')
print (srv.service.GetEntryPoints())