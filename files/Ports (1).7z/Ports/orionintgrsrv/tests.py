# -*- coding: utf-8 -*-

#тесты для драйвера Модуля интеграции Орион Про

from driver import DriverOrion
import json
import unittest
import logging, logging.config
import time

logging_config = dict(
    version = 1,
    formatters = {
        'f': {'format':
              '%(asctime)s %(name)-12s %(levelname)-8s %(message)s'}
        },
    handlers = {
        'h': {'class': 'logging.StreamHandler',
              'formatter': 'f',
              'level': logging.DEBUG}
        },
    root = {
        'handlers': ['h'],
        'level': logging.DEBUG,
        },
)

class TestOrionMethods(unittest.TestCase):

    def setUp(self):
        logging.config.dictConfig(logging_config)
        self._driver = DriverOrion(self.__eventHandler, self.__stateHandler)
        self._driver.connect()
        while not self._driver.eventS.OISok:
            time.sleep(1)

    def test_ReadAL(self):
        command = {
            'cmd': 'OISImportAccessLevel',
            'id' : 1
        }
        result = self._driver.sendCommand(command)
        self.assertEqual(result["status"], "ok")
        result = self._driver.disconnect()
        self.assertEqual(result["status"], "ok")



    def __eventHandler(self, evt):
        "Обработчик событий от устройства"
        if isinstance(evt, dict):
            evt = json.dumps(evt)
        print "event: %s"%evt


    def __stateHandler(self, evt):
        "Обработчик состояний объектов устройства"
        if isinstance(evt, dict):
            evt = json.dumps(evt)
        print "state: %s" % evt

if __name__ == '__main__':
    unittest.main()