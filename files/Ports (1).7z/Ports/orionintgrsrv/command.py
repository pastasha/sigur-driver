# -*- coding: utf-8 -*-
import sys

import requests
from suds import options
from suds.options import Options
from suds.reader import DefinitionsReader
from suds.transport import TransportError
from suds.transport.http import HttpTransport
from suds.wsdl import Definitions

from wiegandcard import CardCode
from config import orionintgrsrvConfig
from suds.xsd.doctor import Import
from suds.xsd.doctor import ImportDoctor
from suds.client import Client
from suds.wsse import Security, UsernameToken
import logging
import urlparse
import urllib
import datetime
import time
import json
import structures #все действия со структурами и преоразованиями данных
import base64
import urllib2
from suds.transport.https import HttpAuthenticated
from suds.cache import NoCache


class HttpAuthenticated(HttpTransport):
    """
    Provides basic HTTP authentication for servers that do not follow the
    specified challenge/response model. Appends the I{Authorization} HTTP
    header with base64 encoded credentials on every HTTP request.
    """

    def open(self, request):
        self.addcredentials(request)
        try:
            url = request.url
            u2request = urllib2.Request(url=url, headers=request.headers)
            self.proxy = self.options.proxy
            return self.u2open(u2request)
        except urllib2.HTTPError, e:
            raise TransportError(str(e), e.code, e.fp)

    def send(self, request):
        self.addcredentials(request)
        return HttpTransport.send(self, request)

    def addcredentials(self, request):
        credentials = self.credentials()
        if None not in credentials:
            credentials = ':'.join(credentials)
            if sys.version_info < (3, 0):
                encodedString = base64.b64encode(credentials)
            else:
                encodedBytes = base64.urlsafe_b64encode(credentials.encode())
                encodedString = encodedBytes.decode()
            request.headers['Authorization'] = 'Basic %s' % encodedString

    def credentials(self):
        return self.options.username, self.options.password

class OrionItgSrvService(object):
    def __init__(self, wsdlFile, urlSoap, tns, user=None, passwd=None):
        self.httpauth = True if (user and passwd) else False
        self.user = user if user else None
        self.passwd = passwd if passwd else None
        self.encrypt = False
        self.url = urlparse.urljoin('file:', urllib.pathname2url(wsdlFile))
        imp = Import(self.url, self.url)
        for i in tns:
            imp.filter.add(i)

        if self.httpauth:
            try:
                t = HttpAuthenticated(username=self.user, password=self.passwd)
                self.ws_client = Client(url=urlSoap, transport=t, cache=NoCache(), doctor=ImportDoctor(imp))
            except Exception as e:
                import traceback
                traceback.print_exc()

        else:
            self.ws_client = Client(url=urlSoap,cache=NoCache(), plugins=[ImportDoctor(imp)])
        self.service = self.ws_client.service
        self.factory = self.ws_client.factory

    def set_wsse(self):
        ''' Basic ws-security auth '''
        security = Security()

        if self.encrypt:
            pass
            #не реализовано
            #token = UsernameDigestTokenDtDiff(
            #    self.user, self.passwd, dt_diff=self.dt_diff)
        else:
            token = UsernameToken(self.user, self.passwd)
            token.setnonce()
            token.setcreated()

        security.tokens.append(token)
        return security
    

def getResult(status, res=None):
    return {"status" : status, "res": res}


class Command:
    def mapParams(self):
        '''Преобразование параметров команды в переменные класса'''
        self.acc_lvl_comment = ''
        '''TODO refactoring variable name'''
        if 'permit' in self.params:
            data = self.params['permit']
        else:
            data = self.params

        self.postName = data.get('postName', '')
        self.uid = data.get('uid', '')
        self.CompanyId = data.get('CompanyId', '')
        self.Address = data.get('Address', '')
        self.Phone = data.get('Phone', '')
        self.HomePhone = data.get('HomePhone', '')
        if 'Name' in data:
            names = data['Name'].split(' ')
            if len(names) == 0:
                names = [' ', ' ', ' ']
            self.name = names[0]
            if len(names) == 1:
                self.name2 = ''
                self.name3 = ''
            elif len(names) == 2:
                self.name2 = names[1]
                self.name3 = ' '
            elif len(names) > 2:
                self.name2 = names[1]
                self.name3 = ' '.join(names[2:])
            self.shortName = '%s %s. %s.' % (self.name, self.name2[:1], self.name3[:1])
        else:
            self.name = ''
            self.name2 = ''
            self.name3 = ''

        if 'BirthDay' in data:
            self.bday = datetime.datetime.strptime(data['BirthDay'], '%Y-%m-%d')
        self.accLvlID = data.get('accLvlId', '')

        if 'StartTime' in data:
            startstamp = data['StartTime']
            if startstamp < 978307200:
                startstamp = 978307200
            self.start = datetime.datetime.fromtimestamp(startstamp)

        if 'EndTime' in data:
            endstamp = data['EndTime']
            if endstamp < 978307200:
                endstamp = 978307200
            self.end = datetime.datetime.fromtimestamp(endstamp)
        # Cпециально, копирования даты окончания действия пропуска в поле день рождения, чтобы можно было показать в
        # Перс. карт.
        if hasattr(self,'end'):
            self.bday = self.end

        employeeNumber = data.get('employeeNumber', '')
        if employeeNumber.isdigit() and int(employeeNumber) != 0:
            self.tabelNumber = employeeNumber
        else:
            self.tabelNumber = ''

        if 'SubjectID' in data:
            self.esmUID = data['SubjectID']

        self.ExtID = data.get('ExtID', '')
        self.orgName = data.get('Org', '')
        self.departName = data.get('Department', '')
        self.postName = data.get('Post', '')

        # if 'ScheduleID' in data:
        #    self.scheduleid = data['ScheduleID']
        # Сделано чтобы график работы сотрудника всегда был Графиком работы подразделения
        self.scheduleid = 0

        if 'GroupID' in data:
            self.groupid = data['GroupID']
        else:
            self.groupid = []
        # enum(Создан = 0, Активирован = 1, Деактивирован = 2, Заблокирован = 3)
        if 'State' in data:
            self.permitState = data['State']

        self.dismissed = data.get('dismissed', '')
        self.blockcomment = data.get('blockcomment', '')
        #в поле Адрес записываем комментарий блокировки, если пропуск заблокирован
        if self.blockcomment != '':
            self.Address = self.blockcomment

        if 'stop' in data:
            self.stoplist = data['stop']
        else:
            self.stoplist = False
        if 'addKeyString' in data:
            self.addKeyString = data['addKeyString']

        if 'Photo' in data:
            self.photo = data['Photo']

        if 'BirthPlace' in data:
            self.BirthPlace = data['BirthPlace']

        if 'items' in data:
            self.accessLevelItems = data['items']

        self.comment = data.get('comment', '')

        if 'forceupdatePers' in data:
            self.forceupd = True
        else:
            self.forceupd = False

        self.DocType = 0 #всегда паспорт
        self.DocSeries = ''
        if 'DocSeries' in data:
            self.DocSeries = data['DocSeries']
        self.DocNumber = ''
        if 'DocNumber' in data:
            self.DocNumber = data['DocNumber']
        self.Issuer = ''
        if 'Issuer' in data:
            self.Issuer = data['Issuer']
        self.IssueDate = datetime.datetime.strptime('1899-12-30 00:00:00', '%Y-%m-%d %H:%M:%S')
        if 'IssueDate' in data:
            try:
                iDate = int(data['IssueDate'])
                self.IssueDate = datetime.datetime.fromtimestamp(iDate)
            except:
                pass

        if 'cmd' in data and data['cmd'] == 'OISCreateAccessLevel':
            self.acc_lvl_comment = data['comment']
            self.AccLvlName = data['name']
            self.items_data = data['items']

        if 'cmd' in data and data['cmd'] == 'OISUpdateAccessLevel':
            self.acc_lvl_comment = data['comment']
            self.AccLvlName = data['name']
            self.items_data = data['items']
            self.acc_lvl_id = data['id']

        if 'cmd' in data and data['cmd'] == 'OISDeleteAccessLevel':
            self.acc_lvl_comment = ''
            self.AccLvlName = ''
            self.items_data = ''
            self.acc_lvl_id = data['Id']

        if 'cmd' in data and data['cmd'] == 'OISImportAccessLevel':
            self.acc_lvl_comment = ''
            self.AccLvlName = ''
            self.items_data = ''
            self.acc_lvl_id = data['id']

    def OISReadOrgList(self):
        '''Чтение списка организаций'''
        try:
            self.logger.info("CMD: run OISReadOrgList")
            reply = self.orionItgSrv.service.GetCompanies()
            if reply.Success:
                res = [{
                    'ID': str(i.Id),
                    'Name': i.Name
                } for i in reply.OperationResult]
                return {
                    "status": "ok",
                    "arrayOrg": json.dumps(res)
                }
            else:
                self.logger.error("CMD: OISReadPersonList error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: CSOReadOgr Error", exc_info=True)
            return getResult('error', repr(e))

    def OISReadPostList(self):
        '''Чтение списка должностей'''
        self.logger.info("CMD: run CSOReadPost")
        try:
            reply = self.orionItgSrv.service.GetPositions()
            if reply.Success:
                res = [{
                    'ID': i.Id,
                    'Name': i.Name
                } for i in reply.OperationResult]
                return {
                    "status": "ok",
                    "arrayPost"	: json.dumps(res)
                }
            else:
                self.logger.error("CMD: OISReadPersonList error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: CSOReadPost Error", exc_info=True)
            return getResult('error', repr(e))

    def OISReadDepList(self):
        '''Чтение списка подрадеделений'''
        self.logger.info("CMD: run OISReadDepList")
        try:
            reply = self.orionItgSrv.service.GetDepartments()
            if reply.Success:
                departs = reply.OperationResult
                res = [{
                    'ID': i.Id,
                    'Name': i.Name,
                    'GroupID': i.AccessLevelId,
                    'GrName': ''
                } for i in departs]
                return {
                    "status": "ok",
                    "arrayDep"	: json.dumps(res)
                }
            else:
                self.logger.error("CMD: OISReadPersonList error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: OISReadDepList Error", exc_info=True)
            return getResult('error', repr(e))

    def OISGetEntryPoints(self):
        '''Чтение списка точек доступа'''
        self.logger.info("CMD: run OISGetEntryPoints")
        try:
            reply = self.orionItgSrv.service.GetEntryPoints()
            if reply.Success == True:
                res = [{
                    'ID': i.Id,
                    'Name': i.Name
                } for i in reply.OperationResult]
                return {
                    "status": "ok",
                    "arrayPoints"	: json.dumps(res)
                }
            else:
                self.logger.error("CMD: OISGetEntryPoints error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: OISGetEntryPoints Error", exc_info=True)
            return getResult('error', repr(e))

    def OISGetAccessZones(self):
        '''Чтение списка точек доступа'''
        self.logger.info("CMD: run OISGetAccessZones")
        try:
            reply = self.orionItgSrv.service.GetAccessZones()
            if reply.Success == True:
                res = [{
                    'ID': i.Id,
                    'Name': i.Name
                } for i in reply.OperationResult]
                return {
                    "status": "ok",
                    "arrayZones"	: json.dumps(res)
                }
            else:
                self.logger.error("CMD: OISGetAccessZones error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: OISGetAccessZones Error", exc_info=True)
            return getResult('error', repr(e))

    def addUser(self):
        if self.orgName == '':
            self.logger.error('No assigned organization')
            return{'status':'error', 'res': u'Не задана организация'}
        self.logger.info("CMD: addUser start")
        try:
            res = self.orionItgSrv.factory.create('ns4:TPersonData')
            res.Id = 0  # int
            res.FirstName = self.name2  # str
            res.MiddleName = self.name3  # str
            res.LastName = self.name  # str
            res.BirthDate = self.bday  # DateTime yyyy-mm-dd
            res.CompanyId = 0#int(self.orgId)  # int
            res.DepartmentId = 0#int(self.departId)  # int
            res.PositionId = 0#int(self.postId)  # int
            res.Company = self.orgName
            res.Department = self.departName
            res.Position = self.postName[:80] # в БД Орион имеется ограничение
            res.Address = self.Address
            res.TabNum = self.tabelNumber# if self.tabelNumber != '' else 0
            res.Photo = self.photo  # byte[]
            res.Phone = self.Phone
            res.AccessLevelId = self.scheduleid
            res.ExternalId = self.esmUID
            res.Status = 6
            res.ContactIdIndex = 0  # int
            res.IsLockedDayCrossing = False  # bool
            res.IsFreeShedule = False  # bool
            res.DocumentType = 0
            res.DocumentSerials = self.DocSeries
            res.DocumentNumber = self.DocNumber
            res.DocumentIssueDate = self.IssueDate
            res.DocumentEndingDate = datetime.datetime.strptime('1899-12-30 00:00:00', '%Y-%m-%d %H:%M:%S')
            res.DocumentIsser = self.Issuer
            res.Birthplace = self.BirthPlace
            #res.DocumentIsserCode= ''
            res.ArchivingTimeStamp = None
            res.Sex = 0
            res.IsInBlackList = False if self.blockcomment == '' else True
            res.IsDismissed = False if self.dismissed == '' else True
            res.DismissedComment = self.dismissed
            res.BlackListComment = self.blockcomment
            reply = self.orionItgSrv.service.AddPerson(res)
            if reply.Success == True:
                self.logger.info(u'added user success with id: %s'% reply.OperationResult.Id)
                self.uid = reply.OperationResult.Id
            else:
                self.logger.info(u'addUser ERROR : %s'% reply.ServiceError.ErrorCode + ', text: ' + reply.ServiceError.InnerExceptionMessage)
                if 'TabNumber' in reply.ServiceError.InnerExceptionMessage:
                    t_pers_data = self.orionItgSrv.service.GetPersonByTabNumber(int(self.tabelNumber)).OperationResult
                    if (t_pers_data.LastName+' '+t_pers_data.FirstName+' '+t_pers_data.MiddleName) == (self.name+' '+self.name2+' '+self.name3) :
                        self.uid = t_pers_data.Id
                        self.updateUser()
                        return self.uid
                    self.uid = {'tabNumErr':t_pers_data}
                else:
                    self.logger.error("CMD: addUser error: " + reply.ServiceError.InnerExceptionMessage)
                    return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except Exception as e:
            self.logger.error("CMD: addUser Error", exc_info=True)
            return getResult('error', repr(e))
        self.logger.info("CMD: addUser finished")
        return self.uid

    def updateUser(self):
        self.logger.info("CMD: updateUser start")
        try:
            if self.forceupd:
                res = self.orionItgSrv.service.GetPersonById(self.ExtID).OperationResult
                res.ExternalId = self.esmUID
                reply = self.orionItgSrv.service.UpdatePerson(res)
                return {"status": "ok"}
            else:
                userId = self.uid if self.uid != '' else self.ExtID
                res = self.orionItgSrv.factory.create('ns4:TPersonData')
                res.Id = userId  # int
                res.FirstName = self.name2  # str
                res.MiddleName = self.name3  # str
                res.LastName = self.name  # str
                res.BirthDate = self.bday  # DateTime yyyy-mm-dd
                res.CompanyId = 0 # int(self.orgId)  # int
                res.DepartmentId = 0 # int(self.departId)  # int
                res.PositionId = 0  # int(self.postId)  # int
                res.Company = self.orgName
                res.Department = self.departName
                res.Position = self.postName
                res.Address = self.Address
                res.TabNum = self.tabelNumber if self.tabelNumber != '' else 0
                res.Photo = self.photo  # byte[]
                res.Phone = self.Phone
                res.AccessLevelId = self.scheduleid
                res.ExternalId = self.esmUID
                res.Status = 6
                res.ContactIdIndex = 0  # int
                res.IsLockedDayCrossing = False  # bool
                res.IsFreeShedule = False  # bool
                res.DocumentType = 0
                res.DocumentSerials = self.DocSeries
                res.DocumentNumber = self.DocNumber
                res.DocumentIssueDate = self.IssueDate
                res.Birthplace = self.BirthPlace
                res.DocumentEndingDate = datetime.datetime.strptime('1899-12-30 00:00:00', '%Y-%m-%d %H:%M:%S')
                res.DocumentIsser = self.Issuer
                # res.DocumentIsserCode= ''
                res.ArchivingTimeStamp = None
                res.Sex = 0
                res.IsInBlackList = False if self.blockcomment == '' else True
                res.IsDismissed = False if self.dismissed == '' else True
                res.DismissedComment = self.dismissed
                res.BlackListComment = self.blockcomment
                reply = self.orionItgSrv.service.UpdatePerson(res)
                if reply.Success != True:
                    self.logger.error("CMD: updateUser error: "+reply.ServiceError.InnerExceptionMessage)
                    if 'TabNumber' in  reply.ServiceError.InnerExceptionMessage :
                        self.uid = {
                            'tabNumErr':self.orionItgSrv.service.GetPersonByTabNumber(int(self.tabelNumber)).OperationResult
                        }
                    return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except BaseException:
            self.logger.error('Except updateUser ',exc_info=True)
        self.logger.info("CMD: updateUser finished")
        return None

    def searchAccLvlByItems(self):
        self.logger.info('Search acclvl')
        if len(self.groupid) > 1:
            reply = self.orionItgSrv.service.GetAccessLevels()
            if reply.Success == True:
                for i in reply.OperationResult:
                    if i.Id  in self.groupid:
                        self.logger.info('Find acclvl, id=%s' % i.Id)
                        return i
        elif len(self.groupid) == 1:
            reply = self.orionItgSrv.service.GetAccessLevels()
            if reply.Success == True :
                for i in reply.OperationResult :
                    if i.Id == self.groupid[0]:
                        self.logger.info('Find acclvl, id=%s' % i.Id)
                        return i
            else:
                self.logger.error('Failed to take data from OIS')
                raise Exception('Failed to take data from OIS')
        try:
            self.logger.info('No data to search')
            reply = self.orionItgSrv.service.GetAccessLevels()
            if reply.Success == True:
                for i in reply.OperationResult:
                    if i.Id == 1:
                        return i
        except Exception as e:
            self.logger.error (e.message)
            return False
        return False

    def addCard(self, code):
        self.logger.info("CMD: addCard start")
        try:
            #ищем человека , он уже должен быть создан на этот момент
            if self.uid == self.ExtID == '':
                self.logger.error(u'Частно лицо не найдено, требуется создание нового')
            else:
                #пытаемся найти уровень доступа , если нет подходящего то создаем его

                accLvl = self.groupid[0] if len(self.groupid) >= 1 else 0 #self.searchAccLvlByItems()
                if accLvl == 0:
                    self.logger.info(u'Уровень доступа не задан')
                # проверяем, возможно карта уже существует
                reply = self.orionItgSrv.service.GetKeyData(code)
                if reply.Success == True and reply.OperationResult != None:
                    # если нашли карту, человека то просто обновляем данные по карте
                    self.logger.info(u'Обновльение существующей карты')
                    keyData = reply.OperationResult
                    keyData.AccessLevelId = accLvl
                    keyData.StartDate = self.start
                    keyData.EndDate = self.end
                    keyData.IsBlocked = True if self.permitState == 3 else False
                    keyData.IsStoreInDevice = True if self.permitState == 1 else False
                    keyData.IsInStopList = bool(self.stoplist)
                    reply = self.orionItgSrv.service.UpdateKeyData(keyData)
                    if reply.Success == True:
                        self.logger.info(u'Карта %s успешно обновлениа'%reply.OperationResult.Code)
                    else:
                        self.logger.info(u'Ошибка обновление карты : %s'%reply.ServiceError.InnerExceptionMessage)
                elif reply.Success == True and reply.OperationResult == None:
                    self.logger.info(u'Создание новой карты доступа')
                    reply = self.orionItgSrv.service.GetPersonById(int(self.uid if self.uid!='' else self.ExtID))
                    if reply.Success and reply.OperationResult:
                        persTData = reply.OperationResult
                        aclvl_struct = self.orionItgSrv.factory.create('ns4:TAccessLevel')
                        aclvl_struct.Id = accLvl
                        reply = self.orionItgSrv.service.PutPassWithAccLevels(code, persTData, [aclvl_struct], self.start, self.end)

                        if not reply.Success:
                            str = 'Failed to create key, error %s' % reply.ServiceError.InnerExceptionMessage
                            self.logger.error(str)
                            raise Exception(str)
                    else:
                        str = 'Failed to find person, error %s' % reply.ServiceError.InnerExceptionMessage
                        self.logger.error(str)
                        raise Exception(str)
                elif not reply.Success:
                    str = "CMD: addCard  error "+reply.ServiceError.InnerExceptionMessage
                    self.logger.error(str)
                    raise Exception(str)
        except:
            self.logger.error("CMD: addCard  error",exc_info=True)
            pass
        self.logger.info("CMD: addCard finished")

    def updateCard(self, code):
        self.logger.info("CMD: updateCard start")
        try:
            res = self.orionItgSrv.factory.create('ns4:TKeyData')
            res.Id = 0
            res.Code = code
            res.CodeType = 4
            res.PersonId = int(self.uid if self.uid != '' else self.ExtID)
            res.AccessLevelId = self.groupid[0] if len(self.groupid) > 0 else 0
            res.StartDate = self.start
            res.EndDate = self.end
            res.IsBlocked = True if self.permitState == 3 else False
            res.IsStoreInDevice = True if self.permitState == 1 else False 
            res.IsInStopList = bool(self.stoplist) 
            res.IsStoreInS2000 = False
            print(res)
            reply = self.orionItgSrv.service.UpdateKeyData(res)

            if reply.Success == True:
                self.logger.info("CMD: updateCard success")
            else:
                self.logger.error("CMD: updateCard error: " + reply.ServiceError.InnerExceptionMessage)
                return getResult('error', reply.ServiceError.InnerExceptionMessage)
        except:
            self.logger.error('Except updateCard ', exc_info=True)

        self.logger.info("CMD: updateCard finished")

    def userRegisterAsync(self):
        self.logger.info("CMD: userRegister start")
        self.mapParams()
        if self.orgName == u'':
            return {'status': 'fail', 'res': u'Не задана организация'}
        self.logger.info('company - %s, depart - "%s", post - "%s"'%(self.orgName, self.departName , self.postName))

        if self.esmUID != '':
            reply = self.orionItgSrv.service.GetPersonByExternalId(int(self.esmUID))
            if reply.Success and hasattr(reply.OperationResult, 'ExternalId') \
                and reply.OperationResult.ExternalId and int(reply.OperationResult.ExternalId) == int(self.esmUID):
                self.uid = reply.OperationResult.Id
                self.updateUser()
            elif self.tabelNumber != '':
                reply = self.orionItgSrv.service.GetPersonByTabNumber(self.tabelNumber)
                if reply.Success and hasattr(reply.OperationResult,'ExternalId') \
                            and reply.OperationResult.ExternalId and int(reply.OperationResult.ExternalId) == int(self.esmUID):
                    self.uid = reply.OperationResult.Id
                    self.updateUser()
                else:
                    self.uid = self.addUser()
            else:
                self.uid = self.addUser()
        else:
            self.uid = self.addUser()

        if isinstance(self.uid, dict) and 'tabNumErr' in self.uid:
            tmp = self.uid['tabNumErr']
            return {
                'status':'FAILED',
                'res': 'tabnum',
                'err_data': '%s %s %s' % (tmp.LastName, tmp.FirstName, tmp.MiddleName)
            }

        if isinstance(self.uid, dict) and 'status' in self.uid:
            return {
                'status':'FAILED',
                'res':self.uid['res']
            }

        '''проверка карты и создание'''
        permit = self.params['permit']
        cardCode = CardCode(permit['CardCode']).encode_for_orion()
        userpass = self.orionItgSrv.service.GetKeyData(cardCode).OperationResult
        if userpass is None:
            if self.permitState != 2:
                self.logger.info('No pass in orion, need to add')
                self.addCard(cardCode)
        else:
            if self.permitState != 2: # не деактивирован
                self.logger.info('Pass exists, update')
                self.passid = userpass
                self.actionCard = 1
                self.updateCard(cardCode)
        if self.permitState == 3:  # блокировка
            self.OISBlockCard(cardCode)
        if self.permitState == 2 and userpass is not None:
            self.actionCard = 2  # удаление карты
            self.passid = userpass
            reply =  self.orionItgSrv.service.DeletePass(cardCode)
            if reply.Success == True:
                self.logger.info("CMD: userRegister, key %s deleted"%cardCode)
            else:
                self.logger.warning("CMD: userRegister, key %s drop failed,error : %s "
                                    %(cardCode,reply.ServiceError.InnerExceptionMessage))
                return {"status": "failed"}
        time.sleep(0.01)
        self.logger.info("CMD: userRegister finished")
        # тут все верно так как в uid может быть dict в результате команды addUser
        ret = {"status": "ok","ext_id":self.uid} if isinstance(self.uid, int) else self.uid
        return ret

    # TODO
    def OISDeletePerson(self):
        return

    def OISCreateAccessLevel(self):
        self.logger.info("CMD: OISCreateAccessLevel start")
        acclvl = structures.createDataType(self.orionItgSrv, 'TAccessLevel')
        itemsData = []
        if hasattr(self, 'accessLevelItems'):
            for i in self.accessLevelItems:
                cur_item = structures.createDataType(self.orionItgSrv,'TAccessLevelItem')
                cur_item.ItemType = 'ACCESSPOINT' if i['ItemType'] == 1 else 'ACCESSZONE'
                cur_item.ItemId = i['ItemId']
                cur_item.Id = i['Id']
                cur_item.TimeWindowId = i['TimeWindowId']
                cur_item.Antipassback  = i['Antipassback']
                cur_item.LockTime = i['LockTime']
                cur_item.IsZonalAntipassback = i['IsZonalAntipassback']
                cur_item.DoubleConfirmationId = i['DoubleConfirmationId']
                cur_item.TripleConfirmationId = i['TripleConfirmationId']
                cur_item.IsConfirming = i['IsConfirming']
                cur_item.IsConfirmationButton = i['IsConfirmationButton']
                cur_item.Rights = i['Rights']
                itemsData.append(cur_item)
                self.logger.info(repr(cur_item))

        self.logger.info('Filling struct with data')
        acclvl.Id = 0
        acclvl.Name = self.AccLvlName
        acclvl.Description = self.acc_lvl_comment
        acclvl.Items = itemsData
        reply = self.orionItgSrv.service.CreateAccessLevel(acclvl)
        if reply.Success == True:
            self.acc_lvl_id = reply.OperationResult.Id
            dataAL = self.orionItgSrv.service.GetAccessLevelById(self.acc_lvl_id)
            if not dataAL.Success :
                return getResult('error', dataAL.ServiceError.InnerExceptionMessage)

            if not dataAL.OperationResult:
                return getResult('error', u'Уровень доступа не найден!')
            allAcclvl = dataAL.OperationResult
            res = structures.TAccessLevelToDict([allAcclvl])

            self.logger.info('Success, acclvl created.')
            return {"status": "ok", "acclvl": json.dumps(res)}

        resmsg=u'Ошибка создания уровня доступа: %s' % reply.ServiceError.InnerExceptionMessage
        self.logger.info(resmsg)
        return {"status": "fail", 'res': resmsg}

    # TODO
    def OISCreateTimeWindow(self):
        return

    # TODO
    def OISDeleteTimeWindow(self):
        return

    def OISBlockCard(self,code):
        self.logger.info('Cmd: OISBlockCard start')
        if self.permitState == 3:
            reply = self.orionItgSrv.service.BlockPass(code, 1)
            if reply.Success:
                self.logger.info('Success OISBlockCard')
                return {'success': True, 'res': reply.OperationResult}
            else:
                self.logger.info('Failed OISBlockCard')
                return {'success': False, 'res': reply.ServiceError.InnerExceptionMessage}

    # TODO
    def OISUpdateKey(self):
        return

    # TODO
    def OISCreateKey(self):
        return

    def get_access_level_item_from_list(self, item):
        resItem = self.orionItgSrv.factory.create('ns4:TAccessLevelItem')
        resItem.Id = item['Id'] if 'Id' in item else 0
        resItem.ItemType = item['ItemType']
        resItem.ItemId = item['ItemId']
        resItem.TimeWindowId = item['TimeWindowId']
        resItem.Rights = item['Rights']
        resItem.Antipassback = item['Antipassback']
        resItem.LockTime = item['LockTime']
        resItem.IsZonalAntipassback = item['IsZonalAntipassback']
        resItem.DoubleConfirmationId = item['DoubleConfirmationId']
        resItem.TripleConfirmationId = item['TripleConfirmationId']
        resItem.IsConfirming = item['IsConfirming']
        resItem.IsConfirmationButton = item['IsConfirmationButton']
        return resItem

    def __del_access_level_item_from_db(self, item):
        return self.orionItgSrv.service.DeleteAccessLevelItem(item)

    def OISDeleteAccessLevel(self):
        try:
            res = self.orionItgSrv.service.GetAccessLevelById(int(self.acc_lvl_id))
            if res.Success:
                accLvl = res.OperationResult
                if accLvl:
                    res = self.orionItgSrv.service.DeleteAccessLevel(accLvl)
                    if not res.Success:
                        return getResult("fail",res.ServiceError)
                return getResult("ok")
            return getResult("fail", res.ServiceError)
        except Exception as e:
            self.logger.error(u'Ошибка удаления уровня доступа %s : %s' % (self.acc_lvl_id, e.message), exc_info=True)
            return getResult("fail", u'Ошибка удаления уровня доступа %s : %s' % (self.acc_lvl_id, e.message))

    def OISUpdateAccessLevel(self):
        try:
            res = self.orionItgSrv.service.GetAccessLevelById(int(self.acc_lvl_id))
            if res.Success and res.OperationResult:
                accLvl = res.OperationResult
                #обновление уровня доступа
                if accLvl.Name != self.AccLvlName or accLvl.Description != self.acc_lvl_comment:
                    accLvl.Name = self.AccLvlName
                    accLvl.Description = self.acc_lvl_comment
                    res = self.orionItgSrv.service.EditAccessLevel(accLvl)
                    if not res.Success:
                        return getResult("fail", res.ServiceError)
                itemsInDB = accLvl.Items[:]
                #цикл для удаления отсутвующих полномочий
                for i in itemsInDB:
                    itemFound = False
                    for j in self.items_data:
                        if i.ItemId == j['ItemId'] and i.Id == j['Id'] and j['Id'] != 0:
                            itemFound = True
                            break
                    if not itemFound:
                        #удаляем из БД
                        res = self.__del_access_level_item_from_db(i)
                        if not res.Success:
                            return getResult("fail", u"Ошибка удаления полномочия %s : %s" %
                                             (i.ItemId, res.ServiceError))
                        itemsInDB.remove(i)
                #обновление и добавление полномочий
                #res = self.orionItgSrv.service.GetAccessLevelById(int(self.acc_lvl_id))
                #itemsInDB = accLvl.Items.copy()
                for j in self.items_data:
                    itemFound = False
                    for i in itemsInDB:
                        if j['ItemId'] == i.ItemId:
                            j['Id']=i.Id
                            itemFound = True
                            #Идентификатор мостовой связи
                            updateItem = self.get_access_level_item_from_list(j)
                            res = self.orionItgSrv.service.EditAccessLevelItem(updateItem)
                            if not res.Success:
                                return getResult("fail", u"Ошибка обновления полномочия %s : %s" %
                                                 (updateItem.ItemId, res.ServiceError))

                    if not itemFound:
                        addItem = self.get_access_level_item_from_list(j)
                        res = self.orionItgSrv.service.AddAccessLevelItem(accLvl, addItem)
                        if not res.Success:
                            return getResult("fail", u"Ошибка добавления полномочия %s : %s" %
                                             (addItem.ItemId, res.ServiceError))

                return self.OISImportAccessLevel()
            else:
                return getResult("fail", res.ServiceError)
        except Exception as e:
            self.logger.error(u'Ошибка обновления уровня доступа %s : %s' % (self.acc_lvl_id, e.message), exc_info=True)
            return getResult("fail", u'Ошибка обновления уровня доступа %s : %s' % (self.acc_lvl_id, e.message))

    def OISImportAccessLevel(self):
        dataAL = self.orionItgSrv.service.GetAccessLevelById(self.acc_lvl_id)
        if not dataAL.Success :
            return getResult('error', dataAL.ServiceError.InnerExceptionMessage)

        if not dataAL.OperationResult:
            return getResult('error', u'Уровень доступа не найден!')
        allAcclvl = dataAL.OperationResult
        res = structures.TAccessLevelToDict([allAcclvl])
        return self.append_name_item_to_dict(res)

    def append_name_item_to_dict(self, acl_dict):
        acLvlZones = self.orionItgSrv.service.GetAccessZones()
        if acLvlZones.Success != True:
            return getResult('error',acLvlZones.ServiceError.InnerExceptionMessage)

        acLvlPoints = self.orionItgSrv.service.GetEntryPoints()
        if acLvlPoints.Success != True:
            return getResult('error', acLvlPoints.ServiceError.InnerExceptionMessage)

        acLvlZones = structures.accItemsToDict(acLvlZones.OperationResult)
        acLvlPoints = structures.accItemsToDict(acLvlPoints.OperationResult)
        try:
            for k in acl_dict:
                items_ = k['items']
                for z in xrange(len(items_)):
                    current_item = items_[z]
                    if current_item['type'] == 'ACCESSPOINT':
                        if current_item['item_id'] == 0:
                            current_item['name'] = u'Все точки досутпа'
                        else:
                            current_item['name'] = acLvlPoints[str(current_item['item_id'])] if str(
                                current_item['item_id']) in acLvlPoints else 'undefined access point'
                    elif current_item['type'] == 'ACCESSZONE':
                        if current_item['item_id'] == 0:
                            current_item['name'] = u'Все зоны доступа'
                        else:
                            current_item['name'] = acLvlZones[str(current_item['item_id'])] if str(
                                current_item['item_id']) in acLvlZones else 'undefined access zone'
        except Exception as e:
            return getResult('error', u'Ошибка обработки информации уровня доступа %s'%e.message)

        return getResult('ok', acl_dict)
    
    methodMap = {
        'userRegisterAsync': userRegisterAsync,
        'updateUser': updateUser,
        'OISReadOrgList': OISReadOrgList,
        'OISReadDepList': OISReadDepList,
        'OISReadPostList': OISReadPostList,
        'OISUpdateKey': OISUpdateKey,
        'OISDeleteTimeWindow': OISDeleteTimeWindow,
        'OISCreateTimeWindow': OISCreateTimeWindow,
        'OISCreateKey': OISCreateKey,
        'OISDeleteAccessLevel': OISDeleteAccessLevel,
        'OISCreateAccessLevel': OISCreateAccessLevel,
        'OISDeletePerson': OISDeletePerson,
        'OISUpdateAccessLevel': OISUpdateAccessLevel,
        'OISGetEntryPoints': OISGetEntryPoints,
        'OISGetAccessZones': OISGetAccessZones,
        'OISImportAccessLevel': OISImportAccessLevel
    }

    def __init__(self, params):
        self.params = params
        self.logger = logging.getLogger('__main__.orionDrv.cmd')
        self.config = orionintgrsrvConfig()
        self.mapParams()
        self.logger.info(u' Запуск выполнения команды: %s' % params['cmd'] if 'cmd' in params else 'Unknown')
        try:
            url = urlparse.urljoin('file:', urllib.pathname2url(self.config.wsdlFile))
            imp = Import(url, url)
            for i in self.config.tns:
                imp.filter.add(i)
            # self.orionItgSrv = Client(url=self.config.urlDict['IOrionProCompat'], plugins=[ImportDoctor(imp)])
            self.orionItgSrv = OrionItgSrvService(self.config.wsdlFile, self.config.urlDict['IOrionProCompat'],
                                                  self.config.tns, self.config.user, self.config.password)
        except:
            self.logger.error("Driver: failed to create connection to integration server")
            return
        try:
            self.method = self.methodMap[params['cmd']]
        except KeyError as e:
            self.logger.error("Driver: have no command %s"%params['cmd'])

    def __call__(self):
        try:
            cmdrs = self.method(self)
            self.logger.info('Driver:______ cmd finished')
            return cmdrs
        except Exception as e:
            self.logger.error('Driver: command except ',exc_info= True)
            return {"status": "fail", 'res': repr(e)}
