# -*- coding: utf-8 -*-

import sys
import os
import logging
dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(dir_path)

logging.getLogger().info('===================')
logging.getLogger().info('working dir %s' % dir_path)
logging.getLogger().info('===================')
