# -*- coding: utf-8 -*-

__author__ = "ananev"
__date__ = "$29.09.2011 9:41:54$"

import json
import logging

import os
import socket
import string
import threading
import time
import errno
import sys

RecvTimeout = 1


class RpcServerClientNotExists(Exception):
    def __init__(self, serv):
        self.__serv = serv

    def __str__(self):
        return '%s error: client no connected' % self.__serv


class RpcServer(threading.Thread):


    def __init__(self, host, port=None):
        logger = logging.getLogger(__name__)
        if port:
            self.run = self.__run1
        else:
            self.run = self.__run2

        threading.Thread.__init__(self)

        self.__lock = threading.RLock()
        self.__flag = threading.Event()
        self.__flag.set()
        self.__lastPingTime = time.time()

        self.__host = host
        self.__port = port
        if port:

            self.__sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            while True:
                try:
                    self.__sock.bind((host, port))
                    break
                except Exception as e:
                    self.logger.info(u"Bind server RPC Socket failed, socket error: %s" % e.errno if hasattr(e, 'errno') else 'unknown')
                    time.sleep(3)
            self.__sock.listen(1)
            self.__sock.settimeout(RecvTimeout)
            self.__workSock = None
        else:
            self.__workSock = host
            self.__workSock.settimeout(RecvTimeout)

    def __str__(self):
        return ('RpcServer %s:%s' % (self.__host, self.__port)) \
            if self.__port else 'RpcServer'

    def __recvProcess(self, buff):

        rxData = ''
        socketIsDown = False
        try:
            rxData = self.__workSock.recv(1024)
            if len(rxData)==0:
                self.logger.debug("recive: None ")
                socketIsDown = True
        except socket.timeout:
            if self.isEvSenderWaitOk():
                self.updateWaitTime()
            return buff
        except socket.error as e:
            self.logger.debug('recive: no data available - %s' % str(e))
            socketIsDown = True
        except Exception as e:
            self.logger.debug('recive: Exception %s'%repr(e),exc_info = True)
            socketIsDown = True
            
        if socketIsDown:
            with self.__lock:
                self.__workSock.close()
                self.__workSock = None
            self.onDisconnect()
            return None
        buff = '%s%s' % (buff, rxData)
        while True:
            index = string.find(buff, '\r\n')
            if index == -1:
                break
            self.__requestProcess(buff[:index])
            buff = buff[index + 2:]

        return buff

    def __run2(self):
        buff = ''
        while self.__flag.isSet():
            buff = self.__recvProcess(buff)
            if not buff:
                break

    def __run1(self):
        buff = ''
        while self.__flag.isSet():
            try:
                if not self.__workSock:
                    try:
                        buff = ''
                        self.logger.info('Waiting for connection from sServer...')
                        workSock, addr = self.__sock.accept()
                        workSock.settimeout(RecvTimeout)
                        workSock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                        if sys.platform.startswith('win'):
                            # This will enable socket keep alive, with a 10 second keep alive time
                            # and a 3 second keep alive interval.
                            workSock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 10000, 3000))
                        else:
                            # TODO: set keep alive options for linux
                            pass
                        with self.__lock:
                            self.__workSock = workSock
                        self.onAccept(addr)
                    except socket.timeout:
                        pass
                    except Exception:
                        self.logger.exception('__run1 fail 1')
                else:
                    buff = self.__recvProcess(buff)
            except Exception as e:
                self.debugMsg = '__run1'
                self.logger.error('__run1 fail 2', exc_info=True)
        os._exit(0)

    def __requestProcess(self, msg):
        try:
            msg = json.loads(msg)
            req = str(msg['req'])
        except Exception as e:
            return

        self.__lastPingTime = time.time()
        if req == 'ping':
            self.__pingProcess()
        elif req == 'method':
            self.__methodProcess(msg)
        elif req == 'amethod':
            self.__amethodProcess(msg)
        else:
            self.__send({'rep': 'undefReq'})

    def __amethodProcess(self, msg):
        try:
            methodName = str(msg['reqData']['name'])
            methodParams = tuple(msg['reqData']['params'])
        except BaseException:
            self.logger.error(
                "asynch method '%s' error: badMethodRequest" %
                methodName, exc_info=True)
            return

        if methodName in dir(RpcServer) or not hasattr(self, methodName):
            self.logger.error(
                "asynch method '%s' error: undefMethod" %
                methodName, exc_info=True)
            return

        try:
            getattr(self, methodName)(*methodParams)
        except Exception:
            self.logger.error(
                "asynch method '%s' error:" %
                methodName, exc_info=True)

    def __methodProcess(self, msg):
        try:
            reqId = None
            methodName = str(msg['reqData']['name'])
            methodParams = tuple(msg['reqData']['params'])
            reqId = long(msg['reqId'])
        except BaseException:
            self.__send({
                'rep': 'method',
                'repId': reqId,
                'repData': {
                    'error': 'badMethodRequest'
                }
            })
            self.logger.error("badMethodRequest", exc_info=True)
            return
        if methodName in dir(RpcServer) or \
                not hasattr(self, methodName):
            self.__send({
                'rep': 'method',
                'repId': reqId,
                'repData': {
                    'name': methodName,
                    'status': 'error',
                    'error': 'undefMethod'
                }
            })
            return

        try:
            result = getattr(self, methodName)(*methodParams)
        except Exception as e:
            self.__send({
                'rep': 'method',
                'repId': reqId,
                'repData': {
                    'name': methodName,
                    'status': 'exception',
                    'error': str(e)
                }
            })
            self.logger.error("exception", exc_info=True)
        else:
            self.__send({
                'rep': 'method',
                'repId': reqId,
                'repData': {
                    'name': methodName,
                    'status': 'ok',
                    'result': result
                }
            })

    def __pingProcess(self):
        try:
            self.__send({'rep': 'pong'})
        except BaseException:
            self.logger.error("Error at ping", exc_info=True)

    def stop(self):
        self.__flag.clear()
        self.join(RecvTimeout * 4)

    def __send(self, data):
        return self.__sendData('%s\r\n' % json.dumps(data)) - 2

    def __sendData(self, data):
        with self.__lock:
            if self.__workSock:
                # sys.__stdout__.write(str(type(data)))
                try:
                    return self.__workSock.send(data)
                except Exception as e:
                    self.logger.debug('__sendData error', exc_info=True)
                    self.__workSock.close()
                    self.__workSock = None
            raise RpcServerClientNotExists(self)

    def send(self, data):
        buff = {
            'rep': 'event',
            'repData': {
                'data': data
            }
        }
        rs = self.__send(buff)
        if len(json.dumps(buff)) == rs:
            return True
        else:
            return False
