# -*- coding: utf-8 -*-

import time


class SpeedMeter(object):
    _inst = {}

    def __init__(self, name='SpeedMeter', period=3):
        if name in self._inst:
            raise Exception('SpeedMeter %s already exists' % name)
        self._inst[name] = self
        self._name = name
        self._period = period
        self._cnt = 0
        self._last = time.time()
        self._avgSum = 0.0
        self._avgCnt = 1
        self.stateSpeed = '%s: processed %.2f op/sec, (avg %.2f op/sec)' % (self._name, 0, 0)

    @classmethod
    def get(cls, name):
        return cls._inst[name]

    def update(self):
        self._cnt += 1
        t = time.time()
        if t - self._last > self._period:
            speed = (float(self._cnt) / (t - self._last))
            self._avgSum += speed
            self._avgCnt += 1
            self.stateSpeed = '%s: processed %.2f op/sec, (avg %.2f op/sec)' %\
                              (self._name, speed, self._avgSum / self._avgCnt)
            self._cnt = 0
            self._last = t
        return self.stateSpeed
    
    def getStateSpeed(self):
        t = time.time()
        if (t - self._last) > 0.0:
            try:
                speed = (float(self._cnt) / (t - self._last))
            except:
                speed = 0.0
            if t - self._last > self._period:
                self.stateSpeed = '%s: processed %.2f op/sec, (avg %.2f op/sec)' %\
                                  (self._name, speed, self._avgSum / self._avgCnt)
        return self.stateSpeed
