# -*- coding: utf-8 -*-
import logging, logging.config

import collections
import json
import os
import sys
import threading
import time
from ctypes import *
if sys.platform.startswith('win'):
    import win32api

import my_rpc.rpc_server as rpc_server
from settings import setting

from speedmeter import SpeedMeter

# enable dumps
# TODO need change to faulthandler in python 3.x?
import cgitb
DUMPS_PATH = './dumps'
if not os.path.exists(DUMPS_PATH):
    os.mkdir(DUMPS_PATH)
cgitb.enable(display=False, logdir=DUMPS_PATH)


class PortsException(Exception): pass


class EventSender(threading.Thread):
    logger = logging.getLogger(__name__)
    __READY = 0
    __WAITING = 1
    __RESEND_TIMEOUT = 5

    def __init__(self, srv):
        threading.Thread.__init__(self)
        try:
            self.query_dll = cdll.LoadLibrary('pqueue.dll')
            self.q_type = True
            if (self.query_dll.init(c_int(int(setting['net']['port'])), None)) == 0:
                self.logger.error("PQueue loading error!  Use RAM query'")
                self.q_type = False
                self.__queue = collections.deque()
            else:
                self.logger.info("PQueue loaded!")
        except:
            self.logger.error("PQueue loading error! Use RAM query'", exc_info=True)
            self.q_type = False
            self.__queue = collections.deque()
        self.__queueStates = collections.deque()
        self.__flag = False
        self.__state = self.__READY
        self.__lastEvt = None
        self.__waitLastTime = time.time()
        self.__srv = srv
        self.__outgoingSpeedMeter = SpeedMeter('out')
        self.__incomingEvetsSpeedMeter = SpeedMeter('iEv')
        self.__incomingStatesSpeedMeter = SpeedMeter('iSt')
        self.__lockWaitUpdate = threading.RLock()
        self.__outgoingSpeedMsg = ''
        self.__incomingEventsSpeedMsg = ''
        self.__incomingStatesSpeedMsg = ''

    def stop(self):
        self.__flag = False
        if self.q_type:
            self.query_dll.close(c_int(int(setting['net']['port'])))
        self.join(7)

    def run(self):
        self.__flag = True
        while True:
            outgoingSpeed=self.__outgoingSpeedMeter.getStateSpeed()
            if outgoingSpeed != self.__outgoingSpeedMsg:
                self.__outgoingSpeedMsg = outgoingSpeed
                self.__srv.updateStatusBarSpeed(self.__outgoingSpeedMsg)
            incomingSpeed = self.__incomingEvetsSpeedMeter.getStateSpeed()
            if incomingSpeed != self.__incomingEventsSpeedMsg:
                self.__incomingEventsSpeedMsg = incomingSpeed
            incomingSpeed = self.__incomingStatesSpeedMeter.getStateSpeed()
            if incomingSpeed != self.__incomingStatesSpeedMsg:
                self.__incomingStatesSpeedMsg = incomingSpeed
            if self.__state == self.__READY:
                try:
                    evt = None
                    # приоритет выгрузке состояний
                    if len(self.__queueStates) > 0:
                        evt = self.__queueStates.popleft()                    
                    else:
                        if self.q_type:
                            slen = c_long()
                            if self.__lastEvt:
                                evt = self.__lastEvt
                            else:
                                data = self.query_dll.pop(c_int(int(setting['net']['port'])), byref(slen))
                                if slen.value == 0:
                                    if self.__flag:
                                        time.sleep(0.01)
                                        continue
                                    else:
                                        break
                                evt = string_at(data, slen.value)
                            # self.query_dll.erase()
                        else:
                            evt = self.__queue.popleft()
                    self.__lastEvt = evt
                    try:
                        evt = json.loads(evt)
                    except:
                        self.__lastEvt = None
                        self.logger.exception("Cant parse json: %s" % evt)
                except IndexError:
                    if self.__flag:
                        time.sleep(0.01)
                    else:
                        break
                else:
                    try:
                        self.logger.debug("Send notif %s" % evt)
                        while True:
                            self.__state = self.__WAITING
                            self.updateWaitTime()
                            if self.__srv.send(evt):
                                break
                            else:
                                time.sleep(0.1)
                    except rpc_server.RpcServerClientNotExists:
                        pass
                    except:
                        self.logger.exception('Event send error!')
                        time.sleep(self.__RESEND_TIMEOUT)

            if self.isWaitingOk():
                if self.__flag:
                    time.sleep(0.001)
                    if self.getWaitTime() > self.__RESEND_TIMEOUT:
                        self.reSend()
                else:
                    break
    
    def updateWaitTime(self):
        with self.__lockWaitUpdate:
            self.__waitLastTime = time.time()
        
    def getWaitTime(self):
        res = time.time() - self.__waitLastTime
        return res
        
    def isWaitingOk(self):
        return self.__state == self.__WAITING
        
    def reSend(self):
        # if self.__lastEvt:
        #     # logging.info(repr(self.__lastEvt))
        #     # self.__queue.appendleft(self.__lastEvt)
        #     if self.q_type:
        #         self.query_dll.push(c_char_p(self.__lastEvt), len(self.__lastEvt))
        #     else:
        #         self.__queue.appendleft(self.__lastEvt)
        self.setReady()

    def setReady(self):
        self.__state = self.__READY

    def push(self, func):
        if self.q_type:
            self.query_dll.push(c_int(int(setting['net']['port'])), c_char_p(func), len(func))
        else:
            self.__queue.append(func)
        self.__incomingEvetsSpeedMeter.update()
            
    def pushState(self, state):
        self.__queueStates.append(state)
        self.__incomingStatesSpeedMeter.update()
            
    def sendEventOk(self):
        if self.q_type:
            self.query_dll.erase(c_int(int(setting['net']['port'])))
        self.__lastEvt = None
        self.setReady()
        self.__outgoingSpeedMeter.update()
    

class Ports2(rpc_server.RpcServer):
    logger = logging.getLogger(__name__)

    def __init__(self, host, port):
        rpc_server.RpcServer.__init__(self, host, port)
        self.__driver = None

        self.__statusBar = {
            'baseString': self.__class__.__name__,
            'driver': '',
            'parameters': [{
                'name': "",
                'state': False,
                'displayedStatus_0': u"не работает",
                'displayedStatus_1': u"работает"
            }]
        }

        sys.path.append('.')
        self.__es = EventSender(self)
        self.__es.start()

        self.bundle_dir = ''
        if getattr(sys, 'frozen', False):
            # we are running in a bundle
            self.bundle_dir = sys._MEIPASS + '\\'
            self.logger.info('we are running in a bundle %s' % self.bundle_dir)
        else:
            # we are running in a normal Python environment
            self.bundle_dir = os.getcwd()
            self.logger.info('we are running in a normal Python environment - %s' % self.bundle_dir)
        # загружаем структуру протокола
        self.loadProtocolStruct()

    def loadProtocolStruct(self):
        self.logger.info("Load protocol struct")
        common_section = setting['common']
        if not common_section:
            raise PortsException("No 'common' section in configuration")
        common_device = common_section['device']
        if not common_device:
            raise PortsException("No 'device' section in configuration/common")
        sys.path.append(os.path.join(self.bundle_dir, common_device))
        os.chdir(os.path.join(self.bundle_dir, common_device))

        self.__statusBar['driver'] = common_device

    def updateStatusBar(self, name="", state=False, displayedStatus_0="", displayedStatus_1=""):
        if name:
            for param in self.__statusBar['parameters']:
                if name == param['name']:
                    param['state'] = state
                    param['displayedStatus_0'] = displayedStatus_0 if displayedStatus_0 else param['displayedStatus_0']
                    param['displayedStatus_1'] = displayedStatus_1 if displayedStatus_1 else param['displayedStatus_1']
                    break
            else:
                self.__statusBar['parameters'].append({
                    'name': name,
                    'state': state,
                    'displayedStatus_0': displayedStatus_0 if displayedStatus_0 else u"не работает",
                    'displayedStatus_1': displayedStatus_1 if displayedStatus_1 else u"работает"
                })
        paramString = ""
        for param in self.__statusBar['parameters']:
            if param['name']:
                paramString += " | " + param['name'] + " - " + (
                    param['displayedStatus_1'] if param['state'] else param['displayedStatus_0'])
        if 'name_cmd' in setting['common']:
            temp = u'{0}  {1}  {2} - {3}'.format(self.__statusBar['baseString'], self.__statusBar['driver'],
                                                      paramString, setting['common']['name_cmd'])
        else:
            temp = u'{0}  {1} {2}'.format(self.__statusBar['baseString'], self.__statusBar['driver'], paramString)
        if sys.platform.startswith('win'):
            win32api.SetConsoleTitle(temp.encode('cp866'))

    def updateStatusBarSpeed(self, srtSpeed=""):
        if 'name_cmd' in setting['common']:
            temp = u'{0}  {1}  {2} - {3}'.format(self.__statusBar['baseString'], self.__statusBar['driver'],
                                                      srtSpeed, setting['common']['name_cmd'])
        else:
            temp = u'{0}  {1}  {2}'.format(self.__statusBar['baseString'], self.__statusBar['driver'], srtSpeed)
        if sys.platform.startswith('win'):
            win32api.SetConsoleTitle(temp.encode('cp866'))

    def stop(self):
        self.logger.info("Stopping service 'Ports'...")
        self.__es.stop()
        rpc_server.RpcServer.stop(self)
        self.logger.info("Service 'Ports' has successfully stopped.")

    def __eventHandler(self, evt):
        "Обработчик событий от устройства"
        if isinstance(evt, dict):
            evt = json.dumps(evt)
        #self.logger.debug('Handle event: %s'%evt)
        self.__es.push(evt)

    def __stateHandler(self, evt):
        "Обработчик состояний объектов устройства"
        if isinstance(evt, dict):
            evt = json.dumps(evt)
        self.logger.debug("Handle state: %s" % evt)
        self.__es.pushState(evt)

    def connect(self):
        self.logger.info("Method 'connect'")
        try:
            self.loadDriver()
            self.__driver.connect()
            self.__es.setReady()
        except PortsException:
            self.logger.exception("Error on load driver instance! ")
        except Exception:
            self.logger.exception("Connection method error!")

    def loadDriver(self):
        common_section = setting['common']
        if not common_section:
            raise PortsException("No section with name 'common' found in driver settings")
        device_name = common_section['device']
        if not device_name:
            raise PortsException("No parameter with name 'device' found in driver settings")
        device_name = device_name.lower()

        if self.__driver:
            return

        if device_name == "pce":
            from pce.driver_pce import DriverPCE
            self.__driver = DriverPCE(self.__eventHandler, self.__stateHandler)
        elif device_name == "intellect":
            from intellect.driver_intellect import DriverIntellect
            self.__driver = DriverIntellect(self.__eventHandler, self.__stateHandler)
        elif device_name == "jupiter":
            from jupiter.DriverJupiter import DriverJupiter
            self.__driver = DriverJupiter(self.__eventHandler, self.__stateHandler)
        elif device_name == "securos":
            from securos.driver_intellect import DriverIntellect
            self.__driver = DriverIntellect(self.__eventHandler, self.__stateHandler)
        elif device_name == "housekeeper":
            from housekeeper.driver_housekeeper import DriverHousekeeper
            self.__driver = DriverHousekeeper(self.__eventHandler, self.__stateHandler)
        elif device_name == "remote_site":
            from remote_site.driver_remote_site import DriverRemoteSite
            self.__driver = DriverRemoteSite(self.__eventHandler, self.__stateHandler)
        elif device_name == "orioniso":
            from orioniso.driver import DriverOrioniso
            self.__driver = DriverOrioniso(self.__eventHandler, self.__stateHandler,self.logger, self.updateStatusBar)
        elif device_name == "mobotix":
            from mobotix.DriverMobotix import DriverMobotix
            self.__driver = DriverMobotix(self.__eventHandler, self.__stateHandler)
        elif device_name == "centum":
            from centum.DriverCentum import DriverCentum
            self.__driver = DriverCentum(self.__eventHandler, self.__stateHandler)
        elif device_name == "apollo":
            from apollo.DriverApollo import DriverApollo
            self.__driver = DriverApollo(self.__eventHandler, self.__stateHandler)
        elif device_name == "rubej08":
            from rubej08.interface import Rubej08Interface
            self.__driver = Rubej08Interface(self.__eventHandler, self.__stateHandler)
        elif device_name == "axxon":
            from axxon.DriverAxxon import DriverAxxon
            self.__driver = DriverAxxon(self.__eventHandler, self.__stateHandler)
        elif device_name == "bosch":
            from bosch.driver_bosch import DriverBOSCH
            self.__driver = DriverBOSCH(self.__eventHandler, self.__stateHandler)
        elif device_name == "gsm":
            from gsm.driver_gsm import DriverGSM
            self.__driver = DriverGSM(self.__eventHandler, self.__stateHandler)
        elif device_name == "zabbix":
            from zabbix.zabbixdriver import ZabbixDriver
            self.__driver = ZabbixDriver.createInstance(self.__eventHandler, self.__stateHandler)
        elif device_name == 'hikvision':
            from hikvision.DriverOnvif import DriverOnvif
            self.__driver = DriverOnvif(self.__eventHandler, self.__stateHandler)
        elif device_name == "onvif":
            from onvif.DriverOnvif import DriverOnvif
            self.__driver = DriverOnvif(self.__eventHandler, self.__stateHandler)
        elif device_name == "fortmonitor_driver":
            from fortmonitor_driver.driver import FortMonitorDriver
            self.__driver = FortMonitorDriver(self.__eventHandler, self.__stateHandler)
        elif device_name == "omnicomm":
            from omnicomm.OmnicommDriver import OmnicommDriver
            self.__driver = OmnicommDriver(self.__eventHandler, self.__stateHandler)
        elif device_name == "nts":
            from nts.driver_nts import DriverNts
            self.__driver = DriverNts(self.__eventHandler, self.__stateHandler)
        elif device_name == "biostar":
            from biostar.driver_biostar import DriverBiostar
            self.__driver = DriverBiostar(self.__eventHandler, self.__stateHandler)
        elif device_name == "milestone":
            from milestone.DriverMilestone import DriverMilestone
            self.__driver = DriverMilestone(self.__eventHandler, self.__stateHandler)
        elif device_name == "trassir":
            from trassir.DriverTrassir import DriverTrassir
            self.__driver = DriverTrassir(self.__eventHandler, self.__stateHandler)
        elif device_name == "tss":
            from tss.DriverTSS import DriverTSS
            self.__driver = DriverTSS(self.__eventHandler, self.__stateHandler)
        elif device_name == "orionintgrsrv":
            from orionintgrsrv.driver import DriverOrion
            self.__driver = DriverOrion(self.__eventHandler, self.__stateHandler)
        elif device_name == "vizir":
            from vizir.DriverVizir import DriverVizir
            self.__driver = DriverVizir(self.__eventHandler, self.__stateHandler)
        elif device_name == "rtls":
            from rtls.driver_RTLS import driver_RTLS
            self.__driver = driver_RTLS(self.__eventHandler, self.__stateHandler)
        elif device_name == "orionro":
            from orionro.DriverOrionRO import DriverOrionRO
            self.__driver = DriverOrionRO(self.__eventHandler, self.__stateHandler)
        elif device_name == "plavnik":
            from plavnik.DriverPlavnik import DriverPlavnik
            self.__driver = DriverPlavnik(self.__eventHandler, self.__stateHandler)
        elif device_name == "winmag":
            from winmag.DriverEsser import DriverEsser
            self.__driver = DriverEsser(self.__eventHandler, self.__stateHandler)
        elif device_name == "boschbis":
            from boschbis.DriverBoschBis import DriverBoschBis
            self.__driver = DriverBoschBis(self.__eventHandler, self.__stateHandler)
        elif device_name == "volnaalpha":
            from volnaalpha.driver import DriverVA
            self.__driver = DriverVA(self.__eventHandler, self.__stateHandler)
        elif device_name == "goalcity":
            from goalcity.DriverGoalcity import DriverGoalcity
            self.__driver = DriverGoalcity(self.__eventHandler, self.__stateHandler)
        elif device_name == "dsc":
            from dsc.driver import DriverDsc
            self.__driver = DriverDsc(self.__eventHandler, self.__stateHandler)
        else:
            raise PortsException("Unknown driver name: '%s'" % device_name)

    def disconnect(self):
        self.logger.info("Client disconnect")
        if self.__driver:
            self.__driver.disconnect()

    def sendCommand(self, cmd):
        self.logger.info("sendCommand: %.500s...\n" % cmd)
        if self.__driver:
            result = self.__driver.sendCommand(cmd)
            self.logger.info("command result: {0}\n".format(result))
            return result

    def sendOk(self):
        # Не включать это принт в продакшене иначе одиин портс не будет давать больше 300 событий
        self.logger.debug("sendOk")
        self.__es.sendEventOk()
        
    def isEvSenderWaitOk(self):
        return self.__es.isWaitingOk()

    def updateWaitTime(self):
        self.__es.updateWaitTime()

    def onAccept(self, addr):
        self.logger.info("onAccept: %s:%d" % addr)
        if self.__driver and hasattr(self.__driver, 'onConnect'):
            self.__driver.onConnect()

    def onDisconnect(self):
        self.logger.info("onDisconnect")
        if self.__driver and hasattr(self.__driver, 'onDisconnect'):
            self.__driver.onDisconnect()


def main():
    # logging.config.fileConfig('ports.log.config', disable_existing_loggers=False)
    # для собранных модуле идентификатор БД постоянный
    Redis_db = 20
    if 'Redis_db' in setting['logs']:
        Redis_db += setting['logs']['Redis_db']
    logLevel = 'INFO'
    if 'LogLevel' in setting['logs']:
        logLevel = setting['logs']['LogLevel']
    config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'driver_Fmt': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            },
            'driver_Console': {
                'format': '%(asctime)s %(message)s',
            }
        },
        'handlers': {
            'ConsoleHandler': {
                'level': logLevel,
                'class': 'logging.StreamHandler',
                'formatter': 'driver_Console',
            },
            'RedisHandler': {
                'level': logLevel,
                'class': 'rlog.RedisListHandler',
                'key': '%s:%s' % (setting['common']['device'], setting['net']['port']),
                'host': setting['logs']['Redis_host'],
                'password': setting['logs']['Redis_password'],
                'port': setting['logs']['Redis_port'],
                'db': Redis_db,
                'max_messages': setting['logs']['Redis_messages_per_logger']
            },
            'FileHandler': {
                'level': logLevel,
                'class': 'logging.handlers.TimedRotatingFileHandler',
                'formatter': 'driver_Fmt',
                'filename': 'logs/ports.log',
                'when': 'midnight',
                'backupCount': 10,
                'encoding': 'utf8'
            },
        },
        'root': {
            'handlers': ['ConsoleHandler', 'FileHandler', 'RedisHandler'],
            'level': 'DEBUG',
        }
    }
    logging.config.dictConfig(config)
    logging.info('Start ports')
    try:
        net_section = setting['net']
        if not net_section:
            raise PortsException("No section 'net' in configuration")
        ports = Ports2(net_section['ip'], net_section['port'])
        ports.updateStatusBar()
        logging.info('Start ports')
        ports.start()
        import time
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logging.info("Interrupted by user break")
        ports.stop()
    except PortsException:
        logging.error("Error on configuration 'Ports' service: ", exc_info=True)
    except Exception:
        logging.error("Error on start 'Ports' service: ", exc_info=True)


if __name__ == "__main__":
    main()
